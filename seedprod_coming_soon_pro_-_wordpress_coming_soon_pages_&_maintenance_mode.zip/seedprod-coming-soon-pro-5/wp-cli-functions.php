<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {

	

	/**
	 * Import a theme from a URL using WP-CLI.
	 *
	 * ## OPTIONS
	 *
	 * <theme-url>
	 * : The URL of the theme to import.
	 *
	 * ## EXAMPLES
	 *
	 *     wp seedprod_import_theme_from_url http://example.com/theme.zip
	 *
	 * @param array $args       Command arguments.
	 * @param array $assoc_args Command associative arguments.
	 */
	function seedprod_pro_import_theme_from_url( $args, $assoc_args ) {
		list( $theme_url ) = $args;

		$nonce = wp_create_nonce( 'seedprod_import_theme_by_url' );
		try {

			$response = wp_remote_head( $theme_url );

			if ( is_wp_error( $response ) ) {
				WP_CLI::error( 'An error occurred while checking the URL: ' . $response->get_error_message() );
			}

			$response_code = wp_remote_retrieve_response_code( $response );

			if ( 200 !== $response_code ) {
				WP_CLI::error( 'The ZIP file does not exist at the provided URL.' );
			}

			$result = seedprod_pro_import_theme_by_url_cli( $theme_url, $nonce );

			if ( true === $result || ( is_array( $result ) && ! empty( $result['success'] ) ) ) {
				if ( is_array( $result ) && ! empty( $result['warnings'] ) ) {
					foreach ( $result['warnings'] as $w ) {
						WP_CLI::warning( sprintf( 'image not imported (%s): %s', $w['reason'], $w['url'] ) );
					}
				}
				WP_CLI::success( 'Theme imported successfully.' );
			} else {
				WP_CLI::error( is_array( $result ) && isset( $result['error'] ) ? $result['error'] : $result );
			}
		} catch ( Exception $e ) {
			WP_CLI::error( 'An error occurred: ' . $e->getMessage() );
		}
	}
	WP_CLI::add_command( 'seedprod_import_theme_from_url', 'seedprod_pro_import_theme_from_url' );

	

	/**
	 * Import a landing page from a URL using WP-CLI.
	 *
	 * ## OPTIONS
	 *
	 * <landing-page-url>
	 * : The URL of the landing page to import.
	 *
	 * ## EXAMPLES
	 *
	 *     wp seedprod_import_landing_page_from_url http://example.com/landing-page.zip
	 *
	 * @param array $args       Command arguments.
	 * @param array $assoc_args Command associative arguments.
	 */
	function seedprod_pro_import_landing_page_from_url( $args, $assoc_args ) {
		list( $theme_url ) = $args;

		$nonce = wp_create_nonce( 'seedprod_pro_import_landing_pages' );
		try {

			$response = wp_remote_head( $theme_url );

			if ( is_wp_error( $response ) ) {
				WP_CLI::error( 'An error occurred while checking the URL: ' . $response->get_error_message() );
			}

			$response_code = wp_remote_retrieve_response_code( $response );

			if ( 200 !== $response_code ) {
				WP_CLI::error( 'The ZIP file does not exist at the provided URL.' );
			}

			$result = seedprod_pro_import_landing_page_cli( $theme_url, $nonce );

			if ( is_wp_error( $result ) ) {
				WP_CLI::error( 'Failed to import landing pages: ' . $result->get_error_message() );
			}

			if ( is_array( $result ) && isset( $result['error'] ) ) {
				WP_CLI::error( 'Failed to import landing pages: ' . $result['error'] );
			}

			if ( is_array( $result ) && ! empty( $result['warnings'] ) ) {
				foreach ( $result['warnings'] as $w ) {
					WP_CLI::warning( sprintf( 'image not imported (%s): %s', $w['reason'], $w['url'] ) );
				}
			}

			$imported_pages = array();
			if ( is_array( $result ) && isset( $result['imported_pages'] ) ) {
				$imported_pages = $result['imported_pages'];
			} elseif ( is_array( $result ) && ! isset( $result['success'] ) ) {
				// Backwards-compat: helper used to return the raw imported_pages list.
				$imported_pages = $result;
			}

			// Output imported page IDs and titles. The V2 importer returns bare IDs;
			// the older one returned an array per page.
			foreach ( $imported_pages as $page ) {
				$page_id = is_array( $page ) && isset( $page['id'] ) ? $page['id'] : $page;
				WP_CLI::success( 'Imported Page ID: ' . $page_id );
			}

			//WP_CLI::success( 'Landing pages imported successfully.' );

		} catch ( Exception $e ) {
			WP_CLI::error( 'An error occurred: ' . $e->getMessage() );
		}
	}
	WP_CLI::add_command( 'seedprod_import_landing_page_from_url', 'seedprod_pro_import_landing_page_from_url' );

	/**
	 * Export a landing page using WP-CLI.
	 *
	 * @param string $theme_url The URL of the theme to import.
	 * @param string $nonce     The nonce value for security verification.
	 * @return mixed|array|string|array[] Depending on the outcome, may return various data or an error message.
	 */
	function seedprod_pro_import_landing_page_cli( $theme_url, $nonce ) {

		if ( ! wp_verify_nonce( $nonce, 'seedprod_pro_import_landing_pages' ) ) {
			return 'Invalid request. Please provide a valid nonce.';
		}

		$is_ajax_request = false;
		if ( null === $theme_url ) {
			$is_ajax_request = check_ajax_referer( 'seedprod_pro_import_landing_pages' );
		}

		if ( $is_ajax_request || ! empty( $theme_url ) ) {

			// The V2 importer and its helpers live in the admin layer, which does
			// not load under WP-CLI because is_admin() is false there.
			if ( ! function_exists( 'seedprod_pro_v2_extract_zip' ) ) {
				require_once SEEDPROD_PRO_PLUGIN_PATH . 'admin/includes/import-export-functions.php';
			}

			$url   = wp_nonce_url( 'admin.php?page=seedprod_pro_import_landing_pages', 'seedprod_import_landing_pages' );
			$creds = request_filesystem_credentials( $url, '', false, false, null );
			if ( false === $creds ) {
				return array( 'error' => 'Failed to obtain filesystem credentials.' );
			}

			if ( ! WP_Filesystem( $creds ) ) {
				request_filesystem_credentials( $url, '', true, false, null );
				return array( 'error' => 'Failed to initialize filesystem.' );
			}

			$source = ! empty( $theme_url ) ? $theme_url : '';

			$file_import_url_json = wp_remote_get( $source, array( 'sslverify' => false ) );
			if ( is_wp_error( $file_import_url_json ) ) {
				$error_code    = wp_remote_retrieve_response_code( $file_import_url_json );
				$error_message = wp_remote_retrieve_response_message( $file_import_url_json );
				return array( 'error' => $error_message );
			}

			$response_code = (int) wp_remote_retrieve_response_code( $file_import_url_json );
			if ( 200 !== $response_code ) {
				return array( 'error' => sprintf( 'The import URL returned HTTP %d.', $response_code ) );
			}

			if ( '' !== $source && $file_import_url_json['body'] ) {
				$url_data = pathinfo( $source );

				$filename = $url_data['basename'];

				if ( false !== strpos( $filename, '.zip' ) ) {
					$filename = substr( $filename, 0, strpos( $filename, '.zip' ) + 4 );
				}

				if ( ! preg_match( '/\.zip$/i', $filename ) ) {
					return array( 'error' => 'The file you are trying to upload is not a .zip file.' );
				}

				$filename_import = 'seedprod-themes-imports';

				global $wp_filesystem;
				$upload_dir   = wp_upload_dir();
				$path         = trailingslashit( $upload_dir['basedir'] );
				$path_baseurl = trailingslashit( $upload_dir['baseurl'] );

				$filenoext = basename( $filename_import, '.zip' ); // absolute path to the directory where zipper.php is in (lowercase).
				$filenoext = basename( $filenoext, '.ZIP' ); // absolute path to the directory where zipper.php is in (when uppercase).

				$targetdir  = $path . $filenoext; // target directory.
				$targetzip  = $path . $filename; // target zip file.
				$target_url = $path_baseurl . $filenoext;

				if ( is_dir( $targetdir ) ) {
					seedprod_pro_v2_recursive_rmdir( $targetdir );
				}
				wp_mkdir_p( $targetdir );

				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- WP_Filesystem may not be initialized in CLI context.
				if ( file_put_contents( $targetzip, $file_import_url_json['body'] ) ) {
					$extract_result = seedprod_pro_v2_extract_zip( $targetzip, $targetdir, false );
					wp_delete_file( $targetzip );
					if ( is_wp_error( $extract_result ) ) {
						return array( 'error' => $extract_result->get_error_message() );
					}

					$theme_json_data     = $targetdir . '/export_page.json';
					$theme_json_data_url = $target_url . '/export_page.json';

					if ( ! file_exists( $theme_json_data ) ) {
						return array( 'error' => 'The ZIP did not contain export_page.json.' );
					}

					$data = seedprod_pro_v2_read_json_file( $theme_json_data, $theme_json_data_url );
					if ( is_wp_error( $data ) ) {
						return array( 'error' => $data->get_error_message() );
					}

					if ( ! empty( $data->type ) && 'landing-page' !== $data->type ) {
						return array( 'error' => 'This does not appear to be a SeedProd landing page.' );
					}

					$import_result = seedprod_pro_v2_landing_import_json( $data );
					// remove the json file for security.
					wp_delete_file( $theme_json_data );

					return $import_result;
				} else {
					return array( 'error' => 'There was a problem with the upload. Please try again.' );
				}
			} else {
				return array( 'error' => 'There was a problem with the upload. Please try again.' );
			}
		}
	}

	

	/**
	 * Activate a license using WP-CLI.
	 *
	 * ## OPTIONS
	 *
	 * <license-key>
	 * : The license key to activate.
	 *
	 * ## EXAMPLES
	 *
	 *     wp seedprod_activate_license ABCDEFG1234567
	 *
	 * @param array $args Command arguments.
	 */
	function seedprod_pro_activate_license( $args ) {
		list( $license_key ) = $args;

		// Generate a nonce.
		$nonce = wp_create_nonce( 'seedprod_nonce' );

		try {
			// Call the function to activate the license with nonce.
			$result = seedprod_pro_save_api_key_cli( $license_key, $nonce );

			if ( 'true' === $result['status'] ) {
				WP_CLI::success( 'License activated successfully.' );
			} else {
				WP_CLI::error( 'Failed to activate license: ' . $result['msg'] );
			}
		} catch ( Exception $e ) {
			WP_CLI::error( 'An error occurred: ' . $e->getMessage() );
		}
	}
	WP_CLI::add_command( 'seedprod_activate_license', 'seedprod_pro_activate_license' );

	/**
	 * Save API Key
	 *
	 * @param string $api_key API key for activation.
	 * @param string $nonce   The nonce for verification.
	 * @return array Return result array.
	 */
	function seedprod_pro_save_api_key_cli( $api_key = null, $nonce = null ) {
		// Verify the nonce.
		if ( ! wp_verify_nonce( $nonce, 'seedprod_nonce' ) ) {
			return array(
				'status' => 'false',
				'msg'    => 'Invalid nonce. Please try again.',
			);
		}

		if ( empty( $api_key ) ) {
			$api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) : null;
		}

		if ( defined( 'SEEDPROD_LOCAL_JS' ) ) {
			$slug = 'seedprod-coming-soon-pro-5/seedprod-coming-soon-pro-5.php';
		} else {
			$slug = SEEDPROD_PRO_SLUG;
		}

		// Get token and generate one if one does not exist.
		$token = get_option( 'seedprod_token' );
		if ( empty( $token ) ) {
			$token = strtolower( wp_generate_password( 32, false, false ) );
			update_option( 'seedprod_token', $token );
		}

		// Validate the API key.
		$data = array(
			'action'            => 'info',
			'license_key'       => $api_key,
			'token'             => $token,
			'wp_version'        => get_bloginfo( 'version' ),
			'domain'            => home_url(),
			'installed_version' => SEEDPROD_PRO_VERSION,
			'slug'              => $slug,
		);

		if ( empty( $data['license_key'] ) ) {
			return array(
				'status' => 'false',
				'msg'    => __( 'License Key is required.', 'seedprod-pro' ),
			);
		}

		$headers = array(
			'Accept' => 'application/json',
		);

		$url      = SEEDPROD_PRO_API_URL . 'update';
		$response = wp_remote_post(
			$url,
			array(
				'body'    => $data,
				'headers' => $headers,
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'status' => 'false',
				'msg'    => $response->get_error_message(),
			);
		}

		$status_code = wp_remote_retrieve_response_code( $response );

		if ( 200 !== $status_code ) {
			return array(
				'status' => 'false',
				'msg'    => wp_remote_retrieve_response_message( $response ),
			);
		}

		$body = wp_remote_retrieve_body( $response );

		if ( ! empty( $body ) ) {
			$body = json_decode( $body );
		}

		if ( ! empty( $body->valid ) && true === $body->valid ) {
			// Store API key.
			update_option( 'seedprod_user_id', $body->user_id );
			update_option( 'seedprod_api_token', $body->api_token );
			update_option( 'seedprod_api_key', $data['license_key'] );
			update_option( 'seedprod_api_message', $body->message );
			update_option( 'seedprod_license_name', $body->license_name );
			update_option( 'seedprod_a', true );
			update_option( 'seedprod_per', $body->per );

			return array(
				'status'       => 'true',
				// Translators: %s is the license name.
				'license_name' => sprintf( __( 'You currently have the <strong>%s</strong> license.', 'seedprod-pro' ), $body->license_name ),
				'msg'          => $body->message,
				'body'         => $body,
			);
		} else {
			$api_msg = __( 'Invalid License Key.', 'seedprod-pro' );
			if ( 'Unauthenticated.' !== $body->message ) {
				$api_msg = $body->message;
			}
			update_option( 'seedprod_license_name', '' );
			update_option( 'seedprod_api_token', '' );
			update_option( 'seedprod_api_key', '' );
			update_option( 'seedprod_api_message', $api_msg );
			update_option( 'seedprod_a', false );
			update_option( 'seedprod_per', '' );

			return array(
				'status' => 'false',
				'msg'    => $api_msg,
				'body'   => $body,
			);
		}
	}


	/**
	 * Enable or disable a theme using WP-CLI.
	 *
	 * ## OPTIONS
	 *
	 * <true|false>
	 * : Whether to enable or disable the theme.
	 *
	 * ## EXAMPLES
	 *
	 *     wp seedprod_enable_theme true
	 *
	 * @param array $args Command arguments.
	 */
	function seedprod_pro_enable_theme( $args ) {
		list( $enable ) = $args;

		$enable = filter_var( $enable, FILTER_VALIDATE_BOOLEAN );

		// Generate a nonce.
		$nonce = wp_create_nonce( 'seedprod_pro_update_seedprod_theme_enabled' );

		try {
			// Call the function to enable/disable the theme with nonce.
			$result = seedprod_pro_update_seedprod_theme_enabled_cli( $enable, $nonce );

			if ( true === $result || 'disabled' === $result ) {
				WP_CLI::success( 'Theme ' . ( $enable ? 'enabled' : 'disabled' ) . ' successfully.' );
			} else {
				WP_CLI::error( 'Failed to ' . ( $enable ? 'enable' : 'disable' ) . ' theme.' );
			}
		} catch ( Exception $e ) {
			WP_CLI::error( 'An error occurred: ' . $e->getMessage() );
		}
	}
	WP_CLI::add_command( 'seedprod_enable_theme', 'seedprod_pro_enable_theme' );

	/**
	 * Enable or disable the theme.
	 *
	 * @param boolean $enable Whether to enable or disable the theme.
	 * @param string  $nonce  The nonce for verification.
	 * @return boolean True on success, false on failure.
	 */
	function seedprod_pro_update_seedprod_theme_enabled_cli( $enable = null, $nonce = null ) {
		// Verify the nonce.
		if ( ! wp_verify_nonce( $nonce, 'seedprod_pro_update_seedprod_theme_enabled' ) ) {
			return false;
		}

		$seedprod_theme_enabled_update = false;
		if ( true === $enable ) {
			$seedprod_theme_enabled_update = true;
		}

		update_option( 'seedprod_theme_enabled', $seedprod_theme_enabled_update );

		if ( true === $seedprod_theme_enabled_update ) {
			$result = seedprod_pro_create_blog_and_home_for_theme_cli( $nonce );
			return true;
		} else {
			return 'disabled';
		}
	}

	/**
	 * Create blog and home pages if they don't exist, and set them as the front and posts pages.
	 *
	 * @param string $nonce The nonce for verification.
	 * @return boolean True on success, false on failure.
	 */
	function seedprod_pro_create_blog_and_home_for_theme_cli( $nonce ) {

			// Verify the nonce.
		if ( ! wp_verify_nonce( $nonce, 'seedprod_pro_update_seedprod_theme_enabled' ) ) {
			return false;
		}

			// create front page and blog page.
			$posts_page_id = get_page_by_path( 'blog' );
			// Check if the page already exists.
		if ( empty( $posts_page_id ) ) {
			$posts_page_id = wp_insert_post(
				array(
					'comment_status' => 'close',
					'ping_status'    => 'close',
					'post_author'    => 1,
					'post_title'     => 'Blog',
					'post_name'      => 'blog',
					'post_status'    => 'publish',
					'post_content'   => '',
					'post_type'      => 'page',
				)
			);
		} else {
			$posts_page_id = $posts_page_id->ID;
		}

			$front_page_id = get_page_by_path( 'home' );
			// Check if the page already exists.
		if ( empty( $front_page_id ) ) {
			$front_page_id = wp_insert_post(
				array(
					'comment_status' => 'close',
					'ping_status'    => 'close',
					'post_author'    => 1,
					'post_title'     => 'Home',
					'post_name'      => 'home',
					'post_status'    => 'publish',
					'post_content'   => '',
					'post_type'      => 'page',
				)
			);
		} else {
			$front_page_id = $front_page_id->ID;
		}

			update_option( 'show_on_front', 'page' );
			update_option( 'page_for_posts', $posts_page_id );
			update_option( 'page_on_front', $front_page_id );

			return true;
	}

	

	/**
	 * Enable or disable the coming soon page using WP-CLI.
	 *
	 * ## OPTIONS
	 *
	 * <true|false>
	 * : Whether to enable or disable the coming soon page.
	 *
	 * [--page_id=<id>]
	 * : The ID of the page to use for coming soon.
	 *
	 * ## EXAMPLES
	 *
	 * wp seedprod_enable_coming_soon_page true --page_id=123
	 *
	 * @param array $args       Command arguments.
	 * @param array $assoc_args Associative arguments.
	 */
	function seedprod_pro_enable_coming_soon_page( $args, $assoc_args ) {
		list( $enable ) = $args;
		$enable         = filter_var( $enable, FILTER_VALIDATE_BOOLEAN );

		$page_id = isset( $assoc_args['page_id'] ) ? intval( $assoc_args['page_id'] ) : null;

		// Generate a nonce.
		$nonce = wp_create_nonce( 'seedprod_enable_coming_soon_page' );

		try {
			// Call the function to enable/disable the coming soon page with nonce.
			$result = seedprod_pro_enable_coming_soon_page_function_cli( $enable, $nonce, $page_id );

			if ( false !== $result ) {
				$action = $enable ? 'enabled' : 'disabled';
				WP_CLI::success( "Coming soon page $action successfully." );
			} else {
				$action = $enable ? 'enable' : 'disable';
				WP_CLI::error( "Failed to $action coming soon page." );
			}
		} catch ( Exception $e ) {
			WP_CLI::error( 'An error occurred: ' . $e->getMessage() );
		}
	}
	WP_CLI::add_command( 'seedprod_enable_coming_soon_page', 'seedprod_pro_enable_coming_soon_page' );

	/**
	 * Enable or disable the coming soon page.
	 *
	 * @param boolean      $enable  Whether to enable or disable the coming soon page.
	 * @param string       $nonce   The nonce for verification.
	 * @param integer|null $page_id The ID of the page to use for coming soon.
	 * @return boolean True on success, false on failure.
	 */
	function seedprod_pro_enable_coming_soon_page_function_cli( $enable, $nonce, $page_id = null ) {
		// Verify the nonce.
		if ( ! wp_verify_nonce( $nonce, 'seedprod_enable_coming_soon_page' ) ) {
			return false;
		}

		$settings = get_option( 'seedprod_settings', array() );

		if ( ! is_array( $settings ) ) {
			// If settings are not an array, initialize it as an array.
			$settings = array();
		}

		// Update the settings with the new coming soon page status.
		$settings['enable_coming_soon_mode'] = $enable ? true : false;

		if ( $page_id ) {
			update_option( 'seedprod_coming_soon_page_id', $page_id );
		}

		// Update the option in the database.
		update_option( 'seedprod_settings', wp_json_encode( $settings ) );

		return true;
	}

	
	/**
	 * Export the SeedProd theme to a ZIP file.
	 *
	 * Creates a ZIP file containing all SeedProd theme templates and their
	 * associated images, compatible with the SeedProd theme import feature.
	 * Runs without timeout constraints, making it suitable for large sites.
	 *
	 * ## OPTIONS
	 *
	 * [--output=<path>]
	 * : Path for the output ZIP file. Defaults to seedprod-theme-export-{date}.zip in the current directory.
	 *
	 * [--[no-]export-images]
	 * : Whether to download and include images. Default: true.
	 *
	 * ## EXAMPLES
	 *
	 *     # Export theme to current directory
	 *     wp seedprod_export_theme
	 *
	 *     # Export to specific path
	 *     wp seedprod_export_theme --output=/tmp/my-theme.zip
	 *
	 *     # Export without images (faster, smaller file)
	 *     wp seedprod_export_theme --no-export-images
	 *
	 * @param array $args       Command arguments.
	 * @param array $assoc_args Command associative arguments.
	 */
	function seedprod_pro_export_theme_cli( $args, $assoc_args ) {

		// Pre-flight checks.
		if ( ! class_exists( 'ZipArchive' ) ) {
			WP_CLI::error( 'The ZipArchive PHP extension is required but not available.' );
		}

		WP_Filesystem();
		global $wp_filesystem;
		if ( ! $wp_filesystem ) {
			WP_CLI::error( 'Unable to initialize the WordPress filesystem.' );
		}

		// Parse options.
		$export_images = \WP_CLI\Utils\get_flag_value( $assoc_args, 'export-images', true );
		$output_path   = isset( $assoc_args['output'] )
			? $assoc_args['output']
			: 'seedprod-theme-export-' . gmdate( 'Y-m-d-His' ) . '.zip';

		if ( ! path_is_absolute( $output_path ) ) {
			$output_path = getcwd() . '/' . $output_path;
		}

		$output_dir = dirname( $output_path );
		if ( ! is_dir( $output_dir ) ) {
			WP_CLI::error( 'Output directory does not exist: ' . $output_dir );
		}
		if ( ! is_writable( $output_dir ) ) {
			WP_CLI::error( 'Output directory is not writable: ' . $output_dir );
		}

		// Query theme templates.
		global $wpdb;
		$tablename      = $wpdb->prefix . 'posts';
		$meta_tablename = $wpdb->prefix . 'postmeta';

		$sql      = "SELECT * FROM $tablename p LEFT JOIN $meta_tablename pm ON (pm.post_id = p.ID)";
		$sql     .= " WHERE post_status='publish' AND post_type = 'seedprod' AND meta_key = '_seedprod_is_theme_template' ";
		$results  = $wpdb->get_results( $sql ); // phpcs:ignore

		if ( empty( $results ) ) {
			WP_CLI::error( 'No SeedProd theme templates found. Make sure you have published theme templates.' );
		}

		WP_CLI::log( sprintf( 'Found %d theme template(s).', count( $results ) ) );

		// Build export JSON (mirrors seedprod_pro_export_theme_files logic).
		$processed_data   = array();
		$export           = array();
		$export['type']             = 'theme-builder';
		$export['current_home_url'] = home_url();
		$export['theme']            = array();
		$export['mapped']           = array();

		$shortcode_exports = array();

		$is_template = false;
		foreach ( $results as $k => $v ) {
			if ( strpos( $v->post_content_filtered, 'placehold.co' ) !== false ) {
				$is_template = true;
				break;
			}
		}

		foreach ( $results as $k => $v ) {
			$meta = get_post_meta( $v->ID );
			if ( true === $is_template ) {
				unset( $meta['_seedprod_css'] );
				unset( $meta['_seedprod_html'] );
			}

			$meta             = wp_json_encode( $meta );
			$content          = $v->post_content;
			$content_filtered = $v->post_content_filtered;

			if ( false === $is_template ) {
				$processed_data[ $k ] = seedprod_pro_process_image_filenames( $content_filtered, $content );
			} else {
				$processed_data[ $k ] = array(
					'data'   => $content_filtered,
					'html'   => $content,
					'images' => array(),
				);
			}

			$export['theme'][] = array(
				'order'                 => $v->menu_order,
				'post_content'          => base64_encode( $processed_data[ $k ]['html'] ), // phpcs:ignore
				'post_content_filtered' => base64_encode( $processed_data[ $k ]['data'] ), // phpcs:ignore
				'post_title'            => base64_encode( $v->post_title ), // phpcs:ignore
				'meta'                  => base64_encode( $meta ), // phpcs:ignore
			);

			$post_content_shortcode = $processed_data[ $k ]['html'];
			$re                     = '/((\[)(sp_template_part id="){1}[0-9]*["](\]))/m';

			preg_match_all( $re, $post_content_shortcode, $matches, PREG_SET_ORDER, 0 );

			if ( $matches ) {
				foreach ( $matches as $t => $val ) {
					$shortcode_content = $val[0];
					$shortcode_page_sc = str_replace( '[sp_template_part id="', '', $shortcode_content );
					$shortcode_page_sc = str_replace( '"]', '', $shortcode_page_sc );

					$shortcode_exports[ $shortcode_page_sc ] = array(
						'id'        => $shortcode_page_sc,
						'shortcode' => $shortcode_content,
					);
				}
			}
		}

		// Build shortcode mappings.
		foreach ( $shortcode_exports as $k => $sc_val ) {
			$page_id        = $sc_val['id'];
			$page_shortcode = $sc_val['shortcode'];

			$sql      = "SELECT p.post_title FROM $tablename p LEFT JOIN $meta_tablename pm ON (pm.post_id = p.ID)";
			$sql     .= " WHERE p.id = %d and post_status='publish' AND post_type = 'seedprod' AND meta_key = '_seedprod_is_theme_template' ";
			$safe_sql = $wpdb->prepare( $sql, absint( $page_id ) ); // phpcs:ignore
			$page     = $wpdb->get_row( $safe_sql ); // phpcs:ignore

			if ( ! empty( $page ) ) {
				$export['mapped'][] = array(
					'id'         => $page_id,
					'shortcode'  => base64_encode( $page_shortcode ), // phpcs:ignore
					'page_title' => $page->post_title,
				);
			}
		}

		// Prepare exports directory.
		$upload_dir = wp_upload_dir();
		$contentdir = trailingslashit( $upload_dir['basedir'] ) . 'seedprod-themes-exports/';

		if ( is_dir( $contentdir ) ) {
			recursive_rmdir( $contentdir );
		}
		mkdir( $contentdir, 0777 );

		// Download images.
		$files_to_download = array();
		$all_failed_images = array();
		$skipped_images    = array();

		if ( $export_images ) {
			$total_images = 0;
			foreach ( $processed_data as $v1 ) {
				$total_images += count( $v1['images'] );
			}

			if ( $total_images > 0 ) {
				WP_CLI::log( sprintf( 'Downloading %d image(s)...', $total_images ) );
				$progress = \WP_CLI\Utils\make_progress_bar( 'Downloading images', count( $processed_data ) );

				foreach ( $processed_data as $k1 => $v1 ) {
					$failed_images     = seedprod_pro_save_images_locally( $v1['images'] );
					$all_failed_images = array_merge( $all_failed_images, $failed_images );

					foreach ( $v1['images'] as $image ) {
						$image_path = $contentdir . $image['filename'];
						if ( file_exists( $image_path ) ) {
							$files_to_download[] = $image['filename'];
						}
					}
					$progress->tick();
				}
				$progress->finish();
			} else {
				WP_CLI::log( 'No images to download.' );
			}
		} else {
			WP_CLI::log( 'Skipping image download (--no-export-images).' );
			foreach ( $processed_data as $v1 ) {
				$skipped_images = array_merge( $skipped_images, $v1['images'] );
			}
		}

		// Create ZIP file.
		$zip          = new ZipArchive();
		$temp_zip     = $contentdir . 'seedprod-export-theme-files.zip';

		if ( $zip->open( $temp_zip, ZipArchive::CREATE | ZipArchive::OVERWRITE ) !== true ) {
			WP_CLI::error( 'Failed to create ZIP file.' );
		}

		foreach ( $files_to_download as $filename ) {
			$zip->addFile( $contentdir . $filename, $filename );
		}

		$zip->addFromString( 'export_theme.json', wp_json_encode( seedprod_pro_restore_failed_image_urls( $export, array_merge( $all_failed_images, $skipped_images ) ) ) );
		$zip->close();

		// Move ZIP to output path.
		if ( ! rename( $temp_zip, $output_path ) ) { // phpcs:ignore
			if ( ! copy( $temp_zip, $output_path ) ) {
				WP_CLI::error( 'Failed to write ZIP to output path: ' . $output_path );
			}
			wp_delete_file( $temp_zip );
		}

		// Cleanup exports directory.
		if ( is_dir( $contentdir ) ) {
			recursive_rmdir( $contentdir );
		}

		// Report results.
		if ( ! empty( $all_failed_images ) ) {
			WP_CLI::warning( sprintf( '%d image(s) could not be downloaded and were excluded.', count( $all_failed_images ) ) );
			foreach ( $all_failed_images as $failed ) {
				WP_CLI::log( sprintf( '  - %s: %s', $failed['url'], $failed['error'] ) );
			}
		}

		$filesize = size_format( filesize( $output_path ) );
		WP_CLI::success( sprintf( 'Theme exported to: %s (%s)', $output_path, $filesize ) );
	}
	WP_CLI::add_command( 'seedprod_export_theme', 'seedprod_pro_export_theme_cli' );
	
}



if ( ! function_exists( 'seedprod_pro_import_theme_by_url_cli' ) ) {
	/**
	 * Import a theme from a URL.
	 *
	 * Shared helper used by the WP-CLI command and the REST Abilities API.
	 *
	 * @param string $theme_url The URL of the theme ZIP to import.
	 * @param string $nonce     The nonce value for security verification.
	 * @return true|array|string True on success, or an array/string with an 'error' key on failure.
	 */
	function seedprod_pro_import_theme_by_url_cli( $theme_url, $nonce ) {

		if ( ! wp_verify_nonce( $nonce, 'seedprod_import_theme_by_url' ) ) {
			return 'Invalid request. Please provide a valid nonce.';
		}

		$is_ajax_request = false;
		if ( null === $theme_url ) {
			$is_ajax_request = check_ajax_referer( 'seedprod_pro_import_theme_by_url' );
		}

		if ( $is_ajax_request || ! empty( $theme_url ) ) {

			if ( ! function_exists( 'request_filesystem_credentials' ) ) {
				require_once ABSPATH . 'wp-admin/includes/file.php';
			}

			// The import helpers live in the admin layer, which does not load under
			// WP-CLI because is_admin() is false there.
			if ( ! function_exists( 'seedprod_pro_v2_extract_zip' ) ) {
				require_once SEEDPROD_PRO_PLUGIN_PATH . 'admin/includes/import-export-functions.php';
			}

			$url   = wp_nonce_url( 'admin.php?page=seedprod_pro_import_theme_by_url', 'seedprod_import_theme_files' );
			$creds = request_filesystem_credentials( $url, '', false, false, null );
			if ( false === $creds ) {
				return array( 'error' => 'Failed to obtain filesystem credentials.' );
			}

			if ( ! WP_Filesystem( $creds ) ) {
				request_filesystem_credentials( $url, '', true, false, null );
				return array( 'error' => 'Failed to initialize filesystem.' );
			}

			$source = ! empty( $theme_url ) ? $theme_url : '';

			$file_import_url_json = wp_remote_get( $source, array( 'sslverify' => false ) );
			if ( is_wp_error( $file_import_url_json ) ) {
				$error_code    = wp_remote_retrieve_response_code( $file_import_url_json );
				$error_message = wp_remote_retrieve_response_message( $file_import_url_json );
				return array( 'error' => $error_message );
			}
			$response_code = (int) wp_remote_retrieve_response_code( $file_import_url_json );
			if ( 200 !== $response_code ) {
				return array( 'error' => sprintf( 'The import URL returned HTTP %d.', $response_code ) );
			}

			if ( '' !== $source && $file_import_url_json['body'] ) {

				$url_data = pathinfo( $source );

				$filename = $url_data['basename'];

				if ( false !== strpos( $filename, '.zip' ) ) {
					$filename = substr( $filename, 0, strpos( $filename, '.zip' ) + 4 );
				}

				if ( ! preg_match( '/\.zip$/i', $filename ) ) {
					return array( 'error' => 'The file you are trying to upload is not a .zip file.' );
				}

				$filename_import = 'seedprod-themes-imports';

				global $wp_filesystem;
				$upload_dir = wp_upload_dir();
				$path       = trailingslashit( $upload_dir['basedir'] );
				$webpath    = trailingslashit( $upload_dir['baseurl'] );

				$filenoext = basename( $filename_import, '.zip' );
				$filenoext = basename( $filenoext, '.ZIP' );

				$targetdir    = $path . $filenoext;
				$targetzip    = $path . $filename;
				$webtargetdir = $webpath . $filenoext;

				if ( is_dir( $targetdir ) ) {
					recursive_rmdir( $targetdir );
				}
				wp_mkdir_p( $targetdir );
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- WP_Filesystem may not be initialized in CLI context.
				if ( file_put_contents( $targetzip, $file_import_url_json['body'] ) ) {

					$extract_result = seedprod_pro_v2_extract_zip( $targetzip, $targetdir, true );
					wp_delete_file( $targetzip );
					if ( is_wp_error( $extract_result ) ) {
						return array( 'error' => $extract_result->get_error_message() );
					}

					$theme_json_data     = $targetdir . '/export_theme.json';
					$web_theme_json_data = $webtargetdir . '/export_theme.json';

					if ( ! file_exists( $theme_json_data ) ) {
						return array( 'error' => 'The ZIP did not contain export_theme.json.' );
					}

					$data = seedprod_pro_v2_read_json_file( $theme_json_data, $web_theme_json_data );
					if ( is_wp_error( $data ) ) {
						return array( 'error' => $data->get_error_message() );
					}

					if ( ! empty( $data->type ) && 'theme-builder' !== $data->type ) {
						return array( 'error' => 'This does not appear to be a SeedProd theme.' );
					}

					$result = seedprod_pro_theme_import_json( $data );
					wp_delete_file( $theme_json_data );

					return is_array( $result ) ? $result : true;
				} else {
					return array( 'error' => 'There was a problem with the upload. Please try again.' );
				}
			} else {
				return array( 'error' => 'There was a problem with the upload. Please try again.' );
			}
		}
	}
}

if ( ! function_exists( 'seedprod_pro_save_api_key_cli' ) ) {
	/**
	 * Save / activate a SeedProd API key.
	 *
	 * Shared helper used by the WP-CLI command and the REST Abilities API.
	 *
	 * @param string|null $api_key API key for activation.
	 * @param string|null $nonce   The nonce for verification.
	 * @return array Result array with 'status' and 'msg' keys.
	 */
	function seedprod_pro_save_api_key_cli( $api_key = null, $nonce = null ) {
		// Verify the nonce.
		if ( ! wp_verify_nonce( $nonce, 'seedprod_nonce' ) ) {
			return array(
				'status' => 'false',
				'msg'    => 'Invalid nonce. Please try again.',
			);
		}

		if ( empty( $api_key ) ) {
			$api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) : null;
		}

		if ( defined( 'SEEDPROD_LOCAL_JS' ) ) {
			$slug = 'seedprod-coming-soon-pro-5/seedprod-coming-soon-pro-5.php';
		} else {
			$slug = SEEDPROD_PRO_SLUG;
		}

		// Get token and generate one if one does not exist.
		$token = get_option( 'seedprod_token' );
		if ( empty( $token ) ) {
			$token = strtolower( wp_generate_password( 32, false, false ) );
			update_option( 'seedprod_token', $token );
		}

		// Validate the API key.
		$data = array(
			'action'            => 'info',
			'license_key'       => $api_key,
			'token'             => $token,
			'wp_version'        => get_bloginfo( 'version' ),
			'domain'            => home_url(),
			'installed_version' => SEEDPROD_PRO_VERSION,
			'slug'              => $slug,
		);

		if ( empty( $data['license_key'] ) ) {
			return array(
				'status' => 'false',
				'msg'    => __( 'License Key is required.', 'seedprod-pro' ),
			);
		}

		$headers = array(
			'Accept' => 'application/json',
		);

		$url      = SEEDPROD_PRO_API_URL . 'update';
		$response = wp_remote_post(
			$url,
			array(
				'body'    => $data,
				'headers' => $headers,
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'status' => 'false',
				'msg'    => $response->get_error_message(),
			);
		}

		$status_code = wp_remote_retrieve_response_code( $response );

		if ( 200 !== $status_code ) {
			return array(
				'status' => 'false',
				'msg'    => wp_remote_retrieve_response_message( $response ),
			);
		}

		$body = wp_remote_retrieve_body( $response );

		if ( ! empty( $body ) ) {
			$body = json_decode( $body );
		}

		if ( ! empty( $body->valid ) && true === $body->valid ) {
			// Store API key.
			update_option( 'seedprod_user_id', $body->user_id );
			update_option( 'seedprod_api_token', $body->api_token );
			update_option( 'seedprod_api_key', $data['license_key'] );
			update_option( 'seedprod_api_message', $body->message );
			update_option( 'seedprod_license_name', $body->license_name );
			update_option( 'seedprod_a', true );
			update_option( 'seedprod_per', $body->per );

			return array(
				'status'       => 'true',
				// Translators: %s is the license name.
				'license_name' => sprintf( __( 'You currently have the <strong>%s</strong> license.', 'seedprod-pro' ), $body->license_name ),
				'msg'          => $body->message,
				'body'         => $body,
			);
		} else {
			$api_msg = __( 'Invalid License Key.', 'seedprod-pro' );
			if ( 'Unauthenticated.' !== $body->message ) {
				$api_msg = $body->message;
			}
			update_option( 'seedprod_license_name', '' );
			update_option( 'seedprod_api_token', '' );
			update_option( 'seedprod_api_key', '' );
			update_option( 'seedprod_api_message', $api_msg );
			update_option( 'seedprod_a', false );
			update_option( 'seedprod_per', '' );

			return array(
				'status' => 'false',
				'msg'    => $api_msg,
				'body'   => $body,
			);
		}
	}
}

