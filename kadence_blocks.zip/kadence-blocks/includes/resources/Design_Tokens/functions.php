<?php declare( strict_types=1 );

use KadenceWP\KadenceBlocks\Design_Tokens\Foundation_Presets\Catalog;
use KadenceWP\KadenceBlocks\Design_Tokens\Foundation_Presets\Selector;
use KadenceWP\KadenceBlocks\Design_Tokens\Projection\Adapter\Contracts\Adapter_Interface;
use KadenceWP\KadenceBlocks\Design_Tokens\Projection\Css_Var\Slot_Target_Reader;
use KadenceWP\KadenceBlocks\Design_Tokens\Projection\Css_Var\Slot\Font_Size_Target;
use KadenceWP\KadenceBlocks\Design_Tokens\Projection\Css_Var\Slot\Spacing_Target;
use KadenceWP\KadenceBlocks\Design_Tokens\Registry\Token_Registry;

if ( ! function_exists( 'kadence_blocks_register_design_token' ) ) {
	/**
	 * Declare a design token in the single Registry. Thin readability wrapper over
	 * Token_Registry::register() that mirrors KB's existing global helpers. The declaration accepts
	 * 'id' (DTCG dot-path), 'type' (DTCG $type), 'label', optional 'group', optional 'projections'
	 * and an optional 'css_var' override. See Token_Definition::from_array().
	 *
	 * Register before `init` priority 1: the baseline guard runs once there and does not re-validate
	 * tokens declared later, so a token registered on a later hook skips baseline validation entirely.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $definition The token declaration. See Token_Definition::from_array().
	 *
	 * @return void
	 */
	function kadence_blocks_register_design_token( array $definition ): void {
		/** @var Token_Registry $registry */
		$registry = kadence_blocks()->get( Token_Registry::class );
		$registry->register( $definition );
	}
}

if ( ! function_exists( 'kadence_blocks_register_design_preset_bindings' ) ) {
	/**
	 * Declare that a block accepts presets, plus its per-property bindings. Preset names, default and
	 * values are document data, not declared here.
	 *
	 * @since 3.8.0
	 *
	 * @param array{block: string, bindings?: array<string, array<string, mixed>>} $declaration See Preset_Bindings::from_array().
	 *
	 * @return void
	 */
	function kadence_blocks_register_design_preset_bindings( array $declaration ): void {
		/** @var Token_Registry $registry */
		$registry = kadence_blocks()->get( Token_Registry::class );
		$registry->register_preset_bindings( $declaration );
	}
}

if ( ! function_exists( 'kadence_blocks_register_design_token_adapter' ) ) {
	/**
	 * Register a per-block adapter — a named transform keyed to the Kadence Blocks block type whose
	 * attributes cannot be expressed as a clean token/variable reference. Adapters apply to Kadence Blocks
	 * blocks only: they run through KB's own block-attributes seam, so a core or third-party block is never
	 * touched. Thin readability wrapper over Token_Registry::register_adapter() that mirrors KB's existing
	 * global helpers. Most blocks need none.
	 *
	 * Register any time before the block renders (e.g. on `init`): the adapter projector looks the adapter
	 * up by block when KB assembles the block's attributes, so registration order does not matter.
	 *
	 * @since 3.8.0
	 *
	 * @param Adapter_Interface $adapter The adapter to register.
	 *
	 * @return void
	 */
	function kadence_blocks_register_design_token_adapter( Adapter_Interface $adapter ): void {
		/** @var Token_Registry $registry */
		$registry = kadence_blocks()->get( Token_Registry::class );
		$registry->register_adapter( $adapter );
	}
}

if ( ! function_exists( 'kadence_blocks_design_foundation_presets' ) ) {
	/**
	 * The foundation-preset catalogue reader — the beginner on-ramp's "what can I pick?" surface. Thin
	 * accessor over the Catalog service that lists the shipped type scales and starter palettes (the
	 * admin UI and MCP surface read it to render the picker).
	 *
	 * @since 3.8.0
	 *
	 * @return Catalog
	 */
	function kadence_blocks_design_foundation_presets(): Catalog {
		/** @var Catalog $presets */
		$presets = kadence_blocks()->get( Catalog::class );

		return $presets;
	}
}

if ( ! function_exists( 'kadence_blocks_apply_design_foundation_preset' ) ) {
	/**
	 * Apply a foundation-preset choice, seeding the primitive layer as store overrides. Thin readability
	 * wrapper over Selector::apply().
	 *
	 * @since 3.8.0
	 *
	 * @param string $group  The preset group key, e.g. "typeScale".
	 * @param string $choice The preset slug within the group, e.g. "goldenRatio".
	 *
	 * @return void
	 */
	function kadence_blocks_apply_design_foundation_preset( string $group, string $choice ): void {
		/** @var Selector $selector */
		$selector = kadence_blocks()->get( Selector::class );
		$selector->apply( $group, $choice );
	}
}

if ( ! function_exists( 'kadence_blocks_variable_font_size_scale' ) ) {
	/**
	 * The token-driven fluid font-size scale as a slug => value map, used to seed the base of KB's
	 * `kadence_blocks_variable_font_sizes` filter (includes/init.php and
	 * class-kadence-blocks-editor-assets.php) so the shipped clamp() values live once, in the baseline,
	 * rather than being copied into each emission site. Returns an empty array when token projection is
	 * unavailable or inactive, so callers keep their own fallback. Thin accessor over the Slot_Target_Reader.
	 *
	 * @since 3.8.0
	 *
	 * @return array<string,string> Slug => resolved font-size value (a clamp() string by default).
	 */
	function kadence_blocks_variable_font_size_scale(): array {
		try {
			/** @var Slot_Target_Reader $reader */
			$reader = kadence_blocks()->get( Slot_Target_Reader::class );
		} catch ( \Throwable $e ) {
			return [];
		}

		return $reader->read( Font_Size_Target::class );
	}
}

if ( ! function_exists( 'kadence_blocks_variable_spacing_scale' ) ) {
	/**
	 * The token-driven spacing scale as a slug => value map, used to seed the base of KB's
	 * `--global-kb-spacing-*` emission (includes/init.php) so the shipped spacing literals live once, in
	 * the baseline, rather than being copied into the emission. Returns an empty array when token
	 * projection is unavailable or inactive, so callers keep their own fallback. Thin accessor over the
	 * Slot_Target_Reader.
	 *
	 * @since 3.8.0
	 *
	 * @return array<string,string> Slug => resolved spacing length.
	 */
	function kadence_blocks_variable_spacing_scale(): array {
		try {
			/** @var Slot_Target_Reader $reader */
			$reader = kadence_blocks()->get( Slot_Target_Reader::class );
		} catch ( \Throwable $e ) {
			return [];
		}

		return $reader->read( Spacing_Target::class );
	}
}
