<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocks\Design_Tokens\Rest\V1;

use KadenceWP\KadenceBlocks\Design_Tokens\Database\Active_Token_Library_Store;
use KadenceWP\KadenceBlocks\Design_Tokens\Database\Token_Store;
use KadenceWP\KadenceBlocks\Design_Tokens\Document\Mutator;
use KadenceWP\KadenceBlocks\Design_Tokens\Registry\Token_Registry;
use KadenceWP\KadenceBlocks\Design_Tokens\Resolver\Effective_Palettes;
use KadenceWP\KadenceBlocks\Design_Tokens\Resolver\Exception\Alias_Cycle_Exception;
use KadenceWP\KadenceBlocks\Design_Tokens\Resolver\Exception\Dangling_Alias_Exception;
use KadenceWP\KadenceBlocks\Design_Tokens\Resolver\Token_Resolver;
use KadenceWP\KadenceBlocks\Design_Tokens\Rest\V1\Contracts\Controller;
use KadenceWP\KadenceBlocks\Design_Tokens\Schema\Validation\Dtcg_Validator;
use KadenceWP\KadenceBlocks\Design_Tokens\Schema\Vocabulary\Alias;
use KadenceWP\KadenceBlocks\Design_Tokens\Schema\Vocabulary\Extensions;
use KadenceWP\KadenceBlocks\Design_Tokens\Schema\Vocabulary\Sentinels;
use KadenceWP\KadenceBlocks\StellarWP\DB\Database\Exceptions\DatabaseQueryException;
use KadenceWP\KadenceBlocks\Utils\Cast;
use WP_Error;
use WP_Http;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * REST controller for the per-library color palettes.
 *
 * Owns the `$extensions.com.kadence.designTokens.colorPalettes` surface: list the library's palettes, read /
 * create / replace / delete a palette (label + ordered groups of swatches), and get / set the library's
 * `$current` (active) palette. Modeled on {@see Presets_Controller} — the closest per-library `$extensions`
 * write precedent — plus {@see Active_Token_Library_Controller} for the pointer.
 *
 * Writes go through the same gate: capability check (via {@see Controller}), the DTCG validator (swatch
 * `$value` grammar), a resolver dry-run, and palette-specific guards — `$current` / `$default` must name a
 * real palette, each swatch `token` must target a real color leaf, no duplicate `token` within a palette,
 * and `label` must be a string. Because a palette's values live under `$extensions`, the resolver dry-run
 * never sees them, so alias targets are guarded here explicitly.
 *
 * One further guard is specific to the DEFAULT palette: it is the structure template every other palette is
 * projected from, so a write against it may not drop a swatch the shipped baseline defines
 * ({@see guard_baseline_swatches()}). Those rows are permanent — reverted, never removed, which is what
 * {@see delete_swatch()} does with them: restore the shipped color on the default palette, drop the delta
 * (back to inherited) on any other. Only a user-added swatch's row is actually removable.
 *
 * @since 3.8.0
 */
final class Palettes_Controller extends Controller {

	/**
	 * The request parameter that carries the token library slug a read/write targets.
	 *
	 * @since 3.8.0
	 *
	 * @var string
	 */
	private const LIBRARY_PARAM = 'library';

	/**
	 * The palette id path/request parameter.
	 *
	 * @since 3.8.0
	 *
	 * @var string
	 */
	private const ID_PARAM = 'id';

	/**
	 * The palette label request parameter.
	 *
	 * @since 3.8.0
	 *
	 * @var string
	 */
	private const LABEL_PARAM = 'label';

	/**
	 * The palette groups request parameter.
	 *
	 * @since 3.8.0
	 *
	 * @var string
	 */
	private const GROUPS_PARAM = 'groups';

	/**
	 * The `$current` pointer request parameter.
	 *
	 * @since 3.8.0
	 *
	 * @var string
	 */
	private const CURRENT_PARAM = 'current';

	/**
	 * The literal segment for the `$current` sub-route.
	 *
	 * @since 3.8.0
	 *
	 * @var string
	 */
	private const CURRENT_ROUTE = 'current';

	/**
	 * The palette-id path capture.
	 *
	 * @since 3.8.0
	 *
	 * @var string
	 */
	private const ID_ROUTE = '(?P<' . self::ID_PARAM . '>[\w-]+)';

	/**
	 * The swatch-token path/request parameter.
	 *
	 * @since 3.8.0
	 *
	 * @var string
	 */
	private const TOKEN_PARAM = 'token';

	/**
	 * The single-swatch sub-route under a palette: `{id}/swatches/{token}`. The token capture allows the dots
	 * and hyphens a token dot-path carries (e.g. `primitive.color.brand.button-hover`).
	 *
	 * @since 3.8.0
	 *
	 * @var string
	 */
	private const SWATCH_ROUTE = self::ID_ROUTE . '/swatches/(?P<' . self::TOKEN_PARAM . '>[\w.-]+)';

	/**
	 * @var Token_Store
	 *
	 * @since 3.8.0
	 */
	private Token_Store $store;

	/**
	 * @var Mutator
	 *
	 * @since 3.8.0
	 */
	private Mutator $mutator;

	/**
	 * @var Token_Resolver
	 *
	 * @since 3.8.0
	 */
	private Token_Resolver $resolver;

	/**
	 * @var Dtcg_Validator
	 *
	 * @since 3.8.0
	 */
	private Dtcg_Validator $validator;

	/**
	 * @var Effective_Palettes
	 *
	 * @since 3.8.0
	 */
	private Effective_Palettes $palettes;

	/**
	 * @var Token_Registry
	 *
	 * @since 3.8.0
	 */
	private Token_Registry $registry;

	/**
	 * @var Active_Token_Library_Store
	 *
	 * @since 3.8.0
	 */
	private Active_Token_Library_Store $active;

	/**
	 * Memoised item schema for this request.
	 *
	 * @since 3.8.0
	 *
	 * @var array<string, mixed>|null
	 */
	private ?array $item_schema = null;

	/**
	 * @since 3.8.0
	 *
	 * @param Token_Store                $store     The sole gateway to the kb_design_tokens table.
	 * @param Mutator                    $mutator   The pure structural document transforms.
	 * @param Token_Resolver             $resolver  The resolver, for the write dry-run.
	 * @param Dtcg_Validator             $validator The DTCG grammar validator.
	 * @param Effective_Palettes         $palettes  The effective palettes reader.
	 * @param Token_Registry             $registry  The token registry, for the swatch-target guard.
	 * @param Active_Token_Library_Store $active    Owns the active-library pointer.
	 */
	public function __construct(
		Token_Store $store,
		Mutator $mutator,
		Token_Resolver $resolver,
		Dtcg_Validator $validator,
		Effective_Palettes $palettes,
		Token_Registry $registry,
		Active_Token_Library_Store $active
	) {
		$this->store     = $store;
		$this->mutator   = $mutator;
		$this->resolver  = $resolver;
		$this->validator = $validator;
		$this->palettes  = $palettes;
		$this->registry  = $registry;
		$this->active    = $active;
		$this->rest_base = 'palettes';
	}

	/**
	 * Register the palette collection, `$current` pointer, and single-palette routes.
	 *
	 * The `current` sub-route is registered before the single-palette `{id}` route so the literal segment
	 * is not captured as a palette id.
	 *
	 * @since 3.8.0
	 *
	 * @return void
	 */
	public function register_routes(): void {
		register_rest_route(
			$this->namespace,
			"/$this->rest_base",
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_items' ],
					'permission_callback' => [ $this, 'get_items_permissions_check' ],
					'args'                => [ self::LIBRARY_PARAM => $this->library_param() ],
				],
				'schema' => [ $this, 'get_item_schema' ],
			]
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/' . self::CURRENT_ROUTE,
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_current' ],
					'permission_callback' => [ $this, 'get_item_permissions_check' ],
					'args'                => [ self::LIBRARY_PARAM => $this->library_param() ],
				],
				[
					// POST and PUT both set the pointer; it is an idempotent write, so they share one handler.
					'methods'             => [ WP_REST_Server::CREATABLE, 'PUT' ],
					'callback'            => [ $this, 'set_current' ],
					'permission_callback' => [ $this, 'update_item_permissions_check' ],
					'args'                => $this->get_current_params(),
				],
				'schema' => [ $this, 'get_item_schema' ],
			]
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/' . self::ID_ROUTE,
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_item' ],
					'permission_callback' => [ $this, 'get_item_permissions_check' ],
					'args'                => $this->get_id_params(),
				],
				[
					// POST creates and PUT replaces the palette at this id; a single palette node write is
					// create-or-replace either way, so both verbs share one handler.
					'methods'             => [ WP_REST_Server::CREATABLE, 'PUT' ],
					'callback'            => [ $this, 'update_item' ],
					'permission_callback' => [ $this, 'update_item_permissions_check' ],
					'args'                => $this->get_write_params(),
				],
				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'delete_item' ],
					'permission_callback' => [ $this, 'delete_item_permissions_check' ],
					'args'                => $this->get_id_params(),
				],
				'schema' => [ $this, 'get_item_schema' ],
			]
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/' . self::SWATCH_ROUTE,
			[
				[
					// POST and PUT both set one swatch's value; it is an idempotent upsert, so they share a handler.
					'methods'             => [ WP_REST_Server::CREATABLE, 'PUT' ],
					'callback'            => [ $this, 'update_swatch' ],
					'permission_callback' => [ $this, 'update_item_permissions_check' ],
					'args'                => $this->get_swatch_write_params(),
				],
				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'delete_swatch' ],
					'permission_callback' => [ $this, 'delete_item_permissions_check' ],
					'args'                => $this->get_swatch_params(),
				],
				'schema' => [ $this, 'get_item_schema' ],
			]
		);
	}

	/**
	 * List a library's palettes: a flat row per palette carrying its id, label, and `is_default` /
	 * `is_current` / `user_created` flags, each with an embeddable `self` link `_embed` resolves into
	 * the palette's full `effective_view()`.
	 *
	 * @since 3.8.0
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_items( $request ) {
		$slug = $this->slug( $request );
		$rows = array_map(
			fn( array $row ) => $this->prepare_response_for_collection( $this->prepare_item_for_response( $row, $request ) ),
			$this->prepare_items( $slug )
		);

		return new WP_REST_Response( $rows, WP_Http::OK );
	}

	/**
	 * Read a single palette node, or 404 when the library defines no palette with that id.
	 *
	 * @since 3.8.0
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_item( $request ) {
		$slug = $this->slug( $request );
		$id   = Cast::to_string( $request->get_param( self::ID_PARAM ) );

		if ( $this->palettes->palette( $id, $slug ) === null ) {
			return $this->not_found( $id );
		}

		return new WP_REST_Response( $this->effective_view( $id, $slug ), WP_Http::OK );
	}

	/**
	 * Create or replace a palette (POST or PUT /palettes/{id}): read its label + groups from the request, run
	 * the shape and swatch guards, replace the palette node in the library's stored overrides, and validate-and-save.
	 * A single palette node write is create-or-replace either way, so POST and PUT share this handler.
	 *
	 * A write against the default palette must additionally keep every baseline swatch: dropping one there
	 * removes it from every palette, so it is a 403 rather than a structure edit.
	 *
	 * @since 3.8.0
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_item( $request ) {
		$slug = $this->slug( $request );
		$id   = Cast::to_string( $request->get_param( self::ID_PARAM ) );

		$node = [
			Extensions::get_label_key()  => Cast::to_string( $request->get_param( self::LABEL_PARAM ) ),
			Extensions::get_groups_key() => $this->groups_param( $request ),
		];

		$shape = $this->guard_palette_shape( $node, $id );
		if ( $shape !== null ) {
			return $shape;
		}

		$swatches = $this->guard_swatches( $node, $id );
		if ( $swatches !== null ) {
			return $swatches;
		}

		$locked = $this->guard_baseline_swatches( $node, $id, $slug );
		if ( $locked !== null ) {
			return $locked;
		}

		// The default palette keeps every swatch row (it is the structure template). A non-default palette
		// stores only its DELTAS: a swatch equal to the default palette's value is inherited, not persisted, so
		// the palette resolves against the default for everything it does not change.
		$node = $this->prepare_for_storage( $node, $slug, $id === $this->palettes->default_palette( $slug ) );

		// Replace the palette node wholesale (remove-then-merge) rather than a plain merge. A delta-reduced node
		// has a shorter/reordered groups list than the one already stored, and a plain merge index-merges the two
		// lists positionally — leaving stale groups/swatches behind. This is the same guard the swatch write path
		// relies on, so both routes converge on {@see write_palette_node()}.
		return $this->write_palette_node( $slug, $id, $node );
	}

	/**
	 * Drop a palette's stored node (DELETE /palettes/{id}). What that leaves behind depends on whether the
	 * shipped baseline also defines the palette: a user-created one is gone from the listing, while a baseline
	 * palette — the `default` among them — RESETS to its shipped definition and stays. Either way the request
	 * removes only overrides, which is why the two cases share one handler. This matches the DELETE semantics
	 * of the sibling library and preset controllers, where dropping the default resets it to baseline.
	 *
	 * Deleting the palette `$current` names hands that pointer to the default palette, so the stored document
	 * never keeps an id that resolves to nothing.
	 *
	 * Idempotent for a baseline palette (a reset with nothing stored changes nothing); a palette the library
	 * does not define at all is a 404.
	 *
	 * @since 3.8.0
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function delete_item( $request ) {
		$slug = $this->slug( $request );
		$id   = Cast::to_string( $request->get_param( self::ID_PARAM ) );

		if ( $this->palettes->palette( $id, $slug ) === null ) {
			return $this->not_found( $id );
		}

		$document = $this->mutator->remove_by_keys( $this->stored_document( $slug ), $this->palette_keys( $id ) );

		// Removing the palette `$current` points at leaves that pointer naming an id that is no longer there.
		// Nothing renders wrong — every reader fail-softs to `$default` — but the stale id stays in storage,
		// and it springs back the moment the id exists again: a palette later created under the same id would
		// go live without anyone activating it. Hand the pointer to the default palette instead. Only for a
		// palette that actually goes away; deleting a baseline one reverts it and leaves it in the listing,
		// so a pointer at it stays valid.
		if ( $this->palettes->current( $slug ) === $id && in_array( $id, $this->palettes->user_created( $slug ), true ) ) {
			$document = $this->mutator->merge(
				$document,
				$this->pointer_partial( Extensions::get_current_key(), $this->palettes->default_palette( $slug ) )
			);
		}

		return $this->validate_and_save( $document, $id, $slug );
	}

	/**
	 * Set a single palette swatch's value and/or structural label (POST or PUT /palettes/{id}/swatches/{token}):
	 * validate just this one token, upsert the sent fields into the palette, and save. Only the sent swatch is
	 * guarded, so editing one color never depends on the palette's other swatches being valid, and every token
	 * the palette does not set falls back to the default palette. Setting a non-default palette's swatch value
	 * to the default value reverts it to inherited, the same as a DELETE. A label is structural — defined once,
	 * inherited by every palette — so it can only be set on the library's default palette; sending one against
	 * any other palette id is rejected. A request for a palette the library does not define is a 404.
	 *
	 * @since 3.8.0
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_swatch( $request ) {
		$slug  = $this->slug( $request );
		$id    = Cast::to_string( $request->get_param( self::ID_PARAM ) );
		$token = Cast::to_string( $request->get_param( self::TOKEN_PARAM ) );

		$node = $this->palettes->palette( $id, $slug );

		if ( $node === null ) {
			return $this->not_found( $id );
		}

		$value = $request->get_param( Sentinels::get_value_key() );
		$label = $request->get_param( self::LABEL_PARAM );

		if ( ! is_string( $value ) && ! is_string( $label ) ) {
			return $this->invalid( $id, __( 'A swatch value or label is required.', 'kadence-blocks' ) );
		}

		if ( is_string( $value ) && $value === '' ) {
			return $this->invalid( $id, __( 'A swatch value cannot be empty.', 'kadence-blocks' ) );
		}

		if ( is_string( $label ) && $label === '' ) {
			return $this->invalid( $id, __( 'A swatch label cannot be empty.', 'kadence-blocks' ) );
		}

		$default_id = $this->palettes->default_palette( $slug );

		if ( is_string( $label ) && $id !== $default_id ) {
			return $this->invalid( $id, __( 'A swatch label is structural and can only be set on the library\'s default palette.', 'kadence-blocks' ) );
		}

		$fields = [];

		if ( is_string( $value ) ) {
			$guard = $this->guard_swatch_target( $id, $token, $value );

			if ( $guard !== null ) {
				return $guard;
			}

			$fields['value'] = $value;
		} elseif ( is_string( $label ) ) {
			// A label-only write has no new value to guard, so guard the token's CURRENT effective value
			// instead — a token that is stale or no longer a registered color must still be rejected. A
			// token this palette has never stored has no current value here; that genuinely-new-token case
			// is left to the downstream DTCG schema validation, which already rejects it.
			$current_value = $this->palettes->complete_swatch_values( $id, $slug )[ $token ] ?? null;

			if ( is_string( $current_value ) ) {
				$guard = $this->guard_swatch_target( $id, $token, $current_value );

				if ( $guard !== null ) {
					return $guard;
				}
			}
		}

		if ( is_string( $label ) ) {
			$fields['label'] = $label;
		}

		if ( isset( $fields['value'] ) ) {
			$default = $this->palettes->complete_swatch_values( $default_id, $slug );

			// A non-default swatch equal to the default value is inherited, not stored, so setting it back to
			// the default reverts it — identical to a DELETE. Only applies to a value write; a label-only
			// write never reverts anything.
			$node = ( $id !== $default_id && ( $default[ $token ] ?? null ) === $fields['value'] )
				? $this->remove_swatch_from_node( $node, $token )
				: $this->set_swatch_fields_in_node( $node, $token, $fields, $slug );
		} else {
			$node = $this->set_swatch_fields_in_node( $node, $token, $fields, $slug );
		}

		return $this->write_palette_node( $slug, $id, $node );
	}

	/**
	 * Undo a palette's own value for one swatch (DELETE /palettes/{id}/swatches/{token}). What "undo" means
	 * depends on where the swatch came from, because only one of the two is a row a palette may lose:
	 *
	 *   - A swatch the shipped baseline defines is permanent, so this REVERTS its value and keeps the row. On
	 *     the default palette that means restoring the shipped color; on any other palette it means dropping
	 *     the delta so the swatch inherits the default palette again.
	 *   - A user-added swatch has no shipped value to fall back to, so its row is REMOVED. Done on the default
	 *     palette — which owns the structure every palette is projected from — that retires the color entirely.
	 *
	 * Idempotent either way: a token a palette never set is already inherited, and a row already gone stays
	 * gone. An unknown palette is a 404.
	 *
	 * @since 3.8.0
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function delete_swatch( $request ) {
		$slug  = $this->slug( $request );
		$id    = Cast::to_string( $request->get_param( self::ID_PARAM ) );
		$token = Cast::to_string( $request->get_param( self::TOKEN_PARAM ) );

		$node = $this->palettes->palette( $id, $slug );

		if ( $node === null ) {
			return $this->not_found( $id );
		}

		$baseline = $this->palettes->baseline_swatch_values();

		// The default palette's rows are the permanent swatch set, so a baseline swatch there is written back
		// at its baseline value rather than dropped — {@see reduce_default_to_overrides()} then strips that
		// value on the way to the store, leaving the row following the baseline again. Every other case drops
		// the palette's own entry: a non-default palette's delta (leaving it inherited) or a user-added row.
		$node = ( $id === $this->palettes->default_palette( $slug ) && array_key_exists( $token, $baseline ) )
			? $this->set_swatch_fields_in_node( $node, $token, [ 'value' => $baseline[ $token ] ], $slug )
			: $this->remove_swatch_from_node( $node, $token );

		return $this->write_palette_node( $slug, $id, $node );
	}

	/**
	 * Read the library's `$current` palette id.
	 *
	 * @since 3.8.0
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_current( $request ) {
		return new WP_REST_Response( [ self::CURRENT_PARAM => $this->palettes->current( $this->slug( $request ) ) ], WP_Http::OK );
	}

	/**
	 * Set the library's `$current` palette (PUT /palettes/current). The target must name a palette the library
	 * defines, otherwise it is a 422.
	 *
	 * @since 3.8.0
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function set_current( $request ) {
		$slug = $this->slug( $request );
		$id   = Cast::to_string( $request->get_param( self::CURRENT_PARAM ) );

		if ( $this->palettes->palette( $id, $slug ) === null ) {
			return new WP_Error(
				'rest_design_tokens_invalid',
				__( 'The current palette must name a palette the library defines.', 'kadence-blocks' ),
				[
					'status'            => WP_Http::UNPROCESSABLE_ENTITY,
					self::CURRENT_PARAM => $id,
				]
			);
		}

		$partial   = $this->pointer_partial( Extensions::get_current_key(), $id );
		$candidate = $this->mutator->merge( $this->stored_document( $slug ), $partial );

		$saved = $this->validate_and_save( $candidate, $id, $slug );

		if ( $saved instanceof WP_Error ) {
			return $saved;
		}

		return new WP_REST_Response( $this->prepare_items_embedded( $slug ), $saved->get_status() );
	}

	/**
	 * The JSON Schema for a palette resource.
	 *
	 * @since 3.8.0
	 *
	 * @return array<string, mixed>
	 */
	public function get_item_schema(): array {
		if ( $this->item_schema !== null ) {
			return $this->add_additional_fields_schema( $this->item_schema );
		}

		$this->item_schema = [
			'$schema'    => 'http://json-schema.org/draft-07/schema#',
			'title'      => 'design-token-palette',
			'type'       => 'object',
			'properties' => [
				self::ID_PARAM     => [
					'description' => __( 'The palette id.', 'kadence-blocks' ),
					'type'        => 'string',
					'context'     => [ 'view' ],
				],
				self::LABEL_PARAM  => [
					'description' => __( 'The palette label.', 'kadence-blocks' ),
					'type'        => 'string',
					'context'     => [ 'view' ],
				],
				self::GROUPS_PARAM => [
					'description' => __( 'The ordered color groups, each an ordered list of swatches.', 'kadence-blocks' ),
					'type'        => 'array',
					'context'     => [ 'view' ],
				],
			],
		];

		return $this->add_additional_fields_schema( $this->item_schema );
	}

	/**
	 * Wrap one listing row in a `WP_REST_Response` carrying its `self` link — what `_embed` resolves
	 * through `get_item()` into the row's full `effective_view()`, and what the standard
	 * `prepare_response_for_collection()` call in `get_items()` below merges into the row's own array
	 * as `_links` (not a nested response object — see `Contracts\Controller` for why this repo's
	 * controllers otherwise build plain arrays directly). The `self` link is built against the
	 * SAME library the listing itself resolved (via `slug()`), not the site's active library —
	 * otherwise `_embed`'s internal sub-request would silently re-resolve against whatever library
	 * happens to be active, returning the wrong palette's data for a listing requested against a
	 * non-active library.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $item    The listing row: `{id, label, is_default, is_current, user_created}`.
	 * @param WP_REST_Request      $request Full details about the request.
	 *
	 * @return WP_REST_Response
	 */
	public function prepare_item_for_response( $item, $request ) {
		$response = new WP_REST_Response( $item );
		$response->add_links( $this->prepare_links( $item, $this->slug( $request ) ) );

		return $response;
	}

	/**
	 * The `self` link for a listing row, targeting `GET /palettes/{id}?library={slug}` — the
	 * single-palette route `_embed` resolves into the row's full group/swatch data. The `library`
	 * query arg pins the embedded sub-request to the library the listing was requested for; without
	 * it, `_embed` falls back to the site's active library, which is wrong whenever the listing
	 * targets a non-active one.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $item The listing row.
	 * @param string               $slug The token library slug the listing was resolved for.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	protected function prepare_links( $item, string $slug ) {
		$href = rest_url( sprintf( '%s/%s/%s', $this->namespace, $this->rest_base, Cast::to_string( $item[ self::ID_PARAM ] ) ) );

		return [
			'self' => [
				'href'       => add_query_arg( self::LIBRARY_PARAM, $slug, $href ),
				'embeddable' => true,
			],
		];
	}

	/**
	 * The effective, editable view of a palette: the DEFAULT palette's full group/swatch structure (the field
	 * template) with each swatch's value taken from the palette's own delta when it defines one, otherwise the
	 * inherited default value. This is what the palette editor renders so every field is present even when the
	 * palette stores only a few deltas.
	 *
	 * Two flags per swatch drive the editor's undo affordance, and they answer different questions:
	 *
	 *   - `baseline` — whether the shipped palette defines this swatch. A baseline swatch's row is permanent
	 *     (see {@see guard_baseline_swatches()}), so the editor offers Reset for it and Delete only for the
	 *     rest.
	 *   - `overridden` — whether there is anything to undo: the palette stores its own value for the swatch.
	 *     One test serves every palette, the default included, because the default palette stores only the
	 *     swatches the site changed; a swatch left at the baseline keeps its row but stores no `$value`, so
	 *     it reads as not overridden and there is nothing to undo.
	 *
	 * @since 3.8.0
	 * @since 3.9.1 Shows the complement worked out from the primary.
	 *
	 * @param string $id   The palette id.
	 * @param string $slug The token library slug.
	 *
	 * @return array<string, mixed>
	 */
	private function effective_view( string $id, string $slug ): array {
		$template = $this->palettes->palette( $this->palettes->default_palette( $slug ), $slug ) ?? [];
		$deltas   = $this->palettes->stored_swatch_values( $id, $slug );
		$own      = $this->palettes->palette( $id, $slug ) ?? [];
		$baseline = $this->palettes->baseline_swatch_values();
		$complete = $this->palettes->complete_swatch_values( $id, $slug );

		$token_key    = Extensions::get_swatch_token_key();
		$label_key    = Extensions::get_label_key();
		$value_key    = Sentinels::get_value_key();
		$swatches_key = Extensions::get_swatches_key();

		$template_groups = $template[ Extensions::get_groups_key() ] ?? [];
		$groups          = [];

		if ( ! is_array( $template_groups ) ) {
			$template_groups = [];
		}

		foreach ( $template_groups as $group ) {
			if ( ! is_array( $group ) || ! isset( $group[ $swatches_key ] ) || ! is_array( $group[ $swatches_key ] ) ) {
				continue;
			}

			$swatches = [];

			foreach ( $group[ $swatches_key ] as $swatch ) {
				if ( ! is_array( $swatch ) || ! isset( $swatch[ $token_key ] ) || ! is_string( $swatch[ $token_key ] ) ) {
					continue;
				}

				$token          = $swatch[ $token_key ];
				$has_own        = array_key_exists( $token, $deltas );
				$template_value = $swatch[ $value_key ] ?? null;

				// A swatch this palette does not store falls back to the template's value, and the template
				// itself may not carry one — a default-palette swatch left at the baseline keeps its row but
				// stores no `$value`. The baseline answers that last case, so the row shows the color the
				// token really renders as (on a Kadence site, the theme's Style Guide color). A complement
				// worked out from the primary shows that worked-out color.
				$value = $has_own
					? $deltas[ $token ]
					: ( is_string( $template_value ) && $template_value !== '' ? $template_value : ( $baseline[ $token ] ?? '' ) );

				if ( ! $has_own && $token === Effective_Palettes::get_complement_token() && isset( $complete[ $token ] ) ) {
					$value = $complete[ $token ];
				}

				// There is something to reset exactly when the palette stores its own value — true for every
				// palette now that the default stores only the swatches it changes.
				$overridden = $has_own;

				$swatches[] = [
					$token_key   => $token,
					$label_key   => $swatch[ $label_key ] ?? $token,
					$value_key   => $value,
					'baseline'   => array_key_exists( $token, $baseline ),
					'overridden' => $overridden,
				];
			}

			$groups[] = [
				Extensions::get_group_id_key() => $group[ Extensions::get_group_id_key() ] ?? '',
				$label_key                     => $group[ $label_key ] ?? '',
				$swatches_key                  => $swatches,
			];
		}

		return [
			self::ID_PARAM     => $id,
			self::LABEL_PARAM  => $own[ $label_key ] ?? $id,
			self::GROUPS_PARAM => $groups,
		];
	}

	/**
	 * Prepare a palette node for storage: drop the presentational-only `overridden` / `baseline` flags the effective view
	 * adds to every swatch, and — for a non-default palette — reduce it to its deltas by dropping every swatch
	 * whose `$value` equals the library's default palette value for that token (and any group left empty). So a
	 * palette persists only the colors it actually changes; the rest are inherited from the default.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $node       The full palette node from the request.
	 * @param string               $slug       The token library slug.
	 * @param bool                 $is_default Whether this is the library's default palette (which keeps every swatch row;
	 *                                         {@see reduce_default_to_overrides()} then strips the values it does not need).
	 *
	 * @return array<string, mixed>
	 */
	private function prepare_for_storage( array $node, string $slug, bool $is_default ): array {
		$default      = $is_default ? [] : $this->palettes->complete_swatch_values( $this->palettes->default_palette( $slug ), $slug );
		$token_key    = Extensions::get_swatch_token_key();
		$value_key    = Sentinels::get_value_key();
		$swatches_key = Extensions::get_swatches_key();

		$node_groups = $node[ Extensions::get_groups_key() ] ?? [];
		$groups      = [];

		if ( ! is_array( $node_groups ) ) {
			$node_groups = [];
		}

		foreach ( $node_groups as $group ) {
			if ( ! is_array( $group ) || ! isset( $group[ $swatches_key ] ) || ! is_array( $group[ $swatches_key ] ) ) {
				continue;
			}

			$swatches = [];

			foreach ( $group[ $swatches_key ] as $swatch ) {
				if ( ! is_array( $swatch ) || ! isset( $swatch[ $token_key ] ) || ! is_string( $swatch[ $token_key ] ) ) {
					continue;
				}

				unset( $swatch['overridden'], $swatch['baseline'] );

				$token = $swatch[ $token_key ];
				$value = $swatch[ $value_key ] ?? null;

				// The default palette keeps every swatch ROW — it is the structure template, and dropping a row
				// there removes it from every palette. A non-default palette keeps only swatches that differ
				// from the default value (the deltas).
				if ( $is_default || ! ( array_key_exists( $token, $default ) && $default[ $token ] === $value ) ) {
					$swatches[] = $swatch;
				}
			}

			if ( $swatches !== [] ) {
				$group[ $swatches_key ] = $swatches;
				$groups[]               = $group;
			}
		}

		$node[ Extensions::get_groups_key() ] = $groups;

		return $node;
	}

	/**
	 * Validate and persist a candidate overrides document, then respond with the library's palette listing.
	 *
	 * Mirrors {@see Presets_Controller::validate_and_save()}: an empty candidate clears the library; otherwise
	 * the DTCG validator (422) and a resolver dry-run (422) gate the write, the encode is guarded (500), and
	 * the store persists it. First write to a library reports 201.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $candidate The full candidate overrides document.
	 * @param string               $id        The palette id being written, for error context.
	 * @param string               $slug      The token library slug being written.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	private function validate_and_save( array $candidate, string $id, string $slug ) {
		$status = $this->store->get_version( $slug ) !== '' ? WP_Http::OK : WP_Http::CREATED;

		if ( $candidate === [] ) {
			return $this->persist( '', $id, $status, $slug );
		}

		$result = $this->validator->validate( $candidate, Dtcg_Validator::get_context_overrides() );

		if ( ! $result->is_valid() ) {
			return new WP_Error(
				'rest_design_tokens_invalid',
				__( 'The color palette failed validation.', 'kadence-blocks' ),
				[
					'status'       => WP_Http::UNPROCESSABLE_ENTITY,
					self::ID_PARAM => $id,
					'errors'       => $result->to_array(),
				]
			);
		}

		try {
			$this->resolver->resolve_overrides( $candidate );
		} catch ( Alias_Cycle_Exception | Dangling_Alias_Exception $e ) {
			return new WP_Error(
				'rest_design_tokens_unresolvable',
				$e->getMessage(),
				[
					'status'       => WP_Http::UNPROCESSABLE_ENTITY,
					self::ID_PARAM => $id,
				]
			);
		}

		$encoded = wp_json_encode( $candidate );

		if ( $encoded === false ) {
			return new WP_Error(
				'rest_design_tokens_save_failed',
				__( 'The color palette could not be encoded.', 'kadence-blocks' ),
				[
					'status'       => WP_Http::INTERNAL_SERVER_ERROR,
					self::ID_PARAM => $id,
				]
			);
		}

		return $this->persist( $encoded, $id, $status, $slug );
	}

	/**
	 * Commit a raw document to a library and respond with the palette listing, mapping a write failure to 500.
	 *
	 * @since 3.8.0
	 *
	 * @param string $document The raw overrides-only DTCG JSON (empty string clears the library).
	 * @param string $id       The palette id being written, for error context.
	 * @param int    $status   The success status code.
	 * @param string $slug     The token library slug being written.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	private function persist( string $document, string $id, int $status, string $slug ) {
		try {
			$this->store->save_document( $document, $slug );
		} catch ( DatabaseQueryException $e ) {
			return new WP_Error(
				'rest_design_tokens_save_failed',
				__( 'The color palette could not be saved.', 'kadence-blocks' ),
				[
					'status'       => WP_Http::INTERNAL_SERVER_ERROR,
					self::ID_PARAM => $id,
				]
			);
		}

		return new WP_REST_Response( $this->prepare_items_embedded( $slug ), $status );
	}

	/**
	 * Reject a palette node whose shape is malformed: the label must be a string, groups an array, each
	 * group an object with an id / label / swatches list, and each swatch an object with a string token,
	 * a string label, and a `$value`. The swatch `$value` grammar itself is left to the DTCG validator.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $node The palette node being written.
	 * @param string               $id   The palette id, for error context.
	 *
	 * @return WP_Error|null A WP_Error when the shape is malformed, null otherwise.
	 */
	private function guard_palette_shape( array $node, string $id ): ?WP_Error {
		if ( ! is_string( $node[ Extensions::get_label_key() ] ) ) {
			return $this->invalid( $id, __( 'The palette label must be a string.', 'kadence-blocks' ) );
		}

		$groups = $node[ Extensions::get_groups_key() ];

		if ( ! is_array( $groups ) || $groups === [] ) {
			return $this->invalid( $id, __( 'A palette must define at least one color group.', 'kadence-blocks' ) );
		}

		$swatches_key = Extensions::get_swatches_key();
		$token_key    = Extensions::get_swatch_token_key();
		$value_key    = Sentinels::get_value_key();
		$label_key    = Extensions::get_label_key();

		foreach ( $groups as $group ) {
			if ( ! is_array( $group )
				|| ! isset( $group[ Extensions::get_group_id_key() ] ) || ! is_string( $group[ Extensions::get_group_id_key() ] )
				|| ! isset( $group[ $label_key ] ) || ! is_string( $group[ $label_key ] )
				|| ! isset( $group[ $swatches_key ] ) || ! is_array( $group[ $swatches_key ] )
			) {
				return $this->invalid( $id, __( 'Each color group must have an id, a label, and a swatches list.', 'kadence-blocks' ) );
			}

			foreach ( $group[ $swatches_key ] as $swatch ) {
				if ( ! is_array( $swatch )
					|| ! isset( $swatch[ $token_key ] ) || ! is_string( $swatch[ $token_key ] ) || $swatch[ $token_key ] === ''
					|| ! isset( $swatch[ $label_key ] ) || ! is_string( $swatch[ $label_key ] )
					|| ! array_key_exists( $value_key, $swatch )
				) {
					return $this->invalid( $id, __( 'Each swatch must have a token, a label, and a value.', 'kadence-blocks' ) );
				}
			}
		}

		return null;
	}

	/**
	 * Reject a palette whose swatches target something other than a real color leaf, or repeat a token:
	 * every swatch `token` must name a registered color token, and no token may appear twice within the
	 * palette. Because palette `$value`s live under `$extensions`, the resolver dry-run never sees them, so
	 * any alias `$value` target is checked here against the registry too.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $node The palette node being written.
	 * @param string               $id   The palette id, for error context.
	 *
	 * @return WP_Error|null A WP_Error when a swatch target is invalid, null otherwise.
	 */
	private function guard_swatches( array $node, string $id ): ?WP_Error {
		$token_key = Extensions::get_swatch_token_key();
		$value_key = Sentinels::get_value_key();
		$groups    = $node[ Extensions::get_groups_key() ];
		$seen      = [];

		// guard_palette_shape() runs first, so the structure below is well-formed; the is_array narrowing
		// keeps this fail-soft (and keeps static analysis honest) if it is ever called on its own.
		if ( ! is_array( $groups ) ) {
			return null;
		}

		foreach ( $groups as $group ) {
			$swatches = is_array( $group ) ? ( $group[ Extensions::get_swatches_key() ] ?? [] ) : [];

			if ( ! is_array( $swatches ) ) {
				continue;
			}

			foreach ( $swatches as $swatch ) {
				if ( ! is_array( $swatch ) || ! isset( $swatch[ $token_key ] ) || ! is_string( $swatch[ $token_key ] ) ) {
					continue;
				}

				$token = $swatch[ $token_key ];

				$definition = $this->registry->get( $token );

				if ( $definition === null || $definition->type !== 'color' ) {
					return $this->invalid(
						$id,
						sprintf( /* translators: %s: the token dot-path. */ __( 'Swatch token "%s" does not target a color.', 'kadence-blocks' ), $token )
					);
				}

				if ( isset( $seen[ $token ] ) ) {
					return $this->invalid(
						$id,
						sprintf( /* translators: %s: the token dot-path. */ __( 'Token "%s" appears more than once in the palette.', 'kadence-blocks' ), $token )
					);
				}

				$seen[ $token ] = true;

				$value = $swatch[ $value_key ] ?? null;

				if ( is_string( $value ) && Alias::is_alias( $value ) && ! $this->registry->has( Alias::path_of( $value ) ) ) {
					return $this->invalid(
						$id,
						sprintf( /* translators: %s: the alias target. */ __( 'Swatch value aliases a token that does not exist: "%s".', 'kadence-blocks' ), Alias::path_of( $value ) )
					);
				}
			}
		}

		return null;
	}

	/**
	 * Reject a DEFAULT-palette write that drops a swatch the shipped baseline defines. Those swatches are the
	 * permanent set: the default palette is the structure template every other palette is projected from, so a
	 * row removed there disappears from every palette at once and can never be recovered. A baseline swatch is
	 * reverted (DELETE /palettes/{id}/swatches/{token}), never removed; only a user-added swatch is deletable.
	 *
	 * Scoped to the default palette on purpose: a non-default palette is stored as DELTAS, so it legitimately
	 * omits most baseline tokens, and applying this guard there would reject every ordinary palette write.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $node The palette node being written.
	 * @param string               $id   The palette id, for error context.
	 * @param string               $slug The token library slug.
	 *
	 * @return WP_Error|null A WP_Error when a baseline swatch is missing, null otherwise.
	 */
	private function guard_baseline_swatches( array $node, string $id, string $slug ): ?WP_Error {
		if ( $id !== $this->palettes->default_palette( $slug ) ) {
			return null;
		}

		$present = array_flip( $this->swatch_tokens_of_node( $node ) );

		foreach ( array_keys( $this->palettes->baseline_swatch_values() ) as $token ) {
			if ( isset( $present[ $token ] ) ) {
				continue;
			}

			return new WP_Error(
				'rest_design_tokens_locked',
				sprintf(
					/* translators: %s: the token dot-path. */
					__( 'Swatch "%s" is part of the shipped palette and cannot be removed.', 'kadence-blocks' ),
					$token
				),
				[
					'status'          => WP_Http::FORBIDDEN,
					self::ID_PARAM    => $id,
					self::TOKEN_PARAM => $token,
				]
			);
		}

		return null;
	}

	/**
	 * Every swatch token a palette node carries, across all of its groups, in order.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $node The palette node.
	 *
	 * @return string[] The swatch token dot-paths.
	 */
	private function swatch_tokens_of_node( array $node ): array {
		$swatches_key = Extensions::get_swatches_key();
		$token_key    = Extensions::get_swatch_token_key();
		$groups       = $node[ Extensions::get_groups_key() ] ?? [];
		$tokens       = [];

		if ( ! is_array( $groups ) ) {
			return $tokens;
		}

		foreach ( $groups as $group ) {
			if ( ! is_array( $group ) || ! isset( $group[ $swatches_key ] ) || ! is_array( $group[ $swatches_key ] ) ) {
				continue;
			}

			foreach ( $group[ $swatches_key ] as $swatch ) {
				if ( is_array( $swatch ) && isset( $swatch[ $token_key ] ) && is_string( $swatch[ $token_key ] ) ) {
					$tokens[] = $swatch[ $token_key ];
				}
			}
		}

		return $tokens;
	}

	/**
	 * Guard a single swatch (a token + value), reusing the palette-write swatch guards: the token must target
	 * a registered color, and an aliased value must name a token that exists.
	 *
	 * @since 3.8.0
	 *
	 * @param string $id    The palette id, for error context.
	 * @param string $token The swatch token dot-path.
	 * @param string $value The swatch value (literal color or alias).
	 *
	 * @return WP_Error|null A WP_Error when the swatch is invalid, null otherwise.
	 */
	private function guard_swatch_target( string $id, string $token, string $value ): ?WP_Error {
		return $this->guard_swatches(
			[
				Extensions::get_groups_key() => [
					[
						Extensions::get_group_id_key() => 'swatch',
						Extensions::get_label_key()    => 'swatch',
						Extensions::get_swatches_key() => [
							[
								Extensions::get_swatch_token_key() => $token,
								Extensions::get_label_key() => '',
								Sentinels::get_value_key() => $value,
							],
						],
					],
				],
			],
			$id
		);
	}

	/**
	 * Upsert one or more fields of a swatch into a palette node: update the sent fields in place if the
	 * palette already carries the token, otherwise add it to the group the default template places it
	 * in (creating that group if the palette does not have it yet). Returns the updated node.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed>  $node   The palette node.
	 * @param string                $token  The swatch token dot-path.
	 * @param array<string, string> $fields The fields to set — `value` and/or `label`, at least one present.
	 * @param string                $slug   The token library slug.
	 *
	 * @return array<string, mixed>
	 */
	private function set_swatch_fields_in_node( array $node, string $token, array $fields, string $slug ): array {
		$groups_key   = Extensions::get_groups_key();
		$swatches_key = Extensions::get_swatches_key();
		$token_key    = Extensions::get_swatch_token_key();
		$value_key    = Sentinels::get_value_key();
		$label_key    = Extensions::get_label_key();
		$group_id_key = Extensions::get_group_id_key();

		$groups = isset( $node[ $groups_key ] ) && is_array( $node[ $groups_key ] ) ? array_values( $node[ $groups_key ] ) : [];

		foreach ( $groups as $gi => $group ) {
			if ( ! is_array( $group ) || ! isset( $group[ $swatches_key ] ) || ! is_array( $group[ $swatches_key ] ) ) {
				continue;
			}

			foreach ( array_values( $group[ $swatches_key ] ) as $si => $swatch ) {
				if ( is_array( $swatch ) && ( $swatch[ $token_key ] ?? null ) === $token ) {
					$groups[ $gi ][ $swatches_key ] = array_values( $group[ $swatches_key ] );

					if ( array_key_exists( 'value', $fields ) ) {
						$groups[ $gi ][ $swatches_key ][ $si ][ $value_key ] = $fields['value'];
					}

					if ( array_key_exists( 'label', $fields ) ) {
						$groups[ $gi ][ $swatches_key ][ $si ][ $label_key ] = $fields['label'];
					}

					$node[ $groups_key ] = $groups;

					return $node;
				}
			}
		}

		[ $group_id, $group_label, $template_label ] = $this->template_slot_for( $token, $slug );

		$swatch = [
			$token_key => $token,
			$label_key => $fields['label'] ?? $template_label,
			$value_key => $fields['value'] ?? '',
		];

		foreach ( $groups as $gi => $group ) {
			if ( is_array( $group ) && ( $group[ $group_id_key ] ?? null ) === $group_id ) {
				$swatches   = isset( $group[ $swatches_key ] ) && is_array( $group[ $swatches_key ] ) ? array_values( $group[ $swatches_key ] ) : [];
				$swatches[] = $swatch;

				$groups[ $gi ][ $swatches_key ] = $swatches;
				$node[ $groups_key ]            = $groups;

				return $node;
			}
		}

		$groups[] = [
			$group_id_key => $group_id,
			$label_key    => $group_label,
			$swatches_key => [ $swatch ],
		];

		$node[ $groups_key ] = $groups;

		return $node;
	}

	/**
	 * Remove a swatch from a palette node by token, dropping a group left empty. Returns the updated node.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $node  The palette node.
	 * @param string               $token The swatch token dot-path.
	 *
	 * @return array<string, mixed>
	 */
	private function remove_swatch_from_node( array $node, string $token ): array {
		$groups_key   = Extensions::get_groups_key();
		$swatches_key = Extensions::get_swatches_key();
		$token_key    = Extensions::get_swatch_token_key();

		$groups = isset( $node[ $groups_key ] ) && is_array( $node[ $groups_key ] ) ? array_values( $node[ $groups_key ] ) : [];
		$out    = [];

		foreach ( $groups as $group ) {
			if ( ! is_array( $group ) || ! isset( $group[ $swatches_key ] ) || ! is_array( $group[ $swatches_key ] ) ) {
				$out[] = $group;

				continue;
			}

			$swatches = [];

			foreach ( $group[ $swatches_key ] as $swatch ) {
				if ( is_array( $swatch ) && ( $swatch[ $token_key ] ?? null ) === $token ) {
					continue;
				}

				$swatches[] = $swatch;
			}

			if ( $swatches !== [] ) {
				$group[ $swatches_key ] = $swatches;
				$out[]                  = $group;
			}
		}

		$node[ $groups_key ] = $out;

		return $node;
	}

	/**
	 * The default palette's group id, group label, and swatch label for a token — the template a new swatch is
	 * placed under when the edited palette does not carry the token yet. Falls back to a generic Accent group
	 * when the template does not group the token (it is still a valid color, since the guard passed).
	 *
	 * @since 3.8.0
	 *
	 * @param string $token The swatch token dot-path.
	 * @param string $slug  The token library slug.
	 *
	 * @return array{0:string,1:string,2:string} The group id, group label, and swatch label.
	 */
	private function template_slot_for( string $token, string $slug ): array {
		$template     = $this->palettes->palette( $this->palettes->default_palette( $slug ), $slug ) ?? [];
		$groups_key   = Extensions::get_groups_key();
		$swatches_key = Extensions::get_swatches_key();
		$token_key    = Extensions::get_swatch_token_key();
		$label_key    = Extensions::get_label_key();
		$group_id_key = Extensions::get_group_id_key();

		$groups = isset( $template[ $groups_key ] ) && is_array( $template[ $groups_key ] ) ? $template[ $groups_key ] : [];

		foreach ( $groups as $group ) {
			if ( ! is_array( $group ) || ! isset( $group[ $swatches_key ] ) || ! is_array( $group[ $swatches_key ] ) ) {
				continue;
			}

			foreach ( $group[ $swatches_key ] as $swatch ) {
				if ( is_array( $swatch ) && ( $swatch[ $token_key ] ?? null ) === $token ) {
					return [
						Cast::to_string( $group[ $group_id_key ] ?? 'accent' ),
						Cast::to_string( $group[ $label_key ] ?? '' ),
						Cast::to_string( $swatch[ $label_key ] ?? $token ),
					];
				}
			}
		}

		return [ 'accent', __( 'Accent', 'kadence-blocks' ), $token ];
	}

	/**
	 * Replace a palette's stored node wholesale: remove the old node from the overrides, then merge the new one
	 * in. The remove-then-merge avoids index-merging the rebuilt groups list into the previous stored node, and
	 * runs the same validate-and-save path as the full palette write.
	 *
	 * @since 3.8.0
	 *
	 * @param string               $slug The token library slug.
	 * @param string               $id   The palette id.
	 * @param array<string, mixed> $node The rebuilt palette node.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	private function write_palette_node( string $slug, string $id, array $node ) {
		if ( $id === $this->palettes->default_palette( $slug ) ) {
			$node = $this->reduce_default_to_overrides( $node, $id, $slug );
		}

		$document  = $this->mutator->remove_by_keys( $this->stored_document( $slug ), $this->palette_keys( $id ) );
		$candidate = $this->mutator->merge( $document, $this->palette_partial( $id, $node ) );

		return $this->validate_and_save( $candidate, $id, $slug );
	}

	/**
	 * Reduce the DEFAULT palette to the swatches it actually changes: drop `$value` from every swatch whose
	 * color already matches the baseline, keeping the row itself. The row has to stay — it is part of the
	 * permanent swatch set {@see guard_baseline_swatches()} protects, and the stored groups list REPLACES the
	 * baseline's once anything is stored ({@see Effective_Palettes::without_superseded_groups()}), so a
	 * dropped row would vanish from every palette.
	 *
	 * Without this a single edit freezes the whole palette. Every write path rebuilds the node from
	 * {@see Effective_Palettes::palette()}, which is the baseline merged with the overrides, so the node
	 * carries a `$value` for all 17 swatches whether or not the site chose any of them. Persisting those
	 * turns each one into a stored override: the palette stops following the baseline, and on a Kadence site
	 * that means it stops following the theme's Style Guide — change a color in the Customizer afterwards and
	 * the Style Library still shows the color that was captured at write time.
	 *
	 * Runs here rather than in {@see prepare_for_storage()} because the swatch endpoints reach the store
	 * without passing through that method; this is the one choke point all three write paths share.
	 *
	 * A complement worked out from the primary is not compared with the baseline. It is dropped when it
	 * matches the color worked out from the primary being written, or when the site hadn't stored one and it
	 * is unchanged from what it showed before this write (a primary change leaves the old worked-out color in
	 * the node). Any other color, the shipped one included, is a choice to keep.
	 *
	 * @since 3.8.0
	 * @since 3.9.1 Keeps a complement the site picked, and drops one that only follows the primary.
	 *
	 * @param array<string, mixed> $node The default palette node being written.
	 * @param string               $id   The default palette id.
	 * @param string               $slug The token library slug.
	 *
	 * @return array<string, mixed>
	 */
	private function reduce_default_to_overrides( array $node, string $id, string $slug ): array {
		$baseline     = $this->palettes->baseline_swatch_values();
		$groups_key   = Extensions::get_groups_key();
		$swatches_key = Extensions::get_swatches_key();
		$token_key    = Extensions::get_swatch_token_key();
		$value_key    = Sentinels::get_value_key();

		$groups = $node[ $groups_key ] ?? [];

		if ( ! is_array( $groups ) ) {
			return $node;
		}

		$values = $baseline;

		foreach ( $groups as $group ) {
			foreach ( is_array( $group ) && is_array( $group[ $swatches_key ] ?? null ) ? $group[ $swatches_key ] : [] as $swatch ) {
				if ( is_array( $swatch ) && is_string( $swatch[ $token_key ] ?? null ) && is_string( $swatch[ $value_key ] ?? null ) ) {
					$values[ $swatch[ $token_key ] ] = $swatch[ $value_key ];
				}
			}
		}

		$complement = Effective_Palettes::get_complement_token();
		$derives    = $this->palettes->derives_complement();
		$follows    = $this->palettes->is_derived_complement( $values )
			|| ( ! array_key_exists( $complement, $this->palettes->stored_swatch_values( $id, $slug ) )
				&& ( $values[ $complement ] ?? null ) === ( $this->palettes->complete_swatch_values( $id, $slug )[ $complement ] ?? null ) );

		foreach ( $groups as $gi => $group ) {
			if ( ! is_array( $group ) || ! isset( $group[ $swatches_key ] ) || ! is_array( $group[ $swatches_key ] ) ) {
				continue;
			}

			foreach ( $group[ $swatches_key ] as $si => $swatch ) {
				if ( ! is_array( $swatch ) || ! isset( $swatch[ $token_key ] ) || ! is_string( $swatch[ $token_key ] ) ) {
					continue;
				}

				$token = $swatch[ $token_key ];

				if ( $derives && $token === $complement ) {
					if ( ! $follows ) {
						continue;
					}
				} elseif ( ! array_key_exists( $token, $baseline ) || ( $swatch[ $value_key ] ?? null ) !== $baseline[ $token ] ) {
					continue;
				}

				unset( $groups[ $gi ][ $swatches_key ][ $si ][ $value_key ] );
			}
		}

		$node[ $groups_key ] = $groups;

		return $node;
	}

	/**
	 * The same shape `GET /palettes?_embed` produces, built directly rather than through a request
	 * object — every write response uses this unconditionally, so the client never needs a follow-up
	 * GET to see the fresh state a write just produced.
	 *
	 * @since 3.8.0
	 *
	 * @param string $slug The token library slug.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function prepare_items_embedded( string $slug ): array {
		return array_map(
			function ( array $row ) use ( $slug ) {
				$row['_embedded'] = [
					'self' => [ $this->effective_view( Cast::to_string( $row[ self::ID_PARAM ] ), $slug ) ],
				];

				return $row;
			},
			$this->prepare_items( $slug )
		);
	}

	/**
	 * The palette listing for a library: every palette as a flat row carrying its id, label, and which
	 * of the three per-library facts it represents (`$default`, `$current`, user-created) — a flat
	 * top-level array, not a wrapper object, because WP core's `_embed` resolution only walks
	 * TOP-LEVEL collection items, never something nested inside a wrapper key. A row's `is_default`/
	 * `is_current`/`user_created` flags carry what the old `{$default, $current, palettes,
	 * userCreated}` wrapper used to convey at the collection level.
	 *
	 * @since 3.8.0
	 *
	 * @param string $slug The token library slug.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function prepare_items( string $slug ): array {
		$section      = $this->palettes->section( $slug );
		$default_id   = $this->palettes->default_palette( $slug );
		$current_id   = $this->palettes->current( $slug );
		$user_created = $this->palettes->user_created( $slug );
		$rows         = [];

		foreach ( $this->palettes->palette_ids( $slug ) as $palette_id ) {
			$node = $section[ $palette_id ] ?? [];

			$rows[] = [
				self::ID_PARAM    => $palette_id,
				self::LABEL_PARAM => is_array( $node ) ? ( $node[ Extensions::get_label_key() ] ?? '' ) : '',
				'is_default'      => $palette_id === $default_id,
				'is_current'      => $palette_id === $current_id,
				'user_created'    => in_array( $palette_id, $user_created, true ),
			];
		}

		return $rows;
	}

	/**
	 * The decoded stored overrides document for a library (the raw palettes source), or an empty array.
	 *
	 * @since 3.8.0
	 *
	 * @param string $slug The token library slug.
	 *
	 * @return array<string, mixed>
	 */
	private function stored_document( string $slug ): array {
		return $this->palettes->raw( $slug );
	}

	/**
	 * A partial document nesting one palette node under the colorPalettes section, for a deep-merge.
	 *
	 * @since 3.8.0
	 *
	 * @param string               $id   The palette id.
	 * @param array<string, mixed> $node The palette node.
	 *
	 * @return array<string, mixed>
	 */
	private function palette_partial( string $id, array $node ): array {
		return $this->color_palettes_partial( [ $id => $node ] );
	}

	/**
	 * A partial document nesting a colorPalettes pointer (`$default` / `$current`) for a deep-merge.
	 *
	 * @since 3.8.0
	 *
	 * @param string $key The pointer key.
	 * @param string $id  The palette id the pointer names.
	 *
	 * @return array<string, mixed>
	 */
	private function pointer_partial( string $key, string $id ): array {
		return $this->color_palettes_partial( [ $key => $id ] );
	}

	/**
	 * Nest a colorPalettes subtree under `$extensions.<namespace>.colorPalettes` for a deep-merge.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $subtree The colorPalettes subtree to nest.
	 *
	 * @return array<string, mixed>
	 */
	private function color_palettes_partial( array $subtree ): array {
		return [
			Extensions::get_extensions_key() => [
				Extensions::get_namespace() => [
					Extensions::get_section_color_palettes() => $subtree,
				],
			],
		];
	}

	/**
	 * The literal key path to a palette node, for {@see Mutator::remove_by_keys()} — literal keys so the
	 * dotted namespace segment is not split.
	 *
	 * @since 3.8.0
	 *
	 * @param string $id The palette id.
	 *
	 * @return string[]
	 */
	private function palette_keys( string $id ): array {
		return [
			Extensions::get_extensions_key(),
			Extensions::get_namespace(),
			Extensions::get_section_color_palettes(),
			$id,
		];
	}

	/**
	 * The groups payload from the request as an array (an absent / non-array payload becomes an empty list,
	 * which the shape guard rejects).
	 *
	 * @since 3.8.0
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return array<int, mixed>
	 */
	private function groups_param( WP_REST_Request $request ): array {
		$groups = $request->get_param( self::GROUPS_PARAM );

		return is_array( $groups ) ? array_values( $groups ) : [];
	}

	/**
	 * The token library a request targets: the `library` parameter when it names a known library, otherwise the
	 * active library. An unknown or absent `library` falls back rather than 404ing.
	 *
	 * @since 3.8.0
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return string
	 */
	private function slug( WP_REST_Request $request ): string {
		$library = Cast::to_string( $request->get_param( self::LIBRARY_PARAM ) );

		if ( $library !== '' && ( $library === Token_Store::default_slug() || $this->store->exists( $library ) ) ) {
			return $library;
		}

		return $this->active->get();
	}

	/**
	 * A 404 for a palette a library does not define.
	 *
	 * @since 3.8.0
	 *
	 * @param string $id The palette id.
	 *
	 * @return WP_Error
	 */
	private function not_found( string $id ): WP_Error {
		return new WP_Error(
			'rest_design_tokens_not_found',
			__( 'Sorry, that palette does not exist.', 'kadence-blocks' ),
			[
				'status'       => WP_Http::NOT_FOUND,
				self::ID_PARAM => $id,
			]
		);
	}

	/**
	 * A 422 for a malformed palette write.
	 *
	 * @since 3.8.0
	 *
	 * @param string $id      The palette id.
	 * @param string $message The human-readable reason.
	 *
	 * @return WP_Error
	 */
	private function invalid( string $id, string $message ): WP_Error {
		return new WP_Error(
			'rest_design_tokens_invalid',
			$message,
			[
				'status'       => WP_Http::UNPROCESSABLE_ENTITY,
				self::ID_PARAM => $id,
			]
		);
	}

	/**
	 * The optional token-library argument shared by every route.
	 *
	 * @since 3.8.0
	 *
	 * @return array<string, mixed>
	 */
	private function library_param(): array {
		return [
			'description'       => __( 'Optional token library slug to target; defaults to the active library.', 'kadence-blocks' ),
			'type'              => 'string',
			'required'          => false,
			'pattern'           => '^[\w-]+$',
			'sanitize_callback' => 'sanitize_key',
		];
	}

	/**
	 * The arguments for the single-palette read / delete routes: the palette id plus the optional library.
	 *
	 * @since 3.8.0
	 *
	 * @return array<string, mixed>
	 */
	private function get_id_params(): array {
		return [
			self::ID_PARAM      => [
				'description'       => __( 'The palette id.', 'kadence-blocks' ),
				'type'              => 'string',
				'required'          => true,
				'pattern'           => '^[\w-]+$',
				'sanitize_callback' => 'sanitize_key',
			],
			self::LIBRARY_PARAM => $this->library_param(),
		];
	}

	/**
	 * The arguments for the palette write route: id, label, groups, and the optional library.
	 *
	 * @since 3.8.0
	 *
	 * @return array<string, mixed>
	 */
	private function get_write_params(): array {
		return array_merge(
			$this->get_id_params(),
			[
				self::LABEL_PARAM  => [
					'description' => __( 'The palette label.', 'kadence-blocks' ),
					'type'        => 'string',
					'required'    => true,
				],
				self::GROUPS_PARAM => [
					'description' => __( 'The ordered color groups, each an ordered list of swatches.', 'kadence-blocks' ),
					'type'        => 'array',
					'required'    => true,
				],
			]
		);
	}

	/**
	 * The arguments for the single-swatch routes: the palette id, the token dot-path, and the optional library.
	 * The token keeps its dots (a dot-path), so it is sanitized with sanitize_text_field rather than the id's
	 * sanitize_key, which would strip them.
	 *
	 * @since 3.8.0
	 *
	 * @return array<string, mixed>
	 */
	private function get_swatch_params(): array {
		return array_merge(
			$this->get_id_params(),
			[
				self::TOKEN_PARAM => [
					'description'       => __( 'The swatch token dot-path.', 'kadence-blocks' ),
					'type'              => 'string',
					'required'          => true,
					'pattern'           => '^[\w.-]+$',
					'sanitize_callback' => 'sanitize_text_field',
				],
			]
		);
	}

	/**
	 * The arguments for the swatch write route: the value and/or the structural label, each optional
	 * individually — `update_swatch()` requires at least one to be present.
	 *
	 * @since 3.8.0
	 *
	 * @return array<string, mixed>
	 */
	private function get_swatch_write_params(): array {
		return array_merge(
			$this->get_swatch_params(),
			[
				Sentinels::get_value_key() => [
					'description' => __( 'The swatch value: a literal color or a {dot.path} alias.', 'kadence-blocks' ),
					'type'        => 'string',
				],
				self::LABEL_PARAM          => [
					'description' => __( 'The swatch\'s structural label. Only valid when {id} is the library\'s default palette — labels are defined once, not per palette.', 'kadence-blocks' ),
					'type'        => 'string',
				],
			]
		);
	}

	/**
	 * The arguments for the `$current` write route: the target palette id plus the optional library.
	 *
	 * @since 3.8.0
	 *
	 * @return array<string, mixed>
	 */
	private function get_current_params(): array {
		return [
			self::CURRENT_PARAM => [
				'description'       => __( 'The palette id to make current.', 'kadence-blocks' ),
				'type'              => 'string',
				'required'          => true,
				'pattern'           => '^[\w-]+$',
				'sanitize_callback' => 'sanitize_key',
			],
			self::LIBRARY_PARAM => $this->library_param(),
		];
	}
}
