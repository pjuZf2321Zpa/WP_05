<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocks\Design_Tokens\Registry;

use KadenceWP\KadenceBlocks\Design_Tokens\Database\Token_Store;
use KadenceWP\KadenceBlocks\Design_Tokens\Registry\Baseline\Json_Baseline_Document;
use KadenceWP\KadenceBlocks\Design_Tokens\Registry\Contracts\Baseline_Document;
use KadenceWP\KadenceBlocks\StellarWP\ProphecyMonorepo\Container\Contracts\Provider as Provider_Contract;
use KadenceWP\KadenceBlocks\Design_Tokens\Document\Mutator;
use KadenceWP\KadenceBlocks\Design_Tokens\Registry\Baseline\Theme_Button_Presets_Baseline_Document;
use KadenceWP\KadenceBlocks\Design_Tokens\Registry\Baseline\Theme_Style_Guide_Baseline_Document;
use KadenceWP\KadenceBlocks\Design_Tokens\Theme_Buttons\Theme_Button_Styles_Overlay;
use KadenceWP\KadenceBlocks\Design_Tokens\Theme_Style_Guide\Style_Guide_Overlay;

/**
 * Wires the Token Registry: binds the singleton and the shipped baseline, defines the global helper,
 * registers the token declarations, then runs the fail-closed baseline guard once all tokens are in.
 *
 * @since 3.8.0
 */
final class Provider extends Provider_Contract {

	/**
	 * @since 3.8.0
	 *
	 * @return void
	 */
	public function register(): void {
		$this->container->singleton( Token_Registry::class, Token_Registry::class );

		// Bind the baseline contract to the shipped, read-only DTCG document (baseline.json), decorated with
		// the active theme's Style Guide so resolution starts from the site's existing look, then with the
		// theme's button styles as Button presets. Every declared token must still have a matching shipped
		// entry or the guard fails closed — both decorators' has() delegate. The version keys the
		// decoded-document cache, so a baseline shipped with a new plugin build invalidates it. Bound lazily:
		// the theme and the declarations are not loaded when providers register, and the first document()
		// read happens on init or later.
		$this->container->singleton(
			Baseline_Document::class,
			function (): Baseline_Document {
				/** @var Style_Guide_Overlay $overlay */
				$overlay = $this->container->get( Style_Guide_Overlay::class );
				/** @var Theme_Button_Styles_Overlay $buttons */
				$buttons = $this->container->get( Theme_Button_Styles_Overlay::class );
				/** @var Mutator $mutator */
				$mutator = $this->container->get( Mutator::class );

				return new Theme_Button_Presets_Baseline_Document(
					new Theme_Style_Guide_Baseline_Document(
						new Json_Baseline_Document( __DIR__ . '/Baseline/baseline.json', KADENCE_BLOCKS_VERSION ),
						$overlay,
						$mutator
					),
					$buttons
				);
			}
		);

		$this->load_helper();

		// Declarations carry __() labels/groups, so they must not be evaluated before init or WordPress
		// fires the _load_textdomain_just_in_time notice. register() runs on plugins_loaded, so defer the
		// declaration load (and the guard that runs once tokens are in) to init. Early priority keeps the
		// registry populated before any consumer (admin UI, projectors, resolver) reads it.
		//
		// The guard validates the registered tokens, so it must run after register_declarations. The
		// later priority makes that ordering explicit rather than relying on same-priority insertion order.
		//
		// The guard is one-shot at init:1 — v1 is central-declarations-only, so tokens declared by
		// third parties on a later hook (init:2+) skip baseline validation and is_active() is not
		// re-checked. Re-validating late registrations is out of scope until the real baseline lands.
		add_action( 'init', [ $this, 'register_declarations' ], 0 );
		add_action( 'init', [ $this, 'sync_user_primitives' ], 0 );
		add_action( 'init', [ $this, 'guard_baseline' ], 1 );
		add_action( Token_Store::changed_action(), [ $this, 'sync_user_primitives_on_change' ], 0 );
	}

	/**
	 * Define the public global helper. Always safe — it only declares functions; third-party callers
	 * use it on their own hooks once the kadence_blocks() accessor exists.
	 *
	 * @since 3.8.0
	 *
	 * @return void
	 */
	private function load_helper(): void {
		require_once __DIR__ . '/../functions.php';
	}

	/**
	 * The single declaration point — registers each declared token / preset bindings against the registry.
	 *
	 * Reads declarations.php as data and registers via the container. Hooked on init (priority 0) because
	 * declarations carry __() strings that must not resolve before the textdomain is available.
	 *
	 * @since 3.8.0
	 *
	 * @return void
	 */
	public function register_declarations(): void {
		/** @var Token_Registry $registry */
		$registry     = $this->container->get( Token_Registry::class );
		$declarations = require __DIR__ . '/declarations.php';

		foreach ( $declarations['tokens'] as $token ) {
			$registry->register( $token );
		}

		foreach ( $declarations['preset_bindings'] as $declaration ) {
			$registry->register_preset_bindings( $declaration );
		}
	}

	/**
	 * @since 3.8.0
	 *
	 * @return void
	 */
	public function sync_user_primitives(): void {
		/** @var User_Primitive_Registrar $registrar */
		$registrar = $this->container->get( User_Primitive_Registrar::class );
		$registrar->sync();
	}

	/**
	 * Every stored library is synced regardless of which one changed or which one is active — the
	 * multi-library projection renders every library, so every library's user primitives must stay
	 * registered.
	 *
	 * @since 3.8.0
	 *
	 * @return void
	 */
	public function sync_user_primitives_on_change(): void {
		/** @var User_Primitive_Registrar $registrar */
		$registrar = $this->container->get( User_Primitive_Registrar::class );
		$registrar->sync();
	}

	/**
	 * @since 3.8.0
	 *
	 * @return void
	 */
	public function guard_baseline(): void {
		/** @var Baseline_Guard $guard */
		$guard = $this->container->get( Baseline_Guard::class );
		$guard->run();
	}
}
