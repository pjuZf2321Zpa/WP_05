<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocks\Design_Tokens\Registry;

use InvalidArgumentException;
use KadenceWP\KadenceBlocks\Design_Tokens\Projection\Adapter\Contracts\Adapter_Interface;
use KadenceWP\KadenceBlocks\Design_Tokens\Registry\Contracts\Baseline_Document;

/**
 * The single declaration point for design tokens. Holds structure only — never values.
 *
 * Every projector and the admin UI read this one registry, so declaring a token once here makes it
 * reach the custom UI, the Kadence palette and the Site Editor without a
 * second source of truth.
 *
 * Resolved as a singleton from KB's container; tokens are declared during the module's Provider boot
 * via kadence_blocks_register_design_token().
 *
 * @since 3.8.0
 */
final class Token_Registry {

	/** @var array<string, Token_Definition> Keyed by token id, insertion-ordered. */
	private array $tokens = [];

	/** @var array<string, Preset_Bindings> The preset bindings a block accepts, keyed by block name. */
	private array $preset_bindings = [];

	/** @var array<string, Adapter_Interface> Keyed by block name. */
	private array $adapters = [];

	/**
	 * Whether token projection is active. Flipped off by the fail-closed guard so projectors and the
	 * UI surface fall back to existing KB behavior rather than projecting a partial/broken set.
	 *
	 * @var bool
	 */
	private bool $active = true;

	/**
	 * Register a user-created primitive. Throws when the id is already held by a non-user-created token.
	 *
	 * $group must already be resolved to its current-locale label — this method never calls
	 * group_label_for() itself; see User_Primitive_Registrar::register_entry(), the one caller with
	 * a logger to report an unresolvable $group_key.
	 *
	 * @since 3.8.0
	 *
	 * @param string $id
	 * @param string $type
	 * @param string $label
	 * @param string $group     Already-resolved, current-locale group label. Empty for ungrouped.
	 * @param string $group_key Stable machine key the group label was resolved from. Empty for ungrouped.
	 *
	 * @throws \RuntimeException When the id belongs to a system registration.
	 *
	 * @return void
	 */
	public function register_user_primitive( string $id, string $type, string $label = '', string $group = '', string $group_key = '' ): void {
		if ( isset( $this->tokens[ $id ] ) && ! $this->tokens[ $id ]->is_user_created() ) {
			throw new \RuntimeException(
				sprintf( 'Cannot register user primitive "%s": id is already registered as a system token.', $id )
			);
		}

		$this->tokens[ $id ] = Token_Definition::from_user_primitive( $id, $type, $label, $group, $group_key );
	}

	/**
	 * Remove a user-created primitive. Only removes the entry when it is user-created.
	 * No-op when the id is absent or belongs to a system token.
	 *
	 * @since 3.8.0
	 *
	 * @param string $id
	 *
	 * @return void
	 */
	public function deregister_user_primitive( string $id ): void {
		if ( isset( $this->tokens[ $id ] ) && $this->tokens[ $id ]->is_user_created() ) {
			unset( $this->tokens[ $id ] );
		}
	}

	/**
	 * @since 3.8.0
	 *
	 * @return string[]
	 */
	public function user_created_ids(): array {
		return array_keys(
			array_filter(
				$this->tokens,
				static fn( Token_Definition $t ): bool => $t->is_user_created()
			)
		);
	}

	/**
	 * Register a single token from its declaration array.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $definition See Token_Definition::from_array().
	 *
	 * @return void
	 */
	public function register( array $definition ): void {
		$token = Token_Definition::from_array( $definition );

		$this->tokens[ $token->id ] = $token;
	}

	/**
	 * Register a block's preset bindings — its bindable surface and picker label. One preset-bindings registration per
	 * block; a later registration for the same block replaces the earlier one.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $declaration See Preset_Bindings::from_array().
	 *
	 * @return void
	 */
	public function register_preset_bindings( array $declaration ): void {
		$preset_bindings = Preset_Bindings::from_array( $declaration );

		$this->preset_bindings[ $preset_bindings->block ] = $preset_bindings;
	}

	/**
	 * Register a per-block adapter — a named transform keyed to the Kadence Blocks block type it adapts.
	 * At most one adapter per block; a later registration for the same block replaces the earlier one.
	 *
	 * @since 3.8.0
	 *
	 * @param Adapter_Interface $adapter The adapter to register.
	 *
	 * @throws InvalidArgumentException When the adapter declares no block (an empty BLOCK const).
	 *
	 * @return void
	 */
	public function register_adapter( Adapter_Interface $adapter ): void {
		$block = $adapter->get_block();

		// A concrete adapter that forgets to override BLOCK would register under the empty key and silently
		// never match, so its apply() would never run. Fail loudly so the misconfiguration surfaces.
		if ( $block === '' ) {
			throw new InvalidArgumentException(
				sprintf( 'Adapter %s must override the BLOCK constant with the block type it adapts.', get_class( $adapter ) )
			);
		}

		$this->adapters[ $block ] = $adapter;
	}

	// ---- Lookups consumed by projectors and the UI ------------------------------------------------

	/**
	 * All registered tokens, keyed by id in insertion order.
	 *
	 * @since 3.8.0
	 *
	 * @return array<string, Token_Definition>
	 */
	public function all(): array {
		return $this->tokens;
	}

	/**
	 * A single token by id, or null when it is not registered.
	 *
	 * @since 3.8.0
	 *
	 * @param string $id The token id.
	 *
	 * @return Token_Definition|null
	 */
	public function get( string $id ): ?Token_Definition {
		return $this->tokens[ $id ] ?? null;
	}

	/**
	 * Whether a token is registered for the given id.
	 *
	 * @since 3.8.0
	 *
	 * @param string $id The token id.
	 *
	 * @return bool
	 */
	public function has( string $id ): bool {
		return isset( $this->tokens[ $id ] );
	}

	/**
	 * @since 3.8.0
	 *
	 * @param string $type DTCG $type, e.g. "color".
	 *
	 * @return array<string, Token_Definition>
	 */
	public function by_type( string $type ): array {
		return array_filter(
			$this->tokens,
			static function ( Token_Definition $t ) use ( $type ): bool {
				return $t->type === $type;
			}
		);
	}

	/**
	 * Tokens that declare a given projection target, e.g. all tokens with a "kadence_slot" projection.
	 *
	 * @since 3.8.0
	 *
	 * @param string $projection Projection id.
	 *
	 * @return array<string, Token_Definition>
	 */
	public function by_projection( string $projection ): array {
		return array_filter(
			$this->tokens,
			static function ( Token_Definition $t ) use ( $projection ): bool {
				return $t->has_projection( $projection );
			}
		);
	}

	/**
	 * The preset bindings a block registers, or null when it registers none. Both the
	 * picker-driven and the preset (no-picker) projectors read this; distinguish the two by their
	 * `label` (picker-driven preset bindings declare one, no-picker preset bindings do not).
	 *
	 * @since 3.8.0
	 *
	 * @param string $block The block name, e.g. "kadence/singlebtn".
	 *
	 * @return Preset_Bindings|null
	 */
	public function for_block( string $block ): ?Preset_Bindings {
		return $this->preset_bindings[ $block ] ?? null;
	}

	/**
	 * All registered preset bindings, keyed by block name, in registration order. The admin UI feed
	 * iterates this to render per-block preset editors; mirrors all() for tokens.
	 *
	 * @since 3.8.0
	 *
	 * @return array<string, Preset_Bindings>
	 */
	public function all_preset_bindings(): array {
		return $this->preset_bindings;
	}

	/**
	 * The adapter registered for a Kadence Blocks block, or null when the block has none (the default —
	 * its CSS vars already carry the tokens).
	 *
	 * @since 3.8.0
	 *
	 * @param string $block The Kadence Blocks block name, e.g. "kadence/advancedheading".
	 *
	 * @return Adapter_Interface|null
	 */
	public function adapter_for_block( string $block ): ?Adapter_Interface {
		return $this->adapters[ $block ] ?? null;
	}

	/**
	 * All registered adapters, keyed by Kadence Blocks block name.
	 *
	 * @since 3.8.0
	 *
	 * @return array<string, Adapter_Interface>
	 */
	public function adapters(): array {
		return $this->adapters;
	}

	/**
	 * The block names that have registered preset bindings, in registration order. Projectors walk
	 * these to emit each block's preset output; the preset values themselves come from the document via
	 * the Preset_Resolver.
	 *
	 * @since 3.8.0
	 *
	 * @return string[]
	 */
	public function preset_binding_blocks(): array {
		return array_keys( $this->preset_bindings );
	}

	/**
	 * The effective projection targets for a binding: a token reference contributes the referenced
	 * token's projections (so a preset reuses the variable the base property already feeds), and the
	 * binding's inline targets are merged on top, supplementing or overriding them (e.g. adding a
	 * block_attr the token never carries). A reference to an unregistered token contributes nothing, so
	 * a stale reference fails soft (its projections are skipped) rather than fatal.
	 *
	 * @since 3.8.0
	 *
	 * @param Binding $binding The binding to resolve.
	 *
	 * @return array<string, mixed> Projection target key => value.
	 */
	public function effective_projections( Binding $binding ): array {
		$base = [];

		if ( $binding->is_token_ref() ) {
			$token = $this->get( (string) $binding->token );
			$base  = $token !== null ? $token->projections : [];
		}

		return array_merge( $base, $binding->projections );
	}

	/**
	 * Convenience: the canonical css-var for an id, honouring any override.
	 *
	 * @since 3.8.0
	 *
	 * @param string $id The token id.
	 *
	 * @return string
	 */
	public function css_var_for( string $id ): string {
		$token = $this->get( $id );

		return $token !== null ? $token->css_var : Css_Var::from_id( $id );
	}

	/**
	 * The schema the admin React app consumes. A token registered in PHP appears in the
	 * UI with no JS change. Values are NOT included here — the resolver supplies current values
	 * separately; this is structure only.
	 *
	 * @since 3.8.0
	 *
	 * @return array{groups: array<string, array<int, array<string, mixed>>>}
	 */
	public function to_ui_schema(): array {
		$groups = [];

		foreach ( $this->tokens as $token ) {
			$groups[ $token->group ][] = [
				'id'          => $token->id,
				'type'        => $token->type,
				'label'       => $token->label,
				'cssVar'      => $token->css_var,
				'projections' => $token->projections,
				'userCreated' => $token->is_user_created(),
			];
		}

		return [ 'groups' => $groups ];
	}

	/**
	 * The current-locale group label a stable group_key resolves to, or null when no declared token
	 * carries that key. A pure accessor: it scans the already-registered declarations for the key and
	 * returns their translated group verbatim — it never calls __() itself, because the key is a
	 * variable and a dynamic string passed to __() is invisible to WP's static string extraction and
	 * would never be translated. The key only ever selects among labels that already exist as literal
	 * __() calls in declarations.php.
	 *
	 * @since 3.8.0
	 *
	 * @param string $group_key The stable machine key, e.g. "border-radius".
	 *
	 * @return string|null
	 */
	public function group_label_for( string $group_key ): ?string {
		if ( $group_key === '' ) {
			return null;
		}

		foreach ( $this->tokens as $token ) {
			if ( $token->group_key === $group_key ) {
				return $token->group;
			}
		}

		return null;
	}

	// ---- Fail-closed activation guard -------------------------------------------------------------

	/**
	 * Whether token projection is currently active.
	 *
	 * @since 3.8.0
	 *
	 * @return bool
	 */
	public function is_active(): bool {
		return $this->active;
	}

	/**
	 * Validate that every declared token has a baseline entry. See the fail-closed policy.
	 *
	 * @since 3.8.0
	 *
	 * @param Baseline_Document $baseline The baseline to validate declared tokens against.
	 *
	 * @return string[] The ids missing from the baseline (empty when valid).
	 */
	public function missing_from_baseline( Baseline_Document $baseline ): array {
		$missing = [];

		foreach ( $this->tokens as $id => $token ) {
			if ( $token->is_user_created() ) {
				continue;
			}

			if ( ! $baseline->has( $id ) ) {
				$missing[] = $id;
			}
		}

		return $missing;
	}

	/**
	 * Disable projection (fail-closed degraded mode).
	 *
	 * @since 3.8.0
	 *
	 * @return void
	 */
	public function deactivate(): void {
		$this->active = false;
	}

	/**
	 * Re-enable projection after a previous deactivate() call.
	 *
	 * @since 3.8.0
	 *
	 * @return void
	 */
	public function activate(): void {
		$this->active = true;
	}
}
