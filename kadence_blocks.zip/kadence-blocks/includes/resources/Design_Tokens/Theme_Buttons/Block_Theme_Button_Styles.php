<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocks\Design_Tokens\Theme_Buttons;

use KadenceWP\KadenceBlocks\Design_Tokens\Theme_Buttons\Contracts\Button_Style_Source;
use KadenceWP\KadenceBlocks\Utils\Cast;
use WP_Block_Styles_Registry;
use WP_Theme_JSON_Resolver;

/**
 * A block theme's button styles, read from its theme.json. Asked after the Kadence adapter and before the
 * classic fallback, and it answers only when the theme's own data styles the button element or block, so
 * core's defaults never read as a theme's values. WordPress copies the `style_data` of every registered
 * block style into the theme data, whoever registered it, so a core/button variation that only the block
 * styles registry supplies is dropped from the theme's data: a plugin's style never reads as the theme's.
 * A theme that registers its variation only through `register_block_style()` looks the same and is dropped
 * too; one it also declares in theme.json or a style partial is kept.
 *
 * Theme Base is class-painted: the theme's global styles keep painting the button, and the values are read
 * from the merged data (core, theme and the user's Global Styles) for display only. A variation the theme
 * defines for core/button becomes a value preset instead, because a variation's CSS needs a core button
 * wrapper the Button block does not have. Its tokens are the theme base values with the variation's own on
 * top, so a property the variation leaves unset follows the theme's button rather than the plugin's Default.
 *
 * @since 3.8.0
 */
final class Block_Theme_Button_Styles implements Button_Style_Source {

	/**
	 * The classes the theme's global styles paint a button with.
	 *
	 * @since 3.8.0
	 *
	 * @var string
	 */
	private const THEME_CLASS = 'wp-block-button__link button kb-btn-global-inherit';

	/**
	 * The preset properties in the order they are listed, whichever order theme.json declares them in.
	 *
	 * @since 3.8.0
	 *
	 * @var string[]
	 */
	private const PROPERTY_ORDER = [
		'button-bg',
		'button-text',
		'button-bg-hover',
		'button-text-hover',
		'button-radius',
		'button-border-width',
		'button-border-style',
		'button-border-color',
		'button-border-hover-color',
		'button-padding',
	];

	/**
	 * The sides of a padding object, in slot order.
	 *
	 * @since 3.8.0
	 *
	 * @var string[]
	 */
	private const SIDES = [ 'top', 'right', 'bottom', 'left' ];

	/**
	 * The corners of a radius object, in slot order.
	 *
	 * @since 3.8.0
	 *
	 * @var string[]
	 */
	private const CORNERS = [ 'topLeft', 'topRight', 'bottomRight', 'bottomLeft' ];

	/**
	 * Returns the theme's own `styles` array. Null resolves to the theme.json resolver at read time.
	 *
	 * @since 3.8.0
	 *
	 * @var callable|null
	 */
	private $theme_data;

	/**
	 * Returns the merged `styles` array the page renders. Null resolves to the theme.json resolver at read time.
	 *
	 * @since 3.8.0
	 *
	 * @var callable|null
	 */
	private $merged_data;

	/**
	 * Returns the `style_data` of each block style registered for core/button, keyed by style name. Null
	 * resolves to the block styles registry at read time.
	 *
	 * @since 3.8.0
	 *
	 * @var callable|null
	 */
	private $registered_data;

	/**
	 * @since 3.8.0
	 *
	 * @param callable|null $theme_data      Returns the theme's own `styles` array; tests hand in a fixture.
	 * @param callable|null $merged_data     Returns the merged `styles` array; tests hand in a fixture.
	 * @param callable|null $registered_data Returns the registered core/button `style_data` by name; tests hand in a fixture.
	 */
	public function __construct( ?callable $theme_data = null, ?callable $merged_data = null, ?callable $registered_data = null ) {
		$this->theme_data      = $theme_data;
		$this->merged_data     = $merged_data;
		$this->registered_data = $registered_data;
	}

	/**
	 * @inheritDoc
	 *
	 * @since 3.8.0
	 */
	public function styles(): array {
		$theme    = $this->theme_styles();
		$elements = $this->sub( $theme, 'elements' );
		$blocks   = $this->sub( $theme, 'blocks' );

		if ( ! isset( $elements['button'] ) && ! isset( $blocks['core/button'] ) ) {
			return [];
		}

		$merged  = $this->merged_styles();
		$element = $this->sub( $this->sub( $merged, 'elements' ), 'button' );
		$block   = $this->sub( $this->sub( $merged, 'blocks' ), 'core/button' );
		$base    = $this->values( array_replace_recursive( $element, $block ) );
		$styles  = [
			'base' => [
				'label'  => __( 'Theme Base', 'kadence-blocks' ),
				'class'  => self::THEME_CLASS,
				'values' => $base,
			],
		];

		// Only the theme's own variations: core ships an outline variation and plugins can register more, and
		// the merged data carries them on every theme, but a preset named after one would promise a look the
		// theme never defined.
		$own        = $this->sub( $this->sub( $blocks, 'core/button' ), 'variations' );
		$variations = $this->sub( $block, 'variations' );

		foreach ( $own as $name => $data ) {
			$name      = Cast::to_string( $name );
			$variation = $this->sub( $variations, $name );

			if ( ! is_array( $data ) || $data === [] || $variation === [] ) {
				continue;
			}

			$values = $this->variation_values( $variation );

			if ( $values === null ) {
				continue;
			}

			$styles[ $name ] = [
				'label'  => sprintf(
					/* translators: %s: the theme's button style variation name, e.g. "Outline". */
					__( 'Theme %s', 'kadence-blocks' ),
					ucwords( str_replace( '-', ' ', $name ) )
				),
				'class'  => '',
				'values' => [],
				'tokens' => $this->ordered( array_replace( $base, $values ) ),
			];
		}

		return $styles;
	}

	/**
	 * A variation's tokens: the same reading as the element, plus the one thing a variation means that
	 * theme.json leaves implicit: an outline clears the resting background through a "transparent none"
	 * gradient (core's own outline data, merged into every variation of that name), which has no binding of
	 * its own. Every property it leaves unset, the hover state included, stays the theme base's, which is
	 * what the theme's own CSS does for its variation.
	 *
	 * Null when the variation paints a real gradient and sets no background: a preset has no gradient
	 * property, and the theme base's solid background in its place would be a look the theme never defined.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $variation The merged variation data.
	 *
	 * @return array<string, mixed>|null
	 */
	private function variation_values( array $variation ): ?array {
		$values   = $this->values( $variation );
		$gradient = $this->css( $this->sub( $variation, 'color' )['gradient'] ?? null );

		if ( isset( $values['button-bg'] ) || $gradient === null ) {
			return $values;
		}

		if ( ! $this->clears_background( $gradient ) ) {
			return null;
		}

		$values['button-bg'] = 'transparent';

		return $values;
	}

	/**
	 * Whether a gradient is the "transparent none" (or "none", or "transparent") core writes to take a
	 * button's background away, as opposed to a real gradient the button would paint.
	 *
	 * @since 3.8.0
	 *
	 * @param string $gradient The variation's gradient, as CSS.
	 *
	 * @return bool
	 */
	private function clears_background( string $gradient ): bool {
		return preg_match( '/^(transparent|none)(\s+(transparent|none))?$/i', $gradient ) === 1;
	}

	/**
	 * The values a theme.json style node renders, keyed by the Button's preset properties. Typography has no
	 * preset field, a gradient and custom css have no binding, and the focus, active and visited states have
	 * no counterpart, so they are not read.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $node The style node: the button element, the button block or a variation.
	 *
	 * @return array<string, mixed>
	 */
	private function values( array $node ): array {
		$values = [];
		$color  = $this->sub( $node, 'color' );
		$hover  = $this->sub( $node, ':hover' );
		$border = $this->sub( $node, 'border' );

		foreach (
			[
				'button-bg'                 => $color['background'] ?? null,
				'button-text'               => $color['text'] ?? null,
				'button-bg-hover'           => $this->sub( $hover, 'color' )['background'] ?? null,
				'button-text-hover'         => $this->sub( $hover, 'color' )['text'] ?? null,
				'button-border-style'       => $border['style'] ?? null,
				'button-border-color'       => $border['color'] ?? null,
				'button-border-hover-color' => $this->sub( $hover, 'border' )['color'] ?? null,
			] as $property => $value
		) {
			$css = $this->css( $value );

			if ( $css !== null ) {
				$values[ $property ] = $css;
			}
		}

		$radius = $this->slots( $border['radius'] ?? null, self::CORNERS );

		if ( $radius !== null ) {
			$values['button-radius'] = $radius;
		}

		$width = $this->css( $border['width'] ?? null );

		if ( $width !== null ) {
			$values['button-border-width'] = [ $width, $width, $width, $width ];
		}

		$padding = $this->slots( $this->sub( $node, 'spacing' )['padding'] ?? null, self::SIDES );

		if ( $padding !== null ) {
			$values['button-padding'] = $padding;
		}

		return $this->ordered( $values );
	}

	/**
	 * A one-value-or-per-slot setting as four slots: a string fills every slot, an object needs every slot
	 * set. Null when the setting is absent or partial.
	 *
	 * @since 3.8.0
	 *
	 * @param mixed    $setting The theme.json value.
	 * @param string[] $keys    The object keys, in slot order.
	 *
	 * @return string[]|null
	 */
	private function slots( $setting, array $keys ): ?array {
		$single = $this->css( $setting );

		if ( $single !== null ) {
			return [ $single, $single, $single, $single ];
		}

		if ( ! is_array( $setting ) ) {
			return null;
		}

		$slots = [];

		foreach ( $keys as $key ) {
			$slot = $this->css( $setting[ $key ] ?? null );

			if ( $slot === null ) {
				return null;
			}

			$slots[] = $slot;
		}

		return $slots;
	}

	/**
	 * A theme.json scalar as CSS, or null when it is not a usable string (unset, empty, or a `false` blanker).
	 * The v3 `var:preset|<group>|<slug>` shorthand becomes the variable core writes for it at CSS time, so a
	 * value stored from here is always valid CSS.
	 *
	 * @since 3.8.0
	 *
	 * @param mixed $value The theme.json value.
	 *
	 * @return string|null
	 */
	private function css( $value ): ?string {
		if ( ! is_string( $value ) && ! is_numeric( $value ) ) {
			return null;
		}

		$value = trim( Cast::to_string( $value ) );

		if ( $value === '' ) {
			return null;
		}

		return (string) preg_replace( '/^var:preset\|([\w-]+)\|([\w-]+)$/', 'var(--wp--preset--$1--$2)', $value );
	}

	/**
	 * A value map in the listing order.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $values The values, in reading order.
	 *
	 * @return array<string, mixed>
	 */
	private function ordered( array $values ): array {
		return array_replace( array_intersect_key( array_fill_keys( self::PROPERTY_ORDER, null ), $values ), $values );
	}

	/**
	 * The theme's own `styles`, empty on a theme without theme.json so a classic theme is never read, and
	 * without the core/button variations only the block styles registry supplies.
	 *
	 * @since 3.8.0
	 *
	 * @return array<string, mixed>
	 */
	private function theme_styles(): array {
		if ( $this->theme_data !== null ) {
			$styles = $this->section( ( $this->theme_data )() );
		} elseif ( wp_theme_has_theme_json() ) {
			$styles = $this->section( WP_Theme_JSON_Resolver::get_theme_data()->get_raw_data()['styles'] ?? null );
		} else {
			return [];
		}

		return $this->without_registered_variations( $styles );
	}

	/**
	 * The styles with every core/button variation the theme adds nothing to removed. Since 6.6 the theme
	 * data carries the `style_data` of each registered block style, with the theme's own data for that name
	 * merged on top, so a variation equal to its registered data came from the registry alone.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $styles The theme data's `styles`.
	 *
	 * @return array<string, mixed>
	 */
	private function without_registered_variations( array $styles ): array {
		$blocks     = $this->sub( $styles, 'blocks' );
		$block      = $this->sub( $blocks, 'core/button' );
		$variations = $this->sub( $block, 'variations' );

		if ( $variations === [] ) {
			return $styles;
		}

		$registered = $this->registered_styles();

		foreach ( $variations as $name => $data ) {
			$style_data = $this->sub( $registered, Cast::to_string( $name ) );

			if ( $style_data !== [] && is_array( $data ) && array_replace_recursive( $style_data, $data ) === $style_data ) {
				unset( $variations[ $name ] );
			}
		}

		unset( $block['variations'] );

		if ( $variations !== [] ) {
			$block['variations'] = $variations;
		}

		unset( $blocks['core/button'] );

		if ( $block !== [] ) {
			$blocks['core/button'] = $block;
		}

		$styles['blocks'] = $blocks;

		return $styles;
	}

	/**
	 * The `style_data` of each block style registered for core/button, keyed by style name. A style without
	 * it maps to an empty array, since WordPress copies nothing of it into the theme data.
	 *
	 * @since 3.8.0
	 *
	 * @return array<string, mixed>
	 */
	private function registered_styles(): array {
		if ( $this->registered_data !== null ) {
			return $this->section( ( $this->registered_data )() );
		}

		$styles = [];

		foreach ( WP_Block_Styles_Registry::get_instance()->get_registered_styles_for_block( 'core/button' ) as $name => $style ) {
			$styles[ Cast::to_string( $name ) ] = $this->sub( $style, 'style_data' );
		}

		return $styles;
	}

	/**
	 * The merged `styles` the page renders: core, the theme and the user's Global Styles.
	 *
	 * @since 3.8.0
	 *
	 * @return array<string, mixed>
	 */
	private function merged_styles(): array {
		if ( $this->merged_data !== null ) {
			return $this->section( ( $this->merged_data )() );
		}

		return $this->section( WP_Theme_JSON_Resolver::get_merged_data()->get_raw_data()['styles'] ?? null );
	}

	/**
	 * A raw `styles` section narrowed to an array.
	 *
	 * @since 3.8.0
	 *
	 * @param mixed $styles The section.
	 *
	 * @return array<string, mixed>
	 */
	private function section( $styles ): array {
		return is_array( $styles ) ? $styles : [];
	}

	/**
	 * The array under a key, empty when the key is missing or holds a scalar.
	 *
	 * @since 3.8.0
	 *
	 * @param array<string, mixed> $node The parent.
	 * @param string               $key  The key.
	 *
	 * @return array<string, mixed>
	 */
	private function sub( array $node, string $key ): array {
		return is_array( $node[ $key ] ?? null ) ? $node[ $key ] : [];
	}
}
