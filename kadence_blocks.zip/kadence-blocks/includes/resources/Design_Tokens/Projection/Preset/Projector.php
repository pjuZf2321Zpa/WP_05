<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocks\Design_Tokens\Projection\Preset;

use KadenceWP\KadenceBlocks\Design_Tokens\Database\Active_Token_Library_Store;
use KadenceWP\KadenceBlocks\Design_Tokens\Projection\Contracts\Abstract_Css_Projector;
use KadenceWP\KadenceBlocks\Design_Tokens\Projection\Media_Queries;
use KadenceWP\KadenceBlocks\Design_Tokens\Registry\Token_Registry;
use KadenceWP\KadenceBlocks\Design_Tokens\Utils\Location;
use Throwable;
use KadenceWP\KadenceBlocks\Design_Tokens\Resolver\Effective_Version;

/**
 * Projects the selectable-preset CSS into the WordPress style pipeline.
 *
 * Appends the per (block, preset) scoped overrides built by {@see Css_Builder} to KB's existing inline
 * style handles, on the front end and in the editor, gated on Token_Registry::is_active() so a
 * deactivated registry leaves KB's behavior untouched. The class that activates a rule is added by the
 * editor-side kbPreset filter; this side only emits the CSS the class hooks.
 *
 * @since 3.8.0
 */
final class Projector extends Abstract_Css_Projector {

	/**
	 * @var Token_Registry
	 *
	 * @since 3.8.0
	 */
	private Token_Registry $registry;


	/**
	 * Owns the active-library pointer, read at build time so the projection follows the active library.
	 *
	 * @since 3.8.0
	 *
	 * @var Active_Token_Library_Store
	 */
	private Active_Token_Library_Store $active;

	/**
	 * @var Css_Builder
	 *
	 * @since 3.8.0
	 */
	private Css_Builder $css_builder;


	/**
	 * Supplies the cache version: the store version, plus the theme Style Guide signature when there is
	 * one, so a Customizer save invalidates this cache even though it bumps no store version.
	 *
	 * @since 3.8.0
	 *
	 * @var Effective_Version
	 */
	private Effective_Version $versions;

	/**
	 * @since 3.8.0
	 *
	 * @param Token_Registry             $registry    The token registry.
	 * @param Active_Token_Library_Store $active      Owns the active-library pointer.
	 * @param Css_Builder                $css_builder The preset CSS builder.
	 * @param Effective_Version          $versions    Supplies the effective cache version for a library.
	 */
	public function __construct(
		Token_Registry $registry,
		Active_Token_Library_Store $active,
		Css_Builder $css_builder,
		Effective_Version $versions
	) {
		$this->registry    = $registry;
		$this->active      = $active;
		$this->css_builder = $css_builder;
		$this->versions    = $versions;
	}

	/**
	 * Append the preset CSS to the front-end global-variables handle.
	 *
	 * @since 3.8.0
	 *
	 * @return void
	 */
	public function enqueue_front_end(): void {
		if ( ! $this->registry->is_active() ) {
			return;
		}

		$css = $this->css();

		if ( $css !== '' ) {
			wp_add_inline_style( 'kadence-blocks-global-variables', $css );
		}
	}

	/**
	 * Append the preset CSS to the editor global-styles handle.
	 *
	 * Shares the Css_Var projector's editor gate (the same page check and filter), so the preset CSS and
	 * the token vars load together in the editor or not at all.
	 *
	 * @since 3.8.0
	 *
	 * @return void
	 */
	public function enqueue_editor(): void {
		if ( ! $this->registry->is_active() ) {
			return;
		}

		/** This filter is documented in includes/resources/Design_Tokens/Projection/Css_Var/Projector.php */
		if ( ! apply_filters( 'kadence_blocks_load_editor_token_vars', Location::is_block_editor() ) ) {
			return;
		}

		$css = $this->editor_css();

		if ( $css !== '' ) {
			wp_add_inline_style( 'kadence-blocks-global-editor-styles', $css );
		}
	}

	/**
	 * Build the preset CSS for the single active token library, via the builder's fragment cache.
	 *
	 * The active library's presets are emitted as canonical --kb-token--preset--* vars plus the coercive scoped
	 * rules. Returns an empty string when the store version cannot be read or a preset cannot be resolved
	 * (e.g. an alias cycle from a direct DB write that bypassed the REST gate), so the page never crashes —
	 * the inline style is simply omitted and KB falls back to its $default look.
	 *
	 * @since 3.8.0
	 *
	 * @return string
	 */
	public function css(): string {
		try {
			$active  = $this->active->get();
			$version = $this->versions->for_slug( $active );

			return $this->css_builder->css_for_version( $active, $version, Media_Queries::all() );
		} catch ( Throwable $e ) {
			return '';
		}
	}

	/**
	 * Build the EDITOR-scoped preset CSS for the single active token library.
	 *
	 * Overrides the base's "editor output equals front-end output" default because one layer is markup-aware:
	 * a state rule (a binding declaring a `css_state`) carries a selector suffix, and a block whose editor renders the
	 * bound element under a different class declares an `editor_css_state` for it. Every other layer — the
	 * canonical `:root` vars and the block-root var retargets — is reused verbatim.
	 *
	 * Degrades the same way {@see self::css()} does: an unreadable store version or an unresolvable preset
	 * yields an empty string rather than an exception, so the editor loads without the inline style.
	 *
	 * @since 3.8.0
	 *
	 * @return string
	 */
	public function editor_css(): string {
		try {
			$active  = $this->active->get();
			$version = $this->versions->for_slug( $active );

			return $this->css_builder->editor_css_for_version( $active, $version, Media_Queries::all() );
		} catch ( Throwable $e ) {
			return '';
		}
	}
}
