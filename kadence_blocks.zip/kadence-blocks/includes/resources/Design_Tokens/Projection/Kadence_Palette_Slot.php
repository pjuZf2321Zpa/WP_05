<?php declare( strict_types=1 );
// cspell:ignore palette .

namespace KadenceWP\KadenceBlocks\Design_Tokens\Projection;

use KadenceWP\KadenceBlocks\Design_Tokens\Registry\Token_Definition;

/**
 * Normalizes a token's "kadence_slot" projection into a Kadence color-palette slot.
 *
 * The Kadence ecosystem keys fifteen color slots palette1…palette15. That slug is the identifier in KB's own
 * kadence_blocks_colors option, in the Kadence theme's kadence_global_palette option, and as the suffix
 * of the --global-paletteN CSS variable. Every consumer resolves through this one class so the slot they
 * target can never drift: the Css_Var legacy bridge (which rewrites the --global-paletteN filter on
 * non-Kadence sites), the Kadence_Option projector (which writes KB's own option), and the palette filter
 * that answers the theme's reads.
 *
 * A token opts in with a bare slug string under "kadence_slot":
 *
 *   'kadence_slot' => 'palette1'   // semantic.color.button-bg => slot "palette1"
 *
 * Font-size slots (sm/md/lg/…) also travel under "kadence_slot" but are NOT palette slots; from_token()
 * returns null for them, so callers that only care about colors skip them cleanly.
 *
 * @since 3.8.0
 */
final class Kadence_Palette_Slot {

	/**
	 * The projection key a token declares to claim a Kadence slot.
	 *
	 * @since 3.8.0
	 *
	 * @var string
	 */
	private const PROJECTION = 'kadence_slot';

	/**
	 * Matches the fifteen Kadence palette slots, palette1…palette15.
	 *
	 * @since 3.8.0
	 * @since 3.9.1 Admits the extended slots palette10…palette15.
	 *
	 * @var string
	 */
	private const SLOT_PATTERN = '/^palette([1-9]|1[0-5])$/';

	/**
	 * The palette slot slug, e.g. "palette1". This is the entry slug in both palette options and the
	 * suffix of --global-paletteN.
	 *
	 * @since 3.8.0
	 *
	 * @var string
	 */
	public string $slug;

	/**
	 * @param string $slug Palette slot slug (palette1…palette15).
	 */
	private function __construct( string $slug ) {
		$this->slug = $slug;
	}

	/**
	 * The projection key.
	 *
	 * @since 3.8.0
	 *
	 * @return string
	 */
	public static function get_projection_key(): string {
		return self::PROJECTION;
	}

	/**
	 * Resolve a token's kadence_slot config to a palette slot, or null when the token declares no
	 * kadence_slot, or declares one that is not a palette slot (e.g. a font-size key).
	 *
	 * @since 3.8.0
	 *
	 * @param Token_Definition $token The token definition.
	 *
	 * @return self|null
	 */
	public static function from_token( Token_Definition $token ): ?self {
		// A missing projection (?? null), a non-string value, and a string that is not palette1…palette15
		// all collapse to "not a palette slot" here, so no separate has_projection() guard is needed.
		$slot = $token->projections[ self::PROJECTION ] ?? null;

		if ( ! is_string( $slot ) || preg_match( self::SLOT_PATTERN, $slot ) !== 1 ) {
			return null;
		}

		return new self( $slot );
	}
}
