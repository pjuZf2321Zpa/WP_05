<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocks\Design_Tokens\Projection\Adapter;

use KadenceWP\KadenceBlocks\Design_Tokens\Projection\Adapter\Contracts\Adapter_Interface;
use KadenceWP\KadenceBlocks\Design_Tokens\Registry\Token_Registry;
use KadenceWP\KadenceBlocks\StellarWP\ProphecyMonorepo\Container\Contracts\Provider as Provider_Contract;

/**
 * Registers the per-block adapter projector and wires it into KB's render path.
 *
 * KB emits `kadence_blocks_block_default_attributes` while assembling a block's attributes (passing the
 * block name), the same seam the block-preset projector uses. Running the adapter there — after the
 * preset overlay (priority 20 vs 10) — lets it rewrite the values a block's attributes cannot express
 * as a clean token/variable reference. The projector looks the adapter up by block at render time, so a
 * block with no adapter is a no-op.
 *
 * @since 3.8.0
 */
final class Provider extends Provider_Contract {

	/**
	 * The adapter classes registered against the Token Registry, resolved from the container so an adapter
	 * can take the Registry or Resolver as a dependency. A Kadence Blocks block whose attributes cannot be
	 * expressed as a clean token/variable reference lists its adapter here.
	 *
	 * @since 3.8.0
	 *
	 * @var class-string<Adapter_Interface>[]
	 */
	private const ADAPTERS = [
		Icon_Size_Adapter::class,
	];

	/**
	 * @inheritDoc
	 *
	 * @since 3.8.0
	 */
	public function register(): void {
		$this->container->singleton( Projector::class );

		// Register the adapters on init at priority 10 — after the token declarations (priority 0) and the
		// baseline guard (priority 1) so an adapter that depends on declared tokens sees a populated
		// registry, and on a round increment that leaves room for other code to register adapters before
		// us. The filter below then looks each adapter up by block.
		add_action( 'init', [ $this, 'register_adapters' ], 10 );

		add_filter(
			'kadence_blocks_block_default_attributes',
			$this->container->callback( Projector::class, 'apply' ),
			20,
			2
		);
	}

	/**
	 * Register the declared adapters against the Token Registry.
	 *
	 * @since 3.8.0
	 *
	 * @return void
	 */
	public function register_adapters(): void {
		/** @var Token_Registry $registry */
		$registry = $this->container->get( Token_Registry::class );

		foreach ( self::ADAPTERS as $adapter ) {
			/** @var Adapter_Interface $instance */
			$instance = $this->container->get( $adapter );
			$registry->register_adapter( $instance );
		}
	}
}
