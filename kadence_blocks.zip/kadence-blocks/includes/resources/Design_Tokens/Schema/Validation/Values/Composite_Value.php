<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocks\Design_Tokens\Schema\Validation\Values;

use KadenceWP\KadenceBlocks\Design_Tokens\Schema\Vocabulary\Alias;
use KadenceWP\KadenceBlocks\Design_Tokens\Schema\Validation\Contracts\Value_Validator;
use KadenceWP\KadenceBlocks\Design_Tokens\Schema\Validation\Kind;
use KadenceWP\KadenceBlocks\Design_Tokens\Schema\Vocabulary\Token_Type;
use KadenceWP\KadenceBlocks\Design_Tokens\Schema\Validation\Validation_Error;

/**
 * Shared walk for a composite $value (shadow): an alias for the whole value, or an object whose every
 * declared sub-field validates "alias OR literal-of-$type" via Kind.
 *
 * The field => $type map comes from Token_Type::composite_fields(), so adding or reshaping a composite
 * is a data edit there, not a change here. Subclasses only name their $type.
 *
 * @since 3.8.0
 */
abstract class Composite_Value implements Value_Validator {

	/**
	 * The composite $type this validator covers (Token_Type::get_type_shadow()).
	 *
	 * @since 3.8.0
	 *
	 * @return string
	 */
	abstract protected function type(): string;

	/**
	 * Validate a composite $value.
	 *
	 * @since 3.8.0
	 *
	 * @param mixed  $value The decoded $value.
	 * @param string $path  Dot-path to the value, for error reporting.
	 *
	 * @return Validation_Error[] Empty when valid.
	 */
	public function validate( $value, string $path ): array {
		// The whole composite may itself be an alias.
		if ( Alias::is_alias( $value ) ) {
			return [];
		}

		// A brace-bearing string is a fumbled alias attempt — a composite literal is otherwise an object.
		if ( is_string( $value ) && Alias::looks_like_alias( $value ) ) {
			return [
				new Validation_Error(
					$path,
					Validation_Error::get_code_alias_malformed(),
					sprintf( 'Value "%s" looks like an alias but is not a whole-string "{dot.path}" reference.', $value )
				),
			];
		}

		if ( ! is_array( $value ) ) {
			return [
				new Validation_Error(
					$path,
					Validation_Error::get_code_value_invalid(),
					sprintf( 'A %s value must be an object of sub-fields or an alias.', $this->type() )
				),
			];
		}

		$fields = Token_Type::composite_fields( $this->type() );
		$errors = [];

		// Every declared sub-field must be present and valid for its kind.
		foreach ( $fields as $field => $kind ) {
			if ( ! array_key_exists( $field, $value ) ) {
				$errors[] = new Validation_Error(
					$path . '.' . $field,
					Validation_Error::get_code_composite_field_missing(),
					sprintf( 'A %s value is missing the required "%s" sub-field.', $this->type(), $field )
				);

				continue;
			}

			$errors = array_merge( $errors, Kind::validate( $kind, $value[ $field ], $path . '.' . $field ) );
		}

		$optional = Token_Type::optional_fields( $this->type() );

		// Optional sub-fields (e.g. shadow's "inset") are validated only when present, and never through
		// Kind::validate() — every optional kind so far ("boolean") has no v1 $type, so Kind has no
		// literal validator for it and would accept any well-formed alias in its place unchecked; a
		// strict literal check is required instead.
		foreach ( $optional as $field => $kind ) {
			if ( ! array_key_exists( $field, $value ) ) {
				continue;
			}

			if ( $kind === Token_Type::get_kind_boolean() && ! is_bool( $value[ $field ] ) ) {
				$errors[] = new Validation_Error(
					$path . '.' . $field,
					Validation_Error::get_code_value_invalid(),
					sprintf( 'A %s value has an "%s" sub-field that must be a literal boolean (true or false); aliases are not accepted.', $this->type(), $field )
				);
			}
		}

		// Any sub-field not in the required or optional map (and not a "$"-prefixed extension) is unknown.
		foreach ( array_keys( $value ) as $field ) {
			if ( isset( $fields[ $field ] ) || isset( $optional[ $field ] ) || ( is_string( $field ) && strncmp( $field, '$', 1 ) === 0 ) ) {
				continue;
			}

			$errors[] = new Validation_Error(
				$path . '.' . $field,
				Validation_Error::get_code_composite_field_unknown(),
				sprintf( 'A %s value has no "%s" sub-field.', $this->type(), (string) $field )
			);
		}

		return $errors;
	}
}
