<?php declare( strict_types=1 );

namespace KadenceWP\KadenceBlocks\Site_Styles;

use KadenceWP\KadenceBlocks\Site_Styles\Contracts\Prints_Site_Rules;
use KadenceWP\KadenceBlocks\Site_Styles\Contracts\Scopes_Site_Styles;
use KadenceWP\KadenceBlocks\Site_Styles\Contracts\Supports_Site_Styles;
use WP_Block_Type_Registry;

/**
 * The blocks that take site-level styles, keyed by block name. Each block's
 * class describes its site styles through `Supports_Site_Styles`.
 *
 * @since 3.9.0
 */
final class Supported_Blocks {

	/**
	 * Identifiers and per-instance data no site-level value may set, whatever
	 * the block. `kadenceDynamic` holds Kadence Blocks Pro's dynamic-content
	 * bindings, which it adds to blocks outside their `block.json`. `kbPreset`
	 * and `kbPalette` are each instance's design-token picks.
	 *
	 * @since 3.9.0
	 */
	private const ALWAYS_EXCLUDED = [ 'uniqueID', 'anchor', 'inQueryBlock', 'noCustomDefaults', 'metadata', 'lock', 'className', 'kadenceDynamic', 'kbPreset', 'kbPalette' ];

	/**
	 * Block name => block.
	 *
	 * @since 3.9.0
	 *
	 * @var array<string, Supports_Site_Styles>
	 */
	private array $blocks = [];

	/**
	 * @since 3.9.0
	 *
	 * @param Supports_Site_Styles[] $blocks The supported blocks.
	 */
	public function __construct( array $blocks ) {
		foreach ( $blocks as $block ) {
			$this->blocks[ $block->get_name() ] = $block;
		}
	}

	/**
	 * @since 3.9.0
	 *
	 * @return array<string, Supports_Site_Styles> Block name => block.
	 */
	public function all(): array {
		return $this->blocks;
	}

	/**
	 * @since 3.9.0
	 *
	 * @param string $block_name Block name, e.g. `kadence/singlebtn`.
	 *
	 * @return Supports_Site_Styles|null The block, null when it isn't supported.
	 */
	public function get( string $block_name ): ?Supports_Site_Styles {
		return $this->blocks[ $block_name ] ?? null;
	}

	/**
	 * The attributes a block's site-level values never set: the ones excluded
	 * for every block, the attributes its `block.json` marks as content, and
	 * its scope attribute when it scopes its site styles.
	 *
	 * A block that doesn't print site rules, scoped or not, shows a site value
	 * only through its overlay attributes and the attributes core's style
	 * stores. It excludes every other attribute too.
	 *
	 * @since 3.9.0
	 *
	 * @param Supports_Site_Styles $block The block.
	 *
	 * @return list<string> Attribute names.
	 */
	public static function excluded_attributes( Supports_Site_Styles $block ): array {
		$excluded   = self::ALWAYS_EXCLUDED;
		$block_type = WP_Block_Type_Registry::get_instance()->get_registered( $block->get_name() );
		$attributes = $block_type && is_array( $block_type->attributes ) ? $block_type->attributes : [];

		foreach ( $attributes as $name => $definition ) {
			if ( ! is_array( $definition ) ) {
				continue;
			}

			$role = $definition['role'] ?? $definition['__experimentalRole'] ?? null;

			if ( 'content' === $role && ! in_array( $name, $excluded, true ) ) {
				$excluded[] = $name;
			}
		}

		if ( $block instanceof Scopes_Site_Styles ) {
			$excluded[] = $block->site_styles_scope_attribute();
		}

		if ( $block instanceof Prints_Site_Rules ) {
			return $excluded;
		}

		$rendered = array_merge( $block->site_styles_overlay_attributes(), array_keys( $block->site_styles_attributes_map() ) );

		foreach ( array_keys( $attributes ) as $name ) {
			if ( is_string( $name ) && ! in_array( $name, $rendered, true ) && ! in_array( $name, $excluded, true ) ) {
				$excluded[] = $name;
			}
		}

		return $excluded;
	}

	/**
	 * The defaults a block's registration declares.
	 *
	 * @since 3.9.0
	 *
	 * @param string $block_name Block name, e.g. `kadence/singlebtn`.
	 *
	 * @return array<string, mixed> Attribute name => default value.
	 */
	public static function registered_defaults( string $block_name ): array {
		$block_type = WP_Block_Type_Registry::get_instance()->get_registered( $block_name );
		$defaults   = [];

		foreach ( ( $block_type ? $block_type->attributes : null ) ?? [] as $name => $definition ) {
			if ( array_key_exists( 'default', $definition ) ) {
				$defaults[ $name ] = $definition['default'];
			}
		}

		return $defaults;
	}
}
