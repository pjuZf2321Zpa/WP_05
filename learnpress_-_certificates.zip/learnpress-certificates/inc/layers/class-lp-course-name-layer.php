<?php
/**
 * Class LP_Certificate_Course_Name_Layer
 */

class LP_Certificate_Course_Name_Layer extends LP_Certificate_Layer {
	public function apply( $data ) {
		$this->options['text'] = ! empty( $data['course_id'] ) ? html_entity_decode( get_the_title( $data['course_id'] ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) : $this->options['text'];
	}
}
