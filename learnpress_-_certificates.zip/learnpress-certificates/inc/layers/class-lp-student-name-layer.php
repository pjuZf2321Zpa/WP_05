<?php

/**
 * Class LP_Certificate_Student_Name_Layer
 */
class LP_Certificate_Student_Name_Layer extends LP_Certificate_Layer {
	public function apply( $data ) {
		if ( ! empty( $data['user_id'] ) ) {
			$user = learn_press_get_user( $data['user_id'] );
			if ( ! empty( $user ) ) {
				$display_name = $user->get_display_name();
				if ( empty( $display_name ) ) {
					$display_name = $user->get_data( 'user_login', '' );
				}
				$this->options['text'] = $display_name;
			}
		}
	}
}
