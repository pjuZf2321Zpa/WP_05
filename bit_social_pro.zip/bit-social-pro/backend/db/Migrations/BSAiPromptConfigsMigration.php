<?php

use BitApps\SocialPro\Config;
use BitApps\SocialPro\Deps\BitApps\WPDatabase\Blueprint;
use BitApps\SocialPro\Deps\BitApps\WPDatabase\Connection;
use BitApps\SocialPro\Deps\BitApps\WPDatabase\Schema;
use BitApps\SocialPro\Deps\BitApps\WPKit\Migration\Migration;

if (!defined('ABSPATH')) {
    exit;
}

final class BSAiPromptConfigsMigration extends Migration
{
    public function up()
    {
        Schema::withPrefix(Connection::wpPrefix() . Config::FREE_PLUGIN_VAR_PREFIX)->create('ai_prompt_configs', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('type');
            $table->string('platform');
            $table->string('model');
            $table->longtext('config');
            $table->longtext('prompt');
            $table->longtext('fallback_content')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::withPrefix(Connection::wpPrefix() . Config::VAR_PREFIX)->drop('ai_prompt_configs');
    }
}
