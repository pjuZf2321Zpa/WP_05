<?php

namespace BitApps\SocialPro\Utils;

/**
 * The Meta Graph API version Pro's Facebook and Instagram calls are pinned to.
 *
 * Deliberately a value of its own rather than an import of
 * BitApps\Social\Utils\MetaGraph. Free and Pro are updated independently — a
 * site can run this build against an older Free for as long as it takes the
 * other update to arrive — and these constants are read as property defaults,
 * which PHP resolves when the class is loaded. Importing the Free one would
 * therefore fatal the moment an Instagram service was touched, taking Instagram
 * publishing down entirely, rather than degrading.
 *
 * Keep in step with BitApps\Social\Utils\MetaGraph::VERSION; that class carries
 * the reasoning about when Meta retires a version.
 */
final class MetaGraph
{
    public const VERSION = 'v23.0';
}
