<?php

namespace BitApps\SocialPro\Utils;

/**
 * Selects the media and the link that a Share Now post sends.
 *
 * This is a Pro copy of BitApps\Social\Utils\DirectShareAttachments. Free and
 * Pro update independently, so a Pro call to the Free class causes a fatal
 * error on a site with an older Free version.
 *
 * The Link and Media checkboxes only hide the other field in the UI, so the
 * old value stays in the saved template. A value is used only when its
 * checkbox is on. A template without a flag is an old record that was saved
 * before the flags existed, so its saved values are used.
 */
final class DirectShareAttachments
{
    /**
     * @param object $template
     *
     * @return array{media: null|array, link: null|string}
     */
    public static function resolve($template)
    {
        $useMedia = !empty($template->media) && ($template->isAllImages ?? true);
        $useLink = !empty($template->link) && ($template->isLinkCard ?? true);

        return [
            'media' => $useMedia ? array_column($template->media, 'url') : null,
            'link'  => $useLink ? $template->link : null,
        ];
    }
}
