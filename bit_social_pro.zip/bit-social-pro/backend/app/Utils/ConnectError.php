<?php

namespace BitApps\SocialPro\Utils;

use WP_Error;

/**
 * Turns a transport failure into something a site owner can act on.
 *
 * A copy of BitApps\Social\Utils\ConnectError rather than an import of it, for
 * the reason given on MetaGraph here: Free and Pro update independently, and a
 * Pro build that hard-references a class only newer Free versions have fatals
 * on a site that has not received both updates yet. Failing to reach a network
 * is exactly the moment the user needs a message rather than a white screen.
 *
 * Keep the wording in step with the Free class; the message is deliberately
 * identical, so both resolve to one entry in the .pot.
 */
final class ConnectError
{
    /**
     * @param mixed  $error    the WP_Error the HTTP client returned
     * @param string $platform display name of the network being reached
     *
     * @return string
     */
    public static function unreachable($error, $platform)
    {
        $reason = $error instanceof WP_Error ? $error->get_error_message() : (string) $error;

        return \sprintf(
            // translators: 1: social network name, 2: the underlying transport error
            __(
                'Your site could not reach %1$s (%2$s). This is a network problem on the server, not a problem with your %1$s account. Try again, and if it keeps happening ask your host to check the server\'s outbound HTTPS connections.',
                'bit-social'
            ),
            $platform,
            $reason
        );
    }
}
