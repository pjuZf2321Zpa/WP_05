<?php

namespace BitApps\SocialPro\Utils;

use BitApps\Social\Model\Account;

/**
 * Pro's way in to the Free plugin's "this account needs reconnecting" flag.
 *
 * The flag itself lives on the Free Account model, and so does the only thing
 * that reads it: the warning the Accounts screen puts on a card. Both arrived
 * in Free 1.17.0, and Pro is updated separately — so on a site that has this
 * build of Pro and an older Free, calling those methods directly is a fatal on
 * the token-refresh path, which is to say every publish.
 *
 * Routed through here instead, where a Free that has no flag to set simply does
 * not get one set. Nothing else acts on the flag, so the cost of skipping it is
 * a card that does not warn until Free catches up — against a plugin that stops
 * posting at all.
 */
final class AccountReconnect
{
    /**
     * @param string $platform
     * @param string $accountId
     * @param string $message   short, user-facing cause
     */
    public static function flag($platform, $accountId, $message = '')
    {
        if (!method_exists(Account::class, 'flagNeedsReconnect')) {
            return;
        }

        Account::flagNeedsReconnect($platform, $accountId, $message);
    }

    /**
     * Strips the flag from a details payload that is about to be saved.
     *
     * @param mixed $details object, array or JSON string; returned in kind
     *
     * @return mixed unchanged where the Free plugin has no flag to strip
     */
    public static function withoutFlag($details)
    {
        if (!method_exists(Account::class, 'withoutReconnectFlag')) {
            return $details;
        }

        return Account::withoutReconnectFlag($details);
    }
}
