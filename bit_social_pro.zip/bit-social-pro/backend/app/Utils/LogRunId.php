<?php

namespace BitApps\SocialPro\Utils;

/**
 * The run id to stamp on a log row Pro writes directly.
 *
 * Most rows are written through the Free plugin's LoggerTrait, which stamps one
 * itself. A few standalone events - a token refresh that failed, a company-page
 * lookup that came back empty - insert their row by hand and would otherwise
 * leave the column null, which the Logs screen has to treat as "not grouped
 * yet" and read the slow way for the whole site.
 *
 * The id comes from the Free plugin's open run where there is one, so a refresh
 * that failed in the middle of a publish is filed with that publish. Reached by
 * name rather than by import: BitApps\Social\Utils\LogRun arrived in Free
 * 1.17.0, Pro updates separately, and naming a class an older Free does not
 * have is a fatal rather than a missing grouping. Without it the row gets an id
 * of its own, which is what a standalone event is anyway.
 */
final class LogRunId
{
    /**
     * @return string
     */
    public static function current()
    {
        $freeLogRun = 'BitApps\\Social\\Utils\\LogRun';

        if (class_exists($freeLogRun) && method_exists($freeLogRun, 'current')) {
            return $freeLogRun::current();
        }

        return md5(uniqid('bit_social_log_run', true));
    }
}
