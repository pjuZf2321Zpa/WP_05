<?php

namespace BitApps\SocialPro\HTTP\Controllers;

use BitApps\Social\Model\Account;
use BitApps\SocialPro\Config;
use BitApps\SocialPro\Model\AiPromptConfig;
use BitApps\SocialPro\Utils\Services\LicenseService;

final class BitSocialAnalyticsController
{
    /**
     * Add the Pro data to the Free report. Free names this data in its consent
     * list (TelemetryData::dataWeCollect), so keep that list in step with this.
     *
     * @param mixed $additional_data
     *
     * @return array
     */
    public function filterTrackingData($additional_data)
    {
        $additional_data = (array) $additional_data;
        $aiPromptConfigs = AiPromptConfig::get(['type', 'model']);
        $aiPlatformAccounts = $this->getAIPlatformAccounts();

        $additional_data['aiPromptConfigs'] = $this->aiPromptConfigsSummary($aiPromptConfigs);
        $additional_data['aiPlatformAccounts'] = $aiPlatformAccounts;
        $additional_data['aiAccountConnectStatus'] = $this->aiAccountConnectStatus($aiPlatformAccounts, $aiPromptConfigs);

        return $additional_data;
    }

    /**
     * Mark the report as Pro. Do not add the license key, because it is a secret.
     *
     * @param mixed $data
     *
     * @return array
     */
    public function addProPluginInfo($data)
    {
        $licenseData = LicenseService::getLicenseData();
        $licenseData = \is_array($licenseData) ? $licenseData : [];

        $data = (array) $data;
        $data['pro'] = [
            'version'    => Config::VERSION,
            'hasLicense' => !empty($licenseData['key']),
            'status'     => $licenseData['status'] ?? null,
            'expireAt'   => $licenseData['expireIn'] ?? null,
        ];

        return $data;
    }

    private function aiPromptConfigsSummary($aiPromptConfigs = null)
    {
        $aiPromptConfigs = $aiPromptConfigs ?? AiPromptConfig::get(['type', 'model']) ?? [];
        $summary = [];
        $modelsByType = [];
        $typeCount = [];

        if (\is_array($aiPromptConfigs) && \count($aiPromptConfigs) > 0) {
            foreach ($aiPromptConfigs as $config) {
                $type = $config['type'] ?? 'unknown';
                $model = $config['model'] ?? 'unknown';

                if (!isset($modelsByType[$type])) {
                    $modelsByType[$type] = [];
                }

                if (!\in_array($model, $modelsByType[$type])) {
                    $modelsByType[$type][] = $model;
                }

                if (!isset($typeCount[$type])) {
                    $typeCount[$type] = 0;
                }

                $typeCount[$type]++;
            }
        }

        $summary['modelsByType'] = $modelsByType;
        $summary['typeCount'] = $typeCount;
        $summary['totalConfigs'] = \is_array($aiPromptConfigs) ? \count($aiPromptConfigs) : 0;

        return $summary;
    }

    private function aiAccountConnectStatus($aiPlatformAccounts = [], $aiPromptConfigs = [])
    {
        // AI platform account connection status based on available AI platform accounts
        $aiPlatformAccountsCount = \is_array($aiPlatformAccounts) ? \count($aiPlatformAccounts) : 0;
        $aiPromptConfigsCount = \is_array($aiPromptConfigs) ? \count($aiPromptConfigs) : 0;

        return [
            'connected'          => $aiPlatformAccountsCount > 0,
            'aiPlatformAccounts' => $aiPlatformAccountsCount,
            'aiPromptConfigs'    => $aiPromptConfigsCount,
            'hasAiConfig'        => $aiPromptConfigsCount > 0,
        ];
    }

    private function getAIPlatformAccounts()
    {
        $accounts = Account::where('account_type', Account::accountType['AI_PLATFORM'])
            ->get(['id,platform']);

        if (empty($accounts)) {
            return [];
        }

        $aiPlatformAccounts = [];

        foreach ($accounts as $account) {
            $aiPlatformAccounts[] = [
                'id'       => $account->id,
                'platform' => $account->platform,
            ];
        }

        return $aiPlatformAccounts;
    }
}
