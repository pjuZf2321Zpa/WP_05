<?php

namespace BitApps\SocialPro\HTTP\Controllers;

use BitApps\Social\Model\Account;
use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\SocialPro\HTTP\Requests\AccountPermissionsUpdateRequest;
use BitApps\SocialPro\HTTP\Services\RoleAccess\AccountPermissionService;
use BitApps\SocialPro\HTTP\Services\RoleAccess\RoleAccessService;

class AccountPermissionController
{
    /**
     * Deliberately checks 'manage_options' directly (not the plugin's generic
     * access capability) so a non-admin role granted plugin access can never
     * read or change which roles may use an account.
     *
     * @param mixed $accountId
     */
    public function show($accountId)
    {
        if (!current_user_can('manage_options')) {
            return Response::error(['message' => __('You are not allowed to manage this setting.', 'bit-social')])->httpStatus(403);
        }

        $selected = AccountPermissionService::getRolesFor($accountId);

        // Selectable options: every WP role. Roles without plugin access can
        // be granted too — they only gain publishing through this account
        // (their authored posts auto-post), not access to the plugin itself.
        return Response::success([
            'roles'      => RoleAccessService::roleOptions(),
            'restricted' => $selected !== null,
            'selected'   => $selected === null ? [] : $selected,
            // Admin-like roles always keep access (userCanUseAccount bypasses
            // restrictions for manage_options users); the UI pins their tags.
            'locked' => RoleAccessService::adminRoles(),
        ]);
    }

    /**
     * Same admin-only gate as show() — see its docblock.
     *
     * @param mixed $accountId
     */
    public function update(AccountPermissionsUpdateRequest $request, $accountId)
    {
        if (!current_user_can('manage_options')) {
            return Response::error(['message' => __('You are not allowed to manage this setting.', 'bit-social')])->httpStatus(403);
        }

        if (!Account::findOne(['id' => absint($accountId)])) {
            return Response::error(['message' => __('Account not found.', 'bit-social')])->httpStatus(404);
        }

        // Accepts bool true/false as well as 'true'/'false'/'1'/'0' strings.
        if (!filter_var($request->restricted, FILTER_VALIDATE_BOOLEAN)) {
            AccountPermissionService::removeAccount($accountId);

            return Response::success(['restricted' => false, 'selected' => []]);
        }

        // Any existing WP role can be granted — plugin access (Roles & Access)
        // is not required; granted roles only gain auto-post/share publishing
        // through this account. Admin-like roles are re-added by the service.
        $roles = array_values(array_intersect(
            (array) $request->roles,
            array_keys(wp_roles()->get_names())
        ));

        AccountPermissionService::updateRolesFor($accountId, $roles);

        return Response::success([
            'restricted' => true,
            'selected'   => AccountPermissionService::getRolesFor($accountId),
        ]);
    }
}
