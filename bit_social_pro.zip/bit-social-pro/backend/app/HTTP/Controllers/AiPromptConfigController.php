<?php

namespace BitApps\SocialPro\HTTP\Controllers;

use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Request\Request;
use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\SocialPro\HTTP\Requests\PromptConfigRequest;
use BitApps\SocialPro\Model\AiPromptConfig;

class AiPromptConfigController
{
    public function index($page, $limit)
    {
        $aiTemplates = AiPromptConfig::select([
            'id',
            'title',
            'type',
            'platform',
            'model',
            'config',
            'prompt',
            'fallback_content',
            'created_at'
        ])->desc()->paginate($page, $limit);

        if (empty($aiTemplates['data'])) {
            return Response::success($aiTemplates);
        }

        foreach ($aiTemplates['data'] as $template) {
            if (isset($template->config) && !\is_null($template->config)) {
                $template->config = json_decode($template->config, true);
            }
        }

        return Response::success($aiTemplates);
    }

    public function store(PromptConfigRequest $request)
    {
        $validatedData = (object) $request->validated();

        $duplicate = AiPromptConfig::where('title', $validatedData->title)->count();

        if ($duplicate) {
            return Response::error("This {$validatedData->title} already exist");
        }

        $aiTemplateData = [
            'title'            => $validatedData->title,
            'type'             => $validatedData->type,
            'platform'         => $validatedData->platform,
            'model'            => $validatedData->model,
            'config'           => $validatedData->config,
            'prompt'           => $validatedData->prompt,
            'fallback_content' => $validatedData->fallbackContent ?? null,
        ];

        $response = AiPromptConfig::insert($aiTemplateData);

        return Response::success($response);
    }

    public function update(PromptConfigRequest $request, AiPromptConfig $aiPromptConfig)
    {
        $validatedData = (object) $request->validated();

        // Check for duplicate title (exclude current record)
        $duplicate = AiPromptConfig::findOne(['title' => $validatedData->title]);
        if ($duplicate && $duplicate->id !== $aiPromptConfig->id) {
            return Response::error("This {$validatedData->title} already exists");
        }

        $aiPromptConfigData = [
            'title'            => $validatedData->title,
            'type'             => $validatedData->type,
            'platform'         => $validatedData->platform,
            'model'            => $validatedData->model,
            'config'           => $validatedData->config,
            'prompt'           => $validatedData->prompt,
            'fallback_content' => $validatedData->fallbackContent ?? null,
        ];

        $aiPromptConfig->update($aiPromptConfigData);

        if ($aiPromptConfig->save()) {
            return Response::success('AI Prompt Config updated');
        }

        return Response::error('AI Prompt Config update failed');
    }

    public function destroy(Request $request)
    {
        AiPromptConfig::whereIn('id', $request->ids)->delete();

        return Response::success('AI prompt configs deleted successfully');
    }

    public function getTextPromptTags()
    {
        $aiPromptConfigs = AiPromptConfig::where('type', 'text')
            ->select(['id', 'title', 'prompt'])
            ->get();

        $promptTags = [];

        foreach ($aiPromptConfigs as $config) {
            $shortTitle = mb_strlen($config->title) > 24
                ? mb_substr($config->title, 0, 24) . '...'
                : $config->title;

            $promptTags[] = [
                'key'         => "prompt_{$config->id}_[{$config->prompt}]",
                'label'       => "{$config->id}. {$shortTitle}",
                'description' => $config->title,
            ];
        }

        return Response::success($promptTags);
    }

    public function getImagePromptTags()
    {
        $aiPromptConfigs = AiPromptConfig::where('type', 'image')
            ->select(['id', 'title', 'prompt'])
            ->get();

        $promptTags = [];

        foreach ($aiPromptConfigs as $config) {
            $shortTitle = mb_strlen($config->title) > 24
                ? mb_substr($config->title, 0, 24) . '...'
                : $config->title;

            $promptTags[] = [
                'value'       => "prompt_{$config->id}",
                'label'       => "{$config->id}. {$shortTitle}",
                'description' => $config->title,
            ];
        }

        return Response::success($promptTags);
    }
}
