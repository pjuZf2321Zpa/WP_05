<?php

namespace BitApps\SocialPro\HTTP\Controllers;

use BitApps\SocialPro\Config;
use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Response;
use BitApps\SocialPro\HTTP\Requests\AccessRolesUpdateRequest;
use BitApps\SocialPro\HTTP\Services\RoleAccess\RoleAccessService;

class RoleAccessController
{
    /**
     * Deliberately checks 'manage_options' directly (not the plugin's
     * generic access capability) so a non-admin role granted plugin access
     * can never read or change who else has access.
     */
    public function getAccessRoles()
    {
        if (!current_user_can('manage_options')) {
            return Response::error(['message' => __('You are not allowed to manage this setting.', 'bit-social')])->httpStatus(403);
        }

        return Response::success([
            'roles'   => RoleAccessService::roleOptions(),
            'allowed' => RoleAccessService::getAllowedRoles(),
            // Admin-like roles (administrator + any role with manage_options)
            // are always allowed; the UI renders them as fixed tags.
            'locked' => RoleAccessService::adminRoles(),
        ]);
    }

    /**
     * Deliberately checks 'manage_options' directly (not the plugin's
     * generic access capability) so a non-admin role granted plugin access
     * can never grant itself more roles or revoke Administrator's access.
     */
    public function updateAccessRoles(AccessRolesUpdateRequest $request)
    {
        if (!current_user_can('manage_options')) {
            return Response::error(['message' => __('You are not allowed to manage this setting.', 'bit-social')])->httpStatus(403);
        }

        $validSlugs = array_keys(wp_roles()->get_names());
        $roles = array_values(array_intersect((array) $request->roles, $validSlugs));
        $roles = array_values(array_unique(array_merge(RoleAccessService::adminRoles(), $roles)));

        $settings = Config::getOption('settings', []);
        if (!\is_array($settings)) {
            $settings = [];
        }
        $settings['access'] = ['roles' => $roles];

        Config::updateOption('settings', $settings);

        RoleAccessService::syncCapability($roles);

        return Response::success(['roles' => $roles]);
    }
}
