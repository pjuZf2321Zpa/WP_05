<?php

namespace BitApps\SocialPro\HTTP\Requests;

use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Request\Request;

class PromptConfigRequest extends Request
{
    public function rules()
    {
        return [
            'title'           => ['required', 'string'],
            'type'            => ['required', 'string'],
            'platform'        => ['required', 'string'],
            'model'           => ['required', 'string'],
            'config'          => ['required', 'array'],
            'prompt'          => ['required', 'string'],
            'fallbackContent' => ['nullable', 'string'],
        ];
    }
}
