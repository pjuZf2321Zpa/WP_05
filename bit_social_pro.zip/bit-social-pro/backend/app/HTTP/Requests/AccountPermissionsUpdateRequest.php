<?php

namespace BitApps\SocialPro\HTTP\Requests;

use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Request\Request;

class AccountPermissionsUpdateRequest extends Request
{
    public function rules()
    {
        return [
            // 'restricted' is parsed with filter_var in the controller — a
            // 'required' rule would reject a legitimate boolean false.
            'restricted' => ['nullable'],
            'roles'      => ['nullable', 'array'],
        ];
    }
}
