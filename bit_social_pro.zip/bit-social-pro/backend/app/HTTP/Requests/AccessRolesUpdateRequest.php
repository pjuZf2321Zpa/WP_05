<?php

namespace BitApps\SocialPro\HTTP\Requests;

use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Request\Request;

class AccessRolesUpdateRequest extends Request
{
    public function rules()
    {
        return [
            'roles' => ['required', 'array'],
        ];
    }
}
