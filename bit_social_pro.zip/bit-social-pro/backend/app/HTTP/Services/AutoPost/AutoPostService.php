<?php

namespace BitApps\SocialPro\HTTP\Services\AutoPost;

use BitApps\Social\HTTP\Controllers\ShareNowController;
use BitApps\Social\HTTP\Controllers\SocialTemplateController;
use BitApps\Social\HTTP\Services\AutoPost\AutoPostRuleService;
use BitApps\Social\Model\Schedule;
use DateTime;
use WP_Post;

class AutoPostService
{
    /**
     * Mirrors CustomSchedule::AUTO_POST_SOURCE in the free plugin. Deliberately
     * a literal rather than a reference to that constant: Pro and Free are
     * updated independently, and a newer Pro against an older Free would fatal
     * on an undefined constant every time a delayed auto-post is created.
     */
    public const SOURCE = 'auto_post';

    /**
     * Turns one matching auto-post rule into a schedule that fires after the
     * rule's delay. One schedule per rule, so a post matching two delayed rules
     * is shared by both, each with its own accounts and post content.
     *
     * Free and Pro update separately, so this can be called by a free build
     * that predates rules: it passes the site-wide auto-post settings as $rule
     * and nothing as $autoPostSettings. Those settings carry the same
     * `postDelay` and `accounts` keys a rule does, so the delay still lands —
     * hence the optional parameter and the missing-name fallback rather than an
     * ArgumentCountError on every delayed publish until the update finishes.
     *
     * Auto-post now runs once the post's data has finished saving, which can be
     * a request or two after the publish; $publishedAt keeps the delay counting
     * from the publish itself. A free build that predates it doesn't pass one,
     * and the delay counts from now as it always did.
     *
     * @param WP_Post  $post
     * @param int      $postId
     * @param array    $rule
     * @param array    $autoPostSettings
     * @param null|int $publishedAt      WP-local timestamp of the publish
     */
    public static function createAutoPostDelay($post, $postId, $rule, $autoPostSettings = [], $publishedAt = null)
    {
        $wpTimeStamp = $publishedAt ? (int) $publishedAt : current_time('timestamp');
        $postDate = date('Y-m-d H:i:s', $wpTimeStamp);
        $templates = AutoPostRuleService::templatesFor(
            $rule,
            (array) (new SocialTemplateController())->getSocialTemplates()
        );
        $delay = isset($rule['postDelay']) && \is_array($rule['postDelay']) ? $rule['postDelay'] : [];
        $startTime = self::getModifyStartTime($postDate, $delay)->format('Y-m-d H:i:s');
        $name = isset($rule['name']) && $rule['name'] !== '' ? " - {$rule['name']}" : '';
        $accounts = isset($rule['accounts']) && \is_array($rule['accounts']) ? $rule['accounts'] : [];

        $scheduleData = [
            'name'   => "Auto Post{$name} - Post ID: {$postId}",
            'config' => [
                // Attribution for the "Created by" column. The post's author
                // rather than the current user: a post going live from its
                // scheduled date is published by WP-Cron, where there is no
                // current user, and the row would read "Unknown".
                'created_by' => (int) $post->post_author,
                // 'source' marks this row as auto-post generated so the missed
                // -schedule reaper can give it a longer catch-up window than a
                // hand-picked Share Now time (see CustomSchedule::isAutoPostSchedule).
                'settings'     => ['started_at' => $startTime, 'source' => self::SOURCE],
                'post_filters' => ['post_type' => $post->post_type, 'specific_postIds' => [$postId]],
                'accounts'     => [
                    'accountIds' => isset($accounts['accountIds']) ? $accounts['accountIds'] : [],
                    'groupIds'   => isset($accounts['groupIds']) ? $accounts['groupIds'] : [],
                ],
                'templates' => $templates,
            ],
            'schedule_type'     => Schedule::scheduleType['SCHEDULE_SHARE'],
            'status'            => Schedule::status['ACTIVE'],
            'started_at'        => $startTime,
            'next_published_at' => $startTime,
        ];

        $scheduleId = Schedule::insert($scheduleData);
        if ($scheduleId) {
            (new ShareNowController())->createSingleEventScheduleIsNotRepeat($scheduleId);
        }
    }

    public static function getModifyStartTime($date, $interval)
    {
        $currentDate = new DateTime($date);

        $every = isset($interval['every']) ? absint($interval['every']) : 0;
        $unit = isset($interval['unit']) && \is_scalar($interval['unit']) ? (string) $interval['unit'] : '';

        // Half a delay is no delay: `modify('+ s')` fails and returns false,
        // which would fatal on the format() call downstream.
        if (!$every || $unit === '') {
            return $currentDate;
        }

        /*
        'every' represents values like 1, 20, 30
        'unit' represents time units such as 'month', 'minute'
        (e.g., "+1 month", "+20 minutes")
        The function returns the modified DateTime object with the interval applied
        */

        return $currentDate->modify("+{$every} {$unit}s");
    }
}
