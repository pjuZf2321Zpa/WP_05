<?php

namespace BitApps\SocialPro\HTTP\Services\RoleAccess;

use BitApps\SocialPro\Config;

class RoleAccessService
{
    public const CAP = 'bit_social_access';

    /**
     * Roles that implicitly always have access: administrator plus any role
     * holding manage_options (custom admin-like roles). Users with
     * manage_options could already use the plugin on free — buying pro must
     * never shrink their access, and revoking them adds no security since
     * they can edit every plugin option anyway.
     *
     * @return string[]
     */
    public static function adminRoles()
    {
        $admins = ['administrator'];

        foreach (wp_roles()->roles as $slug => $roleData) {
            if (!empty($roleData['capabilities']['manage_options'])) {
                $admins[] = $slug;
            }
        }

        return array_values(array_unique($admins));
    }

    /**
     * Every WP role as a {slug, name} option list — shared by the Roles &
     * Access and per-account permission endpoints.
     *
     * @return array<array{slug: string, name: string}>
     */
    public static function roleOptions()
    {
        $options = [];

        foreach (wp_roles()->get_names() as $slug => $name) {
            $options[] = ['slug' => $slug, 'name' => translate_user_role($name)];
        }

        return $options;
    }

    /**
     * Whether an admin has ever saved Roles & Access on this site.
     *
     * Distinguishes "nobody has been granted access" from "the feature was
     * never touched", which getAllowedRoles() cannot: both return just the
     * admin-like roles. Behavior that would *narrow* what already worked —
     * currently the auto-post publisher gate (see pro HookProvider) — must
     * stay off until an admin opts in, so upgrading never silently changes
     * what an existing install does.
     *
     * @return bool
     */
    public static function isConfigured()
    {
        $settings = Config::getOption('settings', []);

        return \is_array($settings) && isset($settings['access']['roles']);
    }

    /**
     * Roles allowed to access the plugin. Admin-like roles (see adminRoles)
     * are always included.
     *
     * @return string[]
     */
    public static function getAllowedRoles()
    {
        $settings = Config::getOption('settings', []);
        $roles = \is_array($settings) && !empty($settings['access']['roles']) ? $settings['access']['roles'] : [];

        if (!\is_array($roles)) {
            $roles = [];
        }

        return array_values(array_unique(array_merge(self::adminRoles(), $roles)));
    }

    /**
     * Grants CAP to exactly the given roles (plus admin-like roles) and
     * revokes it from every other role, so role changes take effect
     * immediately.
     *
     * @param null|string[] $roles
     */
    public static function syncCapability($roles = null)
    {
        if ($roles === null) {
            $roles = self::getAllowedRoles();
        }

        $adminRoles = self::adminRoles();

        $wpRoles = wp_roles();
        foreach ($wpRoles->roles as $slug => $roleData) {
            $shouldHave = \in_array($slug, $adminRoles, true) || \in_array($slug, $roles, true);
            $currentlyHas = !empty($roleData['capabilities'][self::CAP]);

            if ($shouldHave === $currentlyHas) {
                continue;
            }

            $role = get_role($slug);
            if (!$role) {
                continue;
            }

            if ($shouldHave) {
                $role->add_cap(self::CAP);
            } else {
                $role->remove_cap(self::CAP);
            }
        }
    }

    /**
     * Removes CAP from every role. Runs when the license is missing/expired
     * and on plugin deactivation, so the capability granted while licensed
     * never lingers in wp_user_roles as a stale privilege. Idempotent: only
     * writes when a role actually holds the cap.
     */
    public static function revokeCapability()
    {
        foreach (wp_roles()->roles as $slug => $roleData) {
            if (empty($roleData['capabilities'][self::CAP])) {
                continue;
            }

            $role = get_role($slug);
            if ($role) {
                $role->remove_cap(self::CAP);
            }
        }
    }
}
