<?php

namespace BitApps\SocialPro\HTTP\Services\RoleAccess;

use BitApps\SocialPro\Config;
use BitApps\SocialPro\Model\GroupsAccount;

class AccountPermissionService
{
    /**
     * Option holding per-account role restrictions, keyed by account id:
     * ['12' => ['roles' => ['administrator', 'author']]]. An account with no
     * entry is unrestricted — usable by every role allowed in Roles & Access.
     */
    public const OPTION = 'account_permissions';

    /**
     * @return array<string, array{roles: string[]}>
     */
    public static function getAll()
    {
        $permissions = Config::getOption(self::OPTION, []);

        return \is_array($permissions) ? $permissions : [];
    }

    /**
     * Roles allowed on the account, or null when the account is unrestricted.
     *
     * @param int|string $accountId
     *
     * @return null|string[]
     */
    public static function getRolesFor($accountId)
    {
        $permissions = self::getAll();
        $key = (string) absint($accountId);

        if (!isset($permissions[$key]['roles']) || !\is_array($permissions[$key]['roles'])) {
            return;
        }

        return array_values($permissions[$key]['roles']);
    }

    /**
     * Restricts the account to the given roles. Admin-like roles (see
     * RoleAccessService::adminRoles) are always kept in the list so admins
     * can never lock themselves out of an account.
     *
     * @param int|string $accountId
     * @param string[]   $roles
     */
    public static function updateRolesFor($accountId, $roles)
    {
        $roles = array_merge(RoleAccessService::adminRoles(), $roles);

        $permissions = self::getAll();
        $permissions[(string) absint($accountId)] = ['roles' => array_values(array_unique($roles))];

        Config::updateOption(self::OPTION, $permissions);
    }

    /**
     * Removes the account's restriction entry (making it unrestricted).
     * Also hooked to the free plugin's account-deleted action for cleanup.
     *
     * @param int|string $accountId
     */
    public static function removeAccount($accountId)
    {
        $permissions = self::getAll();
        $key = (string) absint($accountId);

        if (!isset($permissions[$key])) {
            return;
        }

        unset($permissions[$key]);
        Config::updateOption(self::OPTION, $permissions);
    }

    /**
     * Whether the user may publish through the account. Administrators always
     * may. On a restricted account the user needs one of the account's granted
     * roles — plugin access (Roles & Access) is NOT required, so an author-only
     * role granted here still auto-posts. An unrestricted account keeps
     * meaning "everyone with plugin access".
     *
     * @param int|string $userId
     * @param int|string $accountId
     *
     * @return bool
     */
    public static function userCanUseAccount($userId, $accountId)
    {
        $userId = absint($userId);

        if (!$userId) {
            return false;
        }

        if (user_can($userId, 'manage_options')) {
            return true;
        }

        $user = get_userdata($userId);

        if (!$user) {
            return false;
        }

        $roles = self::getRolesFor($accountId);

        if ($roles === null) {
            // Unrestricted account. Until an admin has actually saved Roles &
            // Access there is no allow-list to read — getAllowedRoles() is then
            // just the admin-like roles — so restricting one account would
            // quietly take every *other* account away from the roles that were
            // publishing through them yesterday. Same rule as the auto-post
            // publisher gate: narrowing waits for the admin to opt in.
            if (!RoleAccessService::isConfigured()) {
                return true;
            }

            return (bool) array_intersect((array) $user->roles, RoleAccessService::getAllowedRoles());
        }

        return (bool) array_intersect((array) $user->roles, $roles);
    }

    /**
     * Filter for the free plugin's autopost_publisher_allowed gate: lets a
     * publisher without the plugin access capability auto-post when their role
     * is explicitly granted on at least one account — account filtering then
     * limits publishing to exactly those accounts.
     *
     * @param bool       $canPublish
     * @param int|string $userId
     *
     * @return bool
     */
    public static function allowGrantedPublisher($canPublish, $userId)
    {
        if ($canPublish) {
            return true;
        }

        $user = get_userdata(absint($userId));

        if (!$user) {
            return false;
        }

        foreach (self::getAll() as $entry) {
            if (!empty($entry['roles']) && array_intersect((array) $user->roles, (array) $entry['roles'])) {
                return true;
            }
        }

        return false;
    }

    /**
     * Filters a list of account models/objects (anything exposing ->id) down
     * to the ones the user may publish through. Hooked to the free plugin's
     * autopost accounts filter.
     *
     * @param mixed      $accounts
     * @param int|string $userId
     *
     * @return mixed
     */
    public static function filterAccountsForUser($accounts, $userId)
    {
        if (!\is_array($accounts) || empty($accounts) || empty(self::getAll())) {
            return $accounts;
        }

        // No acting user (a post published by WP-CLI or an importer with
        // post_author 0 — see AutoPostController::publisherCanAutoPost). There
        // is no role to evaluate, so filtering would silently reduce the
        // admin's auto-post accounts to none instead of restricting anyone.
        if (!absint($userId)) {
            return $accounts;
        }

        return array_values(array_filter($accounts, function ($account) use ($userId) {
            $accountId = \is_object($account) ? ($account->id ?? 0) : ($account['id'] ?? 0);

            return self::userCanUseAccount($userId, $accountId);
        }));
    }

    /**
     * Same filtering keyed to the logged-in user — hooked to both the free
     * plugin's accounts_list (the Accounts page) and active_accounts (the
     * Share Now / Schedules / Auto Post pickers), so a restricted account is
     * invisible to users who cannot publish through it. Administrators always
     * see every account (userCanUseAccount bypasses restrictions for them).
     *
     * @param mixed $accounts
     *
     * @return mixed
     */
    public static function filterAccountsForCurrentUser($accounts)
    {
        return self::filterAccountsForUser($accounts, get_current_user_id());
    }

    /**
     * Filter for the free plugin's can_use_accounts gate: authorizes the
     * account ids a share-now/schedule save request references — including
     * accounts reached through groups — against the current user's
     * per-account permissions. The pickers only hide restricted accounts;
     * this is the server-side check the save endpoints rely on.
     *
     * @param bool  $permitted
     * @param mixed $accountsConfig {accountIds: int[], groupIds: int[]}
     *
     * @return bool
     */
    public static function authorizeRequestedAccounts($permitted, $accountsConfig)
    {
        if (!$permitted || !\is_array($accountsConfig) || empty(self::getAll())) {
            return $permitted;
        }

        $accountIds = isset($accountsConfig['accountIds']) && \is_array($accountsConfig['accountIds'])
            ? $accountsConfig['accountIds'] : [];

        if (!empty($accountsConfig['groupIds']) && \is_array($accountsConfig['groupIds']) && class_exists(GroupsAccount::class)) {
            $groupAccounts = GroupsAccount::where('group_id', $accountsConfig['groupIds'])->get('account_id');

            foreach ((array) $groupAccounts as $groupAccount) {
                $accountIds[] = \is_object($groupAccount) ? $groupAccount->account_id : ($groupAccount['account_id'] ?? 0);
            }
        }

        $userId = get_current_user_id();

        foreach (array_unique($accountIds) as $accountId) {
            if (!self::userCanUseAccount($userId, $accountId)) {
                return false;
            }
        }

        return true;
    }
}
