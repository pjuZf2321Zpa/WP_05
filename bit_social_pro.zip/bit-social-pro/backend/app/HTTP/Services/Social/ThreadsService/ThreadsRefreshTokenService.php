<?php

namespace BitApps\SocialPro\HTTP\Services\Social\ThreadsService;

use BitApps\Social\Model\Account;
use BitApps\Social\Utils\Hash;
use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use BitApps\SocialPro\Utils\AccountReconnect;

class ThreadsRefreshTokenService
{
    /**
     * Threads can only renew a token while it is still valid, and a renewal
     * happens only when a post goes out. Renew once the 60 day token has 40
     * days left, so a weekly or monthly schedule renews it in time.
     */
    private const RENEW_BEFORE_EXPIRY = 40 * 24 * 60 * 60;

    private $httpHandler;

    private $refreshTokenUrl = 'https://graph.threads.net/refresh_access_token';

    private $accountId;

    private $accountDetails;

    private $accessToken;

    private $expiresIn;

    public function __construct($accountDetails)
    {
        $this->httpHandler = new HttpClient();

        $this->accountDetails = $accountDetails;
        $this->accountId = $accountDetails->account_id;
        $this->accessToken = Hash::decrypt($accountDetails->access_token);
        $this->expiresIn = $accountDetails->expiresIn;
    }

    public function tokenExpiryCheck()
    {
        if ((\intval($this->expiresIn) - self::RENEW_BEFORE_EXPIRY) < time()) {
            return $this->refreshAccessToken();
        }

        return $this->accessToken;
    }

    public function accessToken()
    {
        return $this->tokenExpiryCheck();
    }

    public function refreshAccessToken()
    {
        $params = [
            'grant_type'   => 'th_refresh_token',
            'access_token' => $this->accessToken,
        ];

        $accessTokenUrlWithParams = $this->refreshTokenUrl . '?' . http_build_query($params);

        $result = $this->httpHandler->request($accessTokenUrlWithParams, 'GET', []);

        if (isset($result->access_token)) {
            $this->accessToken = $result->access_token;
            $this->expiresIn = time() + (int) $result->expires_in;
            $this->saveAccessToken();
        } elseif ((int) $this->expiresIn < time()) {
            // A Threads token can only be refreshed while it is still alive;
            // once it lapses the user has to authorize the app again. Before
            // that, the stored token still works and the next publish tries
            // the renewal again.
            AccountReconnect::flag('threads', $this->accountId, __('Threads could not renew the access token.', 'bit-social'));
        }

        return $this->accessToken;
    }

    public function saveAccessToken()
    {
        if (empty($this->accountId)) {
            return;
        }

        $account = Account::findOne(['account_id' => $this->accountId, 'platform' => 'threads']);

        if (!$account) {
            return;
        }

        $accountDetails = AccountReconnect::withoutFlag($this->accountDetails);
        $accountDetails->access_token = Hash::encrypt($this->accessToken);
        $accountDetails->expiresIn = $this->expiresIn;
        $account->update(['details' => $accountDetails])->save();
    }
}
