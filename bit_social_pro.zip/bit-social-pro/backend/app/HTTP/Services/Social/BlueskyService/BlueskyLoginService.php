<?php

namespace BitApps\SocialPro\HTTP\Services\Social\BlueskyService;

use BitApps\Social\HTTP\Services\Traits\LoggerTrait;
use BitApps\Social\Model\Account;
use BitApps\Social\Utils\Common;
use BitApps\Social\Utils\Hash;
use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use BitApps\SocialPro\Utils\ConnectError;

class BlueskyLoginService
{
    use Common, LoggerTrait;

    private $apiBaseUrl = 'https://bsky.social/xrpc/';

    private $HttpClient;

    public function __construct()
    {
        $this->HttpClient = new HttpClient();
    }

    public function authHandler($request)
    {
        $body = $request->body();
        $id = $body['payload']['id'];
        $password = $body['payload']['password'];

        $response = $this->login($id, $password);

        if ($response['status'] === 'error') {
            return (object) $response;
        }

        $loginResponse = $response['data'];

        // Without a session the account assembled below is all nulls, and the
        // Accounts screen would offer it for saving as if the login worked.
        if (!\is_object($loginResponse) || empty($loginResponse->did) || empty($loginResponse->accessJwt)) {
            return (object) ['status' => 'error', 'message' => 'Bluesky login failed, please try again!'];
        }

        $actor = $loginResponse->did;
        $accessToken = $loginResponse->accessJwt;

        $profile = $this->profileInfo($actor, $accessToken);

        if (is_wp_error($profile)) {
            return (object) ['status' => 'error', 'message' => ConnectError::unreachable($profile, 'Bluesky')];
        }

        if (!\is_object($profile) || empty($profile->did)) {
            return (object) ['status' => 'error', 'message' => 'Fetching the Bluesky profile failed, please try again!'];
        }

        return $this->accountInformation($profile, $loginResponse);
    }

    public function profileInfo($actor, $accessToken)
    {
        $url = $this->apiBaseUrl . 'app.bsky.actor.getProfile';
        $headers = [
            'Authorization' => 'Bearer ' . $accessToken,
            'Content-Type'  => 'application/json'
        ];

        $params = [
            'actor' => $actor
        ];

        $url .= '?' . http_build_query($params);

        return $this->HttpClient->request($url, 'GET', [], $headers);
    }

    public function login($id, $password)
    {
        $url = $this->apiBaseUrl . 'com.atproto.server.createSession';
        $body = [
            'identifier' => $id,
            'password'   => $password
        ];
        $headers = [
            'Content-Type' => 'application/json'
        ];
        $response = $this->HttpClient->request($url, 'POST', json_encode($body), $headers);

        // Bluesky being unreachable is a WP_Error, which carries neither the
        // `error` field checked below nor a session.
        if (is_wp_error($response)) {
            return ['status' => 'error', 'message' => ConnectError::unreachable($response, 'Bluesky')];
        }

        if (isset($response->error)) {
            return ['status' => 'error', 'message' => isset($response->message) ? $response->message : $response->error];
        }

        return ['status' => 'success', 'data' => $response];
    }

    public function accountInformation($profile, $loginResponse)
    {
        $userId = $profile->did;
        $accountDetails = [
            'profile_id'    => $userId,
            'account_id'    => $userId,
            'account_name'  => empty($profile->displayName) ? $profile->handle : $profile->displayName,
            'account_type'  => 'profile',
            'platform'      => 'bluesky',
            'user_name'     => $profile->handle,
            'icon'          => $profile->avatar,
            'access_token'  => Hash::encrypt($loginResponse->accessJwt),
            'refresh_token' => Hash::encrypt($loginResponse->refreshJwt),
            'generateOn'    => time(),
        ];

        $userData['profile_id'] = $userId;
        $userData['account_id'] = $userId;
        $userData['account_name'] = $accountDetails['account_name'];
        $userData['details'] = json_encode($accountDetails);
        $userData['platform'] = 'bluesky';
        $userData['account_type'] = Account::accountType['CUSTOM'];
        $userData['status'] = Account::ACCOUNT_STATUS['active'];

        $totalAccount = Account::where('account_id', $userId)->count();
        $isConnected = true;

        if (!$totalAccount || $totalAccount === 0) {
            $isConnected = false;
        }

        $accountData[] = ['account' => $userData, 'isConnected' => $isConnected];

        return $accountData;
    }
}
