<?php

namespace BitApps\SocialPro\HTTP\Services\Social\TelegramService;

use AllowDynamicProperties;
use BitApps\Social\Config;
use BitApps\Social\Deps\BitApps\WPKit\Hooks\Hooks;
use BitApps\Social\HTTP\Services\Interfaces\SocialInterface;
use BitApps\Social\HTTP\Services\Traits\LoggerTrait;
use BitApps\Social\Model\Schedule;
use BitApps\Social\Utils\Common;
use BitApps\Social\Utils\Hash;
use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use BitApps\SocialPro\Utils\DirectShareAttachments;

// use GuzzleHttp\Client;

#[AllowDynamicProperties]
class PostPublishTelegramService implements SocialInterface
{
    use Common, LoggerTrait;

    private $baseUrl = 'https://api.telegram.org/bot';

    private $httpClient;

    private $accessToken;

    private $mediaErrors = [];

    private $linkErrors = [];

    private $commentErrors = [];

    private $telegramData = [];

    private $maxTextLength = 1024;

    public function __construct()
    {
        $this->httpClient = new HttpClient();
    }

    public function publishPost($data)
    {
        $post = $data['post'] ?? null;
        $template = (object) $data['template'];
        $scheduleType = $data['schedule_type'] ?? null;
        $accountDetails = $data['account_details'];
        $schedule_id = $data['schedule_id'] ?? null;
        $accountId = $accountDetails->account_id;
        $accountName = $accountDetails->account_name;

        $this->accessToken = Hash::decrypt($accountDetails->access_token);
        $this->chatId = $accountDetails->account_id;

        $postData = $this->postData($scheduleType, $post, $template);

        $this->telegramData['post'] = $this->normalizePostData($postData, true);

        $postPublishResponse = $this->sendMessage($postData);

        $status = \is_object($postPublishResponse) && $postPublishResponse->ok ? 1 : 0;

        $responseData = [
            'schedule_id' => $schedule_id,
            'details'     => [
                'account_id'   => $accountId,
                'account_name' => $accountName,
                'post_id'      => $post['ID'] ?? null,
                'response'     => $postPublishResponse,
                'post_url'     => null,
            ],
            'platform' => 'telegram',
            'status'   => $status
        ];

        $hookResponse = [
            'account_id'   => $accountId,
            'account_name' => $accountName,
            'post_url'     => $responseData['details']['post_url'],
            'status'       => $responseData['status'],
        ];

        if (\count($this->mediaErrors)) {
            $responseData['details']['mediaErrors'] = $this->mediaErrors;
        }

        if (\count($this->linkErrors)) {
            $responseData['details']['linkErrors'] = $this->linkErrors;
        }

        if (\count($this->commentErrors)) {
            $responseData['details']['commentErrors'] = $this->commentErrors;
        }

        $this->telegramData['platform'] = 'telegram';
        $this->telegramData['response'] = $responseData;

        // A retry rewrites the row it was fired from, the way every other
        // platform does. Logging a new one instead left the failure behind and
        // its run stuck showing a Retry button that could never be satisfied.
        if (\array_key_exists('retry', $data) && $data['retry'] === true) {
            $this->logUpdate($responseData, $data['log_id']);
        } elseif (!(\array_key_exists('keepLogs', $data) && $data['keepLogs'] === false)) {
            $this->logCreate($responseData);
        }
        Hooks::doAction(Config::withPrefix('telegram_post_publish'), $this->normalizePostData($postData), $hookResponse);

        return $this->telegramData;
    }

    public function postData($scheduleType, $post, $template)
    {
        $postData = [];
        $template = (object) $template;

        if ($scheduleType === Schedule::scheduleType['DIRECT_SHARE']) {
            $attachments = DirectShareAttachments::resolve($template);

            $postData['content'] = $template->content ?? null;
            $postData['createdAt'] = date('c');
            $postData['media'] = $attachments['media'];
            $postData['link'] = $attachments['link'];
        } else {
            $template->platform = 'telegram';
            $postData = $this->replacePostContent($post['ID'], $template);
        }

        return $postData;
    }

    public function sendMessage($postData)
    {
        if (!empty($postData['media'])) {
            return $this->sendMediaGroup($postData);
        }
        $url = "{$this->baseUrl}{$this->accessToken}/sendMessage";

        $content = $postData['content'] ?? '';

        $body = [
            'chat_id'    => $this->chatId,
            'text'       => $content,
            'parse_mode' => 'HTML',
        ];

        if (!empty($postData['link'])) {
            $reservedLength = \strlen("\n\n" . $postData['link']);
            $availableLength = $this->maxTextLength - $reservedLength;

            // Trim content if necessary
            if (\strlen($content) > $availableLength) {
                $content = mb_substr($content, 0, $availableLength - 3) . '...';
            }

            $body['text'] = $content . "\n\n" . $postData['link'];
        }

        return $this->httpClient->request($url, 'POST', $body);
    }

    public function sendMediaGroup($postingData)
    {
        $url = "{$this->baseUrl}{$this->accessToken}/sendMediaGroup";

        $media = [];
        foreach ($postingData['media'] as $index => $mediaItem) {
            $media[] = [
                'type'       => 'photo',
                'media'      => $mediaItem,
                'parse_mode' => 'HTML',
            ];
        }

        if (!empty($postingData['content'])) {
            $media[0]['caption'] = $postingData['content'] ?? '';
        }

        $body = [
            'chat_id' => $this->chatId,
            'media'   => wp_json_encode($media),
        ];

        return $this->httpClient->request($url, 'POST', $body);
    }
}
