<?php

namespace BitApps\SocialPro\HTTP\Services\Social\InstagramService;

use AllowDynamicProperties;
use BitApps\Social\Config;
use BitApps\Social\Deps\BitApps\WPKit\Hooks\Hooks;
use BitApps\Social\HTTP\Services\Interfaces\SocialInterface;
use BitApps\Social\HTTP\Services\Traits\LoggerTrait;
use BitApps\Social\Model\Schedule;
use BitApps\Social\Utils\Common;
use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use BitApps\SocialPro\Utils\AccountReconnect;
use BitApps\SocialPro\Utils\MetaGraph;

#[AllowDynamicProperties]
class PostPublishInstagramService implements SocialInterface
{
    use Common, LoggerTrait;

    private $version = MetaGraph::VERSION;

    private $httpHandler;

    /**
     * @var RefreshService $refreshHandler
     */
    private $refreshHandler;

    private $accessToken;

    private $profileId;

    private $mediaUploadErrors = [];

    private $commentError = [];

    private $postData;

    private $baseUrl = 'https://graph.facebook.com/';

    private $postUrl = 'https://www.instagram.com/p/';

    private $instagramData = [];

    public function __construct()
    {
        $this->httpHandler = new HttpClient();
        $this->refreshHandler = new InstagramRefreshTokenService();
    }

    public function publishPost($data)
    {
        $post = $data['post'] ?? null;
        $postData = [];
        $template = (object) $data['template'];
        $scheduleType = $data['schedule_type'] ?? null;
        $accountDetails = $data['account_details'];
        $schedule_id = $data['schedule_id'] ?? null;
        $accessToken = $accountDetails->access_token;
        $account_id = $accountDetails->account_id;
        $account_name = $accountDetails->account_name;
        $generates_on = $accountDetails->generates_on;

        // Accounts connected via "Instagram API with Instagram Login" talk to
        // graph.instagram.com with an Instagram-user token; legacy Facebook-Login
        // accounts (no auth_method) keep using graph.facebook.com with a Page token.
        $authMethod = $accountDetails->auth_method ?? 'facebook_login';
        if ($authMethod === 'instagram_login') {
            $this->baseUrl = 'https://graph.instagram.com/';
        }

        $tokenUpdateData = $this->refreshHandler->tokenExpiryCheck($accessToken, $generates_on, $authMethod);

        // A failed refresh returns false; publish with the stored token rather
        // than saving an empty one over it.
        if (\is_object($tokenUpdateData) && !empty($tokenUpdateData->access_token)) {
            if ($tokenUpdateData->access_token !== $accessToken) {
                $accountDetails->access_token = $tokenUpdateData->access_token;
                $accountDetails->generates_on = $tokenUpdateData->generates_on;
                $this->refreshHandler->saveRefreshedToken($accountDetails);
            }

            $accessToken = $tokenUpdateData->access_token;
        } elseif ((\intval($generates_on) + 60 * DAY_IN_SECONDS) < time()) {
            // The 60-day token could not be renewed — it aged out while the
            // site was idle, or the user removed the app. Warn on the card.
            // A younger token still works, and the next publish tries again.
            AccountReconnect::flag('instagram', $account_id, __('Instagram could not renew the access token.', 'bit-social'));
        }

        $this->accessToken = $accessToken;
        $this->profileId = $accountDetails->account_id;

        if ($scheduleType === Schedule::scheduleType['DIRECT_SHARE']) {
            $templateMedia = array_map(function ($item) {
                return $item['url'];
            }, $template->media);

            $postData['content'] = $template->content ?? null;
            $postData['media'] = $templateMedia ?? null;
            $postData['link'] = $template->link ?? null;
            $postData['comment'] = $template->comment ?? null;

            $template->isFeaturedImage = false;
            $template->isLinkCard = false;

            if (!empty($templateMedia)) {
                $template->isFeaturedImage = true;
            }
            if (empty($templateMedia) && !empty($template->link)) {
                $template->isLinkCard = true;
            }

            // Share Now media skips replacePostContent(), which is where the
            // other paths get their images made Instagram-safe.
            if (!empty($postData['media'])) {
                $postData['media'] = $this->normalizeMediaForPlatform($postData['media'], 'instagram', $template);
            }
        } else {
            $template->platform = 'instagram';
            $postData = $this->replacePostContent($post['ID'], $template);
        }

        $postPublishResponse = $this->instagramPostPublish($postData);

        if (isset($postPublishResponse->shortcode)) {
            $postUrl = $this->postUrl . $postPublishResponse->shortcode;
        }

        $responseData = [
            'schedule_id' => $schedule_id,
            'details'     => [
                'account_id'   => $account_id,
                'account_name' => $account_name,
                'post_id'      => $post['ID'] ?? null,
                'response'     => $postPublishResponse,
                'post_url'     => $postUrl ?? null
            ],
            'platform' => 'instagram',
            'status'   => \is_object($postPublishResponse) && property_exists($postPublishResponse, 'id') ? 1 : 0
        ];

        if (\count($this->mediaUploadErrors)) {
            $responseData['details']['imageUploadErrors'] = $this->mediaUploadErrors;
        }
        if (\count($this->commentError)) {
            $responseData['details']['commentError'] = $this->commentError;
        }

        $hookResponse = [
            'account_id'   => $account_id,
            'account_name' => $account_name,
            'post_url'     => $responseData['details']['post_url'],
            'status'       => $responseData['status'],
        ];

        $this->instagramData['platform'] = 'instagram';
        $this->instagramData['post'] = $this->normalizePostData($postData, true);
        $this->instagramData['response'] = $hookResponse;

        Hooks::doAction(Config::withPrefix('instagram_post_publish'), $this->normalizePostData($postData), $hookResponse);

        if (\array_key_exists('retry', $data) && $data['retry'] === true) {
            // A retry rewrites the row it was launched from rather than adding
            // one, so recovering a post turns that row green instead of leaving
            // a failure and a success side by side — and keeps the tally the
            // Logs screen shows for the run honest.
            $this->logUpdate($responseData, isset($data['log_id']) ? $data['log_id'] : null);
        } elseif (!(\array_key_exists('keepLogs', $data) && $data['keepLogs'] === false)) {
            $this->logCreate($responseData);
        }

        return $this->instagramData;
    }

    public function instagramPostPublish($postData)
    {
        $caption = $postData['content'] ?? null;

        $comment = $postData['comment'] ?? null;
        $media = $postData['media'] ?? [];

        return $this->postMedia($caption, $media, $comment);
    }

    public function postMedia($caption, $media, $comment)
    {
        if (empty($media)) {
            return [
                'status'    => 'error',
                'error_msg' => 'Instagram posts require at least one image. Your WordPress post does not have a featured image or attached image. Please add an image or update your template settings.'
            ];
        }

        if (\count($media) > 10) {
            return [
                'status'    => 'error',
                'error_msg' => 'You have added more than 10 images. Please limit to 10 images.'
            ];
        }

        if (\count($media) > 1) {
            return $this->multipleMediaPost($media, $caption, $comment);
        }

        $mediaUrl = $media[0];

        return $this->singleMediaPost($mediaUrl, $caption, $comment);
    }

    public function mediaUpload($mediaUrl, $caption, $isCarousel = false)
    {
        $params['image_url'] = $mediaUrl;
        if (isset($caption)) {
            $params['caption'] = $caption;
        }
        if ($isCarousel) {
            $params['is_carousel_item'] = 'true';
        }

        $params['access_token'] = $this->accessToken;

        $postPublishUrl = "{$this->baseUrl}{$this->version}/{$this->profileId}/media?";

        $publishPostUrlWithParams = $postPublishUrl . http_build_query($params);

        $uploadResponse = $this->httpHandler->request($publishPostUrlWithParams, 'POST', []);

        if (isset($uploadResponse->id)) {
            return $this->checkPublishSuccess($uploadResponse->id) ? $uploadResponse : false;
        }

        return $uploadResponse;
    }

    public function mediaPublish($creationId)
    {
        $postPublishUrl = "{$this->baseUrl}{$this->version}/{$this->profileId}/media_publish?";
        $params['creation_id'] = $creationId;
        $params['access_token'] = $this->accessToken;

        $publishPostUrlWithParams = $postPublishUrl . http_build_query($params);

        return $this->httpHandler->request($publishPostUrlWithParams, 'POST', []);
    }

    public function shortCode($creationId)
    {
        $postPublishUrl = "{$this->baseUrl}{$this->version}/{$creationId}?";
        $params['fields'] = 'shortcode';
        $params['access_token'] = $this->accessToken;

        $publishPostUrlWithParams = $postPublishUrl . http_build_query($params);

        return $this->httpHandler->request($publishPostUrlWithParams, 'GET', []);
    }

    public function checkPublishSuccess($uploadId)
    {
        $postPublishUrl = "{$this->baseUrl}{$this->version}/{$uploadId}?";
        $params['fields'] = 'status_code';
        $params['access_token'] = $this->accessToken;

        $publishPostUrlWithParams = $postPublishUrl . http_build_query($params);
        $retries = 0;
        while ($retries < 30) {
            $status = $this->httpHandler->request($publishPostUrlWithParams, 'GET', []);

            if (! isset($status->status_code) || \in_array($status->status_code, ['EXPIRED', 'ERROR'])) {
                return false;
            }

            if ($status->status_code == 'IN_PROGRESS') {
                sleep(3);
                $retries++;
            } else {
                break;
            }
        }

        return true;
    }

    public function createCarouselContainer($caption, $uploadIds)
    {
        if (isset($caption)) {
            $params['caption'] = $caption;
        }
        $params['media_type'] = 'CAROUSEL';

        if ($uploadIds) {
            $uploadIdsString = implode(',', $uploadIds);
            $params['children'] = $uploadIdsString;
        }

        $params['access_token'] = $this->accessToken;

        $postPublishUrl = "{$this->baseUrl}{$this->version}/{$this->profileId}/media?";

        $publishPostUrlWithParams = $postPublishUrl . http_build_query($params);

        $uploadResponse = $this->httpHandler->request($publishPostUrlWithParams, 'POST', []);

        if (isset($uploadResponse->id)) {
            return $this->checkPublishSuccess($uploadResponse->id) ? $uploadResponse->id : false;
        }

        return $uploadResponse;
    }

    public function makeComment($mediaId, $message)
    {
        $postCommentUrl = "{$this->baseUrl}{$this->version}/{$mediaId}/comments?";
        $params['message'] = $message;
        $params['access_token'] = $this->accessToken;

        $postCommentUrlWithParams = $postCommentUrl . http_build_query($params);

        return $this->httpHandler->request($postCommentUrlWithParams, 'POST', []);
    }

    public function singleMediaPost($mediaUrl, $caption, $commentMessage)
    {
        $mediaUploadResponse = $this->mediaUpload($mediaUrl, $caption);

        if (isset($mediaUploadResponse->id)) {
            $mediaPublishResponse = $this->mediaPublish($mediaUploadResponse->id);

            if (isset($mediaPublishResponse->id)) {
                if (!empty($commentMessage)) {
                    $commentResponse = $this->makeComment($mediaPublishResponse->id, $commentMessage);
                }

                if (isset($commentResponse->error)) {
                    $this->commentError[] = $commentResponse->error;
                }

                return $this->shortCode($mediaPublishResponse->id);
            }

            return $mediaPublishResponse;
        }

        if (isset($mediaUploadResponse->error)) {
            $this->mediaUploadErrors[] = $this->explainMediaError($mediaUploadResponse->error);
        }
    }

    public function multipleMediaPost($postImages, $caption, $commentMessage)
    {
        foreach ($postImages as $mediaUrl) {
            $uploadResponse = $this->mediaUpload($mediaUrl, $caption, true);

            if (isset($uploadResponse->id)) {
                $uploadIds[] = $uploadResponse->id;
            }

            if (isset($uploadResponse->error)) {
                $this->mediaUploadErrors[] = $this->explainMediaError($uploadResponse->error);
            }
        }

        if (!empty($uploadIds) && \count($uploadIds) > 1) {
            $containerResponse = $this->createCarouselContainer($caption, $uploadIds);
            if (!empty($containerResponse)) {
                $mediaPublishResponse = $this->mediaPublish($containerResponse);

                if (isset($mediaPublishResponse->id)) {
                    if (!empty($commentMessage)) {
                        $commentResponse = $this->makeComment($mediaPublishResponse->id, $commentMessage);
                    }

                    if (isset($commentResponse->error)) {
                        $this->commentError[] = $commentResponse->error;
                    }

                    return $this->shortCode($mediaPublishResponse->id);
                }

                return $mediaPublishResponse;
            }

            return $containerResponse;
        }

        return [
            'status'    => 'error',
            'error_msg' => 'Instagram requires all selected images to be valid and meet their guidelines. Please check your images and try again.'
        ];
    }

    /**
     * Meta's aspect-ratio rejection reads "aspect ratio ()" when it cannot even
     * decode the image, which tells the user nothing. Images that are not in the
     * media library cannot be fixed up locally, so say what Instagram accepts.
     *
     * @param mixed $error
     */
    private function explainMediaError($error)
    {
        if (\is_object($error) && isset($error->error_subcode) && (int) $error->error_subcode === 2207009) {
            $error->error_user_msg = __('Instagram accepts JPEG images with an aspect ratio between 4:5 and 1.91:1. Please use an image within that range.', 'bit-social');
        }

        return $error;
    }
}
