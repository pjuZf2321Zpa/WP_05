<?php

namespace BitApps\SocialPro\HTTP\Services\Social\InstagramService;

use BitApps\Social\Deps\BitApps\WPKit\Http\Client\HttpClient;
use BitApps\Social\HTTP\Services\Traits\LoggerTrait;
use BitApps\Social\Model\Account;
use BitApps\Social\Utils\Common;
use BitApps\SocialPro\Utils\AccountReconnect;
use BitApps\SocialPro\Utils\MetaGraph;
use stdClass;

class InstagramRefreshTokenService
{
    use Common, LoggerTrait;

    private $httpHandler;

    private $baseUrl = 'https://graph.facebook.com/';

    private $instagramBaseUrl = 'https://graph.instagram.com/';

    private $baseServerUrl = 'https://auth-apps.bitapps.pro/apps/';

    private $version = MetaGraph::VERSION;

    private $instagramAppIdUrl;

    private $instagramAppSecretUrl;

    private $refreshTokenUrl;

    private $instagramRefreshTokenUrl;

    public function __construct()
    {
        $this->httpHandler = new HttpClient();
        $this->instagramAppIdUrl = $this->baseServerUrl . 'instagram';
        $this->instagramAppSecretUrl = $this->baseServerUrl . 'secret';
        $this->refreshTokenUrl = $this->baseUrl . $this->version . '/oauth/access_token?';
        $this->instagramRefreshTokenUrl = $this->instagramBaseUrl . 'refresh_access_token?';
    }

    public function tokenExpiryCheck($accessToken, $generates_on, $authMethod = 'facebook_login')
    {
        if (!$accessToken && !$generates_on) {
            return false;
        }
        // Legacy Facebook-Login tokens last 60 days; Instagram-Login long-lived tokens
        // also last 60 days and are refreshable after 24h. A refresh happens only
        // when a post goes out, so refresh after 20 days: a weekly or monthly
        // schedule then always publishes once while the token is still valid.
        $isInstagramLogin = $authMethod === 'instagram_login';
        $expiryWindow = 20 * 24 * 60 * 60;
        if ((\intval($generates_on) + $expiryWindow) < time()) {
            $refreshToken = $isInstagramLogin
                ? $this->refreshInstagramLoginToken($accessToken)
                : $this->refreshToken($accessToken);
            if (!\is_object($refreshToken) || !property_exists($refreshToken, 'access_token')) {
                return false;
            }
            $data = new stdClass();
            $data->access_token = $refreshToken->access_token;
            $data->generates_on = $refreshToken->generates_on;

            return $data;
        }
        $data = new stdClass();
        $data->access_token = $accessToken;
        $data->generates_on = $generates_on;

        return $data;
    }

    public function refreshInstagramLoginToken($accessToken)
    {
        $params = [
            'grant_type'   => 'ig_refresh_token',
            'access_token' => $accessToken,
        ];

        $refreshTokenUrlWithParams = $this->instagramRefreshTokenUrl . http_build_query($params);
        $apiResponse = $this->httpHandler->request($refreshTokenUrlWithParams, 'GET', []);
        if (!\is_object($apiResponse) || !property_exists($apiResponse, 'access_token')) {
            return false;
        }
        $data = new stdClass();
        $data->access_token = $apiResponse->access_token;
        $data->generates_on = time();

        return $data;
    }

    public function refreshToken($accessToken)
    {
        $instagramAppIdData = $this->httpHandler->request($this->instagramAppIdUrl, 'GET', []);

        if (!\is_object($instagramAppIdData) || empty($instagramAppIdData->clientId)) {
            return false;
        }
        $instagramAppId = $instagramAppIdData->clientId;
        $headers = [
            'Content-Type' => 'application/json',
        ];
        $getSecretParams = [
            'client_id' => $instagramAppId,
            'platform'  => 'instagram',
        ];

        $instagramAppSecret = $this->httpHandler->request($this->instagramAppSecretUrl, 'POST', json_encode($getSecretParams), $headers);
        if (empty($instagramAppSecret->clientSecret)) {
            return false;
        }
        $instagramAppSecret = $instagramAppSecret->clientSecret;
        $longTimeAccessTokenParams = [
            'grant_type'        => 'fb_exchange_token',
            'client_id'         => $instagramAppId,
            'client_secret'     => $instagramAppSecret,
            'fb_exchange_token' => $accessToken,
        ];

        $refreshTokenUrlWithParams = $this->refreshTokenUrl . http_build_query($longTimeAccessTokenParams);
        $apiResponse = $this->httpHandler->request($refreshTokenUrlWithParams, 'GET', []);
        if (!\is_object($apiResponse) || !property_exists($apiResponse, 'access_token')) {
            return false;
        }
        $data = new stdClass();
        $data->access_token = $apiResponse->access_token;
        $data->generates_on = time();

        return $data;
    }

    public function saveRefreshedToken($account_detail)
    {
        $accountId = $account_detail->account_id;
        if (empty($accountId)) {
            return;
        }
        $account = Account::findOne(['account_id' => $accountId, 'platform' => 'instagram']);

        if (!$account) {
            return;
        }

        // update() only stages the change; without save() the refreshed token
        // was never persisted and the account died at the old token's expiry.
        $account->update(['details' => AccountReconnect::withoutFlag($account_detail)])->save();
    }
}
