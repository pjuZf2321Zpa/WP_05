<?php

namespace BitApps\SocialPro\HTTP\Services\Social\InstagramService;

use BitApps\Social\Deps\BitApps\WPKit\Http\Client\HttpClient;
use BitApps\Social\Deps\BitApps\WPKit\Http\Response;
use BitApps\Social\HTTP\Services\Interfaces\AuthServiceInterface;
use BitApps\Social\HTTP\Services\Traits\LoggerTrait;
use BitApps\Social\Model\Account;
use BitApps\Social\Utils\Common;
use BitApps\SocialPro\Utils\MetaGraph;

/**
 * Authorizes Instagram professional accounts using "Instagram API with Instagram Login".
 *
 * Unlike the legacy Facebook Login flow, this does not require a linked Facebook Page:
 * the user authorizes directly on instagram.com and we talk to graph.instagram.com.
 * Accounts connected here are tagged details.auth_method = 'instagram_login' so the
 * publish/refresh services know to use the Instagram host + token model.
 */
class InstagramOAuth2Service implements AuthServiceInterface
{
    use Common, LoggerTrait;

    private $httpHandler;

    private $baseUrl = 'https://graph.instagram.com/';

    private $version = MetaGraph::VERSION;

    private $shortAccessTokenUrl = 'https://api.instagram.com/oauth/access_token';

    private $longTimeAccessTokenUrl;

    private $userAccountInfoUrl;

    public function __construct()
    {
        $this->httpHandler = new HttpClient();
        $this->longTimeAccessTokenUrl = $this->baseUrl . 'access_token?';
        $this->userAccountInfoUrl = $this->baseUrl . $this->version . '/me?';
    }

    // TODO: encode only query params value. should  refactor
    public function urlParamEncode($url)
    {
        // Parse the URL to get the query string
        $queryString = parse_url($url, PHP_URL_QUERY);
        if (empty($queryString)) {
            return $url;
        }

        // Separate the query string into key-value pairs
        parse_str($queryString, $params);

        if (isset($params['rest_route'])) {
            // Encode each value in the parameters array
            foreach ($params as $key => $value) {
                $params[$key] = urlencode($value);
            }

            // Rebuild the query string

            $newQueryString = 'rest_route=' . $params['rest_route'];

            // Reconstruct the URL with the encoded query string
            return str_replace($queryString, $newQueryString, $url);
        }

        return $url;
    }

    public function authHandler($request)
    {
        $body = $request->body();
        $app_id = $body['payload']['client_id'];
        $client_secret = $body['payload']['client_secret'];
        $redirect_uri = $this->urlParamEncode($body['payload']['redirect_uri']);
        // Instagram appends a trailing "#_" to the returned authorization code.
        $code = preg_replace('/#_$/', '', $body['payload']['code']);

        $shortAccessTokenData = $this->getShortLivedToken($app_id, $client_secret, $redirect_uri, $code);
        // The Instagram Login business-login endpoint may return either a flat object
        // ({access_token, user_id}) or a {data:[{...}]} wrapper depending on API version.
        $shortToken = $this->extractField($shortAccessTokenData, 'access_token');
        if (empty($shortToken)) {
            return Response::error('Failed to retrieve Instagram access token');
        }

        $longTimeAccessTokenData = $this->getLongLivedToken($client_secret, $shortToken);
        if (empty($longTimeAccessTokenData->access_token)) {
            return Response::error('Failed to retrieve Instagram long-lived token');
        }

        $longTimeAccessToken = $longTimeAccessTokenData->access_token;

        $profile = $this->fetchInstagramProfile($longTimeAccessToken);
        $userId = $profile->user_id ?? ($profile->id ?? $this->extractField($shortAccessTokenData, 'user_id'));
        if (empty($userId)) {
            return Response::error('Failed to retrieve Instagram profile');
        }

        $accountDetails = $this->organizeInstagramProfile($profile, $userId, $longTimeAccessToken);

        // Accounts connected before the move to Instagram Login are keyed by the
        // Instagram Business Account id read off the linked Facebook Page, which
        // this flow never sees. Re-key them by username first, or reconnecting
        // one can never match and the user is told - wrongly - that they signed
        // in with the wrong account.
        $this->migrateLegacyAccountId($accountDetails['user_name'], $userId);

        $isConnected = (bool) Account::findOne(['account_id' => (string) $userId, 'platform' => 'instagram']);

        $account = [
            'profile_id'   => $userId,
            'account_id'   => $userId,
            'account_name' => $accountDetails['account_name'],
            'details'      => json_encode($accountDetails),
            'platform'     => 'instagram',
            'account_type' => Account::accountType['DEFAULT'],
            'status'       => Account::ACCOUNT_STATUS['active'],
        ];

        return [['account' => $account, 'isConnected' => $isConnected]];
    }

    /**
     * Re-keys Instagram rows stored under the Facebook-Login era account id
     * (the Instagram Business Account id) to the id this flow returns, matching
     * them by the username kept in details - the only identifier both auth
     * methods record. Keeps a reconnect updating the existing row, and its
     * schedules, instead of failing to match it.
     *
     * @param string $userName
     * @param string $accountId
     */
    public function migrateLegacyAccountId($userName, $accountId)
    {
        if (empty($userName) || empty($accountId)) {
            return;
        }

        // "_" is a LIKE wildcard and is legal in an Instagram username, so a
        // raw name could match a different account's row.
        $escapedUserName = str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $userName);

        $legacyRows = Account::where('platform', 'instagram')
            ->where('details', 'like', '%"user_name":"' . $escapedUserName . '"%')
            ->get(['id', 'account_id']);

        if (!\is_array($legacyRows)) {
            $legacyRows = empty($legacyRows) ? [] : [$legacyRows];
        }

        $legacyRows = array_values(array_filter($legacyRows, static function ($row) use ($accountId) {
            return (string) $row->account_id !== (string) $accountId;
        }));

        // An install can hold more than one row for the same username - the same
        // profile connected twice, under two apps, or a row left behind by an
        // earlier connect. Re-keying all of them would put the same
        // (account_id, platform) on several rows, which is the pair every lookup
        // here treats as unique: one of them would answer for the account and
        // the rest would keep publishing with tokens nothing ever refreshes.
        //
        // So only the newest is carried over. The others are no worse off than
        // they were before this re-key existed - still keyed to an id the new
        // flow does not use, still needing a connect of their own.
        usort($legacyRows, static function ($a, $b) {
            return (int) $b->id <=> (int) $a->id;
        });

        $legacyRows = \array_slice($legacyRows, 0, 1);

        foreach ($legacyRows as $row) {
            $account = Account::findOne(['id' => $row->id]);

            if (!$account) {
                continue;
            }

            $details = $account->details;

            if (\is_object($details)) {
                $details->account_id = $accountId;
            }

            $account->update([
                'account_id' => $accountId,
                'profile_id' => $accountId,
                'details'    => $details,
            ])->save();
        }
    }

    /**
     * Reads a field from an Instagram token response that may be either a flat
     * object ({field: ...}) or a {data: [{field: ...}]} wrapper.
     *
     * @param mixed  $response
     * @param string $field
     *
     * @return mixed|null
     */
    public function extractField($response, $field)
    {
        if (!\is_object($response)) {
            return null;
        }
        if (isset($response->{$field})) {
            return $response->{$field};
        }
        if (isset($response->data[0]->{$field})) {
            return $response->data[0]->{$field};
        }

        return null;
    }

    public function getShortLivedToken($app_id, $client_secret, $redirect_uri, $code)
    {
        $params = [
            'client_id'     => $app_id,
            'client_secret' => $client_secret,
            'grant_type'    => 'authorization_code',
            'redirect_uri'  => $redirect_uri,
            'code'          => $code,
        ];

        $headers = [
            'Content-Type' => 'application/x-www-form-urlencoded',
        ];

        return $this->httpHandler->request($this->shortAccessTokenUrl, 'POST', http_build_query($params), $headers);
    }

    public function getLongLivedToken($client_secret, $shortLivedToken)
    {
        $params = [
            'grant_type'    => 'ig_exchange_token',
            'client_secret' => $client_secret,
            'access_token'  => $shortLivedToken,
        ];

        $longTimeAccessTokenUrlWithParams = $this->longTimeAccessTokenUrl . http_build_query($params);

        return $this->httpHandler->request($longTimeAccessTokenUrlWithParams, 'GET', []);
    }

    public function fetchInstagramProfile($accessToken)
    {
        $params = [
            'fields'       => 'user_id,username,name,account_type,profile_picture_url',
            'access_token' => $accessToken,
        ];

        $userAccountInfoUrlWithParams = $this->userAccountInfoUrl . http_build_query($params);

        return $this->httpHandler->request($userAccountInfoUrlWithParams, 'GET', []);
    }

    public function organizeInstagramProfile($profile, $profileId, $accessToken)
    {
        return [
            'user_name'    => $profile->username ?? '',
            'account_id'   => $profileId,
            'account_name' => $profile->name ?? ($profile->username ?? $profileId),
            'account_type' => 'profile',
            'category'     => '',
            'icon'         => $profile->profile_picture_url ?? '',
            'access_token' => $accessToken,
            'auth_method'  => 'instagram_login',
            'generates_on' => time(),
        ];
    }
}
