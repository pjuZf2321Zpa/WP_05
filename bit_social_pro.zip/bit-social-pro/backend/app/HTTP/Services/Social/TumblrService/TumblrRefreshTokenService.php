<?php

namespace BitApps\SocialPro\HTTP\Services\Social\TumblrService;

use BitApps\Social\Config;
use BitApps\Social\Model\Account;
use BitApps\Social\Model\Log;
use BitApps\Social\Utils\Hash;
use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use BitApps\SocialPro\Utils\AccountReconnect;
use BitApps\SocialPro\Utils\LogRunId;

/**
 * Tumblr rotates refresh tokens: every refresh invalidates the stored one, so
 * two overlapping publishes must never refresh the same account at once. The
 * refresh is therefore serialized behind a per account lock.
 */
class TumblrRefreshTokenService
{
    /**
     * Seconds after which a held lock is assumed abandoned by a dead request.
     */
    private const LOCK_TIMEOUT = 60;

    /**
     * How long to sleep between checks while another request refreshes.
     */
    private const WAIT_STEP_MICROSECONDS = 500000;

    /**
     * Give up waiting after this many steps and publish with the token we have.
     */
    private const MAX_WAIT_STEPS = 10;

    private $httpHandler;

    private $authBaseUrl = 'https://api.tumblr.com/v2/oauth2';

    private $accountId;

    private $accountDetails;

    private $clientId;

    private $clientSecret;

    private $accessToken;

    private $refreshToken;

    private $generateOn;

    private $tokenExpiresIn;

    public function __construct($accountDetails)
    {
        $this->httpHandler = new HttpClient();

        $this->accountId = $accountDetails->account_id;
        $this->clientId = Hash::decrypt($accountDetails->client_id);
        $this->clientSecret = Hash::decrypt($accountDetails->client_secret);

        $this->setTokenDetails($accountDetails);
    }

    public function tokenExpiryCheck()
    {
        if (!$this->accessToken && !$this->refreshToken) {
            return false;
        }

        // OAuth1 accounts authenticate with a token/secret pair and have no
        // refresh token, so there is nothing to renew.
        if (empty($this->refreshToken)) {
            return $this->accessToken;
        }

        if ($this->isExpired()) {
            return $this->refreshAccessToken();
        }

        return $this->accessToken;
    }

    public function accessToken()
    {
        return $this->tokenExpiryCheck();
    }

    public function refreshAccessToken()
    {
        if (!$this->acquireRefreshLock()) {
            // Another request is refreshing this account right now; wait for
            // it and reuse the rotated pair it stored.
            $this->waitForOtherRefresh();

            return $this->accessToken;
        }

        try {
            // Another request may have rotated the pair between this object
            // being built and the lock being taken, so reread before spending
            // the refresh token.
            $this->reloadAccountDetails();

            if (!$this->isExpired()) {
                return $this->accessToken;
            }

            return $this->requestNewAccessToken();
        } finally {
            delete_option($this->lockKey());
        }
    }

    public function saveAccessToken()
    {
        if (empty($this->accountId)) {
            return;
        }
        $account = Account::findOne(['account_id' => $this->accountId, 'platform' => 'tumblr']);

        if (!$account) {
            return;
        }

        $accountDetails = AccountReconnect::withoutFlag($this->accountDetails);
        $accountDetails->access_token = Hash::encrypt($this->accessToken);
        $accountDetails->refresh_token = Hash::encrypt($this->refreshToken);
        $accountDetails->tokenExpiresIn = $this->tokenExpiresIn;
        $accountDetails->generates_on = time();
        $account->update(['details' => $accountDetails])->save();
    }

    private function requestNewAccessToken()
    {
        $params = [
            'grant_type'    => 'refresh_token',
            'client_id'     => $this->clientId,
            'client_secret' => $this->clientSecret,
            'refresh_token' => $this->refreshToken
        ];

        $header = ['Content-Type' => 'application/x-www-form-urlencoded'];
        $result = $this->httpHandler->request($this->authBaseUrl . '/token', 'POST', $params, $header);

        if (!\is_object($result) || empty($result->access_token)) {
            $this->logRefreshFailure($result);

            // Tumblr rotates refresh tokens, so a rejected refresh leaves no
            // usable grant behind — the account needs a fresh authorization.
            // A request that never reached Tumblr did not use the refresh
            // token, so the next publish tries again with it.
            if (!is_wp_error($result)) {
                AccountReconnect::flag('tumblr', $this->accountId, __('Tumblr could not renew the access token.', 'bit-social'));
            }

            return $this->accessToken;
        }

        $this->accessToken = $result->access_token;

        // Keep the stored refresh token unless the response carries a new one,
        // so a partial response cannot wipe the only working token.
        if (!empty($result->refresh_token)) {
            $this->refreshToken = $result->refresh_token;
        }

        if (!empty($result->expires_in)) {
            $this->tokenExpiresIn = (int) $result->expires_in;
        }

        $this->saveAccessToken();

        return $this->accessToken;
    }

    private function isExpired()
    {
        return (\intval($this->generateOn) + \intval($this->tokenExpiresIn) - 10) < time();
    }

    private function setTokenDetails($accountDetails)
    {
        // OAuth1 accounts carry neither a refresh token nor an expiry, so every
        // field is read defensively.
        $this->accountDetails = $accountDetails;
        $this->accessToken = Hash::decrypt($accountDetails->access_token ?? '');
        $this->refreshToken = Hash::decrypt($accountDetails->refresh_token ?? '');
        $this->generateOn = $accountDetails->generates_on ?? 0;
        $this->tokenExpiresIn = $accountDetails->tokenExpiresIn ?? 0;
    }

    private function reloadAccountDetails()
    {
        $account = Account::findOne(['account_id' => $this->accountId, 'platform' => 'tumblr']);

        if (!$account || empty($account->details)) {
            return;
        }

        $details = \is_string($account->details) ? json_decode($account->details) : $account->details;

        if (\is_object($details) && isset($details->access_token, $details->refresh_token)) {
            $this->setTokenDetails($details);
        }
    }

    private function lockKey()
    {
        return Config::withPrefix('tumblr_refresh_lock_' . md5((string) $this->accountId));
    }

    private function acquireRefreshLock()
    {
        if ($this->claimLock()) {
            return true;
        }

        $lockedAt = (int) get_option($this->lockKey());

        if ($lockedAt && ($lockedAt + self::LOCK_TIMEOUT) < time()) {
            delete_option($this->lockKey());

            return $this->claimLock();
        }

        return false;
    }

    /**
     * add_option is atomic - option_name carries a unique index - so exactly
     * one concurrent request can claim the lock.
     */
    private function claimLock()
    {
        return add_option($this->lockKey(), time(), '', 'no');
    }

    private function waitForOtherRefresh()
    {
        $lockKey = $this->lockKey();

        for ($step = 0; $step < self::MAX_WAIT_STEPS; $step++) {
            usleep(self::WAIT_STEP_MICROSECONDS);

            // The other process releases the lock from outside this request,
            // so the options cache has to be dropped before every look.
            wp_cache_delete($lockKey, 'options');

            if (!get_option($lockKey)) {
                break;
            }
        }

        $this->reloadAccountDetails();
    }

    private function logRefreshFailure($response)
    {
        Log::insert([
            'schedule_id' => null,
            'platform'    => 'tumblr',
            'status'      => Log::status['FAIL'],
            'run_id'      => LogRunId::current(),
            'details'     => wp_json_encode([
                'account_id'   => $this->accountId,
                'account_name' => $this->accountDetails->account_name ?? '',
                'message'      => 'Access token refresh failed; the next publish may be unauthorized.',
                'response'     => $response,
            ]),
        ]);
    }
}
