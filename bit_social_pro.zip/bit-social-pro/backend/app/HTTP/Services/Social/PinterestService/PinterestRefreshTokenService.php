<?php

namespace BitApps\SocialPro\HTTP\Services\Social\PinterestService;

use BitApps\Social\HTTP\Services\Traits\LoggerTrait;
use BitApps\Social\Model\Account;
use BitApps\Social\Utils\Common;
use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use stdClass;
use BitApps\SocialPro\Utils\AccountReconnect;

class PinterestRefreshTokenService
{
    use Common, LoggerTrait;

    private $httpHandler;

    private $baseUrl = 'https://api.pinterest.com/';

    private $version = 'v5/';

    private $refreshTokenUrl;

    public function __construct()
    {
        $this->httpHandler = new HttpClient();
        $this->refreshTokenUrl = $this->baseUrl . $this->version . 'oauth/token';
    }

    public function tokenExpiryCheck($client_id, $client_secret, $access_token, $expires_in, $refresh_token, $refresh_token_expires_in)
    {
        if (!$access_token && !$refresh_token) {
            return false;
        }

        if ((\intval($expires_in)) < time()) {
            return $this->refreshToken($client_id, $client_secret, $access_token, $refresh_token, $refresh_token_expires_in);
        }

        $data = new stdClass();
        $data->access_token = $access_token;
        $data->expires_in = $expires_in;
        $data->refresh_token = $refresh_token;
        $data->refresh_token_expires_in = $refresh_token_expires_in;

        return $data;
    }

    public function refreshToken($client_id, $client_secret, $access_token, $refresh_token, $refresh_token_expires_in = null)
    {
        $headers = [
            'Authorization' => 'Basic ' . base64_encode($client_id . ':' . $client_secret),
            'Content-Type'  => 'application/x-www-form-urlencoded'
        ];

        $params = [
            'grant_type'    => 'refresh_token',
            'refresh_token' => $refresh_token
        ];

        $tokenResponse = $this->httpHandler->request($this->refreshTokenUrl, 'POST', $params, $headers);

        if (!\is_object($tokenResponse) || empty($tokenResponse->access_token)) {
            return (object) ['status' => 'error', 'message' => 'Refresh token request failed!'];
        }

        $data = new stdClass();
        $data->access_token = $tokenResponse->access_token;
        $data->expires_in = time() + (int) ($tokenResponse->expires_in ?? 0);
        // Pinterest rotates the refresh token only in continuous-refresh mode;
        // keep the stored pair when the response carries no replacement.
        $data->refresh_token = !empty($tokenResponse->refresh_token) ? $tokenResponse->refresh_token : $refresh_token;
        $data->refresh_token_expires_in = !empty($tokenResponse->refresh_token_expires_at) ? $tokenResponse->refresh_token_expires_at : $refresh_token_expires_in;

        return $data;
    }

    public function saveRefreshedToken($account_detail)
    {
        $accountId = $account_detail->account_id;
        if (empty($accountId)) {
            return;
        }
        $account = Account::findOne(['account_id' => $accountId, 'platform' => 'pinterest']);

        if (!$account) {
            return;
        }

        // update() only stages the change; without save() the rotated token
        // pair was never persisted, bricking the account at the next refresh.
        $account->update(['details' => AccountReconnect::withoutFlag($account_detail)])->save();
    }
}
