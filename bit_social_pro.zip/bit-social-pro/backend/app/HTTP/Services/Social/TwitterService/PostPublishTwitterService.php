<?php

namespace BitApps\SocialPro\HTTP\Services\Social\TwitterService;

use AllowDynamicProperties;
use BitApps\Social\Config;
use BitApps\Social\Deps\BitApps\WPKit\Hooks\Hooks;
use BitApps\Social\HTTP\Services\Interfaces\SocialInterface;
use BitApps\Social\HTTP\Services\Traits\LoggerTrait;
use BitApps\Social\Model\Schedule;
use BitApps\Social\Utils\Common;
use BitApps\Social\Utils\Hash;
use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use BitApps\SocialPro\HTTP\Services\Traits\TwitterOAuthHelperTrait;
use BitApps\SocialPro\Utils\AccountReconnect;
use BitApps\SocialPro\Utils\DirectShareAttachments;

#[AllowDynamicProperties]
class PostPublishTwitterService implements SocialInterface
{
    use Common, LoggerTrait, TwitterOAuthHelperTrait;

    public const OAuth1 = '1.1';

    public const OAuth2 = '2';

    public const TWEET_URL = 'https://api.twitter.com/2/tweets';

    public const UPLOAD_IMAGE_URL_V2 = 'https://api.x.com/2/media/upload';

    public const POST_BASE_URL = 'https://twitter.com';

    public const USER_INFO_URL_v2 = 'https://api.twitter.com/2/users/me';

    public const USER_INFO_FIELDS = 'verified_type,subscription_type';

    public const LONG_POSTS_CACHE_SECONDS = 86400;

    /**
     * X counts these characters as 1 and all other characters as 2.
     */
    private const DOUBLE_WEIGHT_CHARACTERS = '/[^\x{0000}-\x{10FF}\x{2000}-\x{200D}\x{2010}-\x{201F}\x{2032}-\x{2037}]/u';

    public const MAX_MEDIA = 4;

    public const POST_LENGTH = 280;

    public const VERIFIED_POST_LENGTH = 25000;

    public const LINK_TEXT_LENGTH = 25;

    private $httpClient;

    private $refreshTokenHandler;

    private $apiVersion;

    private $accountId;

    private $userName;

    private $clientId;

    private $clientSecret;

    private $accessToken;

    private $accessTokenSecret;

    private $twitterData = [];

    public function __construct()
    {
        $this->httpClient = new HttpClient();
        $this->refreshTokenHandler = new TwitterRefreshTokenService();
    }

    public function publishPost($data)
    {
        $post = $data['post'] ?? null;
        $postId = $post['ID'] ?? null;
        $retry = $data['retry'] ?? false;
        $logId = $data['log_id'] ?? null;

        $postData = [];

        $scheduleType = $data['schedule_type'] ?? null;
        $template = (object) $data['template'];
        $accountDetails = $data['account_details'];
        $scheduleId = $data['schedule_id'] ?? null;

        $accountName = $accountDetails->account_name;
        $userName = $accountDetails->user_name;
        $accountId = $accountDetails->account_id;
        $refreshToken = property_exists($accountDetails, 'refresh_token') ? Hash::decrypt($accountDetails->refresh_token) : null;
        $expiresIn = property_exists($accountDetails, 'expires_in') ? $accountDetails->expires_in : null;

        $this->accountId = $accountId;

        $this->userName = $userName;
        $this->apiVersion = $accountDetails->api_version;
        $this->clientId = Hash::decrypt($accountDetails->client_id);
        $this->clientSecret = Hash::decrypt($accountDetails->client_secret);
        $this->accessToken = Hash::decrypt($accountDetails->access_token);

        if ($this->apiVersion === static::OAuth1) {
            $this->accessTokenSecret = property_exists($accountDetails, 'access_token_secret') ? Hash::decrypt($accountDetails->access_token_secret) : null;
        }

        if (($this->apiVersion === static::OAuth2) && (\intval($expiresIn)) < time()) {
            $tokenUpdateData = $this->refreshTokenHandler->refreshToken($this->clientId, $this->clientSecret, $refreshToken);

            if (!property_exists($tokenUpdateData, 'access_token') && !property_exists($tokenUpdateData, 'refresh_token')) {
                // The refresh token is spent or revoked; nothing here can
                // recover it, so warn on the account card.
                AccountReconnect::flag('twitter', $accountId, __('X (Twitter) could not renew the access token.', 'bit-social'));

                return $tokenUpdateData;
            }

            $this->accessToken = $tokenUpdateData->access_token;

            $accountDetails->access_token = Hash::encrypt($tokenUpdateData->access_token);
            $accountDetails->refresh_token = Hash::encrypt($tokenUpdateData->refresh_token);
            $accountDetails->expires_in = $tokenUpdateData->expires_in;

            $this->refreshTokenHandler->saveDetails($accountDetails);
        }

        if ($scheduleType === Schedule::scheduleType['DIRECT_SHARE']) {
            $attachments = DirectShareAttachments::resolve($template);

            $postData['content'] = $template->content ?? null;
            $postData['media'] = $attachments['media'];
            $postData['link'] = $attachments['link'];
        } else {
            $template->platform = 'twitter';
            $postData = $this->replacePostContent($post['ID'], $template);
        }

        $tweetResponse = $this->createTweet($postData, $template, $accountDetails);

        $this->twitterData['post'] = $this->normalizePostData($postData, true);

        $this->logAndRetry($scheduleId, $accountId, $accountName, $postId, $tweetResponse, $userName, $retry, $logId, $data);

        Hooks::doAction(Config::withPrefix('twitter_post_publish'), $this->normalizePostData($postData), $this->twitterData['response']);

        return $this->twitterData;
    }

    /**
     * Whether the account can post past 280 characters. The legacy `verified`
     * flag stays false for Premium subscribers, so this reads the subscription
     * type. The result stays in `long_posts` for one day, because a subscription
     * can change. If X does not give an answer, this uses the last known value.
     *
     * @param mixed $accountDetails
     *
     * @return bool
     */
    public function canLongPost($accountDetails)
    {
        $checkedAt = (int) ($accountDetails->long_posts_checked_at ?? 0);

        if (isset($accountDetails->long_posts) && time() - $checkedAt < static::LONG_POSTS_CACHE_SECONDS) {
            return (bool) $accountDetails->long_posts;
        }

        $longPosts = $this->fetchLongPosts();

        if ($longPosts === null) {
            return (bool) ($accountDetails->long_posts ?? $accountDetails->verified ?? false);
        }

        $accountDetails->long_posts = $longPosts;
        $accountDetails->long_posts_checked_at = time();

        $this->refreshTokenHandler->saveDetails($accountDetails);

        return $longPosts;
    }

    /**
     * @return null|bool null if the response does not show the subscription state
     */
    private function fetchLongPosts()
    {
        $query = ['user.fields' => static::USER_INFO_FIELDS];
        $url = static::USER_INFO_URL_v2 . '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);

        $headers = [
            'Authorization' => $this->authHeader(static::USER_INFO_URL_v2, 'GET', $query),
        ];

        $userDetails = $this->httpClient->request($url, 'GET', [], $headers);

        if (!\is_object($userDetails) || !isset($userDetails->data)) {
            return null;
        }

        $user = $userDetails->data;
        $subscription = $user->subscription_type ?? null;

        // A business or government type does not prove that the account can post
        // long text. A trimmed post still publishes, but X rejects a post that is too long.
        if (($user->verified_type ?? null) === 'blue') {
            return true;
        }

        if ($subscription === null) {
            return null;
        }

        return !\in_array($subscription, ['None', ''], true);
    }

    /**
     * The length of the text as X counts it. A link in the text counts as its
     * full length here, so the result can be higher than the X count but not lower.
     *
     * @param string $text
     *
     * @return int
     */
    private function weightedLength($text)
    {
        return mb_strlen($text, 'UTF-8') + (int) preg_match_all(self::DOUBLE_WEIGHT_CHARACTERS, $text);
    }

    /**
     * @param string $text
     * @param int    $maxLength
     *
     * @return string
     */
    private function trimToWeightedLength($text, $maxLength)
    {
        preg_match_all('/\X/u', $text, $characters);

        $trimmed = '';
        $length = 0;

        foreach ($characters[0] as $character) {
            $length += $this->weightedLength($character);

            if ($length > $maxLength) {
                break;
            }

            $trimmed .= $character;
        }

        return $trimmed;
    }

    private function createTweet($postData, $template, $accountDetails)
    {
        $media = $postData['media'] ?? null;

        $headers = [
            'Authorization' => 'Bearer ' . $this->accessToken,
            'Content-Type'  => 'application/json',
        ];

        $data['text'] = $postData['content'];

        if (!empty($template->trimMessage)) {
            $text = wp_check_invalid_utf8((string) $postData['content'], true);
            $reservedLength = ($media || $postData['link']) ? static::LINK_TEXT_LENGTH : 0;

            // Ask X about the account only when the text is too long for all accounts.
            if ($this->weightedLength($text) > static::POST_LENGTH - $reservedLength) {
                $postMaxLength = $this->canLongPost($accountDetails) ? static::VERIFIED_POST_LENGTH : static::POST_LENGTH;

                $data['text'] = $this->trimToWeightedLength($text, $postMaxLength - $reservedLength);
            }
        }

        if ($media) {
            $mediaList = \is_array($media) ? \array_slice($media, 0, static::MAX_MEDIA) : [$media];
            $mediaIds = [];
            foreach ($mediaList as $imageUrl) {
                $uploaded = $this->uploadMedia($imageUrl);

                if (!isset($uploaded->data->id)) {
                    return $uploaded;
                }

                $mediaIds[] = $uploaded->data->id;
            }

            $data['text'] .= "\n";
            $data['media'] = ['media_ids' => $mediaIds];
        } elseif ($postData['link']) {
            $data['text'] .= "\n" . $postData['link'];
        }

        if ($this->apiVersion === static::OAuth1) {
            $response = $this->twitterOAuth(static::TWEET_URL, wp_json_encode($data), 'POST', $this->clientId, $this->clientSecret, $this->accessToken, $this->accessTokenSecret);

            return $response;
        }

        return $this->httpClient->request(static::TWEET_URL, 'POST', wp_json_encode($data), $headers);
    }

    private function uploadMedia($imageUrl)
    {
        $attachmentId = attachment_url_to_postid($imageUrl);

        $filePath = $attachmentId ? get_attached_file($attachmentId) : $imageUrl;

        $fileContent = @file_get_contents($filePath);

        if ($fileContent === false) {
            $response = wp_remote_get($imageUrl, ['timeout' => 30, 'sslverify' => false]);

            $fileContent = is_wp_error($response) ? false : wp_remote_retrieve_body($response);
        }

        if (empty($fileContent)) {
            return (object) ['errors' => [['message' => 'Failed to fetch media file: ' . $imageUrl]]];
        }

        $urlPath = parse_url($imageUrl, PHP_URL_PATH) ?? '';
        $fileName = basename($urlPath) ?: 'media';

        $mimeType = $this->detectMimeType($fileContent, $fileName) ?: 'image/jpeg';

        $mediaCategory = strpos($mimeType, 'video/') === 0 ? 'tweet_video' : 'tweet_image';

        $boundary = wp_generate_password(24, false);
        $eol = "\r\n";

        $body = '--' . $boundary . $eol;
        $body .= 'Content-Disposition: form-data; name="media_category"' . $eol . $eol;
        $body .= $mediaCategory . $eol;
        $body .= '--' . $boundary . $eol;
        $body .= 'Content-Disposition: form-data; name="media"; filename="' . $fileName . '"' . $eol;
        $body .= 'Content-Type: ' . $mimeType . $eol . $eol;
        $body .= $fileContent . $eol;
        $body .= '--' . $boundary . '--' . $eol;

        // A multipart body is not part of the OAuth 1.0a signature.
        $headers = [
            'Authorization' => $this->authHeader(static::UPLOAD_IMAGE_URL_V2, 'POST'),
            'Content-Type'  => 'multipart/form-data; boundary=' . $boundary,
        ];

        return $this->httpClient->request(static::UPLOAD_IMAGE_URL_V2, 'POST', $body, $headers);
    }

    private function authHeader($url, $method, $signedParams = [])
    {
        if ($this->apiVersion === static::OAuth1) {
            return $this->twitterOAuthHeader($url, $method, $this->clientId, $this->clientSecret, $this->accessToken, $this->accessTokenSecret, $signedParams);
        }

        return 'Bearer ' . $this->accessToken;
    }

    private function logAndRetry($scheduleId, $accountId, $accountName, $postId, $tweetResponse, $userName, $retry, $logId, $data)
    {
        $responseData = [
            'schedule_id' => $scheduleId,
            'details'     => [
                'account_id'   => $accountId,
                'account_name' => $accountName,
                'post_id'      => $postId ?? null,
                'response'     => $tweetResponse,
                'api_version'  => $this->apiVersion,
                'post_url'     => isset($tweetResponse->data->id) ? static::POST_BASE_URL . "/{$userName}/status/{$tweetResponse->data->id}" : ''
            ],
            'platform' => 'twitter',
            'status'   => isset($tweetResponse->data->id) ? 1 : 0
        ];

        $hookResponse = [
            'account_id'   => $accountId,
            'account_name' => $accountName,
            'post_url'     => $responseData['details']['post_url'],
            'status'       => $responseData['status'],
        ];

        $this->twitterData['platform'] = 'twitter';
        $this->twitterData['response'] = $hookResponse;

        if ($retry) {
            $this->logUpdate($responseData, $logId);

            return;
        }

        if (!(\array_key_exists('keepLogs', $data) && $data['keepLogs'] === false)) {
            $this->logCreate($responseData);
        }
    }
}
