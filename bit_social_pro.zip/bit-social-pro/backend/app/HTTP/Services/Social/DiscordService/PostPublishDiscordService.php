<?php

namespace BitApps\SocialPro\HTTP\Services\Social\DiscordService;

use AllowDynamicProperties;
use BitApps\Social\Config;
use BitApps\Social\Deps\BitApps\WPKit\Hooks\Hooks;
use BitApps\Social\HTTP\Services\Interfaces\SocialInterface;
use BitApps\Social\HTTP\Services\Traits\LoggerTrait;
use BitApps\Social\Model\Schedule;
use BitApps\Social\Utils\Common;
use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use BitApps\SocialPro\Utils\DirectShareAttachments;

#[AllowDynamicProperties]
class PostPublishDiscordService implements SocialInterface
{
    use Common, LoggerTrait;

    public const VERSION = 'v5/';

    private $httpHandler;

    private $linkedinInstance;

    /**
     * @var RefreshService $refreshHandler
     */
    private $refreshHandler;

    private $baseURl = 'https://discord.com/';

    private $baseApiUrl;

    private $discordData = [];

    public function __construct()
    {
        $this->httpHandler = new HttpClient();
        $this->baseApiUrl = $this->baseURl . 'api/';
        $this->httpHandler->setBaseUri($this->baseApiUrl);
    }

    public function publishPost($data)
    {
        $post = $data['post'] ?? null;
        $post_data = [];
        $template = (object) $data['template'];
        $scheduleType = $data['schedule_type'] ?? null;
        $account_detail = $data['account_details'];

        $schedule_id = $data['schedule_id'] ?? null;
        $account_id = $account_detail->account_id;
        $account_name = $account_detail->account_name;
        $guild_id = $account_detail->build_id;
        $botToken = $account_detail->botToken;

        if ($scheduleType === Schedule::scheduleType['DIRECT_SHARE']) {
            $attachments = DirectShareAttachments::resolve($template);

            $post_data['content'] = $template->content ?? null;
            $post_data['media'] = $attachments['media'];
            $post_data['link'] = $attachments['link'];
        } else {
            $template->platform = 'discord';
            $post_data = $this->replacePostContent($post['ID'], $template);
        }

        $this->discordData['post'] = $this->normalizePostData($post_data, true);

        $postPublishResponse = $this->discordPostPublish($post_data, $account_detail, $botToken, $post['ID'] ?? null, $scheduleType);

        $channel_id = property_exists($postPublishResponse, 'channel_id') ? $postPublishResponse->channel_id : '';
        $messageUrl = $channel_id ? "{$this->baseURl}channels/{$guild_id}/{$channel_id}" : '';

        $responseData = [
            'schedule_id' => $schedule_id,
            'details'     => [
                'account_id'   => $account_id,
                'account_name' => $account_name,
                'post_id'      => $post['ID'] ?? null,
                'response'     => $postPublishResponse,
                'post_url'     => $messageUrl
            ],
            'platform' => 'discord',
            'status'   => property_exists($postPublishResponse, 'id') ? 1 : 0
        ];

        $hookResponse = [
            'account_id'   => $account_id,
            'account_name' => $account_name,
            'post_url'     => $responseData['details']['post_url'],
            'status'       => $responseData['status'],
        ];

        $this->discordData['platform'] = 'discord';
        $this->discordData['response'] = $hookResponse;

        Hooks::doAction(Config::withPrefix('discord_post_publish'), $this->normalizePostData($post_data), $hookResponse);

        if (\array_key_exists('retry', $data) && $data['retry'] === true) {
            // A retry rewrites the row it was launched from rather than adding
            // one, so recovering a post turns that row green instead of leaving
            // a failure and a success side by side — and keeps the tally the
            // Logs screen shows for the run honest.
            $this->logUpdate($responseData, isset($data['log_id']) ? $data['log_id'] : null);
        } elseif (!(\array_key_exists('keepLogs', $data) && $data['keepLogs'] === false)) {
            $this->logCreate($responseData);
        }

        return $this->discordData;
    }

    public function discordPostPublish($post_data, $account_detail, $botToken, $post_id, $scheduleType)
    {
        $post_title = get_the_title($post_id);
        $post_content = $post_data['content'] ?? null;
        $post_link = $post_data['link'] ?? null;

        $media = $post_data['media'] ?? null;

        return $this->sendMessage($account_detail, $botToken, $post_title, $post_content, $post_link, $media);
    }

    public function sendMessage($account_detail, $botToken, $post_title, $post_content, $post_link, $media)
    {
        $endpoint = "channels/{$account_detail->account_id}/messages";
        $message = !empty($post_link) ? \sprintf("%s\n%s", $post_content, $post_link) : $post_content;
        $images = $media;

        $this->httpHandler->setHeader('Authorization', 'Bot ' . $botToken);
        $finalData = ['content' => $message];

        if (!empty($images)) {
            foreach ($images as $image) {
                $finalData['embeds'][] = ['image' => ['url' => $image]];
            }
        }

        $this->httpHandler->setContentType('application/json');
        $this->httpHandler->setBody(wp_json_encode($finalData));

        return $this->httpHandler->post($endpoint);
    }
}
