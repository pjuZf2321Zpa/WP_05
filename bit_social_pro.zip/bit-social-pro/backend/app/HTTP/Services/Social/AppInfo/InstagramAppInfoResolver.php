<?php

namespace BitApps\Social\HTTP\Services\Social\AppInfo;

use BitApps\Social\HTTP\Services\Interfaces\PlatformAppInfoResolverInterface;

class InstagramAppInfoResolver implements PlatformAppInfoResolverInterface
{
    public function getAppInfo($validatedData)
    {
        // "Instagram API with Instagram Login" apps have no app-token introspection
        // endpoint (unlike Facebook apps), so credentials can only be truly validated
        // during the OAuth round-trip. Do a lightweight presence check here.
        $appKey = $validatedData->appKey ?? '';
        $appSecret = $validatedData->appSecret ?? '';

        if (empty($appKey) || empty($appSecret)) {
            return (object) ['status' => 'error', 'message' => 'Invalid App Credentials!'];
        }

        return (object) ['status' => 'success', 'appName' => 'Instagram App', 'icon_url' => ''];
    }
}
