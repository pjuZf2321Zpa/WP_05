<?php

namespace BitApps\SocialPro\HTTP\Services\Ai\OpenaiService;

use BitApps\Social\Model\Account;
use BitApps\Social\Utils\Hash;
use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

class OpenaiKeyAuthService
{
    private const VERIFY_URL = 'https://api.openai.com/v1/models';

    private $httpClient;

    public function __construct()
    {
        $this->httpClient = new HttpClient();
    }

    public function authHandler($request)
    {
        $body = $request->body();
        $apiKey = $body['key'] ?? null;

        if (empty($apiKey)) {
            return (object) [
                'status'  => 'error',
                'message' => 'API key is required'
            ];
        }

        $response = $this->verifyOpenAIKey($apiKey);

        if ($response->status === 'error') {
            return $response;
        }

        return $this->savePlatform($apiKey);
    }

    private function verifyOpenAIKey($key)
    {
        $headers = [
            'Authorization' => 'Bearer ' . $key,
        ];

        $response = $this->httpClient->request(self::VERIFY_URL, 'GET', [], $headers);

        if (isset($response->error)) {
            return (object) [
                'status'  => 'error',
                'message' => 'Invalid OpenAI API Key'
            ];
        }

        return (object) [
            'status'  => 'success',
            'message' => 'Valid OpenAI API Key'
        ];
    }

    private function savePlatform($key)
    {
        $platformData = [
            'profile_id'   => 'openai',
            'account_id'   => 'openai',
            'account_name' => 'OpenAI',
            'details'      => json_encode(['key' => Hash::encrypt($key)]),
            'platform'     => 'openai',
            'account_type' => Account::accountType['AI_PLATFORM'],
            'status'       => Account::ACCOUNT_STATUS['active'],
        ];

        // Upsert: re-entering/rotating the key refreshes the existing
        // 'openai' row instead of accumulating duplicates.
        $response = Account::upsertConnected($platformData);

        if ($response) {
            return (object) [
                'status'  => 'success',
                'message' => 'OpenAI API key saved successfully'
            ];
        }

        return (object) [
            'status'  => 'error',
            'message' => 'Failed to save OpenAI API key'
        ];
    }
}
