<?php

namespace BitApps\SocialPro\HTTP\Services\Traits;

use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

trait TwitterOAuthHelperTrait
{
    public function twitterOAuth($url, $data, $requestType, $appKey, $appSecret, $accessToken = null, $accessTokenSecret = null, $screenName = null, $fileType = null, $imageData = null, $callbackUrl = null)
    {
        $signedParams = [];

        if ($fileType === 'image') {
            $signedParams = ['media_data' => $imageData];
        }

        if ($screenName !== null) {
            $signedParams = ['screen_name' => $screenName];
        }

        $oauthHeader = $this->twitterOAuthHeader($url, $requestType, $appKey, $appSecret, $accessToken, $accessTokenSecret, $signedParams, $callbackUrl);

        $headers = [
            'Authorization' => $oauthHeader
        ];
        if ($fileType === 'image') {
            $headers['Content-Type'] = 'application/x-www-form-urlencoded';
        } elseif (!empty($data)) {
            $headers['Content-Type'] = 'application/json';
        }

        $url = $screenName !== null ? $url . '?screen_name=' . rawurlencode($screenName) : $url;

        $httpClient = new HttpClient();

        return $httpClient->request($url, $requestType, $data, $headers);
    }

    /**
     * Build an OAuth 1.0a Authorization header. $signedParams are the query
     * (or urlencoded body) params that must be part of the signature; a
     * multipart or JSON body is never signed, so pass nothing for those.
     *
     * @param mixed      $url
     * @param mixed      $requestType
     * @param mixed      $appKey
     * @param mixed      $appSecret
     * @param null|mixed $accessToken
     * @param null|mixed $accessTokenSecret
     * @param mixed      $signedParams
     * @param null|mixed $callbackUrl
     */
    public function twitterOAuthHeader($url, $requestType, $appKey, $appSecret, $accessToken = null, $accessTokenSecret = null, $signedParams = [], $callbackUrl = null)
    {
        $oauthParams = [
            'oauth_consumer_key'     => $appKey,
            'oauth_nonce'            => wp_rand(1000000, 99999999),
            'oauth_signature_method' => 'HMAC-SHA1',
            'oauth_timestamp'        => time(),
            'oauth_version'          => '1.0',
        ];

        if ($accessToken !== null) {
            $oauthParams['oauth_token'] = $accessToken;
        }

        if ($callbackUrl !== null) {
            $oauthParams['oauth_callback'] = $callbackUrl;
        }

        $params = array_merge($oauthParams, $signedParams);

        ksort($params);

        $baseString = $requestType . '&' . rawurlencode($url) . '&' . rawurlencode(http_build_query($params, '', '&', PHP_QUERY_RFC3986));

        $signatureKey = rawurlencode($appSecret) . '&';
        if ($accessTokenSecret !== null) {
            $signatureKey .= rawurlencode($accessTokenSecret);
        }

        $oauthParams['oauth_signature'] = base64_encode(hash_hmac('sha1', $baseString, $signatureKey, true));

        return 'OAuth ' . implode(', ', array_map(
            function ($key, $value) {
                return rawurlencode($key) . '="' . rawurlencode($value) . '"';
            },
            array_keys($oauthParams),
            $oauthParams
        ));
    }
}
