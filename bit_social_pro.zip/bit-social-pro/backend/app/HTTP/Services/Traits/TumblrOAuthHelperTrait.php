<?php

namespace BitApps\SocialPro\HTTP\Services\Traits;

use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Client\HttpClient;

trait TumblrOAuthHelperTrait
{
    public function tumblrOAuth($oauthToken, $oauthVerifier, $oauthSecret, $url, $data, $requestType, $appKey, $appSecret, $accessToken = null, $accessTokenSecret = null)
    {
        $oauthParams = [
            'oauth_consumer_key'     => $appKey,
            'oauth_nonce'            => md5(wp_rand(1000000, 99999999)),
            'oauth_signature_method' => 'HMAC-SHA1',
            'oauth_timestamp'        => time(),
            'oauth_version'          => '1.0',
        ];

        if ($oauthToken !== null) {
            $oauthParams['oauth_token'] = $oauthToken;
        }

        if ($oauthVerifier !== null) {
            $oauthParams['oauth_verifier'] = $oauthVerifier;
        }

        if ($accessToken !== null) {
            $oauthParams['oauth_token'] = $accessToken;
        }

        $params = $oauthParams;

        $params = array_merge($params, $data);

        ksort($params);

        $baseString = $requestType . '&' . rawurlencode($url) . '&' . rawurlencode(http_build_query($params, '', '&', PHP_QUERY_RFC3986));

        $signatureKey = rawurlencode($appSecret) . '&';

        if ($oauthSecret !== null) {
            $signatureKey .= rawurlencode($oauthSecret);
        }

        if ($accessTokenSecret !== null) {
            $signatureKey .= rawurlencode($accessTokenSecret);
        }

        $oauthParams['oauth_signature'] = base64_encode(hash_hmac('sha1', $baseString, $signatureKey, true));

        $oauthHeader = 'OAuth ' . implode(', ', array_map(
            function ($key, $value) {
                return rawurlencode($key) . '="' . rawurlencode($value) . '"';
            },
            array_keys($oauthParams),
            $oauthParams
        ));

        // OAuth2 accounts have an access token and no token secret. All other
        // calls (the OAuth1 handshake and OAuth1 accounts) use the signed header.
        $isOAuth2 = $accessToken !== null && $accessTokenSecret === null;

        $headers = [
            'Authorization' => $isOAuth2 ? "Bearer {$accessToken}" : $oauthHeader,
            'Content-Type'  => 'application/x-www-form-urlencoded'
        ];

        $httpClient = new HttpClient();

        return $httpClient->request($url, $requestType, $data, $headers);
    }
}
