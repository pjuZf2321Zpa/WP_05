<?php

namespace BitApps\SocialPro\Providers;

use BitApps\Social\HTTP\Services\Social\LinkedinService\Helper;
use BitApps\Social\Model\Log;
use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Client\HttpClient;
use BitApps\SocialPro\Utils\LogRunId;

class LinkedInCompanyPageProvider
{
    public static function getLinkedinCompanyPage($apiBaseUrl, $version, $accessToken)
    {
        $header = Helper::makeHeader($accessToken);

        $data = [
            'q'          => 'roleAssignee',
            'role'       => 'ADMINISTRATOR',
            'projection' => '(elements*(organizationalTarget~(id,localizedName,vanityName,logoV2(original~:playableStreams))))'
        ];

        $company_pages = $apiBaseUrl . $version . 'organizationalEntityAcls?' . http_build_query($data);

        $httpHandler = new HttpClient();

        $rawData = $httpHandler->request($company_pages, 'GET', null, $header);
        $decodedData = json_decode(json_encode($rawData), true);

        if (!empty($decodedData['elements']) && \is_array($decodedData['elements'])) {
            return Helper::organizeCompanies($decodedData);
        }

        // An empty element list is normal for members without pages, but an
        // API error here used to be swallowed, silently dropping every page
        // from the connect/reconnect picker. Record it so the cause (missing
        // Community Management API product, dropped organization scopes) is
        // visible in the plugin log.
        if (is_wp_error($rawData) || isset($decodedData['serviceErrorCode']) || isset($decodedData['status']) || isset($decodedData['message'])) {
            Log::insert([
                'schedule_id' => null,
                'platform'    => 'linkedin',
                'status'      => Log::status['FAIL'],
                'run_id'      => LogRunId::current(),
                'details'     => wp_json_encode([
                    'message'  => 'Fetching LinkedIn company pages failed, so only the personal profile is offered. Check the LinkedIn app products (Community Management API) and organization permissions.',
                    'response' => is_wp_error($rawData) ? $rawData->get_error_message() : $decodedData,
                ]),
            ]);
        }

        return [];
    }
}
