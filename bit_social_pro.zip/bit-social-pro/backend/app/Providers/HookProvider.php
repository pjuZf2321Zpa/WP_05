<?php

namespace BitApps\SocialPro\Providers;

use BitApps\Social\Config as FreeConfig;
use BitApps\SocialPro\Config;
use BitApps\SocialPro\Deps\BitApps\WPKit\Hooks\Hooks;
use BitApps\SocialPro\Deps\BitApps\WPKit\Http\RequestType;
use BitApps\SocialPro\Deps\BitApps\WPKit\Http\Router\Router;
use BitApps\SocialPro\HTTP\Services\Ai\OpenaiService\OpenaiService;
use BitApps\SocialPro\HTTP\Services\Notification\NotificationHandler;
use BitApps\SocialPro\HTTP\Services\RoleAccess\AccountPermissionService;
use BitApps\SocialPro\HTTP\Services\RoleAccess\RoleAccessService;
use BitApps\SocialPro\Plugin;
use BitApps\SocialPro\Utils\ProSmartTagHandler;
use FilesystemIterator;

class HookProvider
{
    private $_pluginBackend;

    public function __construct()
    {
        $this->_pluginBackend = Config::get('BASEDIR') . DIRECTORY_SEPARATOR;
        $this->loadTriggersAjax();
        $this->loadAppHooks();
        $this->loadActionsHooks();
        Hooks::addAction('rest_api_init', [$this, 'loadApi']);
        Hooks::addFilter(Config::VAR_PREFIX . 'validation_check', [ValidationHookProvider::class, 'getProValidationRules'], 10, 2);
        Hooks::addFilter(Config::VAR_PREFIX . 'get_linkedin_company_page', [LinkedInCompanyPageProvider::class, 'getLinkedinCompanyPage'], 10, 3);
        Hooks::addFilter(Config::VAR_PREFIX . 'smart_tags', [ProSmartTagHandler::class, 'getProSmartTagValue'], 10, 2);

        Hooks::addAction('bit_social_delete_ai_image', [OpenaiService::class, 'deleteAiImage']);

        // Email notifications on post failure + scheduled digest reports.
        Hooks::addAction(FreeConfig::withPrefix('log_data'), [NotificationHandler::class, 'onLog'], 10, 4);
        Hooks::addAction(FreeConfig::withPrefix('schedules_missed'), [NotificationHandler::class, 'onSchedulesMissed']);
        Hooks::addAction(NotificationHandler::DIGEST_HOOK, [NotificationHandler::class, 'runDigest']);
        Hooks::addFilter('cron_schedules', [NotificationHandler::class, 'registerDigestSchedule']);

        // Per-account role permissions: drop restricted accounts from auto-post
        // publishing and from the account pickers, and authorize the account ids
        // a share-now/schedule save references. License-gated like the
        // access_capability filter (pro Plugin::loaded): the grants persisted in
        // the account_permissions option must stop applying — in particular
        // allowGrantedPublisher, which widens who may auto-post — the moment the
        // license lapses.
        if (Config::isPro()) {
            // Free auto-post defaults to 'edit_posts' (anyone who can publish). On pro,
            // restrict the base gate to the role-access cap so only roles granted in
            // Roles & Access trigger auto-post; allowGrantedPublisher then re-widens it
            // for roles explicitly granted on an account's permissions.
            //
            // Only once an admin has actually saved Roles & Access, though: narrowing
            // the gate on an install that never opened the screen would silently stop
            // auto-post for every Editor/Author — and for any post published by
            // WP-Cron whose author isn't an admin — with nothing in the UI saying so.
            if (RoleAccessService::isConfigured()) {
                Hooks::addFilter(FreeConfig::withPrefix('autopost_publisher_capability'), static function () {
                    return RoleAccessService::CAP;
                });
            }
            Hooks::addFilter(FreeConfig::withPrefix('autopost_accounts'), [AccountPermissionService::class, 'filterAccountsForUser'], 10, 2);
            Hooks::addFilter(FreeConfig::withPrefix('autopost_publisher_allowed'), [AccountPermissionService::class, 'allowGrantedPublisher'], 10, 2);
            Hooks::addFilter(FreeConfig::withPrefix('active_accounts'), [AccountPermissionService::class, 'filterAccountsForCurrentUser']);
            Hooks::addFilter(FreeConfig::withPrefix('can_use_accounts'), [AccountPermissionService::class, 'authorizeRequestedAccounts'], 10, 2);
            // Same filtering for the Accounts page list: a restricted account is
            // hidden outright from users whose role isn't granted on it, instead
            // of listed read-only. Managing accounts (connect, reconnect, delete,
            // enable/disable) stays admin-only in the free controllers.
            Hooks::addFilter(FreeConfig::withPrefix('accounts_list'), [AccountPermissionService::class, 'filterAccountsForCurrentUser']);
        }

        // Cleanup needs no license — a stale entry must not survive its account.
        Hooks::addAction(FreeConfig::withPrefix('account_deleted'), [AccountPermissionService::class, 'removeAccount']);
    }

    /**
     * Helps to register integration ajax.
     */
    public function loadActionsHooks()
    {
        // $this->includeTaskHooks('Actions');
    }

    /**
     * Loads API routes.
     */
    public function loadApi()
    {
        if (
            is_readable($this->_pluginBackend . 'hooks' . DIRECTORY_SEPARATOR . 'api.php')
            && RequestType::is(RequestType::API)
        ) {
            $router = new Router(RequestType::API, Config::SLUG, 'v1');

            include $this->_pluginBackend . 'hooks' . DIRECTORY_SEPARATOR . 'api.php';
            $router->register();
        }
    }

    /**
     * Helps to register App hooks.
     */
    protected function loadAppHooks()
    {
        // Same role-access gate as the free plugin's ajax routes: don't register the
        // pro ajax routes at all for users whose role isn't allowed to use the plugin.
        // The access_capability filter is registered at plugins_loaded (pro Plugin::loaded),
        // so it is already in effect when this runs at init 11.
        if (
            RequestType::is(RequestType::AJAX)
            && is_readable($this->_pluginBackend . 'hooks' . DIRECTORY_SEPARATOR . 'ajax.php')
            && FreeConfig::userHasAccess()
        ) {
            $router = new Router(RequestType::AJAX, Config::VAR_PREFIX, '');
            $router->setMiddlewares(Plugin::instance()->middlewares());
            include $this->_pluginBackend . 'hooks' . DIRECTORY_SEPARATOR . 'ajax.php';
            $router->register();
        }

        if (is_readable($this->_pluginBackend . 'hooks.php')) {
            include $this->_pluginBackend . 'hooks.php';
        }
    }

    /**
     * Helps to register Triggers ajax.
     */
    protected function loadTriggersAjax()
    {
        // $this->includeTaskHooks('Triggers');
    }

    /**
     * Backend Routes and Hooks.
     *
     * @param string $taskName Triggers|Actions
     */
    private function includeTaskHooks($taskName)
    {
        $taskDir = $this->_pluginBackend . DIRECTORY_SEPARATOR . 'controllers' . DIRECTORY_SEPARATOR . $taskName;
        $dirs = new FilesystemIterator($taskDir);
        foreach ($dirs as $dirInfo) {
            if ($dirInfo->isDir()) {
                $taskName = basename($dirInfo);
                $taskPath = $taskDir . DIRECTORY_SEPARATOR . $taskName . DIRECTORY_SEPARATOR;
                if (is_readable($taskPath . 'Routes.php') && RequestType::is('ajax') && RequestType::is('admin')) {
                    include $taskPath . 'Routes.php';
                }

                if (is_readable($taskPath . 'Hooks.php')) {
                    include $taskPath . 'Hooks.php';
                }
            }
        }
    }
}
