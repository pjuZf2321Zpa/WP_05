<?php

namespace BitApps\SocialPro\Model;

use BitApps\SocialPro\Config;
use BitApps\SocialPro\Deps\BitApps\WPDatabase\Model;

final class AiPromptConfig extends Model
{
    protected $prefix = Config::FREE_PLUGIN_VAR_PREFIX;

    protected $fillable = [
        'title',
        'type',
        'platform',
        'model',
        'config',
        'prompt',
        'fallback_content',
    ];
}
