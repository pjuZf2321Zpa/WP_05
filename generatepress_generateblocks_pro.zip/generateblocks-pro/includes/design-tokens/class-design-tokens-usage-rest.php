<?php
/**
 * Design Token usage REST endpoint.
 *
 * @package GenerateBlocksPro\Design_Tokens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Read-only REST controller for Design Token usages.
 */
class GenerateBlocks_Pro_Design_Tokens_Usage_Rest extends GenerateBlocks_Pro_Singleton {

	const NAMESPACE_ROOT = 'generateblocks-pro/design-tokens/v1';

	/**
	 * Register hooks.
	 */
	public function init() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register the read-only usages route.
	 */
	public function register_routes(): void {
		register_rest_route(
			self::NAMESPACE_ROOT,
			'/usages',
			[
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'get_usages' ],
				'permission_callback' => [ $this, 'permissions_check' ],
				'args'                => [
					'name'    => [
						'type'     => 'string',
						'required' => true,
					],
					'refresh' => [
						'type'              => 'boolean',
						'required'          => false,
						'default'           => false,
						'sanitize_callback' => 'rest_sanitize_boolean',
					],
				],
			]
		);
	}

	/**
	 * Permission check for usage inspection.
	 */
	public function permissions_check(): bool {
		return GenerateBlocks_Pro_Design_Tokens::can_manage_tokens();
	}

	/**
	 * Scan Global Styles CSS, block content, token presets, and other
	 * token values for references to one custom property.
	 *
	 * @param WP_REST_Request $request Incoming request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_usages( WP_REST_Request $request ) {
		$name    = (string) $request->get_param( 'name' );
		$refresh = rest_sanitize_boolean( $request->get_param( 'refresh' ) );

		if ( ! GenerateBlocks_Pro_Design_Tokens::is_valid_token_name( $name ) ) {
			return new WP_Error(
				'gb_design_tokens_invalid_name',
				__( 'Invalid token name.', 'generateblocks-pro' ),
				[ 'status' => 400 ]
			);
		}

		return rest_ensure_response( GenerateBlocks_Pro_Design_Tokens_Usage::find_usages( $name, $refresh ) );
	}
}

GenerateBlocks_Pro_Design_Tokens_Usage_Rest::get_instance()->init();
