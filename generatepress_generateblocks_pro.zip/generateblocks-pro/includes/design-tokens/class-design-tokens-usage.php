<?php
/**
 * Design Tokens usage scanner.
 *
 * @package GenerateBlocksPro\Design_Tokens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Find occurrences of `var(--token-name)` across the site.
 *
 * Four surfaces are scanned, so a rename/delete warning reflects every place
 * a token name is the public contract:
 *   - **Global Styles** — the compiled CSS stored on `gblocks_styles` posts
 *     (gb_style_css meta).
 *   - **Block content** — `post_content` across editor-supporting post types,
 *     using the same two-phase recent-posts-then-filter query pattern that
 *     Global Styles usage search uses, so site-size doesn't blow up into a
 *     full table scan.
 *   - **Token presets** — option values in another token's nested display
 *     configuration that reference this token through `var()`.
 *   - **Root variables** — other custom properties anywhere in the managed
 *     `:root` styles object that reference this one through `var()`.
 */
class GenerateBlocks_Pro_Design_Tokens_Usage {

	const CACHE_PREFIX = 'gb_dt_usage_';

	/**
	 * Option holding the cache generation counter. Bumped by `clear_cache()`
	 * so every previously-written transient key becomes unreachable — works
	 * identically whether transients live in wp_options or a persistent
	 * object cache (Redis/Memcached), where direct SQL deletes clear nothing.
	 */
	const CACHE_GENERATION_OPTION = 'generateblocks_design_tokens_usage_cache_gen';

	/**
	 * Cache TTL in seconds. 15 minutes matches the cadence a user is likely
	 * to iterate on a token before re-checking where it's referenced, so most
	 * repeat clicks are served from the transient. Orphaned generations age
	 * out on this TTL (WP's scheduled expired-transient cleanup handles the
	 * DB rows).
	 */
	const CACHE_TTL = 900;

	/**
	 * Per-section cap on rows returned to the client.
	 */
	const RESULT_LIMIT = 50;

	/**
	 * Return the combined list of usages for a token name, consulting the
	 * transient cache first.
	 *
	 * Response shape:
	 *   - styles: rows for Global Styles that reference the token
	 *   - posts: rows for posts whose content references the token
	 *   - presets: rows for other token preset values that reference the token
	 *   - tokens: rows for other tokens whose value references the token
	 *   - limited: whether either DB scan was partial (the post scan's
	 *     recent-posts window, or a full Global Styles candidate pool)
	 *   - limits: post-scan stats for a limited scan (max_posts, scanned, total)
	 *
	 * @param string $name    CSS variable name, including the leading `--`.
	 * @param bool   $refresh Whether to bypass the cached result.
	 * @return array{
	 *     styles: array<int, array{styleId:int, selector:string, occurrences:int}>,
	 *     posts: array<int, array{postId:int, title:string, typeLabel:string, status:string, editUrl:string, occurrences?:int, restricted?:bool}>,
	 *     presets: array<int, array{name:string, label:string, occurrences:int}>,
	 *     tokens: array<int, array{name:string, label:string, occurrences:int}>,
	 *     limited: bool,
	 *     limits: array<string, mixed>,
	 * }
	 */
	public static function find_usages( string $name, bool $refresh = false ): array {
		if ( ! GenerateBlocks_Pro_Design_Tokens::is_valid_token_name( $name ) ) {
			return self::empty_result();
		}

		$cache_key = self::cache_key( $name );

		if ( ! $refresh ) {
			$cached = get_transient( $cache_key );

			// Require every section key so a value cached by an older build is
			// treated as stale and recomputed.
			if ( is_array( $cached ) && isset( $cached['styles'], $cached['posts'], $cached['presets'], $cached['tokens'] ) ) {
				return self::decorate_for_current_user( $cached );
			}
		}

		$pattern       = self::build_usage_pattern( $name );
		$global_styles = self::scan_global_styles( $name, $pattern );
		$posts         = self::scan_block_content( $name, $pattern );

		// Either DB scan can be partial — the post scan through its
		// recent-posts window, the Global Styles scan through its candidate
		// cap. Both invalidate a clean "not used anywhere" answer the same
		// way, so they share the `limited` flag; the post-scan stats are
		// attached whenever the flag is set so the usage modal always has
		// concrete numbers to render alongside its warning.
		$limited = $posts['limited'] || $global_styles['limited'];

		$result = [
			'styles'  => array_merge(
				$global_styles['items'],
				self::scan_root_style_declarations( $pattern )
			),
			'posts'   => $posts['items'],
			'presets' => self::count_preset_references(
				GenerateBlocks_Pro_Design_Tokens::get_tokens(),
				$pattern
			),
			'tokens'  => self::scan_token_self_refs( $name, $pattern ),
			'limited' => $limited,
			'limits'  => $limited ? $posts['limits'] : [],
		];

		set_transient( $cache_key, $result, self::CACHE_TTL );

		return self::decorate_for_current_user( $result );
	}

	/**
	 * Transient key for a token name under the current cache generation.
	 *
	 * @param string $name Token name.
	 */
	private static function cache_key( string $name ): string {
		$generation = (int) get_option( self::CACHE_GENERATION_OPTION, 1 );

		return self::CACHE_PREFIX . $generation . '_' . md5( $name );
	}

	/**
	 * Fill in the request-specific fields of a (possibly cached) result.
	 *
	 * Post access and edit links are per-user, so both are resolved at serve
	 * time rather than baked into the shared transient. Unreadable posts remain
	 * represented by anonymous rows: silently dropping them would make a known
	 * usage disappear from delete and rename warnings, while returning their
	 * stored metadata would disclose protected content. Negative request-local
	 * IDs keep the rendered rows distinct without exposing real post IDs.
	 *
	 * @param array $result Result payload (fresh or from cache).
	 * @return array
	 */
	private static function decorate_for_current_user( array $result ): array {
		if ( empty( $result['posts'] ) || ! is_array( $result['posts'] ) ) {
			return $result;
		}

		$restricted_index = 0;

		foreach ( $result['posts'] as &$item ) {
			if ( ! isset( $item['postId'] ) ) {
				continue;
			}

			$post_id = (int) $item['postId'];

			if ( ! current_user_can( 'read_post', $post_id ) ) {
				++$restricted_index;
				$item = [
					'postId'     => -$restricted_index,
					'title'      => __( 'Content you cannot view', 'generateblocks-pro' ),
					'typeLabel'  => __( 'Restricted content', 'generateblocks-pro' ),
					'status'     => '',
					'editUrl'    => '',
					'restricted' => true,
				];
				continue;
			}

			$item['editUrl'] = (string) get_edit_post_link( $post_id, 'raw' );
		}

		unset( $item );

		return $result;
	}

	/**
	 * Build the regex that confirms a real `var(--name)` reference.
	 *
	 * The custom-property name inside a `var()` is terminated by optional
	 * whitespace and then `,` (a fallback follows) or `)`. Matching on that —
	 * rather than a trailing `\b` word boundary — is what keeps a scan for
	 * `--foo` from matching a longer sibling token like `var(--foo-bar)` (a
	 * word boundary sits happily between `foo` and `-`, since `-` is a
	 * non-word character), and it lets a trailing-hyphen name like `--foo-`
	 * correctly match `var(--foo-)`.
	 *
	 * Handles `var(--foo)`, `var(--foo, fallback)`, and `var( --foo )`.
	 *
	 * @param string $name Token name including the leading `--`.
	 * @return string Regex usable with preg_match_all.
	 */
	public static function build_usage_pattern( string $name ): string {
		return '/\bvar\(\s*' . preg_quote( $name, '/' ) . '\s*[,)]/';
	}

	/**
	 * Extract every valid custom-property name referenced through `var()`.
	 *
	 * Pattern-library dependency discovery uses this on block content, Global
	 * Style CSS, and token values. Normalize Gutenberg's block-comment unicode
	 * escaping first so serialized attributes and ordinary CSS follow the same
	 * path.
	 *
	 * @param string $content CSS or serialized block content to inspect.
	 * @return string[] Unique token names in first-seen order.
	 */
	public static function extract_references( string $content ): array {
		$content = self::normalize_for_match( $content );
		$matches = [];

		$result = preg_match_all(
			'/\bvar\(\s*(--[\p{L}_][\p{L}\p{N}\p{M}_-]*)\s*[,)]/u',
			$content,
			$matches
		);

		// PCRE Unicode mode rejects the whole subject when legacy content
		// contains one malformed UTF-8 byte. Preserve discoverable ASCII
		// references in that supported content instead of reporting no usage.
		if ( false === $result ) {
			preg_match_all(
				'/\bvar\(\s*(--[a-zA-Z_][a-zA-Z0-9_-]*)\s*[,)]/',
				$content,
				$matches
			);
		}

		return array_values( array_unique( $matches[1] ?? [] ) );
	}

	/**
	 * The six-byte JSON-unicode escape for a hyphen-minus (U+002D).
	 *
	 * Gutenberg escapes the leading `--` of a CSS custom-property reference
	 * when serializing block attributes into block-comment JSON — otherwise
	 * `-->` would accidentally terminate the HTML comment. So a token used
	 * in a block's style attribute is stored in post_content as the escape
	 * sequence doubled, not as literal dashes.
	 *
	 * Built with chr() so the PHP source itself doesn't need to carry a
	 * literal backslash-u sequence (which would be fragile through tooling
	 * that rewrites unicode escapes).
	 */
	private static function hyphen_escape(): string {
		return chr( 0x5C ) . 'u002d';
	}

	/**
	 * Normalize the escaped form back to literal dashes so a single regex
	 * can count either form uniformly.
	 *
	 * @param string $content Raw post_content.
	 * @return string
	 */
	private static function normalize_for_match( string $content ): string {
		$prefix = self::hyphen_escape();

		return str_replace( [ $prefix, strtoupper( $prefix ) ], '-', $content );
	}

	/**
	 * JSON-escaped form of a token name, for SQL prefiltering against
	 * post_content. `--gb-brand` becomes `<esc><esc>gb-brand`.
	 *
	 * Core's `serialize_block_attributes()` escapes **every** `--` sequence
	 * (left-to-right, non-overlapping), not just the leading pair, so names
	 * with internal runs — `--gb--brand`, or `--gb-primary---dark` from a
	 * slugified label — must have all of them escaped or the probe never
	 * matches what's stored. `str_replace` applies the same left-to-right
	 * non-overlapping replacement as core's `strtr` map.
	 *
	 * Public for direct test coverage against core's serialization.
	 *
	 * @param string $name Token name.
	 * @return string
	 */
	public static function escaped_form( string $name ): string {
		$prefix = self::hyphen_escape();

		return str_replace( '--', $prefix . $prefix, $name );
	}

	/**
	 * Drop every cached usage result. Called when any token is saved, since
	 * a rename or delete immediately invalidates prior scans.
	 *
	 * Implemented as a generation bump rather than deleting transient rows:
	 * on persistent-object-cache sites transients never touch wp_options, so
	 * a SQL delete would silently clear nothing and stale scans would be
	 * served until the TTL expired. Bumping the key generation invalidates
	 * every backend the same way; the orphaned entries age out on their TTL.
	 */
	public static function clear_cache(): void {
		$generation = (int) get_option( self::CACHE_GENERATION_OPTION, 1 );

		update_option( self::CACHE_GENERATION_OPTION, $generation + 1, false );
	}

	/**
	 * Empty response shape. Used for invalid names or when the user hasn't
	 * defined any tokens yet, so callers can uniformly destructure the result.
	 */
	private static function empty_result(): array {
		return [
			'styles'  => [],
			'posts'   => [],
			'presets' => [],
			'tokens'  => [],
			'limited' => false,
			'limits'  => [],
		];
	}

	/**
	 * Scan nested token preset values for references to another token.
	 *
	 * Public as a pure helper so malformed imported metadata can be covered
	 * without bootstrapping the token store.
	 *
	 * @param array  $tokens  Token metadata rows.
	 * @param string $pattern Precompiled `var(--name)` regex.
	 * @return array<int, array{name:string, label:string, occurrences:int}>
	 */
	public static function count_preset_references( array $tokens, string $pattern ): array {
		$matches = [];

		foreach ( $tokens as $token ) {
			if ( ! is_array( $token ) ) {
				continue;
			}

			$options = $token['display']['options'] ?? [];

			if ( ! is_array( $options ) ) {
				continue;
			}

			$count = 0;

			foreach ( $options as $option ) {
				$value = is_array( $option ) && is_string( $option['value'] ?? null )
					? $option['value']
					: '';
				$count += (int) preg_match_all( $pattern, $value );
			}

			if ( $count ) {
				$matches[] = [
					'name'        => (string) ( $token['name'] ?? '' ),
					'label'       => (string) ( $token['label'] ?? '' ),
					'occurrences' => $count,
				];
			}
		}

		return $matches;
	}

	/**
	 * Scan other token values for a `var(--name)` reference to this token.
	 *
	 * Token values accept `var()` passthroughs, so one token can point at
	 * another. That reference lives in the token option itself — invisible to
	 * the post and Global Styles scans.
	 *
	 * @param string $name    Token name including the leading `--`.
	 * @param string $pattern Precompiled `var(--name)` regex.
	 * @return array<int, array{name:string, label:string, occurrences:int}>
	 */
	private static function scan_token_self_refs( string $name, string $pattern ): array {
		$counts = [];

		foreach ( self::get_root_style_sources() as $source ) {
			$matches = self::count_token_references(
				$source['styles'],
				$name,
				$pattern,
				GenerateBlocks_Pro_Design_Tokens::get_tokens()
			);

			foreach ( $matches as $match ) {
				$token_name = $match['name'];

				if ( ! isset( $counts[ $token_name ] ) ) {
					$counts[ $token_name ] = $match;
					continue;
				}

				$counts[ $token_name ]['occurrences'] += $match['occurrences'];
			}
		}

		return array_values( $counts );
	}

	/**
	 * Read every resolved root candidate without mutating it. Conflict records
	 * are included so usage warnings remain useful while the singleton needs
	 * manual repair.
	 *
	 * @return array<int, array{postId:int,styles:array}>
	 */
	private static function get_root_style_sources(): array {
		if ( ! class_exists( 'GenerateBlocks_Pro_Styles_Root' ) ) {
			return [
				[
					'postId' => 0,
					'styles' => GenerateBlocks_Pro_Design_Tokens::get_root_styles_data(),
				],
			];
		}

		$sources = [];

		foreach ( GenerateBlocks_Pro_Styles_Root::resolve()['ids'] as $post_id ) {
			$styles = get_post_meta( $post_id, 'gb_style_data', true );

			$sources[] = [
				'postId' => (int) $post_id,
				'styles' => is_array( $styles ) ? $styles : [],
			];
		}

		return $sources;
	}

	/**
	 * Report references in ordinary declarations on the root style. References
	 * from one custom property to another are reported in the token section.
	 *
	 * @param string $pattern Precompiled usage pattern.
	 * @return array<int, array{styleId:int,selector:string,occurrences:int}>
	 */
	private static function scan_root_style_declarations( string $pattern ): array {
		$matches = [];

		foreach ( self::get_root_style_sources() as $source ) {
			$count = self::count_non_token_root_references( $source['styles'], $pattern );

			if ( $count ) {
				$matches[] = [
					'styleId'     => $source['postId'],
					'selector'    => ':root',
					'occurrences' => $count,
				];
			}
		}

		return $matches;
	}

	/**
	 * Count references in non-custom-property values anywhere in a root tree.
	 *
	 * @param array  $branch  Current styles branch.
	 * @param string $pattern Precompiled usage pattern.
	 */
	public static function count_non_token_root_references( array $branch, string $pattern ): int {
		$count = 0;

		foreach ( $branch as $property => $value ) {
			if ( is_array( $value ) ) {
				$count += self::count_non_token_root_references( $value, $pattern );
				continue;
			}

			if (
				! is_string( $property )
				|| self::is_token_name( $property )
				|| ! is_string( $value )
			) {
				continue;
			}

			$count += (int) preg_match_all( $pattern, $value );
		}

		return $count;
	}

	/**
	 * Recognize the shared token-name grammar without adding a load-order
	 * requirement to the scanner's pure matching helpers.
	 *
	 * @param string $name Potential token name.
	 */
	private static function is_token_name( string $name ): bool {
		return GenerateBlocks_Pro_Design_Tokens::is_valid_token_name( $name );
	}

	/**
	 * Pure matcher: custom properties — other than `$name` itself — whose value
	 * references `$name` anywhere in the root styles tree.
	 *
	 * @param array  $styles  Root styles object.
	 * @param string $name    Token name including the leading `--`.
	 * @param string $pattern Precompiled `var(--name)` regex.
	 * @param array  $metadata Registered token metadata for labels.
	 * @return array<int, array{name:string, label:string, occurrences:int}>
	 */
	public static function count_token_references( array $styles, string $name, string $pattern, array $metadata = [] ): array {
		$counts = [];
		self::count_root_references_recursive( $styles, $name, $pattern, $counts );
		$labels = [];

		foreach ( $metadata as $token ) {
			$labels[ $token['name'] ] = $token['label'];
		}

		$matches = [];

		foreach ( $counts as $token_name => $count ) {
			$matches[] = [
				'name'        => $token_name,
				'label'       => (string) ( $labels[ $token_name ] ?? '' ),
				'occurrences' => $count,
			];
		}

		return $matches;
	}

	/**
	 * Recursively count references by declaring custom property.
	 *
	 * @param array  $branch  Current styles branch.
	 * @param string $name    Target variable name.
	 * @param string $pattern Precompiled usage pattern.
	 * @param array  $counts  Counts grouped by declaring variable.
	 */
	private static function count_root_references_recursive( array $branch, string $name, string $pattern, array &$counts ): void {
		foreach ( $branch as $property => $value ) {
			if ( is_array( $value ) ) {
				self::count_root_references_recursive( $value, $name, $pattern, $counts );
				continue;
			}

			if (
				! is_string( $property )
				|| $property === $name
				|| ! self::is_token_name( $property )
				|| ! is_string( $value )
			) {
				continue;
			}

			$count = preg_match_all( $pattern, $value );

			if ( $count ) {
				$counts[ $property ] = ( $counts[ $property ] ?? 0 ) + (int) $count;
			}
		}
	}

	/**
	 * Scan `gblocks_styles` CSS for `var(--name)` / `var(--name, fallback)`.
	 *
	 * Two-phase: SQL LIKE narrows the post set to candidates whose CSS text
	 * actually contains the token substring, then a regex confirms it's a
	 * word-boundary match on a real `var()` reference — so `--foo-bar` doesn't
	 * match a scan for `--foo`.
	 *
	 * @param string $name    Token name including the leading `--`.
	 * @param string $pattern Precompiled regex (word-boundary `var(...)`).
	 * @return array{
	 *     items: array<int, array{styleId:int, selector:string, occurrences:int}>,
	 *     limited: bool,
	 * }
	 */
	private static function scan_global_styles( string $name, string $pattern ): array {
		global $wpdb;

		$like = '%' . $wpdb->esc_like( $name ) . '%';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.ID, p.post_title, css.meta_value AS css, sel.meta_value AS selector
				FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} css ON css.post_id = p.ID AND css.meta_key = %s
				LEFT JOIN {$wpdb->postmeta} sel ON sel.post_id = p.ID AND sel.meta_key = %s
				WHERE p.post_type = %s
					AND p.post_status = %s
					AND css.meta_value LIKE %s
				LIMIT %d",
				'gb_style_css',
				'gb_style_selector',
				'gblocks_styles',
				'publish',
				$like,
				self::RESULT_LIMIT
			)
		);

		$rows = is_array( $rows ) ? $rows : [];

		// The SQL LIMIT caps LIKE *candidates*, not confirmed matches — when
		// it's hit, regex-rejected candidates may have crowded out a real
		// `var()` consumer beyond the cap, so the scan must report itself as
		// partial rather than answering a clean "not used in Global Styles".
		$limited = count( $rows ) >= self::RESULT_LIMIT;

		$results = [];

		foreach ( $rows as $row ) {
			if (
				class_exists( 'GenerateBlocks_Pro_Styles_Root' )
				&& ':root' === GenerateBlocks_Pro_Styles_Root::normalize_selector( (string) $row->selector )
			) {
				continue;
			}

			$css   = is_string( $row->css ) ? $row->css : '';
			$count = preg_match_all( $pattern, $css );

			if ( ! $count ) {
				continue;
			}

			$selector = is_string( $row->selector ) && '' !== $row->selector
				? $row->selector
				: (string) $row->post_title;

			$results[] = [
				'styleId'     => (int) $row->ID,
				'selector'    => $selector,
				'occurrences' => (int) $count,
			];
		}

		return [
			'items'   => $results,
			'limited' => $limited,
		];
	}

	/**
	 * Scan `post_content` across editor-supporting post types for `var(--name)`.
	 *
	 * Follows the same two-phase pattern as Global Styles usage search: pull
	 * the most recently modified posts up to `generateblocks_usage_search_max_posts`
	 * (default 5000), then filter those by LIKE. This keeps the query fast on
	 * large sites at the cost of not guaranteeing exhaustive coverage — we
	 * report that truthfully via the `limited` / `limits` response fields.
	 *
	 * The `limits` stats are returned unconditionally — the caller decides
	 * whether to surface them, and attaches them whenever *any* scan was
	 * partial (including the Global Styles candidate scan) so the usage
	 * modal's warning always has numbers to render.
	 *
	 * @param string $name    Token name including the leading `--`.
	 * @param string $pattern Precompiled regex (word-boundary `var(...)`).
	 * @return array{
	 *     items: array<int, array{postId:int, title:string, typeLabel:string, status:string, editUrl:string, occurrences:int}>,
	 *     limited: bool,
	 *     limits: array{maxPosts:int, scannedPosts:int, totalPosts:int},
	 * }
	 */
	private static function scan_block_content( string $name, string $pattern ): array {
		global $wpdb;

		$post_types     = get_post_types_by_support( 'editor' );
		$excluded_types = [ 'revision', 'attachment', 'nav_menu_item', 'gblocks_styles' ];
		$post_types     = array_values( array_diff( $post_types, $excluded_types ) );

		/** This filter is documented in includes/styles/class-styles-rest.php */
		$post_types = apply_filters( 'generateblocks_usage_search_post_types', $post_types, 'design-tokens' );

		if ( empty( $post_types ) ) {
			return [
				'items'   => [],
				'limited' => false,
				'limits'  => [
					'maxPosts'     => 0,
					'scannedPosts' => 0,
					'totalPosts'   => 0,
				],
			];
		}

		$post_statuses = [ 'publish', 'private', 'draft' ];

		/** This filter is documented in includes/styles/class-styles-rest.php */
		$max_posts_to_scan = (int) apply_filters( 'generateblocks_usage_search_max_posts', 5000 );

		$type_placeholders   = implode( ', ', array_fill( 0, count( $post_types ), '%s' ) );
		$status_placeholders = implode( ', ', array_fill( 0, count( $post_statuses ), '%s' ) );

		// Count total eligible posts so we can tell the UI honestly whether
		// this was a partial scan.
		$total_sql = sprintf(
			"SELECT COUNT(ID) FROM {$wpdb->posts} WHERE post_status IN (%s) AND post_type IN (%s)",
			$status_placeholders,
			$type_placeholders
		);

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$total_query = $wpdb->prepare( $total_sql, array_merge( $post_statuses, $post_types ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$total_posts   = (int) $wpdb->get_var( $total_query );
		$scanned_posts = min( $total_posts, $max_posts_to_scan );
		$limited_scan  = $total_posts > $max_posts_to_scan;

		$escaped_name = self::escaped_form( $name );

		// LOCATE() beats LIKE here: the escaped-JSON form contains literal
		// backslashes, and LIKE's default escape character is also `\`,
		// which makes the pattern brittle. LOCATE is a plain substring
		// search with no escape semantics, so what we pass is what's
		// matched.
		// phpcs:disable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$sql = sprintf(
			"SELECT ID, post_title, post_type, post_status, post_content
			FROM (
				SELECT ID, post_title, post_type, post_status, post_content, post_modified
				FROM {$wpdb->posts}
				WHERE post_status IN (%s)
				AND post_type IN (%s)
				ORDER BY post_modified DESC
				LIMIT %%d
			) AS recent_posts
			WHERE LOCATE(%%s, post_content) > 0 OR LOCATE(%%s, post_content) > 0
			LIMIT %%d",
			$status_placeholders,
			$type_placeholders
		);

		$query = $wpdb->prepare(
			$sql, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			array_merge(
				$post_statuses,
				$post_types,
				[ $max_posts_to_scan, $name, $escaped_name, self::RESULT_LIMIT ]
			)
		);
		// phpcs:enable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( $query );

		$items = [];

		foreach ( $rows as $row ) {
			$content = is_string( $row->post_content ) ? self::normalize_for_match( $row->post_content ) : '';
			$count   = preg_match_all( $pattern, $content );

			if ( ! $count ) {
				continue;
			}

			$type_object = get_post_type_object( $row->post_type );
			$type_label  = $type_object ? $type_object->labels->singular_name : $row->post_type;

			$title = '' !== (string) $row->post_title
				? $row->post_title
				: sprintf(
					/* translators: 1: Post type label, 2: Post ID. */
					__( '%1$s #%2$d', 'generateblocks-pro' ),
					$type_label,
					$row->ID
				);

			$items[] = [
				'postId'      => (int) $row->ID,
				'title'       => (string) $title,
				'typeLabel'   => (string) $type_label,
				'status'      => (string) $row->post_status,
				// Per-user; filled in at serve time by decorate_for_current_user().
				'editUrl'     => '',
				'occurrences' => (int) $count,
			];
		}

		// The SQL LIMIT caps LIKE *candidates*, not confirmed matches — when
		// it's hit, regex-rejected candidates may have crowded out real
		// matches beyond the cap, so the scan must report itself as partial.
		$hit_result_cap = count( $rows ) >= self::RESULT_LIMIT;
		$limited        = $limited_scan || $hit_result_cap;

		return [
			'items'   => $items,
			'limited' => $limited,
			'limits'  => [
				'maxPosts'     => $max_posts_to_scan,
				'scannedPosts' => $scanned_posts,
				'totalPosts'   => $total_posts,
			],
		];
	}
}
