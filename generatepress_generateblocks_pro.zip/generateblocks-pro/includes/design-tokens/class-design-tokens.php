<?php
/**
 * Design Tokens core class.
 *
 * @package GenerateBlocksPro\Design_Tokens
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Metadata storage, validation, and editor integration for Design Tokens.
 *
 * Tokens are stored as one versioned envelope in `gb_style_tokens` post meta
 * on the managed `:root` Global Style. Each row stores identity, type, label,
 * scope, category, and optional inline-control display metadata. Values live
 * in that post's Styles Builder data and are joined by custom-property name at
 * read time.
 *
 * `scope[]` is a per-token list of CSS property names. An empty scope is
 * valid for every type: the CSS variable is still emitted into `:root{}`,
 * the token just isn't surfaced in any picker (see `validate_token`).
 *
 * The root snapshot service owns durability for styles, CSS, and this registry
 * together. The only token write is the root aggregate's checksummed save.
 */
class GenerateBlocks_Pro_Design_Tokens extends GenerateBlocks_Pro_Singleton {

	const META_KEY = 'gb_style_tokens';

	const GLOBAL_CONTAINER_WIDTH_TOKEN = '--gb-container-width';

	/**
	 * Storage-shape version. Bump only when the on-disk structure changes in a
	 * way that needs a migration. The dashboard file exporter also stamps this
	 * onto download payloads.
	 */
	const DATA_VERSION = 1;

	/**
	 * Test-only root styles override.
	 *
	 * @var array|null
	 */
	private static ?array $root_styles_for_tests = null;

	/**
	 * Test-only token registry override.
	 *
	 * @var array|null
	 */
	private static ?array $tokens_for_tests = null;

	/**
	 * Read-time keep predicate handed to the store. Drops only rows without
	 * a valid name — a nameless row can't be referenced as `var()` and is
	 * unrepairable noise (corruption, malformed hand-edits).
	 *
	 * @param array $token Already-sanitized token row.
	 */
	public static function is_token_keepable_on_read( array $token ): bool {
		return self::is_valid_token_name( $token['name'] );
	}

	/**
	 * Register hooks.
	 */
	public function init() {
		add_action( 'enqueue_block_editor_assets', [ $this, 'localize_editor_tokens' ], 30 );
		add_filter( 'generateblocks_should_set_container_width', [ $this, 'should_set_container_width' ] );
	}

	/**
	 * Supported token types.
	 *
	 * INVARIANT: adding or removing a type changes which stored rows this
	 * build can interpret (unknown types coerce to `color` in
	 * `sanitize_token`). Any change here must bump DATA_VERSION so an older
	 * build refuses the newer envelope and falls back to its history slots
	 * instead of mis-reading rows.
	 *
	 * @return string[]
	 */
	public static function supported_types(): array {
		return [ 'color', 'unit', 'text' ];
	}

	/**
	 * Capability required to manage design tokens.
	 */
	public static function get_manage_tokens_capability(): string {
		return apply_filters(
			'generateblocks_manage_tokens_capability',
			GenerateBlocks_Pro_Styles::get_manage_styles_capability()
		);
	}

	/**
	 * Whether the current user can manage design tokens.
	 */
	public static function can_manage_tokens(): bool {
		return current_user_can( self::get_manage_tokens_capability() )
			&& (bool) apply_filters( 'generateblocks_can_manage_tokens', true )
			&& GenerateBlocks_Pro_Styles::can_manage_styles();
	}

	/**
	 * Read the stored tokens from the managed root post.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_tokens(): array {
		if ( null !== self::$tokens_for_tests ) {
			return self::$tokens_for_tests;
		}

		return self::read_state()['tokens'];
	}

	/**
	 * Read stored token state with recovery info.
	 *
	 * An unreadable primary envelope falls back to the newest readable root
	 * snapshot. Resolving without an explicit post is observe-only: consumers
	 * such as usage scans must never create the root as a side effect.
	 *
	 * @param WP_Post|null $post    Root post, or null to resolve without creating.
	 * @param bool         $recover Whether corrupt primary meta may use snapshots.
	 * @return array{tokens:array<int, array<string, mixed>>, source:string}
	 */
	public static function read_state( ?WP_Post $post = null, bool $recover = true ): array {
		if ( null === $post && class_exists( 'GenerateBlocks_Pro_Styles_Root' ) ) {
			$post = GenerateBlocks_Pro_Styles_Root::get_post();
		}

		if ( ! $post instanceof WP_Post ) {
			return [
				'tokens' => [],
				'source' => 'none',
			];
		}

		$raw = get_post_meta( $post->ID, self::META_KEY, true );

		if ( self::meta_exists( (int) $post->ID, $raw ) ) {
			$envelope = self::sanitize_envelope( $raw );

			if ( null !== $envelope ) {
				return [
					'tokens' => $envelope['tokens'],
					'source' => 'primary',
				];
			}

			if ( $recover && class_exists( 'GenerateBlocks_Pro_Styles_Root_Snapshots' ) ) {
				for ( $slot = 1; $slot <= 3; $slot++ ) {
					$snapshot = GenerateBlocks_Pro_Styles_Root_Snapshots::get( $slot );

					if ( null === $snapshot ) {
						continue;
					}

					$snapshot_envelope = self::sanitize_envelope( $snapshot['tokens'] ?? null );

					if ( null !== $snapshot_envelope ) {
						return [
							'tokens' => $snapshot_envelope['tokens'],
							'source' => 'snapshot_' . $slot,
						];
					}
				}
			}
		}

		return [
			'tokens' => [],
			'source' => 'none',
		];
	}

	/**
	 * Normalize and validate a complete replacement registry.
	 *
	 * The root persistence service calls this before writing the envelope so
	 * every registry write remains inside the aggregate checksum boundary.
	 *
	 * @param array $tokens Candidate tokens from the client.
	 * @return array|WP_Error Normalized array, or a validation failure.
	 */
	public static function normalize_tokens( array $tokens ) {
		$normalized = [];
		$names_seen = [];

		foreach ( $tokens as $index => $raw ) {
			$sanitized = self::sanitize_token( $raw );

			if ( null === $sanitized ) {
				return new WP_Error(
					'gb_design_tokens_invalid_row',
					sprintf(
						/* translators: %d is the row index */
						__( 'Row %d is not a valid token.', 'generateblocks-pro' ),
						(int) $index + 1
					),
					[ 'status' => 400 ]
				);
			}

			if (
				array_key_exists( 'display', $raw )
				&& null !== $raw['display']
				&& null === self::sanitize_display_item( $raw['display'], $sanitized['type'] )
			) {
				return new WP_Error(
					'gb_design_tokens_invalid_display',
					sprintf(
						/* translators: %d is the row index */
						__( 'Row %d has an invalid inline control configuration.', 'generateblocks-pro' ),
						(int) $index + 1
					),
					[ 'status' => 400 ]
				);
			}

			$validation_error = self::validate_token( $sanitized, (int) $index );

			if ( is_wp_error( $validation_error ) ) {
				return $validation_error;
			}

			if ( isset( $names_seen[ $sanitized['name'] ] ) ) {
				return new WP_Error(
					'gb_design_tokens_duplicate_name',
					sprintf(
						/* translators: %s is the token name */
						__( 'Duplicate token name: %s', 'generateblocks-pro' ),
						$sanitized['name']
					),
					[ 'status' => 400 ]
				);
			}

			$names_seen[ $sanitized['name'] ] = true;
			$normalized[] = $sanitized;
		}

		return $normalized;
	}

	/**
	 * Wrap a trusted normalized registry for post-meta storage.
	 *
	 * @param array $tokens Normalized registry rows.
	 */
	public static function envelope( array $tokens ): array {
		return [
			'version' => self::DATA_VERSION,
			'tokens'  => array_values( $tokens ),
		];
	}

	/**
	 * Parse and sanitize one stored registry envelope.
	 *
	 * Invalid rows are dropped independently so one malformed row cannot hide
	 * the rest of a readable registry. An unreadable envelope returns null.
	 *
	 * @param mixed $raw Stored meta value.
	 * @return array{version:int,tokens:array<int, array<string, mixed>>}|null
	 */
	public static function sanitize_envelope( $raw ): ?array {
		if (
			! is_array( $raw )
			|| ! isset( $raw['version'], $raw['tokens'] )
			|| ! is_int( $raw['version'] )
			|| $raw['version'] > self::DATA_VERSION
			|| ! is_array( $raw['tokens'] )
		) {
			return null;
		}

		$tokens = [];

		foreach ( $raw['tokens'] as $row ) {
			$token = self::sanitize_token( $row );

			if ( null !== $token && self::is_token_keepable_on_read( $token ) ) {
				$tokens[] = $token;
			}
		}

		return self::envelope( $tokens );
	}

	/**
	 * Whether the registry meta key exists on a post.
	 *
	 * @param int   $post_id Post ID.
	 * @param mixed $raw     Already-read meta value.
	 */
	private static function meta_exists( int $post_id, $raw ): bool {
		if ( function_exists( 'metadata_exists' ) ) {
			return metadata_exists( 'post', $post_id, self::META_KEY );
		}

		return '' !== $raw;
	}

	/**
	 * Reset test-only overrides.
	 */
	public static function reset_store_for_tests(): void {
		self::$root_styles_for_tests = null;
		self::$tokens_for_tests = null;
	}

	/**
	 * Test-only seam for consumers that read the registry.
	 *
	 * @param array|null $tokens Token rows, or null to clear the override.
	 */
	public static function set_tokens_for_tests( ?array $tokens ): void {
		self::$tokens_for_tests = $tokens;
	}

	/**
	 * Test-only seam for consumers that join metadata against root values.
	 *
	 * @param array|null $styles Root styles override, or null to clear it.
	 */
	public static function set_root_styles_for_tests( ?array $styles ): void {
		self::$root_styles_for_tests = $styles;
	}

	/**
	 * Read root styles through the non-mutating singleton resolver.
	 */
	public static function get_root_styles_data(): array {
		if ( null !== self::$root_styles_for_tests ) {
			return self::$root_styles_for_tests;
		}

		return class_exists( 'GenerateBlocks_Pro_Styles_Root' )
			? GenerateBlocks_Pro_Styles_Root::get_styles()
			: [];
	}

	/**
	 * Normalize a raw token row into the stored shape, or return null if the
	 * row is unrecognizable.
	 *
	 * @param mixed $raw Raw input row.
	 * @return array|null
	 */
	public static function sanitize_token( $raw ) {
		if ( ! is_array( $raw ) ) {
			return null;
		}

		$id    = isset( $raw['id'] ) && is_string( $raw['id'] ) ? trim( $raw['id'] ) : '';
		$name  = isset( $raw['name'] ) && is_string( $raw['name'] ) ? trim( $raw['name'] ) : '';
		$type  = isset( $raw['type'] ) && is_string( $raw['type'] ) ? strtolower( trim( $raw['type'] ) ) : '';
		$label = isset( $raw['label'] ) && is_string( $raw['label'] ) ? $raw['label'] : '';
		$scope = isset( $raw['scope'] ) && is_array( $raw['scope'] ) ? $raw['scope'] : [];
		$category = isset( $raw['category'] ) && is_string( $raw['category'] )
			? trim( sanitize_text_field( $raw['category'] ) )
			: '';

		if ( function_exists( 'mb_substr' ) ) {
			$category = mb_substr( $category, 0, 100 );
		} else {
			$category = substr( $category, 0, 100 );
		}

		if ( ! in_array( $type, self::supported_types(), true ) ) {
			$type = 'color';
		}

		$scope_clean = [];

		foreach ( $scope as $entry ) {
			if ( ! is_string( $entry ) ) {
				continue;
			}

			$trimmed = trim( $entry );

			if ( '' !== $trimmed && preg_match( '/^[a-zA-Z][a-zA-Z0-9]*$/', $trimmed ) ) {
				$scope_clean[] = $trimmed;
			}
		}

		$token = [
			'id'       => '' !== $id ? sanitize_text_field( $id ) : wp_generate_uuid4(),
			'name'     => $name,
			'type'     => $type,
			'label'    => sanitize_text_field( $label ),
			'scope'    => array_values( array_unique( $scope_clean ) ),
			'category' => $category,
		];

		if ( array_key_exists( 'display', $raw ) && null !== $raw['display'] ) {
			$display = self::sanitize_display_item( $raw['display'], $type );

			if ( null !== $display ) {
				$token['display'] = $display;
			}
		}

		return $token;
	}

	/**
	 * Apply a type change to one registry row.
	 *
	 * A token's Applies to properties and its type-bound quick-edit control only
	 * mean something for the type they were chosen under, so a type change
	 * decides both. `normalize_tokens()` cannot do this on a caller's behalf: it
	 * sees one replacement registry and has no previous type to compare, never
	 * matches scope to type, and rejects the whole write when a control no
	 * longer fits.
	 *
	 * The dashboard and editor apply the same rule in JS
	 * (`displayForTypeChange()` and the scope reset in `useTokenRows`), for a
	 * single token and for a selection alike. Server-side callers changing a
	 * type go through here instead of restating it, then save the registry
	 * through `GenerateBlocks_Pro_Styles_Root::save()` as usual. Keep the two
	 * in step.
	 *
	 * Values are deliberately not judged: a row carries none, and whether the
	 * stored `:root` values suit the new type is for the caller to check with
	 * `is_valid_value_for_type()` before it writes.
	 *
	 * @param array  $token Registry row.
	 * @param string $type  Type to change to.
	 * @return array|WP_Error The row for the new type, or an unsupported-type error.
	 */
	public static function change_token_type( array $token, string $type ) {
		$type = strtolower( trim( $type ) );

		if ( ! in_array( $type, self::supported_types(), true ) ) {
			return new WP_Error(
				'gb_design_tokens_invalid_type',
				__( 'That Design Token type is not supported.', 'generateblocks-pro' ),
				[ 'status' => 400 ]
			);
		}

		$current = isset( $token['type'] ) && is_string( $token['type'] )
			? strtolower( trim( $token['type'] ) )
			: '';

		// An unchanged type keeps its scope and control, exactly as the UI only
		// reacts when the type actually moves.
		if ( $current === $type ) {
			return $token;
		}

		$display = isset( $token['display'] ) && is_array( $token['display'] ) ? $token['display'] : null;
		$control = isset( $display['control'] ) && is_string( $display['control'] ) ? $display['control'] : '';

		$token['type']  = $type;
		$token['scope'] = [];

		if ( null === $display && 'color' === $type ) {
			$token['display'] = [ 'control' => 'colorPicker' ];
		} elseif ( in_array( $control, [ 'colorPicker', 'unitControl' ], true ) ) {
			unset( $token['display'] );
		}

		return $token;
	}

	/**
	 * Validate a normalized token row. Returns WP_Error on failure, null on ok.
	 *
	 * Callers should run `sanitize_token` first; this routine assumes the
	 * shape is already in stored form.
	 *
	 * @param array $token Normalized token.
	 * @param int   $index Position in the incoming array, for error messages.
	 * @return WP_Error|null
	 */
	public static function validate_token( array $token, int $index ) {
		if ( ! self::is_valid_token_name( $token['name'] ) ) {
			return new WP_Error(
				'gb_design_tokens_invalid_name',
				sprintf(
					/* translators: %d is the row index */
					__( 'Row %d: invalid token name. Use format --name.', 'generateblocks-pro' ),
					$index + 1
				),
				[ 'status' => 400 ]
			);
		}

		// Empty scope is valid: it means the token is registered but is not
		// surfaced in any property picker.
		return null;
	}

	/**
	 * Sanitize and semantically validate one display item.
	 *
	 * @param mixed  $raw  Candidate item.
	 * @param string $type Stored token type.
	 * @return array{control:string,options?:array<int, array{label:string,value:string}>}|null
	 */
	private static function sanitize_display_item( $raw, string $type ): ?array {
		if ( ! is_array( $raw ) ) {
			return null;
		}

		$control = isset( $raw['control'] ) && is_string( $raw['control'] )
			? trim( $raw['control'] )
			: '';

		if ( 'colorPicker' === $control ) {
			return 'color' === $type ? [ 'control' => 'colorPicker' ] : null;
		}

		if ( 'unitControl' === $control ) {
			return 'unit' === $type ? [ 'control' => 'unitControl' ] : null;
		}

		$options = $raw['options'] ?? null;

		if (
			! in_array( $control, [ 'buttonGroup', 'select' ], true )
			|| ! is_array( $options )
			|| count( $options ) > 50
		) {
			return null;
		}

		$clean = [];

		foreach ( $options as $option ) {
			if (
				! is_array( $option )
				|| ! isset( $option['label'], $option['value'] )
				|| ! is_string( $option['label'] )
				|| ! is_string( $option['value'] )
			) {
				return null;
			}

			$label = trim( sanitize_text_field( $option['label'] ) );
			$value = trim( $option['value'] );

			if ( '' === $label || ! self::is_valid_value_for_type( $value, $type ) ) {
				return null;
			}

			$clean[] = [
				'label' => $label,
				'value' => $value,
			];
		}

		if ( empty( $clean ) ) {
			return null;
		}

		return [
			'control' => $control,
			'options' => $clean,
		];
	}

	/**
	 * Shape the `gbDesignTokens` global. One source of truth so editor,
	 * style book, and dashboard never drift out of sync.
	 */
	public static function get_localized_token_data(): array {
		$styles = self::get_root_styles_data();
		$tokens = [];
		$variable_names = [];

		self::collect_variable_names( $styles, $variable_names );

		foreach ( self::get_tokens() as $token ) {
			$name = $token['name'];

			if (
				! array_key_exists( $name, $styles )
				|| ! is_string( $styles[ $name ] )
				|| ! self::is_valid_value_for_type( $styles[ $name ], $token['type'] )
			) {
				continue;
			}

			$tokens[] = array_merge( $token, [ 'value' => $styles[ $name ] ] );
		}

		return [
			'tokens'        => $tokens,
			'variableNames' => array_values( array_unique( $variable_names ) ),
		];
	}

	/**
	 * Take ownership of GenerateBlocks' global container width while a usable
	 * Design Token manages the same CSS custom property. GenerateBlocks then
	 * hides its legacy Settings input and suppresses its frontend `:root`
	 * fallback declaration, leaving this token's root value as the only
	 * frontend declaration. The saved legacy value is never changed, and both
	 * surfaces return as soon as the token stops being usable.
	 *
	 * @param bool $should_set Whether GenerateBlocks would manage the width.
	 * @return bool
	 */
	public function should_set_container_width( $should_set ): bool {
		if ( ! $should_set ) {
			return false;
		}

		foreach ( self::get_localized_token_data()['tokens'] as $token ) {
			if (
				self::GLOBAL_CONTAINER_WIDTH_TOKEN === $token['name']
				&& 'unit' === $token['type']
			) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Collect every custom-property name from all root branches.
	 *
	 * @param array $branch Current styles branch.
	 * @param array $names  Collected variable names.
	 */
	private static function collect_variable_names( array $branch, array &$names ): void {
		foreach ( $branch as $key => $value ) {
			if ( self::is_valid_token_name( (string) $key ) ) {
				$names[] = (string) $key;
				continue;
			}

			if ( is_array( $value ) ) {
				self::collect_variable_names( $value, $names );
			}
		}
	}

	/**
	 * Localize token data onto the block editor script.
	 */
	public function localize_editor_tokens() {
		wp_localize_script(
			'generateblocks-pro-editor',
			'gbDesignTokens',
			self::get_localized_token_data()
		);
	}

	/**
	 * Validate a CSS custom property identifier.
	 *
	 * Accepts the practical unescaped subset shared with the client: a Unicode
	 * letter or underscore after `--`, followed by Unicode letters, numbers,
	 * combining marks, underscores, or dashes.
	 *
	 * @param string $name Token name to validate.
	 * @return bool
	 */
	public static function is_valid_token_name( string $name ): bool {
		return (bool) preg_match( '/^--[\p{L}_][\p{L}\p{N}\p{M}_-]*$/u', $name );
	}

	/**
	 * Dispatch to the right typed value validator.
	 *
	 * @param string $value Value to validate.
	 * @param string $type  Token type (color, unit, text).
	 * @return bool
	 */
	public static function is_valid_value_for_type( string $value, string $type ): bool {
		switch ( $type ) {
			case 'color':
				return self::is_valid_color_value( $value );
			case 'unit':
				return self::is_valid_length_value( $value );
			case 'text':
				return self::is_valid_text_value( $value );
		}

		return false;
	}

	/**
	 * Validate a color token value.
	 *
	 * @param string $value Value to validate.
	 * @return bool
	 */
	public static function is_valid_color_value( string $value ): bool {
		$trimmed = trim( $value );

		if ( '' === $trimmed || ! self::passes_safety_check( $trimmed ) ) {
			return false;
		}

		if ( preg_match( '/^#([0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i', $trimmed ) ) {
			return true;
		}

		if ( self::starts_with_function( $trimmed, self::color_functions() ) ) {
			return true;
		}

		$lower = strtolower( $trimmed );

		if ( in_array( $lower, self::css_wide_keywords(), true ) ) {
			return true;
		}

		return in_array( $lower, self::named_colors(), true );
	}

	/**
	 * Validate a length/size token value.
	 *
	 * @param string $value Value to validate.
	 * @return bool
	 */
	public static function is_valid_length_value( string $value ): bool {
		$trimmed = trim( $value );

		if ( '' === $trimmed || ! self::passes_safety_check( $trimmed ) ) {
			return false;
		}

		if ( self::starts_with_function( $trimmed, self::length_functions() ) ) {
			return true;
		}

		$number = '-?(\d+(\.\d+)?|\.\d+)';
		$units  = '%|px|em|rem|vh|vw|vmin|vmax|ch|ex|cap|ic|lh|rlh|svw|svh|lvw|lvh|dvw|dvh|pt|pc|mm|cm|in|q|fr|deg|rad|grad|turn|s|ms';

		if ( preg_match( '/^' . $number . '(' . $units . ')?$/i', $trimmed ) ) {
			return true;
		}

		$lower = strtolower( $trimmed );

		if ( in_array( $lower, self::css_wide_keywords(), true ) ) {
			return true;
		}

		$length_keywords = [ 'auto', 'none', 'normal', 'fit-content', 'max-content', 'min-content' ];

		return in_array( $lower, $length_keywords, true );
	}

	/**
	 * Validate a free-form text token value. The escape hatch for anything
	 * the typed validators are too strict for (font stacks, grid templates,
	 * etc.). Any non-empty string that passes the safety check is allowed.
	 *
	 * @param string $value Value to validate.
	 * @return bool
	 */
	public static function is_valid_text_value( string $value ): bool {
		$trimmed = trim( $value );

		if ( '' === $trimmed ) {
			return false;
		}

		return self::passes_safety_check( $trimmed );
	}

	/**
	 * Reject anything that could escape its declaration in the single-line
	 * `:root{}` blob: breakout characters, line breaks, CSS comment markers,
	 * unclosed strings (a CSS bad-string swallows every declaration after
	 * it), dangling escapes (a trailing `\` eats the emitted `;` terminator),
	 * and unbalanced parentheses outside strings.
	 *
	 * Mirrored byte-for-byte by `passesSafetyCheck` in
	 * src/design-tokens/utils.js — change both together.
	 *
	 * @param string $value Value to check.
	 */
	private static function passes_safety_check( string $value ): bool {
		if ( preg_match( '/[<>{};\n\r\f]|\/\*|\*\//', $value ) ) {
			return false;
		}

		$length = strlen( $value );
		$quote  = '';
		$depth  = 0;

		for ( $i = 0; $i < $length; $i++ ) {
			$ch = $value[ $i ];

			if ( '\\' === $ch ) {
				if ( $i === $length - 1 ) {
					return false;
				}

				++$i;
				continue;
			}

			if ( '' !== $quote ) {
				if ( $ch === $quote ) {
					$quote = '';
				}

				continue;
			}

			if ( '"' === $ch || "'" === $ch ) {
				$quote = $ch;
				continue;
			}

			if ( '(' === $ch ) {
				++$depth;
			} elseif ( ')' === $ch ) {
				--$depth;

				if ( $depth < 0 ) {
					return false;
				}
			}
		}

		return '' === $quote && 0 === $depth;
	}

	/**
	 * CSS-function names accepted as passthroughs in the color validator.
	 */
	private static function color_functions(): array {
		return [ 'rgb', 'rgba', 'hsl', 'hsla', 'hwb', 'lab', 'lch', 'oklab', 'oklch', 'color', 'color-mix', 'light-dark', 'var', 'env' ];
	}

	/**
	 * CSS-function names accepted as passthroughs in the length validator.
	 */
	private static function length_functions(): array {
		return [ 'calc', 'min', 'max', 'clamp', 'var', 'env', 'minmax', 'fit-content' ];
	}

	/**
	 * Whether `$value` begins with one of the allowed CSS function names.
	 *
	 * Per CSS syntax a function token is the name IMMEDIATELY followed by
	 * `(` — `calc (…)` is an ident plus a parens block and invalid where a
	 * length is expected, so no whitespace is tolerated. The JS validator
	 * matches the same rule.
	 *
	 * @param string $value     Value to inspect.
	 * @param array  $functions Allowed function names (no parens).
	 */
	private static function starts_with_function( string $value, array $functions ): bool {
		$lower = strtolower( $value );

		foreach ( $functions as $fn ) {
			if ( 0 === strpos( $lower, $fn . '(' ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * CSS-wide keywords accepted by both color and length validators.
	 */
	private static function css_wide_keywords(): array {
		return [ 'inherit', 'initial', 'unset', 'revert', 'revert-layer' ];
	}

	/**
	 * Named CSS colors (CSS Color Module Level 4) plus `transparent` and
	 * `currentcolor`.
	 */
	private static function named_colors(): array {
		static $names = null;

		if ( null !== $names ) {
			return $names;
		}

		$names = [
			'aliceblue',
			'antiquewhite',
			'aqua',
			'aquamarine',
			'azure',
			'beige',
			'bisque',
			'black',
			'blanchedalmond',
			'blue',
			'blueviolet',
			'brown',
			'burlywood',
			'cadetblue',
			'chartreuse',
			'chocolate',
			'coral',
			'cornflowerblue',
			'cornsilk',
			'crimson',
			'cyan',
			'darkblue',
			'darkcyan',
			'darkgoldenrod',
			'darkgray',
			'darkgreen',
			'darkgrey',
			'darkkhaki',
			'darkmagenta',
			'darkolivegreen',
			'darkorange',
			'darkorchid',
			'darkred',
			'darksalmon',
			'darkseagreen',
			'darkslateblue',
			'darkslategray',
			'darkslategrey',
			'darkturquoise',
			'darkviolet',
			'deeppink',
			'deepskyblue',
			'dimgray',
			'dimgrey',
			'dodgerblue',
			'firebrick',
			'floralwhite',
			'forestgreen',
			'fuchsia',
			'gainsboro',
			'ghostwhite',
			'gold',
			'goldenrod',
			'gray',
			'green',
			'greenyellow',
			'grey',
			'honeydew',
			'hotpink',
			'indianred',
			'indigo',
			'ivory',
			'khaki',
			'lavender',
			'lavenderblush',
			'lawngreen',
			'lemonchiffon',
			'lightblue',
			'lightcoral',
			'lightcyan',
			'lightgoldenrodyellow',
			'lightgray',
			'lightgreen',
			'lightgrey',
			'lightpink',
			'lightsalmon',
			'lightseagreen',
			'lightskyblue',
			'lightslategray',
			'lightslategrey',
			'lightsteelblue',
			'lightyellow',
			'lime',
			'limegreen',
			'linen',
			'magenta',
			'maroon',
			'mediumaquamarine',
			'mediumblue',
			'mediumorchid',
			'mediumpurple',
			'mediumseagreen',
			'mediumslateblue',
			'mediumspringgreen',
			'mediumturquoise',
			'mediumvioletred',
			'midnightblue',
			'mintcream',
			'mistyrose',
			'moccasin',
			'navajowhite',
			'navy',
			'oldlace',
			'olive',
			'olivedrab',
			'orange',
			'orangered',
			'orchid',
			'palegoldenrod',
			'palegreen',
			'paleturquoise',
			'palevioletred',
			'papayawhip',
			'peachpuff',
			'peru',
			'pink',
			'plum',
			'powderblue',
			'purple',
			'rebeccapurple',
			'red',
			'rosybrown',
			'royalblue',
			'saddlebrown',
			'salmon',
			'sandybrown',
			'seagreen',
			'seashell',
			'sienna',
			'silver',
			'skyblue',
			'slateblue',
			'slategray',
			'slategrey',
			'snow',
			'springgreen',
			'steelblue',
			'tan',
			'teal',
			'thistle',
			'tomato',
			'turquoise',
			'violet',
			'wheat',
			'white',
			'whitesmoke',
			'yellow',
			'yellowgreen',
			'transparent',
			'currentcolor',
		];

		return $names;
	}
}

GenerateBlocks_Pro_Design_Tokens::get_instance()->init();
