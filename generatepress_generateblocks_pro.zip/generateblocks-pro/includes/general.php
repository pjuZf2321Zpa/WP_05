<?php
/**
 * General actions and filters.
 *
 * @package GenerateBlocks
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_filter( 'admin_body_class', 'generateblocks_pro_set_design_system_body_class', 20 );
/**
 * Mark migrated admin screens before the first paint.
 *
 * GbAdminPage repeats this class in JavaScript as a defensive fallback. The
 * server-side class prevents the legacy GenerateBlocks header from flashing
 * before React mounts.
 *
 * @param string $classes Existing admin body classes.
 * @return string Admin body classes.
 */
function generateblocks_pro_set_design_system_body_class( $classes ) {
	$current_screen = get_current_screen();
	$migrated_screens = array(
		'generateblocks_page_generateblocks-asset-library',
		'generateblocks_page_generateblocks-conditions',
		'generateblocks_page_generateblocks-editor-access',
		'generateblocks_page_generateblocks-forms',
		'generateblocks_page_generateblocks-overlay-panels',
	);

	if ( $current_screen && in_array( $current_screen->id, $migrated_screens, true ) ) {
		$classes .= ' gb-admin-page-active';
	}

	return $classes;
}

/**
 * Get an array of string handles for the package styles.
 *
 * @return array An array of string handles.
 */
function generateblocks_pro_get_package_style_deps() {
	return [ 'generateblocks-pro-packages', 'generateblocks-pro-admin-ui' ];
}

add_action( 'admin_enqueue_scripts', 'generateblocks_pro_packages_scripts', 1 );
/**
 * Register package stylesheets.
 * Update generateblocks_pro_get_package_style_deps above when adding new styles.
 */
function generateblocks_pro_packages_scripts() {
	$component_asset_info = generateblocks_pro_get_enqueue_assets( 'packages' );
	$gp_tokens_css        = GENERATEBLOCKS_PRO_DIR . 'dist/gp-tokens.css';

	wp_register_style(
		'generateblocks-pro-gp-tokens',
		GENERATEBLOCKS_PRO_DIR_URL . 'dist/gp-tokens.css',
		[],
		file_exists( $gp_tokens_css ) ? filemtime( $gp_tokens_css ) : GENERATEBLOCKS_PRO_VERSION
	);

	$admin_ui_css = GENERATEBLOCKS_PRO_DIR . 'dist/admin-ui.css';

	wp_register_style(
		'generateblocks-pro-admin-ui',
		GENERATEBLOCKS_PRO_DIR_URL . 'dist/admin-ui.css',
		[ 'wp-components' ],
		file_exists( $admin_ui_css ) ? filemtime( $admin_ui_css ) : GENERATEBLOCKS_PRO_VERSION
	);

	wp_enqueue_style(
		'generateblocks-pro-packages',
		GENERATEBLOCKS_PRO_DIR_URL . 'dist/packages.css',
		'',
		$component_asset_info['version']
	);

	$edge22_packages = [
		'block-styles',
		'components',
		'styles-builder',
	];

	foreach ( $edge22_packages as $name ) {
		$package_asset_info = generateblocks_pro_get_enqueue_assets( "{$name}-imported" );
		$script_asset_info = generateblocks_pro_get_enqueue_assets( $name );

		$registered = wp_register_script(
			"generateblocks-pro-$name",
			GENERATEBLOCKS_PRO_DIR_URL . 'dist/' . $name . '.js',
			$package_asset_info['dependencies'],
			$script_asset_info['version'],
			true
		);

		// The package builds its at-rule list once as it loads, so the presets
		// have to be printed right before it.
		if ( $registered && 'styles-builder' === $name ) {
			$at_rules = wp_json_encode( generateblocks_pro_get_default_at_rules(), JSON_HEX_TAG | JSON_HEX_AMP );

			if ( $at_rules ) {
				wp_add_inline_script(
					"generateblocks-pro-$name",
					'window.generateBlocksDefaultAtRules = ' . $at_rules . ';',
					'before'
				);
			}
		}

		wp_register_style(
			"generateblocks-pro-$name",
			false,
			[ 'generateblocks-pro-packages' ],
			$component_asset_info['version']
		);
	}

	$dashboard_table_css = GENERATEBLOCKS_PRO_DIR . 'dist/dashboard-table.css';

	wp_register_style(
		'generateblocks-pro-dashboard-table',
		GENERATEBLOCKS_PRO_DIR_URL . 'dist/dashboard-table.css',
		[ 'wp-components', 'generateblocks-pro-gp-tokens' ],
		file_exists( $dashboard_table_css ) ? filemtime( $dashboard_table_css ) : GENERATEBLOCKS_PRO_VERSION
	);
}

/**
 * Whether the current user can import a Design System through the public
 * browser API.
 *
 * @return bool
 */
function generateblocks_pro_design_system_import_available() {
	if (
		! class_exists( 'GenerateBlocks_Pro_Styles' )
		|| ! class_exists( 'GenerateBlocks_Pro_Design_Tokens' )
		|| ! is_callable( array( 'GenerateBlocks_Pro_Styles', 'can_manage_styles' ) )
		|| ! is_callable( array( 'GenerateBlocks_Pro_Design_Tokens', 'can_manage_tokens' ) )
	) {
		return false;
	}

	try {
		return GenerateBlocks_Pro_Styles::can_manage_styles()
			&& GenerateBlocks_Pro_Design_Tokens::can_manage_tokens();
	} catch ( Throwable $error ) {
		return false;
	}
}

/**
 * Enqueue the public Design System import API for an authorized admin surface.
 *
 * A consumer owns its own screen and decides when to call this function. GBP
 * owns only artifact validation and persistence; it has no knowledge of the
 * workflow requesting the import.
 *
 * @return bool Whether the API was enqueued.
 */
function generateblocks_pro_enqueue_design_system_import() {
	if ( ! generateblocks_pro_design_system_import_available() ) {
		return false;
	}

	$assets = generateblocks_pro_get_enqueue_assets( 'design-system-import' );

	wp_enqueue_script(
		'generateblocks-pro-design-system-import',
		GENERATEBLOCKS_PRO_DIR_URL . 'dist/design-system-import.js',
		$assets['dependencies'],
		$assets['version'],
		true
	);

	wp_set_script_translations(
		'generateblocks-pro-design-system-import',
		'generateblocks-pro',
		GENERATEBLOCKS_PRO_DIR . 'languages'
	);

	return true;
}

add_action( 'admin_enqueue_scripts', 'generateblocks_pro_enqueue_dashboard_table_styles', 20 );
/**
 * Enqueue the retained dashboard table styles only on GenerateCloud's screen.
 */
function generateblocks_pro_enqueue_dashboard_table_styles() {
	$current_screen = get_current_screen();

	if ( ! $current_screen ) {
		return;
	}

	if ( 'generateblocks_page_generateblocks-public-keys' === $current_screen->id ) {
		wp_enqueue_style( 'generateblocks-pro-dashboard-table' );
	}
}

add_action( 'enqueue_block_editor_assets', 'generateblocks_pro_do_block_editor_assets', 9 );
/**
 * Enqueue Gutenberg block assets for both frontend + backend.
 *
 * Assets enqueued:
 * 1. blocks.style.build.css - Frontend + Backend.
 * 2. blocks.build.js - Backend.
 * 3. blocks.editor.build.css - Backend.
 *
 * @uses {wp-blocks} for block type registration & related functions.
 * @uses {wp-element} for WP Element abstraction — structure of blocks.
 * @uses {wp-i18n} to internationalize the block's text.
 * @uses {wp-editor} for WP editor styles.
 * @since 1.0.0
 */
function generateblocks_pro_do_block_editor_assets() {
	global $pagenow;

	$deps = array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor', 'wp-html-entities' );

	if ( 'widgets.php' === $pagenow ) {
		unset( $deps[3] );
	}

	$assets = generateblocks_pro_get_enqueue_assets(
		'blocks',
		[
			'dependencies' => $deps,
			'version' => filemtime( GENERATEBLOCKS_PRO_DIR . 'dist/blocks.js' ),
		]
	);

	wp_enqueue_script(
		'generateblocks-pro',
		GENERATEBLOCKS_PRO_DIR_URL . 'dist/blocks.js',
		$assets['dependencies'],
		$assets['version'],
		true
	);

	wp_set_script_translations( 'generateblocks-pro', 'generateblocks-pro', GENERATEBLOCKS_PRO_DIR . 'languages' );

	$admin_settings = wp_parse_args(
		get_option( 'generateblocks_admin', array() ),
		generateblocks_pro_get_admin_option_defaults()
	);
	$screen         = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	$post_type      = $screen && ! empty( $screen->post_type ) ? $screen->post_type : get_post_type();

	wp_localize_script(
		'generateblocks-pro',
		'generateBlocksPro',
		array(
			'templatesURL' => admin_url( 'edit.php?post_type=gblocks_templates' ),
			'svgIcons' => generateblocks_pro_editor_icon_list(),
			'isGlobalStyle' => 'gblocks_global_style' === get_post_type(),
			'globalStyleIds' => generateblocks_pro_get_global_style_ids(),
			'globalStyleAttrs' => generateblocks_pro_get_global_style_attrs(),
			'hasRgbaSupport' => version_compare( GENERATEBLOCKS_VERSION, '1.4.0-alpha.1', '>=' ),
			'hasColorGroups' => version_compare( GENERATEBLOCKS_VERSION, '1.5.0-alpha.1', '>=' ),
			'enableRemoteTemplates' => $admin_settings['enable_remote_templates'],
			'enableLocalTemplates' => $admin_settings['enable_local_templates'],
			'isACFActive' => class_exists( 'ACF' ),
			'generateblocksVersion' => GENERATEBLOCKS_VERSION,
			'generateblocksProVersion' => GENERATEBLOCKS_PRO_VERSION,
			'blockStyles' => function_exists( 'generateblocks_get_default_styles' ) ? generateblocks_get_default_styles() : array(),
			'showIncompatibleGlobalStyles' => apply_filters( 'generateblocks_show_incompatible_global_styles', false ),
			'useLegacyPatternLibrary' => generateblocks_pro_has_legacy_patterns(),
			'adminUrl' => admin_url(),
			'canManageStyles' => GenerateBlocks_Pro_Styles::can_manage_styles(),
			'canManageDesignTokens' => class_exists( 'GenerateBlocks_Pro_Design_Tokens' )
				&& GenerateBlocks_Pro_Design_Tokens::can_manage_tokens(),
			'rootStylePostId' => class_exists( 'GenerateBlocks_Pro_Styles_Root' )
				? GenerateBlocks_Pro_Styles_Root::get_resolved_post_id()
				: 0,
			'canManageForms' => class_exists( 'GenerateBlocks_Pro_Form_Post_Type' )
				&& GenerateBlocks_Pro_Form_Post_Type::current_user_can( 'manage' ),
			'canUseForms' => class_exists( 'GenerateBlocks_Pro_Form_Post_Type' )
				&& GenerateBlocks_Pro_Form_Post_Type::current_user_can( 'use' ),
			'canImportPatternForms' => generateblocks_pro_can_import_pattern_forms(),
			'hasFormsEnabled' => generateblocks_pro_forms_enabled(),
			'formControlHtmlAttributes' => class_exists( 'GenerateBlocks_Block_Form_Field_Control' )
				? GenerateBlocks_Block_Form_Field_Control::get_allowed_html_attribute_names()
				: array(),
			'currentPostType' => $post_type ? (string) $post_type : '',
			'mediaQueries' => function_exists( 'generateblocks_get_media_queries' )
				? generateblocks_get_media_queries()
				: [],
		)
	);

	generateblocks_pro_packages_scripts();

	wp_enqueue_style(
		'generateblocks-pro',
		GENERATEBLOCKS_PRO_DIR_URL . 'dist/blocks.css',
		array_merge( [ 'wp-edit-blocks' ], generateblocks_pro_get_package_style_deps() ),
		filemtime( GENERATEBLOCKS_PRO_DIR . 'dist/blocks.css' )
	);

	$editor_assets = generateblocks_pro_get_enqueue_assets( 'editor' );

	wp_enqueue_script(
		'generateblocks-pro-editor',
		GENERATEBLOCKS_PRO_DIR_URL . 'dist/editor.js',
		$editor_assets['dependencies'],
		$editor_assets['version'],
		true
	);

	wp_enqueue_style(
		'generateblocks-pro-editor',
		GENERATEBLOCKS_PRO_DIR_URL . 'dist/editor.css',
		array_merge( [ 'wp-edit-blocks' ], generateblocks_pro_get_package_style_deps() ),
		filemtime( GENERATEBLOCKS_PRO_DIR . 'dist/editor.css' )
	);

	wp_localize_script(
		'generateblocks-pro-editor',
		'generateblocksProEditor',
		[
			'hasOverlaysEnabled' => generateblocks_pro_overlays_enabled(),
		]
	);

	wp_localize_script(
		'generateblocks-pro-classic-menu-editor-script',
		'generateblocksBlockClassicMenu',
		[
			'hasMenuSupport' => get_theme_support( 'menus' ),
			'menuAdminUrl' => admin_url( 'nav-menus.php' ),
			'navMenus' => wp_get_nav_menus(),
		]
	);
}

add_filter( 'generateblocks_attr_container', 'generateblocks_pro_set_container_attributes', 10, 2 );
/**
 * Set the attributes for our main Container wrapper.
 *
 * @since 1.0.0
 * @param array $attributes The existing attributes.
 * @param array $settings The settings for the block.
 */
function generateblocks_pro_set_container_attributes( $attributes, $settings ) {
	if ( '' !== $settings['url'] && 'wrapper' === $settings['linkType'] ) {
		$attributes['href'] = esc_url( $settings['url'] );

		$rel_attributes = array();

		if ( $settings['relNoFollow'] ) {
			$rel_attributes[] = 'nofollow';
		}

		if ( $settings['target'] ) {
			$rel_attributes[] = 'noopener';
			$rel_attributes[] = 'noreferrer';
			$attributes['target'] = '_blank';
		}

		if ( $settings['relSponsored'] ) {
			$rel_attributes[] = 'sponsored';
		}

		if ( ! empty( $rel_attributes ) ) {
			$attributes['rel'] = implode( ' ', $rel_attributes );
		}

		if ( $settings['hiddenLinkAriaLabel'] ) {
			$attributes['aria-label'] = esc_attr( $settings['hiddenLinkAriaLabel'] );
		}
	}

	$attributes = generateblocks_pro_with_custom_attributes( $attributes, $settings );

	if ( ! empty( $settings['useGlobalStyle'] ) && ! empty( $settings['globalStyleId'] ) ) {
		$attributes['class'] .= ' gb-container-' . esc_attr( $settings['globalStyleId'] );
	}

	return $attributes;
}

add_filter( 'generateblocks_attr_grid-item', 'generateblocks_pro_set_grid_container_attributes', 10, 2 );
/**
 * Set the attributes for our grid item wrapper.
 *
 * @since 1.1.0
 * @param array $attributes The existing attributes.
 * @param array $settings The settings for the block.
 */
function generateblocks_pro_set_grid_container_attributes( $attributes, $settings ) {
	if ( ! empty( $settings['useGlobalStyle'] ) && ! empty( $settings['globalStyleId'] ) ) {
		$attributes['class'] .= ' gb-grid-column-' . esc_attr( $settings['globalStyleId'] );
	}

	return $attributes;
}

add_filter( 'generateblocks_attr_grid-wrapper', 'generateblocks_pro_set_grid_attributes', 10, 2 );
/**
 * Set the attributes for our grid wrapper.
 *
 * @since 1.0.0
 * @param array $attributes The existing attributes.
 * @param array $settings The settings for the block.
 */
function generateblocks_pro_set_grid_attributes( $attributes, $settings ) {
	if ( ! empty( $settings['useGlobalStyle'] ) && ! empty( $settings['globalStyleId'] ) ) {
		$attributes['class'] .= ' gb-grid-wrapper-' . esc_attr( $settings['globalStyleId'] );
	}

	$attributes = generateblocks_pro_with_custom_attributes( $attributes, $settings );

	return $attributes;
}

add_filter( 'generateblocks_attr_button-container', 'generateblocks_pro_set_button_container_attributes', 10, 2 );
/**
 * Set the attributes for our grid wrapper.
 *
 * @since 1.0.0
 * @param array $attributes The existing attributes.
 * @param array $settings The settings for the block.
 */
function generateblocks_pro_set_button_container_attributes( $attributes, $settings ) {
	if ( ! empty( $settings['useGlobalStyle'] ) && ! empty( $settings['globalStyleId'] ) ) {
		$attributes['class'] .= ' gb-button-wrapper-' . esc_attr( $settings['globalStyleId'] );
	}

	$attributes = generateblocks_pro_with_custom_attributes( $attributes, $settings );

	return $attributes;
}

add_filter( 'generateblocks_attr_image', 'generateblocks_pro_set_image_attributes', 10, 2 );
/**
 * Set the attributes for our dynamic image block.
 *
 * @since 1.2.0
 * @param array $attributes The existing attributes.
 * @param array $settings The settings for the block.
 */
function generateblocks_pro_set_image_attributes( $attributes, $settings ) {
	if ( ! empty( $settings['useGlobalStyle'] ) && ! empty( $settings['globalStyleId'] ) ) {
		$attributes['class'] .= ' gb-image-' . esc_attr( $settings['globalStyleId'] );
	}

	$attributes = generateblocks_pro_with_custom_attributes( $attributes, $settings );

	return $attributes;
}

add_filter( 'generateblocks_attr_dynamic-headline', 'generateblocks_pro_set_headline_attributes', 10, 2 );
/**
 * Set the attributes for our dynamic headlines.
 *
 * @since 1.2.0
 * @param array $attributes The existing attributes.
 * @param array $settings The settings for the block.
 */
function generateblocks_pro_set_headline_attributes( $attributes, $settings ) {
	if ( ! empty( $settings['useGlobalStyle'] ) && ! empty( $settings['globalStyleId'] ) ) {
		$attributes['class'] .= ' gb-headline-' . esc_attr( $settings['globalStyleId'] );
	}

	$attributes = generateblocks_pro_with_custom_attributes( $attributes, $settings );

	return $attributes;
}

add_filter( 'generateblocks_attr_dynamic-button', 'generateblocks_pro_set_button_attributes', 10, 2 );
/**
 * Set the attributes for our dynamic buttons.
 *
 * @since 1.2.0
 * @param array $attributes The existing attributes.
 * @param array $settings The settings for the block.
 */
function generateblocks_pro_set_button_attributes( $attributes, $settings ) {
	if ( ! empty( $settings['useGlobalStyle'] ) && ! empty( $settings['globalStyleId'] ) ) {
		$attributes['class'] .= ' gb-button-' . esc_attr( $settings['globalStyleId'] );
	}

	$attributes = generateblocks_pro_with_custom_attributes( $attributes, $settings );

	return $attributes;
}

add_filter( 'generateblocks_after_container_open', 'generateblocks_pro_add_container_link', 10, 2 );
/**
 * Add a hidden container link to the Container.
 *
 * @since 1.0.0
 * @param string $output Block output.
 * @param array  $attributes The block attributes.
 */
function generateblocks_pro_add_container_link( $output, $attributes ) {
	$defaults = generateblocks_get_block_defaults();

	$settings = wp_parse_args(
		$attributes,
		$defaults['container']
	);

	if ( '' !== $settings['url'] && 'hidden-link' === $settings['linkType'] ) {
		$rel_attributes = array();

		if ( $settings['relNoFollow'] ) {
			$rel_attributes[] = 'nofollow';
		}

		if ( $settings['relSponsored'] ) {
			$rel_attributes[] = 'sponsored';
		}

		if ( ! empty( $rel_attributes ) ) {
			$attributes['rel'] = implode( ' ', $rel_attributes );
		}

		if ( $settings['target'] ) {
			$rel_attributes[] = 'noopener';
			$rel_attributes[] = 'noreferrer';
		}

		$output .= sprintf(
			'<a %s></a>',
			generateblocks_attr(
				'container-link',
				array(
					'class' => 'gb-container-link',
					'href' => '' !== $settings['url'] ? esc_url( $settings['url'] ) : '',
					'aria-label' => $settings['hiddenLinkAriaLabel'] ? esc_attr( $settings['hiddenLinkAriaLabel'] ) : '',
					'rel' => ! empty( $rel_attributes ) ? implode( ' ', $rel_attributes ) : '',
					'target' => $settings['target'] ? '_blank' : '',
				),
				$settings
			)
		);
	}

	return $output;
}

add_filter( 'generateblocks_svg_shapes', 'generateblocks_pro_add_custom_svg_shapes' );
/**
 * Add custom SVG shapes from our library.
 *
 * @since 1.0.0
 * @param array $shapes Existing shapes.
 */
function generateblocks_pro_add_custom_svg_shapes( $shapes ) {
	$custom_shapes = get_option( 'generateblocks_svg_shapes', array() );
	$new_shapes = array();

	if ( ! empty( $custom_shapes ) ) {
		// Format our custom shapes to fit our shapes structure.
		foreach ( $custom_shapes as $index => $data ) {
			$new_shapes[ esc_attr( $data['group_id'] ) ] = array(
				'group' => esc_html( $data['group'] ),
				'svgs' => array(),
			);

			if ( isset( $data['shapes'] ) ) {
				foreach ( (array) $data['shapes'] as $shape_index => $shape ) {
					$new_shapes[ esc_attr( $data['group_id'] ) ]['svgs'][ $shape['id'] ] = array(
						'label' => $shape['name'],
						'icon' => $shape['shape'],
					);
				}
			}
		}
	}

	$shapes = array_merge( $new_shapes, $shapes );

	return $shapes;
}

add_filter( 'generateblocks_container_tagname', 'generateblocks_pro_set_container_tagname', 10, 2 );
/**
 * Set the Container block tag name.
 *
 * @since 1.0.0
 *
 * @param string $tagname Current tag name.
 * @param array  $attributes Current attributes.
 */
function generateblocks_pro_set_container_tagname( $tagname, $attributes ) {
	$defaults = generateblocks_get_block_defaults();

	$settings = wp_parse_args(
		$attributes,
		$defaults['container']
	);

	if ( ! empty( $settings['url'] ) && 'wrapper' === $settings['linkType'] ) {
		$tagname = 'a';
	}

	return $tagname;
}

add_filter( 'register_block_type_args', 'generateblocks_pro_filter_block_type_args', 10, 2 );
/**
 * Filter our register_block_type() args.
 *
 * @param array  $args Existing args.
 * @param string $name The block name.
 */
function generateblocks_pro_filter_block_type_args( $args, $name ) {
	if ( 'generateblocks/container' === $name ) {
		if ( ! empty( $args['editor_script_handles'] ) ) {
			$args['editor_script_handles'] = array_merge( $args['editor_script_handles'], [ 'generateblocks-pro' ] );
			$args['editor_style_handles'] = array_merge( $args['editor_style_handles'], [ 'generateblocks-pro' ] );
		}
	}

	return $args;
}

add_filter( 'generateblocks_modify_block_data', 'generateblocks_pro_add_block_data', 10, 2 );
/**
 * Add our blocks to the dataset.
 *
 * @param array $data The block data.
 * @param array $block The block.
 */
function generateblocks_pro_add_block_data( $data, $block ) {
	$block_name = $block['blockName'] ?? '';

	if ( ! $block_name ) {
		return $data;
	}

	if ( 'generateblocks-pro/accordion' === $block_name ) {
		$data['accordion'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/accordion-item' === $block_name ) {
		$data['accordion-item'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/accordion-toggle' === $block_name ) {
		$data['accordion-toggle'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/accordion-toggle-icon' === $block_name ) {
		$data['accordion-toggle-icon'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/tabs' === $block_name ) {
		$data['tabs'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/tabs-menu' === $block_name ) {
		$data['tabs-menu'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/tab-menu-item' === $block_name ) {
		$data['tab-menu-item'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/tab-items' === $block_name ) {
		$data['tab-items'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/tab-item' === $block_name ) {
		$data['tab-item'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/navigation' === $block_name ) {
		$data['navigation'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/classic-menu' === $block_name ) {
		$data['classic-menu'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/classic-menu-item' === $block_name ) {
		$data['classic-menu-item'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/classic-sub-menu' === $block_name ) {
		$data['classic-sub-menu'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/menu-container' === $block_name ) {
		$data['menu-container'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/menu-toggle' === $block_name ) {
		$data['menu-toggle'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/site-header' === $block_name ) {
		$data['site-header'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/carousel' === $block_name ) {
		$data['carousel'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/carousel-items' === $block_name ) {
		$data['carousel-items'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/carousel-item' === $block_name ) {
		$data['carousel-item'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/carousel-pagination' === $block_name ) {
		$data['carousel-pagination'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/carousel-control' === $block_name ) {
		$data['carousel-control'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/form' === $block_name && generateblocks_pro_forms_enabled() ) {
		$data['form'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/form-field' === $block_name && generateblocks_pro_forms_enabled() ) {
		$data['form-field'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/form-field-label' === $block_name && generateblocks_pro_forms_enabled() ) {
		$data['form-field-label'][] = $block['attrs'] ?? [];
	}

	if ( 'generateblocks-pro/form-field-control' === $block_name && generateblocks_pro_forms_enabled() ) {
		$data['form-field-control'][] = $block['attrs'] ?? [];
	}

	// Follow a form-render reference into the referenced gblocks_form post so
	// CSS pre-generation on the host page picks up the form field blocks that
	// live inside. Mirrors the core/block (reusable block) recursion in
	// generateblocks_get_block_data(). Tracks processed form IDs to avoid
	// re-parsing the same form twice on a page with multiple references.
	if (
		'generateblocks-pro/form-render' === $block_name
		&& generateblocks_pro_forms_enabled()
		&& function_exists( 'generateblocks_get_block_data' )
		&& class_exists( 'GenerateBlocks_Pro_Form_Post_Type' )
	) {
		$form_id = isset( $block['attrs']['formId'] ) ? absint( $block['attrs']['formId'] ) : 0;

		if ( $form_id && ( empty( $data['formIds'] ) || ! in_array( $form_id, (array) $data['formIds'], true ) ) ) {
			$form = get_post( $form_id );

			if (
				$form
				&& GenerateBlocks_Pro_Form_Post_Type::POST_TYPE === $form->post_type
				&& 'publish' === $form->post_status
			) {
				$form_blocks = parse_blocks( $form->post_content );

				if ( ! empty( $form_blocks ) ) {
					$data['formIds'][] = $form_id;
					$data               = generateblocks_get_block_data( $form_blocks, $data );
				}
			}
		}
	}

	return $data;
}

add_filter( 'generateblocks_dynamic_css_blocks', 'generateblocks_pro_add_dynamic_css_blocks' );
/**
 * Add our dynamic CSS blocks.
 *
 * @param array $blocks Existing blocks.
 */
function generateblocks_pro_add_dynamic_css_blocks( $blocks ) {
	$blocks['accordion']             = 'GenerateBlocks_Block_Accordion';
	$blocks['accordion-item']        = 'GenerateBlocks_Block_Accordion_Item';
	$blocks['accordion-toggle']      = 'GenerateBlocks_Block_Accordion_Toggle';
	$blocks['accordion-toggle-icon'] = 'GenerateBlocks_Block_Accordion_Toggle_Icon';
	$blocks['tabs']                  = 'GenerateBlocks_Block_Tabs';
	$blocks['tabs-menu']             = 'GenerateBlocks_Block_Tabs_Menu';
	$blocks['tab-menu-item']         = 'GenerateBlocks_Block_Tab_Menu_Item';
	$blocks['tab-items']             = 'GenerateBlocks_Block_Tab_Items';
	$blocks['tab-item']              = 'GenerateBlocks_Block_Tab_Item';
	$blocks['navigation']            = 'GenerateBlocks_Block_Navigation';
	$blocks['classic-menu']          = 'GenerateBlocks_Block_Classic_Menu';
	$blocks['classic-menu-item']     = 'GenerateBlocks_Block_Classic_Menu_Item';
	$blocks['classic-sub-menu']      = 'GenerateBlocks_Block_Classic_Sub_Menu';
	$blocks['menu-container']        = 'GenerateBlocks_Block_Menu_Container';
	$blocks['menu-toggle']           = 'GenerateBlocks_Block_Menu_Toggle';
	$blocks['site-header']           = 'GenerateBlocks_Block_Site_Header';
	$blocks['carousel']             = 'GenerateBlocks_Block_Carousel';
	$blocks['carousel-items']       = 'GenerateBlocks_Block_Carousel_Items';
	$blocks['carousel-item']        = 'GenerateBlocks_Block_Carousel_Item';
	$blocks['carousel-pagination']  = 'GenerateBlocks_Block_Carousel_Pagination';
	$blocks['carousel-control']     = 'GenerateBlocks_Block_Carousel_Control';

	if ( generateblocks_pro_forms_enabled() ) {
		$blocks['form']               = 'GenerateBlocks_Block_Form';
		$blocks['form-field']         = 'GenerateBlocks_Block_Form_Field';
		$blocks['form-field-label']   = 'GenerateBlocks_Block_Form_Field_Label';
		$blocks['form-field-control'] = 'GenerateBlocks_Block_Form_Field_Control';
	}

	return $blocks;
}

add_filter( 'generateblocks_dynamic_tags_allowed_blocks', 'generateblocks_pro_add_dynamic_tags_allowed_blocks' );
/**
 * Add our dynamic tags allowed blocks.
 *
 * @param array $blocks Existing blocks.
 */
function generateblocks_pro_add_dynamic_tags_allowed_blocks( $blocks ) {
	$pro_blocks = [
		'generateblocks-pro/accordion',
		'generateblocks-pro/accordion-content',
		'generateblocks-pro/accordion-item',
		'generateblocks-pro/accordion-toggle',
		'generateblocks-pro/accordion-toggle-icon',
		'generateblocks-pro/tabs',
		'generateblocks-pro/tabs-menu',
		'generateblocks-pro/tab-menu-item',
		'generateblocks-pro/tab-items',
		'generateblocks-pro/tab-item',
	];

	return array_merge( $blocks, $pro_blocks );
}

add_action( 'enqueue_block_editor_assets', 'generateblocks_pro_set_global_styles_permission', 0 );
add_action( 'admin_enqueue_scripts', 'generateblocks_pro_set_global_styles_permission', 0 );
/**
 * Output permissions for use in the editor.
 *
 * @return void
 */
function generateblocks_pro_set_global_styles_permission() {
	if ( 'admin_enqueue_scripts' === current_filter() ) {
		$screen = get_current_screen();

		$allowed_screens = [
			GenerateBlocks_Pro_Style_Book::SCREEN_ID,
		];

		if ( ! $screen || ! in_array( $screen->id, $allowed_screens, true ) ) {
			return;
		}
	}

	$permissions = [
		'canManageStyles' => GenerateBlocks_Pro_Styles::can_manage_styles(),
	];

	$permission_object = wp_json_encode( $permissions );
	wp_register_script( 'generateblocks-global-styles-permissions', '', [], '1.0', false );
	wp_enqueue_script( 'generateblocks-global-styles-permissions' );
	$script = sprintf(
		'var gbGlobalStylePermissions = %s;
		Object.freeze( gbGlobalStylePermissions );',
		$permission_object
	);
	wp_add_inline_script( 'generateblocks-global-styles-permissions', $script );
}

add_action( 'enqueue_block_editor_assets', 'generateblocks_pro_set_conditions_permission', 0 );
add_action( 'admin_enqueue_scripts', 'generateblocks_pro_set_conditions_permission', 0 );
/**
 * Output conditions permissions for use in the editor.
 *
 * @since 2.4.0
 * @return void
 */
function generateblocks_pro_set_conditions_permission() {
	if ( 'admin_enqueue_scripts' === current_filter() ) {
		$screen = get_current_screen();

		// Load on conditions dashboard and post editor screens.
		if ( ! $screen || ( 'generateblocks_page_generateblocks-conditions' !== $screen->id && 'post' !== $screen->base ) ) {
			return;
		}
	}

	$permissions = [
		'canUseConditions' => GenerateBlocks_Pro_Conditions::current_user_can_use_conditions( 'use' ),
		'canManageConditions' => GenerateBlocks_Pro_Conditions::current_user_can_use_conditions( 'manage' ),
	];

	$permission_object = wp_json_encode( $permissions );
	wp_register_script( 'generateblocks-conditions-permissions', '', [], '1.0', false );
	wp_enqueue_script( 'generateblocks-conditions-permissions' );
	$script = sprintf(
		'var gbConditionsPermissions = %s;
		Object.freeze( gbConditionsPermissions );',
		$permission_object
	);
	wp_add_inline_script( 'generateblocks-conditions-permissions', $script );
}

add_action( 'enqueue_block_editor_assets', 'generateblocks_pro_set_overlays_permission', 0 );
add_action( 'admin_enqueue_scripts', 'generateblocks_pro_set_overlays_permission', 0 );
/**
 * Output overlays permissions for use in the editor.
 *
 * @since 2.4.0
 * @return void
 */
function generateblocks_pro_set_overlays_permission() {
	if ( 'admin_enqueue_scripts' === current_filter() ) {
		$screen = get_current_screen();

		// Load on overlays dashboard and post editor screens.
		if ( ! $screen || ( 'generateblocks_page_generateblocks-overlay-panels' !== $screen->id && 'post' !== $screen->base ) ) {
			return;
		}
	}

	$permissions = [
		'canUseOverlays' => GenerateBlocks_Pro_Overlays::current_user_can_use_overlays( 'use' ),
		'canManageOverlays' => GenerateBlocks_Pro_Overlays::current_user_can_use_overlays( 'manage' ),
	];

	$permission_object = wp_json_encode( $permissions );
	wp_register_script( 'generateblocks-overlays-permissions', '', [], '1.0', false );
	wp_enqueue_script( 'generateblocks-overlays-permissions' );
	$script = sprintf(
		'var gbOverlaysPermissions = %s;
		Object.freeze( gbOverlaysPermissions );',
		$permission_object
	);
	wp_add_inline_script( 'generateblocks-overlays-permissions', $script );
}

add_action( 'init', 'generateblocks_pro_register_menu_support' );
/**
 * Register menu support for GenerateBlocks Pro.
 *
 * @return void
 */
function generateblocks_pro_register_menu_support() {
	register_setting(
		'general',
		'generateblocks_pro_classic_menu_support',
		array(
			'type' => 'boolean',
			'default' => false,
			'show_in_rest' => true,
		)
	);
}

add_action( 'after_setup_theme', 'generateblocks_pro_add_menu_support', 100 );
/**
 * Add menu support for GenerateBlocks Pro.
 *
 * @return void
 */
function generateblocks_pro_add_menu_support() {
	if ( get_theme_support( 'menus' ) ) {
		return;
	}

	$menu_support = get_option( 'generateblocks_pro_classic_menu_support', false );

	if ( $menu_support ) {
		add_theme_support( 'menus' );
	}
}
