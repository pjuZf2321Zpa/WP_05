<?php
/**
 * Handles the Global CSS Output.
 *
 * @package GenerateBlocks
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Build and enqueue our global CSS.
 */
class GenerateBlocks_Pro_Enqueue_Styles extends GenerateBlocks_Pro_Singleton {
	/**
	 * Before-values for category-only REST updates, discarded after each request.
	 *
	 * @var array
	 */
	private $category_saves = [];

	/**
	 * Initialize.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'init', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_after_insert_post', [ $this, 'build_css_file_on_save' ], 100, 2 );
		add_action( 'after_delete_post', [ $this, 'build_css_on_delete' ], 100, 2 );
		add_action( 'customize_after_save', [ $this, 'build_css' ] );
		add_filter( 'rest_pre_insert_gblocks_styles', [ $this, 'prepare_category_save' ], 100, 2 );
		add_filter( 'rest_request_after_callbacks', [ $this, 'clear_category_save' ], 100, 3 );
	}

	/**
	 * Remember a category-only update before the existing REST writer runs.
	 *
	 * Explicit request fields exclude schema defaults. Unknown or mixed writes
	 * keep the normal rebuild, including retries of an unchanged CSS value after
	 * a partially failed save. Nothing here changes or short-circuits the writer.
	 *
	 * @param object|WP_Error $prepared_post Prepared post data.
	 * @param WP_REST_Request $request REST request.
	 * @return object|WP_Error
	 */
	public function prepare_category_save( $prepared_post, $request ) {
		if ( is_wp_error( $prepared_post ) || has_filter( 'generateblocks_global_css' ) ) {
			return $prepared_post;
		}

		$params = array_merge( $request->get_query_params(), $request->get_body_params(), (array) $request->get_json_params() );
		$allowed = [ 'id', 'gb_style_category', 'context', '_locale', '_fields', 'rest_route' ];

		if ( ! isset( $params['gb_style_category'] ) || array_diff( array_keys( $params ), $allowed ) ) {
			return $prepared_post;
		}

		$post_id = (int) $request->get_param( 'id' );
		$post = get_post( $post_id );

		if (
			$post_id <= 0 || ! $post instanceof WP_Post || 'gblocks_styles' !== $post->post_type ||
			( class_exists( 'GenerateBlocks_Pro_Styles_Root' ) && GenerateBlocks_Pro_Styles_Root::is_root_post( $post_id ) )
		) {
			return $prepared_post;
		}

		$this->category_saves[ $post_id ] = [
			'request' => $request,
			'blog_id' => get_current_blog_id(),
			'state' => $this->category_save_state( $post ),
		];

		return $prepared_post;
	}

	/**
	 * Read one style's inputs, excluding only its display-only category.
	 *
	 * Comparing all other metadata also keeps changes made by save callbacks on
	 * the normal rebuild path. This reads one record, never the style collection.
	 *
	 * @param WP_Post $post Existing style.
	 * @return array
	 */
	private function category_save_state( $post ) {
		$meta = get_post_meta( $post->ID );
		unset( $meta['gb_style_category'] );

		return [ $post->post_type, $post->post_status, $post->post_title, (int) $post->menu_order, $meta ];
	}

	/**
	 * Discard before-values even when REST returns before the final post hook.
	 *
	 * @param WP_REST_Response|WP_Error $response REST result.
	 * @param array                     $handler Matched route handler.
	 * @param WP_REST_Request           $request Completed request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function clear_category_save( $response, $handler, $request ) {
		foreach ( $this->category_saves as $post_id => $save ) {
			if ( $save['request'] === $request ) {
				unset( $this->category_saves[ $post_id ] );
			}
		}

		return $response;
	}

	/**
	 * Enqueue our assets.
	 */
	public function enqueue_assets() {
		add_action(
			'wp_enqueue_scripts',
			[ $this, 'enqueue_css' ],
			apply_filters( 'generateblocks_global_css_priority', 20 ) // Less than block-specific stylesheets.
		);
	}

	/**
	 * Check whether we're using file or inline mode.
	 */
	public function mode() {
		$mode = apply_filters( 'generateblocks_global_css_print_method', 'file' );

		if (
			( function_exists( 'is_customize_preview' ) && is_customize_preview() ) ||
			is_preview() ||
			// AMP inlines all CSS, so inlining from the start improves CSS processing performance.
			( function_exists( 'is_amp_endpoint' ) && is_amp_endpoint() )
		) {
			return 'inline';
		}

		return $mode;
	}

	/**
	 * This builds the CSS file.
	 * It will also delete an existing file if creating fails for any reason.
	 *
	 * @param string|null $css CSS to write. Null uses the cached CSS.
	 * @return boolean Whether the file has been built or not.
	 */
	public function build_css_file( $css = null ) {
		$built = $this->create_css_file( $css );

		// Delete the file if `create_css_file()` fails for any reason.
		if ( ! $built && file_exists( $this->file( 'path' ) ) ) {
			wp_delete_file( $this->file( 'path' ) );
		}

		return $built;
	}

	/**
	 * Build our cache of utility classes.
	 *
	 * @return string Freshly compiled CSS.
	 */
	public function build_css_cache() {
		$css = GenerateBlocks_Pro_Styles::get_styles_css( false );
		update_option( 'generateblocks_style_css', $css );

		return $css;
	}

	/**
	 * Check to see if we have a global css file.
	 */
	public function has_css_file() {
		return file_exists( $this->file( 'path' ) );
	}

	/**
	 * Enqueue the CSS.
	 */
	public function enqueue_css() {
		if ( 'inline' === $this->mode() || ! $this->has_css_file() ) {
			$css = apply_filters(
				'generateblocks_global_css',
				GenerateBlocks_Pro_Styles::get_styles_css()
			);

			// Add a "dummy" handle we can add inline styles to.
			wp_register_style( 'generateblocks-global', false ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
			wp_enqueue_style( 'generateblocks-global' );

			wp_add_inline_style(
				'generateblocks-global',
				wp_strip_all_tags( $css ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			);
		}

		if ( 'file' === $this->mode() && $this->has_css_file() ) {
			wp_enqueue_style( 'generateblocks-global', esc_url( $this->file( 'uri' ) ), array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
		}
	}

	/**
	 * Creates our CSS file and puts it on the server.
	 *
	 * @param string|null $css CSS to write. Null uses the cached CSS.
	 */
	public function create_css_file( $css = null ) {
		$css = apply_filters(
			'generateblocks_global_css',
			null === $css ? GenerateBlocks_Pro_Styles::get_styles_css() : $css
		);

		if ( ! $css || ! $this->can_write() || ! function_exists( 'generateblocks_get_wp_filesystem' ) ) {
			return false;
		}

		$filesystem = generateblocks_get_wp_filesystem();

		if ( ! $filesystem ) {
			return false;
		}

		// Take care of domain mapping.
		if ( defined( 'DOMAIN_MAPPING' ) && DOMAIN_MAPPING ) {
			if ( function_exists( 'domain_mapping_siteurl' ) && function_exists( 'get_original_url' ) ) {
				$mapped_domain = domain_mapping_siteurl( false );
				$original_domain = get_original_url( 'siteurl' );

				$css = str_replace( $original_domain, $mapped_domain, $css );
			}
		}

		if ( is_writable( $this->file( 'path' ) ) || ( ! file_exists( $this->file( 'path' ) ) && is_writable( dirname( $this->file( 'path' ) ) ) ) ) {
			$chmod_file = 0644;

			if ( defined( 'FS_CHMOD_FILE' ) ) {
				$chmod_file = FS_CHMOD_FILE;
			}

			if ( ! $filesystem->put_contents( $this->file( 'path' ), wp_strip_all_tags( $css ), $chmod_file ) ) {
				return false;
			} else {
				// Do a quick double-check to make sure the file was created.
				if ( ! file_exists( $this->file( 'path' ) ) ) {
					return false;
				}

				return true;
			}
		}
	}

	/**
	 * Determines if the CSS file is writable.
	 */
	public function can_write() {
		global $blog_id;

		// Get the upload directory for this site.
		$upload_dir = wp_get_upload_dir();

		// If this is a multisite installation, append the blogid to the filename.
		$css_blog_id = ( is_multisite() && $blog_id > 1 ) ? '_blog-' . $blog_id : null;

		$file_name   = '/style' . $css_blog_id . '-global.css';
		$folder_path = $upload_dir['basedir'] . DIRECTORY_SEPARATOR . 'generateblocks';

		if ( ! file_exists( $folder_path ) ) {
			// returns true if yes and false if not.
			return wp_mkdir_p( $folder_path );
		}

		$file_path = $folder_path . $file_name;

		if (
			! is_writable( $folder_path ) &&
			( ! file_exists( $file_path ) || ! is_writable( $file_path ) )
		) {
			// Folder not writable & file does not exist or it's not writable.
			return false;
		}

		if (
			is_writable( $folder_path ) &&
			( file_exists( $file_path ) && ! is_writable( $file_path ) )
		) {
			// Folder is writable but the file is not writable.
			return false;
		}

		// All is well!
		return true;
	}

	/**
	 * Gets the css path or url to the stylesheet
	 *
	 * @param string $target path/url.
	 */
	public function file( $target = 'path' ) {
		global $blog_id;

		// Get the upload directory for this site.
		$upload_dir = wp_get_upload_dir();

		// If this is a multisite installation, append the blogid to the filename.
		$css_blog_id = ( is_multisite() && $blog_id > 1 ) ? '_blog-' . $blog_id : null;

		$file_name   = 'style' . $css_blog_id . '-global.css';
		$folder_path = $upload_dir['basedir'] . DIRECTORY_SEPARATOR . 'generateblocks';

		// The complete path to the file.
		$file_path = $folder_path . DIRECTORY_SEPARATOR . $file_name;

		// Get the URL directory of the stylesheet.
		$css_uri_folder = $upload_dir['baseurl'];

		$css_uri = trailingslashit( $css_uri_folder ) . 'generateblocks/' . $file_name;

		// Take care of domain mapping.
		if ( defined( 'DOMAIN_MAPPING' ) && DOMAIN_MAPPING ) {
			if ( function_exists( 'domain_mapping_siteurl' ) && function_exists( 'get_original_url' ) ) {
				$mapped_domain   = domain_mapping_siteurl( false );
				$original_domain = get_original_url( 'siteurl' );
				$css_uri         = str_replace( $original_domain, $mapped_domain, $css_uri );
			}
		}

		$css_uri = set_url_scheme( $css_uri );

		if ( 'path' === $target ) {
			return $file_path;
		} elseif ( 'url' === $target || 'uri' === $target ) {
			$timestamp = ( file_exists( $file_path ) ) ? '?ver=' . filemtime( $file_path ) : '';
			return $css_uri . $timestamp;
		}
	}

	/**
	 * Rebuild our CSS cache and file after we save a class.
	 *
	 * @param int    $post_id The post ID being saved.
	 * @param object $post The post object.
	 */
	public function build_css_file_on_save( $post_id, $post ) {
		$category_save = $this->category_saves[ $post_id ] ?? null;
		unset( $this->category_saves[ $post_id ] );

		if ( 'gblocks_styles' !== $post->post_type ) {
			return;
		}

		// The managed :root lifecycle owns its post meta, snapshots, conflict
		// repair, and derivative refresh as one operation. Never rebuild from the
		// generic post hook while that aggregate may be only partly written.
		if (
			class_exists( 'GenerateBlocks_Pro_Styles_Root' ) &&
			GenerateBlocks_Pro_Styles_Root::is_root_post( (int) $post_id )
		) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// Check if it is an autosave or a revision.
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( $category_save && get_current_blog_id() === $category_save['blog_id'] && ! has_filter( 'generateblocks_global_css' ) ) {
			$saved_post = get_post( $post_id );
			$cached_css = get_option( 'generateblocks_style_css', null );

			if (
				$saved_post instanceof WP_Post &&
				$category_save['state'] === $this->category_save_state( $saved_post ) &&
				is_string( $cached_css ) && '' !== $cached_css && $this->has_css_file()
			) {
				return;
			}
		}

		$this->build_css();
	}

	/**
	 * Rebuild our CSS cache and file after we delete a style.
	 *
	 * @param int    $post_id The post ID being deleted.
	 * @param object $post The post object.
	 */
	public function build_css_on_delete( $post_id, $post ) {
		if ( 'gblocks_styles' !== $post->post_type ) {
			return;
		}

		// EMPTY_TRASH_DAYS=0 turns a managed trash operation into an immediate
		// deletion. The root lifecycle rebuilds once after the aggregate is stable.
		if (
			class_exists( 'GenerateBlocks_Pro_Styles_Root' )
			&& GenerateBlocks_Pro_Styles_Root::is_removing_candidate()
		) {
			return;
		}

		$this->build_css();
	}

	/**
	 * Rebuild our CSS cache and file.
	 */
	public function build_css() {
		$css = $this->build_css_cache();

		// A concurrent identical option update can leave this request's cache stale.
		$this->build_css_file( $css );

		if ( class_exists( 'GenerateBlocks_Pro_Design_Tokens_Usage' ) ) {
			GenerateBlocks_Pro_Design_Tokens_Usage::clear_cache();
		}
	}
}

GenerateBlocks_Pro_Enqueue_Styles::get_instance()->init();
