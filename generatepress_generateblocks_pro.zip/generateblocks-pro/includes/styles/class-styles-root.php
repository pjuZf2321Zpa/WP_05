<?php
/**
 * Managed :root Global Style.
 *
 * @package GenerateBlocksPro\Styles
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolves and protects the selector-derived :root singleton.
 */
class GenerateBlocks_Pro_Styles_Root extends GenerateBlocks_Pro_Singleton {

	const SELECTOR = ':root';
	const TOKENS_META_KEY = 'gb_style_tokens';
	const CREATION_LOCK_OPTION = 'generateblocks_pro_root_style_creation_lock';
	const CREATION_LOCK_TTL = 30;

	/**
	 * Whether the lifecycle service is removing a root candidate.
	 *
	 * @var bool
	 */
	private static $removing_candidate = false;

	/**
	 * Resolved root state for this request.
	 *
	 * @var array|null
	 */
	private static $resolve_cache = null;

	/**
	 * Blog the memoized resolution belongs to. The root singleton is
	 * per-site, so a switch_to_blog() mid-request must not serve another
	 * blog's resolution.
	 *
	 * @var int
	 */
	private static $resolve_cache_blog_id = 0;

	/**
	 * Root REST updates that need one derivative refresh after all registered
	 * fields have been written.
	 *
	 * @var array<int, bool>
	 */
	private static $pending_rest_refresh = [];

	/**
	 * Root aggregate writes staged by the REST guard, keyed by post ID.
	 *
	 * WordPress writes registered REST fields one at a time, but the managed
	 * root is a single aggregate. The guard validates the whole aggregate and
	 * stages it here; the first managed root field callback of the request
	 * writes it and stores the outcome so the remaining root field callbacks
	 * report the same result instead of writing again.
	 *
	 * @var array<int, array{write:array,result:mixed}>
	 */
	private static $rest_aggregate = [];

	/**
	 * Register protection hooks.
	 */
	public function init(): void {
		add_filter( 'rest_pre_insert_gblocks_styles', [ $this, 'guard_rest_write' ], 10, 2 );
		add_action( 'rest_after_insert_gblocks_styles', [ $this, 'refresh_after_rest_write' ], 10, 3 );
		add_filter( 'pre_trash_post', [ $this, 'guard_trash' ], 10, 2 );
		add_filter( 'pre_delete_post', [ $this, 'guard_delete' ], 10, 3 );
		add_action( 'untrashed_post', [ $this, 'refresh_after_untrash' ], 10, 2 );
		add_action( 'enqueue_block_editor_assets', [ $this, 'enqueue_admin_variables' ], 30 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_dashboard_variables' ], 30 );
	}

	/**
	 * Normalize a selector for singleton identity checks.
	 *
	 * @param string $selector Selector to normalize.
	 */
	public static function normalize_selector( string $selector ): string {
		return strtolower( trim( $selector ) );
	}

	/**
	 * Resolve without creating or changing posts.
	 *
	 * @param bool $fresh Whether to bypass the request memo.
	 * @return array{status:string,post:?WP_Post,ids:int[]}
	 */
	public static function resolve( bool $fresh = false ): array {
		if (
			! $fresh
			&& null !== self::$resolve_cache
			&& get_current_blog_id() === self::$resolve_cache_blog_id
		) {
			return self::$resolve_cache;
		}

		self::$resolve_cache_blog_id = get_current_blog_id();

		$query = new WP_Query(
			[
				'post_type'      => 'gblocks_styles',
				'posts_per_page' => -1,
				'post_status'    => 'any',
				'meta_query'     => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					[
						'key'     => 'gb_style_selector',
						'value'   => self::SELECTOR,
						'compare' => 'LIKE',
					],
				],
			]
		);

		$matches = array_values(
			array_filter(
				(array) $query->posts,
				static function ( $post ): bool {
					return $post instanceof WP_Post
						&& self::SELECTOR === self::normalize_selector( (string) get_post_meta( $post->ID, 'gb_style_selector', true ) );
				}
			)
		);

		if ( 1 === count( $matches ) ) {
			$post = $matches[0];

			self::$resolve_cache = [
				'status' => 'publish' === $post->post_status ? 'ready' : 'inactive',
				'post'   => $post,
				'ids'    => [ (int) $post->ID ],
			];

			return self::$resolve_cache;
		}

		if ( count( $matches ) > 1 ) {
			$ids = array_map( 'intval', wp_list_pluck( $matches, 'ID' ) );
			sort( $ids, SORT_NUMERIC );

			self::$resolve_cache = [
				'status' => 'conflict',
				'post'   => null,
				'ids'    => $ids,
			];

			return self::$resolve_cache;
		}

		self::$resolve_cache = [
			'status' => 'absent',
			'post'   => null,
			'ids'    => [],
		];

		return self::$resolve_cache;
	}

	/**
	 * Clear the request-level root resolution memo after a mutation.
	 */
	private static function invalidate_resolve_cache(): void {
		self::$resolve_cache = null;
	}

	/**
	 * Return the singleton post when resolution is unambiguous.
	 */
	public static function get_post(): ?WP_Post {
		$resolved = self::resolve();

		return 'ready' === $resolved['status'] ? $resolved['post'] : null;
	}

	/**
	 * Observe the unambiguous root post ID without creating or repairing it.
	 */
	public static function get_resolved_post_id(): int {
		$resolved = self::resolve();

		return in_array( $resolved['status'], [ 'ready', 'inactive' ], true )
			? (int) $resolved['post']->ID
			: 0;
	}

	/**
	 * Read the managed root state without creating or changing posts.
	 *
	 * @return array|WP_Error
	 */
	public static function read_for_dashboard() {
		$resolved = self::resolve();

		if ( 'conflict' === $resolved['status'] ) {
			return self::conflict_error( $resolved );
		}

		return self::get_state(
			in_array( $resolved['status'], [ 'ready', 'inactive' ], true )
				? $resolved['post']
				: null
		);
	}

	/**
	 * Read the singleton styles object.
	 */
	public static function get_styles(): array {
		$post = self::get_post();

		if ( ! $post ) {
			return [];
		}

		$styles = get_post_meta( $post->ID, 'gb_style_data', true );

		return is_array( $styles ) ? $styles : [];
	}

	/**
	 * Read the singleton's trusted compiled CSS.
	 */
	public static function get_css(): string {
		$post = self::get_post();

		return $post ? (string) get_post_meta( $post->ID, 'gb_style_css', true ) : '';
	}

	/**
	 * Build a variables-only :root block for the outer admin document.
	 *
	 * Only base declarations are emitted. Values are checked at the exact
	 * output boundary so corrupt meta cannot break out and restyle wp-admin.
	 */
	public static function get_admin_variables_css(): string {
		$declarations = [];

		foreach ( self::get_styles() as $property => $value ) {
			if (
				! is_string( $property )
				|| ! class_exists( 'GenerateBlocks_Pro_Design_Tokens' )
				|| ! GenerateBlocks_Pro_Design_Tokens::is_valid_token_name( $property )
				|| ! is_string( $value )
				|| ! self::is_safe_declaration_value( $value )
			) {
				continue;
			}

			$declarations[] = $property . ':' . wp_strip_all_tags( trim( $value ) ) . ';';
		}

		return $declarations ? ':root{' . implode( '', $declarations ) . '}' : '';
	}

	/**
	 * Whether a value can be placed inside one CSS declaration safely.
	 *
	 * Line breaks are rejected even inside quotes: a quoted line break
	 * tokenizes as a CSS bad-string and the re-opened string swallows every
	 * later declaration in the emitted single-line `:root{}` blob. Keep the
	 * rejection classes aligned with `passes_safety_check()` in
	 * class-design-tokens.php — this boundary re-checks stored bytes the
	 * save-time validator may never have seen.
	 *
	 * @param string $value CSS declaration value.
	 */
	public static function is_safe_declaration_value( string $value ): bool {
		$value = trim( $value );

		if ( '' === $value || preg_match( '/[<>{};\n\r\f]|\/\*|\*\//', $value ) ) {
			return false;
		}

		$quote = '';
		$depth = 0;
		$length = strlen( $value );

		for ( $i = 0; $i < $length; $i++ ) {
			$character = $value[ $i ];

			if ( '\\' === $character ) {
				if ( $i === $length - 1 ) {
					return false;
				}

				++$i;
				continue;
			}

			if ( '' !== $quote ) {
				if ( $character === $quote ) {
					$quote = '';
				}

				continue;
			}

			if ( '"' === $character || "'" === $character ) {
				$quote = $character;
				continue;
			}

			if ( '(' === $character ) {
				++$depth;
			} elseif ( ')' === $character ) {
				--$depth;

				if ( $depth < 0 ) {
					return false;
				}
			}
		}

		return '' === $quote && 0 === $depth;
	}

	/**
	 * Enqueue base variables in the block editor's outer admin document.
	 */
	public function enqueue_admin_variables(): void {
		$this->register_admin_variables_style();
	}

	/**
	 * Enqueue base variables on GenerateBlocks dashboard screens.
	 */
	public function enqueue_dashboard_variables(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		if ( ! $screen ) {
			return;
		}

		$screens = (array) apply_filters( 'generateblocks_dashboard_screens', [] );

		if ( in_array( $screen->id, $screens, true ) ) {
			$this->register_admin_variables_style();
		}
	}

	/**
	 * Register the variables-only admin stylesheet.
	 */
	private function register_admin_variables_style(): void {
		$css = self::get_admin_variables_css();

		if ( '' === $css ) {
			return;
		}

		$handle = 'generateblocks-root-variables-admin';

		if ( ! wp_style_is( $handle, 'registered' ) ) {
			wp_register_style( $handle, false ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
		}

		wp_enqueue_style( $handle );
		wp_add_inline_style( $handle, $css ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Resolve the singleton for an authorized write, optionally creating it
	 * when an explicit user action needs a backing record.
	 *
	 * @param bool $create Whether an absent singleton may be created.
	 * @return array|WP_Error
	 */
	public static function resolve_for_dashboard( bool $create = false ) {
		$created = false;

		return self::resolve_for_dashboard_post( $create, $created );
	}

	/**
	 * Explicitly create the singleton and report whether this request created it.
	 *
	 * @return array|WP_Error
	 */
	public static function create_for_dashboard() {
		$created = false;
		$post    = self::resolve_for_dashboard_post( true, $created );

		if ( is_wp_error( $post ) ) {
			return $post;
		}

		$state            = self::get_state( $post );
		$state['created'] = $created;

		return $state;
	}

	/**
	 * Resolve the singleton and optionally create its backing post.
	 *
	 * @param bool $create  Whether an absent singleton may be created.
	 * @param bool $created Whether this request retained the post it created.
	 * @return WP_Post|WP_Error
	 */
	private static function resolve_for_dashboard_post( bool $create, bool &$created ) {
		$created  = false;
		$resolved = self::resolve();

		if ( 'conflict' === $resolved['status'] ) {
			return self::conflict_error( $resolved );
		}

		if ( in_array( $resolved['status'], [ 'ready', 'inactive' ], true ) ) {
			return $resolved['post'];
		}

		if ( ! $create ) {
			return new WP_Error(
				'gb_root_style_absent',
				__( 'The :root style must be loaded before it can be saved.', 'generateblocks-pro' ),
				[ 'status' => 404 ]
			);
		}

		$lock_token = self::acquire_creation_lock();

		if ( '' === $lock_token ) {
			$after_lock = self::resolve( true );

			if ( in_array( $after_lock['status'], [ 'ready', 'inactive' ], true ) ) {
				return $after_lock['post'];
			}

			if ( 'conflict' === $after_lock['status'] ) {
				return self::conflict_error( $after_lock );
			}

			return new WP_Error(
				'gb_root_style_creation_in_progress',
				__( 'The :root style is being created. Try again.', 'generateblocks-pro' ),
				[ 'status' => 409 ]
			);
		}

		try {
			// Another request may have completed between the first read and our
			// successful lock acquisition.
			$after_lock = self::resolve( true );

			if ( in_array( $after_lock['status'], [ 'ready', 'inactive' ], true ) ) {
				return $after_lock['post'];
			}

			if ( 'conflict' === $after_lock['status'] ) {
				return self::conflict_error( $after_lock );
			}

			$post_id = wp_insert_post(
				[
					'post_type'   => 'gblocks_styles',
					'post_title'  => self::SELECTOR,
					'post_status' => 'publish',
				],
				true
			);

			if ( is_wp_error( $post_id ) ) {
				return $post_id;
			}

			// Store the selector last. A partially initialized post must not
			// become visible to the selector-derived resolver.
			$initialized = update_post_meta( $post_id, 'gb_style_data', [] )
				&& update_post_meta( $post_id, 'gb_style_css', '' )
				&& update_post_meta( $post_id, self::TOKENS_META_KEY, self::token_envelope( [] ) )
				&& update_post_meta( $post_id, 'gb_style_selector', self::SELECTOR );

			if ( ! $initialized ) {
				self::remove_root_candidate( (int) $post_id, true );

				return new WP_Error(
					'gb_root_style_create_failed',
					__( 'The :root style could not be created.', 'generateblocks-pro' ),
					[ 'status' => 500 ]
				);
			}

			self::invalidate_resolve_cache();
			$after_create = self::resolve( true );

			if (
				'ready' === $after_create['status']
				&& (int) $post_id === (int) $after_create['post']->ID
			) {
				$created = true;
				return $after_create['post'];
			}

			// An uncoordinated writer may still have created another candidate.
			// Remove only the empty post owned by this request, then prefer the
			// other unambiguous record or surface the real conflict.
			self::remove_root_candidate( (int) $post_id, true );
			$after_cleanup = self::resolve( true );

			if ( in_array( $after_cleanup['status'], [ 'ready', 'inactive' ], true ) ) {
				return $after_cleanup['post'];
			}

			return 'conflict' === $after_cleanup['status']
				? self::conflict_error( $after_cleanup )
				: new WP_Error(
					'gb_root_style_create_failed',
					__( 'The :root style could not be created.', 'generateblocks-pro' ),
					[ 'status' => 500 ]
				);
		} finally {
			self::release_creation_lock( $lock_token );
		}
	}

	/**
	 * Claim the short-lived root creation lock.
	 *
	 * The add_option() call is backed by the unique option_name index, so one PHP
	 * request can claim an absent lock even without a persistent object cache.
	 */
	private static function acquire_creation_lock(): string {
		$token = wp_generate_uuid4();
		$now   = time();
		$lock  = get_option( self::CREATION_LOCK_OPTION, null );

		if (
			null !== $lock
			&& (
				! is_array( $lock )
				|| ! isset( $lock['token'], $lock['created'] )
				|| ! is_string( $lock['token'] )
				|| $now - (int) $lock['created'] >= self::CREATION_LOCK_TTL
			)
		) {
			self::delete_creation_lock_if_matches( $lock );
		}

		$claimed = add_option(
			self::CREATION_LOCK_OPTION,
			[
				'token'   => $token,
				'created' => $now,
			],
			'',
			false
		);

		return $claimed ? $token : '';
	}

	/**
	 * Release the creation lock when it is still owned by this request.
	 *
	 * @param string $token Lock owner token.
	 */
	private static function release_creation_lock( string $token ): void {
		$lock = get_option( self::CREATION_LOCK_OPTION, null );

		if (
			is_array( $lock )
			&& isset( $lock['token'] )
			&& is_string( $lock['token'] )
			&& hash_equals( $lock['token'], $token )
		) {
			self::delete_creation_lock_if_matches( $lock );
		}
	}

	/**
	 * Atomically delete the lock only when the database still contains the
	 * exact value observed by this request.
	 *
	 * @param mixed $lock Observed lock value.
	 * @return bool
	 */
	private static function delete_creation_lock_if_matches( $lock ): bool {
		global $wpdb;

		$deleted = $wpdb->delete(
			$wpdb->options,
			[
				'option_name'  => self::CREATION_LOCK_OPTION,
				'option_value' => maybe_serialize( $lock ),
			],
			[ '%s', '%s' ]
		); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- This compare-and-delete is the lock's atomicity boundary; the matching object-cache entry is cleared below.

		if ( 1 !== $deleted ) {
			return false;
		}

		wp_cache_delete( self::CREATION_LOCK_OPTION, 'options' );

		return true;
	}

	/**
	 * Keep one conflicting root record and move the others to the Trash.
	 *
	 * Conflict repair is intentionally part of this lifecycle service instead
	 * of using the ordinary post REST delete route. That keeps root protection
	 * intact and lets us rebuild every derivative once after the repair.
	 *
	 * @param int $keep_post_id Root post to keep.
	 * @return array|WP_Error
	 */
	public static function resolve_conflict( int $keep_post_id ) {
		$resolved = self::resolve();

		if ( 'conflict' !== $resolved['status'] || ! in_array( $keep_post_id, $resolved['ids'], true ) ) {
			return new WP_Error(
				'gb_root_style_invalid_conflict_resolution',
				__( 'Choose one of the current :root records to keep.', 'generateblocks-pro' ),
				[
					'status'  => 409,
					'current' => self::get_state(),
				]
			);
		}

		$loser_ids = array_values(
			array_filter(
				$resolved['ids'],
				static fn( $post_id ) => $keep_post_id !== $post_id
			)
		);

		$keeper = get_post( $keep_post_id );

		if ( ! $keeper instanceof WP_Post ) {
			return new WP_Error(
				'gb_root_style_conflict_repair_failed',
				__( 'The :root conflict changed while it was being resolved. Reload and try again.', 'generateblocks-pro' ),
				[ 'status' => 409 ]
			);
		}

		// Prove the keeper persists before touching anything else: a failed
		// repair must leave the losers untrashed AND the three-slot snapshot
		// history unrotated, or repeated failures could evict real recovery
		// points without accomplishing anything.
		$current = self::get_state( $keeper );
		$result  = self::persist(
			$keeper,
			$current['styles'],
			$current['css'],
			$current['checksum'],
			false
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$changed = false;

		foreach ( $loser_ids as $post_id ) {
			// Snapshot the losing candidate immediately before it is removed.
			// On hosts with EMPTY_TRASH_DAYS=0 the trash is an immediate hard
			// delete, and no product surface can untrash a root candidate —
			// the snapshot rotation is the only recovery path if the wrong
			// record was kept. Empty candidates are skipped so they can't
			// push real history out.
			$loser_styles = get_post_meta( $post_id, 'gb_style_data', true );
			$loser_styles = is_array( $loser_styles ) ? $loser_styles : [];
			$loser_css    = (string) get_post_meta( $post_id, 'gb_style_css', true );
			$loser_tokens = [];

			if ( class_exists( 'GenerateBlocks_Pro_Design_Tokens' ) ) {
				$loser_post  = get_post( $post_id );
				$token_state = $loser_post instanceof WP_Post
					? GenerateBlocks_Pro_Design_Tokens::read_state( $loser_post, false )
					: [ 'tokens' => [] ];
				$loser_tokens = $token_state['tokens'];
			}

			if ( [] !== $loser_styles || '' !== $loser_css || [] !== $loser_tokens ) {
				GenerateBlocks_Pro_Styles_Root_Snapshots::rotate(
					[
						'selector' => self::SELECTOR,
						'styles'   => $loser_styles,
						'css'      => $loser_css,
						'tokens'   => self::token_envelope( $loser_tokens ),
						'savedAt'  => gmdate( 'c' ),
					]
				);
			}

			if ( ! self::remove_root_candidate( $post_id, false ) ) {
				if ( $changed ) {
					self::refresh_derivatives();
				}

				return new WP_Error(
					'gb_root_style_conflict_repair_failed',
					__( 'A conflicting :root record could not be moved to the Trash.', 'generateblocks-pro' ),
					[
						'status'  => 500,
						'current' => self::get_state(),
					]
				);
			}

			$changed = true;
		}

		$after_repair = self::resolve( true );

		if (
			! in_array( $after_repair['status'], [ 'ready', 'inactive' ], true )
			|| $keep_post_id !== (int) $after_repair['post']->ID
		) {
			if ( $changed ) {
				self::refresh_derivatives();
			}

			return 'conflict' === $after_repair['status']
				? self::conflict_error( $after_repair )
				: new WP_Error(
					'gb_root_style_conflict_repair_failed',
					__( 'The :root conflict changed while it was being resolved. Reload and try again.', 'generateblocks-pro' ),
					[ 'status' => 409 ]
				);
		}

		// Trashing the extras changes which root record feeds the public CSS even
		// when the kept record itself was already canonical and needed no write.
		self::refresh_derivatives();

		return $result;
	}

	/**
	 * Build the standard conflict error and its reviewable candidate summary.
	 *
	 * @param array $resolved Fresh resolver result.
	 */
	private static function conflict_error( array $resolved ): WP_Error {
		$ids = array_values( array_map( 'intval', $resolved['ids'] ?? [] ) );

		return new WP_Error(
			'gb_root_style_conflict',
			sprintf(
				/* translators: %s: comma-separated style post IDs */
				__( 'Multiple :root styles were found (post IDs: %s). Choose which record to keep before continuing.', 'generateblocks-pro' ),
				implode( ', ', $ids )
			),
			[
				'status'     => 409,
				'postIds'    => $ids,
				'candidates' => self::get_conflict_candidates( $ids ),
			]
		);
	}

	/**
	 * Return enough candidate data to make conflict repair an informed choice.
	 *
	 * @param int[] $post_ids Candidate post IDs.
	 * @return array<int, array{postId:int,title:string,status:string,variableCount:int}>
	 */
	private static function get_conflict_candidates( array $post_ids ): array {
		$candidates = [];

		foreach ( $post_ids as $post_id ) {
			$post = get_post( $post_id );

			if ( ! $post instanceof WP_Post || 'gblocks_styles' !== $post->post_type ) {
				continue;
			}

			$styles = get_post_meta( $post_id, 'gb_style_data', true );
			$candidates[] = [
				'postId'        => (int) $post_id,
				'title'         => (string) $post->post_title,
				'status'        => (string) $post->post_status,
				'variableCount' => self::count_custom_properties( is_array( $styles ) ? $styles : [] ),
			];
		}

		return $candidates;
	}

	/**
	 * Count custom-property declarations throughout a root styles tree.
	 *
	 * @param array $branch Styles Builder branch.
	 */
	private static function count_custom_properties( array $branch ): int {
		$count = 0;

		foreach ( $branch as $property => $value ) {
			if ( is_string( $property ) && 0 === strpos( $property, '--' ) ) {
				++$count;
			} elseif ( is_array( $value ) ) {
				$count += self::count_custom_properties( $value );
			}
		}

		return $count;
	}

	/**
	 * Read every string declaration for one custom property.
	 *
	 * @param array  $styles Styles Builder data.
	 * @param string $name   Exact custom-property name.
	 * @return string[]
	 */
	public static function get_custom_property_values( array $styles, string $name ): array {
		$values = [];
		self::collect_custom_property_values( $styles, $name, $values );

		return $values;
	}

	/**
	 * Recursively collect one custom property's values.
	 *
	 * @param array  $branch Current Styles Builder branch.
	 * @param string $name   Exact custom-property name.
	 * @param array  $values Collected string values.
	 * @return void
	 */
	private static function collect_custom_property_values( array $branch, string $name, array &$values ): void {
		foreach ( $branch as $key => $value ) {
			if ( $name === $key && is_string( $value ) ) {
				$values[] = $value;
				continue;
			}

			if ( is_array( $value ) ) {
				self::collect_custom_property_values( $value, $name, $values );
			}
		}
	}

	/**
	 * Project selected custom properties into a partial Styles Builder tree.
	 *
	 * Every at-rule and nested-selector branch is retained in its authored
	 * order. Empty branches and ordinary declarations are omitted.
	 *
	 * @param array $styles Styles Builder data.
	 * @param array $names  Exact custom-property names to retain.
	 * @return array
	 */
	public static function filter_custom_properties( array $styles, array $names ): array {
		$allowed = array_fill_keys(
			array_values(
				array_filter(
					$names,
					'is_string'
				)
			),
			true
		);
		$result  = [];

		foreach ( $styles as $key => $value ) {
			if ( is_string( $key ) && isset( $allowed[ $key ] ) && is_string( $value ) ) {
				$result[ $key ] = $value;
				continue;
			}

			if ( ! is_string( $key ) || ! is_array( $value ) ) {
				continue;
			}

			$branch = self::filter_custom_properties( $value, $names );

			if ( ! empty( $branch ) ) {
				$result[ $key ] = $branch;
			}
		}

		return $result;
	}

	/**
	 * Build the API aggregate and checksum.
	 *
	 * @param WP_Post|null $post Singleton post, or null to resolve.
	 */
	public static function get_state( ?WP_Post $post = null ): array {
		$post = $post ?? self::get_post();

		if ( ! $post ) {
			$resolved = self::resolve();

			return [
				'status'              => $resolved['status'],
				'postIds'             => $resolved['ids'],
				'postId'              => 0,
				'postStatus'          => '',
				'selector'            => self::SELECTOR,
				'styles'              => [],
				'css'                 => '',
				'tokens'              => [],
				'recoveredFromBackup' => false,
				'checksum'            => '',
			];
		}

		$styles = get_post_meta( $post->ID, 'gb_style_data', true );
		$styles = is_array( $styles ) ? $styles : [];
		$css = (string) get_post_meta( $post->ID, 'gb_style_css', true );
		$token_state = class_exists( 'GenerateBlocks_Pro_Design_Tokens' )
			? GenerateBlocks_Pro_Design_Tokens::read_state( $post )
			: [
				'tokens' => [],
				'source' => 'none',
			];
		$state = [
			'postId'     => (int) $post->ID,
			'postStatus' => (string) $post->post_status,
			'selector'   => self::SELECTOR,
			'styles'     => $styles,
			'css'        => $css,
			'tokens'     => $token_state['tokens'],
		];

		return array_merge(
			[
				'status'   => 'publish' === $post->post_status ? 'ready' : 'inactive',
				'postIds'  => [ (int) $post->ID ],
			],
			$state,
			[
				'recoveredFromBackup' => 0 === strpos( $token_state['source'], 'snapshot_' ),
				'checksum'            => md5( (string) wp_json_encode( $state ) ),
			]
		);
	}

	/**
	 * Build the compare token for any Global Style record.
	 *
	 * The managed root includes its registry. Class styles intentionally use
	 * the same post/meta state shape minus tokens so they can opt into the
	 * generic REST guard later without changing the server contract.
	 *
	 * @param WP_Post $post Global Style post.
	 */
	public static function get_post_checksum( WP_Post $post ): string {
		if ( self::is_root_post( (int) $post->ID ) ) {
			return self::get_state( $post )['checksum'];
		}

		$styles = get_post_meta( $post->ID, 'gb_style_data', true );
		$state = [
			'postId'     => (int) $post->ID,
			'postStatus' => (string) $post->post_status,
			'selector'   => (string) get_post_meta( $post->ID, 'gb_style_selector', true ),
			'styles'     => is_array( $styles ) ? $styles : [],
			'css'        => (string) get_post_meta( $post->ID, 'gb_style_css', true ),
		];

		return md5( (string) wp_json_encode( $state ) );
	}

	/**
	 * Persist client-compiled root data with compare-and-save protection.
	 *
	 * @param array      $styles   Styles Builder data.
	 * @param string     $css      Client-compiled CSS.
	 * @param string     $checksum Checksum returned by the last GET/save.
	 * @param array|null $tokens   Replacement registry, or null to leave it untouched.
	 * @return array|WP_Error
	 */
	public static function save( array $styles, string $css, string $checksum, ?array $tokens = null ) {
		$post = self::resolve_for_dashboard( false );

		if ( is_wp_error( $post ) ) {
			return $post;
		}

		return self::persist( $post, $styles, $css, $checksum, true, $tokens );
	}

	/**
	 * Persist one already-resolved root record.
	 *
	 * @param WP_Post    $post                Root record.
	 * @param array      $styles              Styles Builder data.
	 * @param string     $css                 Client-compiled CSS.
	 * @param string     $checksum            Checksum returned by the last read.
	 * @param bool       $refresh_derivatives Whether to rebuild consumers here.
	 * @param array|null $tokens              Replacement registry, or null to leave it untouched.
	 * @return array|WP_Error
	 */
	private static function persist( WP_Post $post, array $styles, string $css, string $checksum, bool $refresh_derivatives, ?array $tokens = null ) {

		$current = self::get_state( $post );
		$checksum_error = self::validate_checksum(
			$post,
			$checksum,
			'gb_root_style_conflict',
			__( 'The :root style changed in another session. Reload before saving.', 'generateblocks-pro' ),
			[ 'current' => $current ]
		);

		if ( is_wp_error( $checksum_error ) ) {
			return $checksum_error;
		}

		$normalized_tokens = null;

		if ( null !== $tokens ) {
			if ( ! class_exists( 'GenerateBlocks_Pro_Design_Tokens' ) ) {
				return new WP_Error(
					'gb_design_tokens_unavailable',
					__( 'Design Tokens are not available.', 'generateblocks-pro' ),
					[ 'status' => 500 ]
				);
			}

			$normalized_tokens = GenerateBlocks_Pro_Design_Tokens::normalize_tokens( $tokens );

			if ( is_wp_error( $normalized_tokens ) ) {
				return $normalized_tokens;
			}
		}

		$write = self::prepare_aggregate_write( $post, $current, $styles, $css, $normalized_tokens );

		if ( is_wp_error( $write ) ) {
			return $write;
		}

		if ( ! $write['semantic_changed'] && ! $write['identity_changed'] ) {
			return $current;
		}

		$result = self::write_aggregate( $post, $write, true, $refresh_derivatives );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return self::get_state( get_post( $post->ID ) );
	}

	/**
	 * Validate one candidate :root aggregate and derive everything its write
	 * needs. Every write entrant runs this, so the REST route and the internal
	 * recovery paths share identical validation and change detection.
	 *
	 * @param WP_Post    $post    Root record.
	 * @param array      $current Current aggregate state.
	 * @param array      $styles  Candidate Styles Builder data.
	 * @param string     $css     Candidate client-compiled CSS.
	 * @param array|null $tokens  Normalized replacement registry, or null to leave it untouched.
	 * @return array|WP_Error
	 */
	private static function prepare_aggregate_write( WP_Post $post, array $current, array $styles, string $css, ?array $tokens ) {
		$next_css = wp_strip_all_tags( $css );
		// An omitted registry leaves the stored one in place, so the values in
		// this write are still checked against it.
		$next_registry = null !== $tokens ? $tokens : $current['tokens'];

		// Design Tokens are an optional module. Without it both sides of the
		// comparison are empty and there is no registry to validate against.
		if ( class_exists( 'GenerateBlocks_Pro_Design_Tokens' ) ) {
			$value_error = self::validate_changed_token_values(
				$next_registry,
				$styles,
				self::get_changed_token_names(
					$current['tokens'],
					$next_registry,
					$current['styles'],
					$styles
				)
			);

			if ( is_wp_error( $value_error ) ) {
				return $value_error;
			}
		}

		$stored_registry = self::capture_meta( (int) $post->ID, self::TOKENS_META_KEY );
		$sanitized_registry = $stored_registry['exists'] && class_exists( 'GenerateBlocks_Pro_Design_Tokens' )
			? GenerateBlocks_Pro_Design_Tokens::sanitize_envelope( $stored_registry['value'] )
			: null;
		// One primary-registry rule for every entrant: the stored envelope is
		// primary only when it is byte-identical to its own sanitized form. A
		// readable-but-non-canonical envelope still has to be rewritten, so it
		// counts as a change and earns a snapshot of the state it replaces.
		$primary_registry = null !== $sanitized_registry
			&& $stored_registry['value'] === $sanitized_registry;
		$tokens_changed = null !== $tokens
			&& ( $current['tokens'] !== $tokens || ! $primary_registry );
		$semantic_changed = $current['styles'] !== $styles || $current['css'] !== $next_css || $tokens_changed;
		$identity_changed = self::SELECTOR !== get_post_meta( $post->ID, 'gb_style_selector', true )
			|| self::SELECTOR !== $post->post_title
			|| 'publish' !== $post->post_status;

		$updates = [
			'gb_style_selector' => self::SELECTOR,
			'gb_style_data'     => $styles,
			'gb_style_css'      => $next_css,
		];

		if ( null !== $tokens ) {
			$updates[ self::TOKENS_META_KEY ] = self::token_envelope( $tokens );
		}

		return [
			'updates'          => $updates,
			'snapshot'         => [
				'selector' => self::SELECTOR,
				'styles'   => $current['styles'],
				'css'      => $current['css'],
				'tokens'   => self::token_envelope( $current['tokens'] ),
				'savedAt'  => gmdate( 'c' ),
			],
			'semantic_changed' => $semantic_changed,
			'identity_changed' => $identity_changed,
		];
	}

	/**
	 * Write one prepared :root aggregate. This is the only place the managed
	 * root's meta is written, so every entrant gets the same slashing, the
	 * same rollback to the prior state, and the same rule that history rotates
	 * only after the write has landed.
	 *
	 * @param WP_Post $post                Root record.
	 * @param array   $write               Prepared write from prepare_aggregate_write().
	 * @param bool    $canonicalize_post   Whether this entrant still owns the post row.
	 * @param bool    $refresh_derivatives Whether to rebuild consumers here.
	 * @return true|WP_Error
	 */
	private static function write_aggregate( WP_Post $post, array $write, bool $canonicalize_post, bool $refresh_derivatives ) {
		$post_id = (int) $post->ID;
		$before = [];

		foreach ( array_keys( $write['updates'] ) as $key ) {
			$before[ $key ] = self::capture_meta( $post_id, $key );
		}

		foreach ( $write['updates'] as $key => $value ) {
			if ( $before[ $key ]['exists'] && $before[ $key ]['value'] === $value ) {
				continue;
			}

			if ( false === update_post_meta( $post_id, $key, wp_slash( $value ) ) ) {
				self::restore_meta( $post_id, $before );

				return new WP_Error(
					'gb_root_style_save_failed',
					__( 'The :root style could not be saved.', 'generateblocks-pro' ),
					[ 'status' => 500 ]
				);
			}

			self::invalidate_resolve_cache();
		}

		if ( $canonicalize_post ) {
			$post_result = wp_update_post(
				[
					'ID'          => $post_id,
					'post_title'  => self::SELECTOR,
					'post_status' => 'publish',
				],
				true
			);

			if ( is_wp_error( $post_result ) ) {
				self::restore_meta( $post_id, $before );

				return $post_result;
			}

			self::invalidate_resolve_cache();
		}

		if ( $write['semantic_changed'] ) {
			self::rotate_snapshot( $write['snapshot'] );
		}

		if ( $refresh_derivatives ) {
			self::refresh_derivatives();
		}

		return true;
	}

	/**
	 * Perform the aggregate write the REST guard staged for this request.
	 *
	 * WordPress writes registered REST fields one at a time; the managed root
	 * is one aggregate, so the first managed root field callback writes all of
	 * it through the shared write core and every later root field callback
	 * reports that same outcome. Returns null when the post has no staged
	 * aggregate — every ordinary class style, which keeps writing its own
	 * field exactly as before.
	 *
	 * @param mixed $post Post being updated.
	 * @return true|WP_Error|null
	 */
	public static function write_staged_rest_aggregate( $post ) {
		if ( ! $post instanceof WP_Post ) {
			return null;
		}

		$post_id = (int) $post->ID;

		if ( ! isset( self::$rest_aggregate[ $post_id ] ) ) {
			return null;
		}

		if ( null !== self::$rest_aggregate[ $post_id ]['result'] ) {
			return self::$rest_aggregate[ $post_id ]['result'];
		}

		$write = self::$rest_aggregate[ $post_id ]['write'];
		// WordPress already wrote the canonical post row from the prepared
		// post, and the one derivative refresh runs after every field has been
		// written (rest_after_insert), so the core does neither here.
		$result = self::write_aggregate( $post, $write, false, false );

		if ( is_wp_error( $result ) ) {
			self::$rest_aggregate[ $post_id ]['result'] = $result;

			return $result;
		}

		self::$rest_aggregate[ $post_id ]['result'] = true;

		// Unconditional, including a write that changes nothing. A request whose
		// aggregate landed can still fail in a later registered field callback,
		// which skips rest_after_insert and strands the refresh this request
		// staged. The client then reloads the persisted state and retries, so
		// the retry's aggregate is a no-op — and a no-op that skipped the flag
		// would leave the derived CSS serving the pre-save value with no further
		// save able to correct it. One redundant rebuild is the cheaper mistake.
		self::$pending_rest_refresh[ $post_id ] = true;

		return true;
	}

	/**
	 * Restore a snapshot through the normal checksummed save path.
	 *
	 * @param int    $slot     One-based snapshot slot.
	 * @param string $checksum Current aggregate checksum.
	 * @return array|WP_Error
	 */
	public static function restore_snapshot( int $slot, string $checksum ) {
		$snapshot = GenerateBlocks_Pro_Styles_Root_Snapshots::get( $slot );

		if ( null === $snapshot ) {
			return new WP_Error(
				'gb_root_style_snapshot_missing',
				__( 'That :root backup is not available.', 'generateblocks-pro' ),
				[ 'status' => 404 ]
			);
		}

		$token_envelope  = class_exists( 'GenerateBlocks_Pro_Design_Tokens' )
			? GenerateBlocks_Pro_Design_Tokens::sanitize_envelope( $snapshot['tokens'] ?? null )
			: null;
		$snapshot_tokens = null !== $token_envelope ? $token_envelope['tokens'] : [];

		// Restore writes the snapshot registry through save(). The REST guard
		// 403s token payloads for users without the tokens capability, so a
		// restore that would change the registry must be held to the same bar —
		// otherwise this route is a capability bypass. Token-neutral restores
		// stay available to styles-capable users. A failed resolution skips the
		// comparison; save() surfaces the same resolution error below.
		if ( class_exists( 'GenerateBlocks_Pro_Design_Tokens' ) ) {
			$post = self::resolve_for_dashboard( false );

			if (
				$post instanceof WP_Post
				&& self::get_state( $post )['tokens'] !== $snapshot_tokens
				&& ! GenerateBlocks_Pro_Design_Tokens::can_manage_tokens()
			) {
				return new WP_Error(
					'gb_design_tokens_forbidden',
					__( 'You are not allowed to manage Design Tokens.', 'generateblocks-pro' ),
					[ 'status' => 403 ]
				);
			}
		}

		return self::save(
			$snapshot['styles'],
			$snapshot['css'],
			$checksum,
			$snapshot_tokens
		);
	}

	/**
	 * Guard standard Global Style REST updates before WordPress writes the post
	 * row or invokes any registered-field callbacks.
	 *
	 * Creates pass through untouched unless they carry Design Tokens, which
	 * only the managed root may store. Existing class styles remain unchanged
	 * unless they explicitly opt into the generic checksum field. The managed
	 * root always requires a checksum and receives every capability, payload,
	 * token and value check at this single pre-write veto point. Nothing is
	 * written here: a validated root aggregate is staged for the one shared
	 * write core, which runs from the first managed root field callback.
	 *
	 * @param WP_Post|WP_Error $prepared_post Prepared post.
	 * @param WP_REST_Request  $request       REST request.
	 * @return WP_Post|WP_Error
	 */
	public function guard_rest_write( $prepared_post, $request ) {
		if ( is_wp_error( $prepared_post ) ) {
			return $prepared_post;
		}

		$post_id            = isset( $prepared_post->ID ) ? (int) $prepared_post->ID : (int) $request->get_param( 'id' );
		$post               = $post_id > 0 ? get_post( $post_id ) : null;
		$requested_selector = $request->get_param( 'gb_style_selector' );
		$targets_root       = is_string( $requested_selector )
			&& self::SELECTOR === self::normalize_selector( $requested_selector );
		$tokens             = $request->get_param( self::TOKENS_META_KEY );
		$has_tokens         = null !== $tokens;

		// A create has no existing state to compare. Root creation remains owned
		// by resolve_for_dashboard(); ordinary class creation is unchanged.
		if ( ! $post instanceof WP_Post || 'gblocks_styles' !== $post->post_type ) {
			if ( $targets_root ) {
				return new WP_Error(
					'gb_root_style_protected',
					__( 'The managed :root Global Style cannot be created through the posts endpoint.', 'generateblocks-pro' ),
					[ 'status' => 409 ]
				);
			}

			// The root is never created here, so a create carrying tokens is
			// always a non-root token write. Reject it exactly like the update
			// path below, before the field callback can store the payload.
			if ( $has_tokens ) {
				return new WP_Error(
					'gb_design_tokens_non_root',
					__( 'Design Tokens can only be stored on the managed :root Global Style.', 'generateblocks-pro' ),
					[ 'status' => 400 ]
				);
			}

			return $prepared_post;
		}

		unset( self::$pending_rest_refresh[ $post_id ], self::$rest_aggregate[ $post_id ] );

		$is_root         = self::is_root_post( $post_id );
		$base_checksum   = $request->get_param( 'gb_base_checksum' );
		$has_checksum    = is_string( $base_checksum ) && '' !== $base_checksum;

		if ( $has_checksum ) {
			$checksum_error = self::validate_checksum(
				$post,
				$base_checksum,
				'gb_style_checksum_conflict',
				// No reload advice here: reloading discards staged edits. The
				// client offers a recovery that keeps them (root-entity.js).
				__( 'This Global Style changed in another session.', 'generateblocks-pro' )
			);

			if ( is_wp_error( $checksum_error ) ) {
				return $checksum_error;
			}
		}

		if ( ! $is_root && $targets_root ) {
			return new WP_Error(
				'gb_root_style_protected',
				__( 'Only the managed :root Global Style may use the :root selector.', 'generateblocks-pro' ),
				[ 'status' => 409 ]
			);
		}

		if ( $has_tokens && ! $is_root ) {
			return new WP_Error(
				'gb_design_tokens_non_root',
				__( 'Design Tokens can only be stored on the managed :root Global Style.', 'generateblocks-pro' ),
				[ 'status' => 400 ]
			);
		}

		if ( ! $is_root ) {
			return $prepared_post;
		}

		if ( ! $has_checksum ) {
			return new WP_Error(
				'gb_root_style_checksum_required',
				__( 'The :root Global Style must include its current checksum.', 'generateblocks-pro' ),
				[ 'status' => 400 ]
			);
		}

		if ( $has_tokens && ! GenerateBlocks_Pro_Design_Tokens::can_manage_tokens() ) {
			return new WP_Error(
				'gb_design_tokens_forbidden',
				__( 'You are not allowed to manage Design Tokens.', 'generateblocks-pro' ),
				[ 'status' => 403 ]
			);
		}

		$styles     = $request->get_param( 'gb_style_data' );
		$css        = $request->get_param( 'gb_style_css' );
		$has_styles = null !== $styles;
		$has_css    = null !== $css;

		if (
			$has_styles !== $has_css
			|| ( $has_styles && ! is_array( $styles ) )
			|| ( $has_css && ! is_string( $css ) )
			|| ( $has_tokens && ! is_array( $tokens ) )
		) {
			return new WP_Error(
				'gb_root_style_invalid_payload',
				__( 'Invalid :root Global Style payload.', 'generateblocks-pro' ),
				[ 'status' => 400 ]
			);
		}

		$current = self::get_state( $post );
		$normalized_tokens = null;

		if ( $has_tokens ) {
			$normalized_tokens = GenerateBlocks_Pro_Design_Tokens::normalize_tokens( $tokens );

			if ( is_wp_error( $normalized_tokens ) ) {
				return $normalized_tokens;
			}
		}

		$write = self::prepare_aggregate_write(
			$post,
			$current,
			$has_styles ? $styles : $current['styles'],
			$has_css ? $css : $current['css'],
			$normalized_tokens
		);

		if ( is_wp_error( $write ) ) {
			return $write;
		}

		if ( method_exists( $request, 'set_param' ) ) {
			// The selector param is what guarantees at least one managed root
			// field callback runs, which is where the aggregate is written.
			$request->set_param( 'gb_style_selector', self::SELECTOR );

			// The staged aggregate write is what persists these values. Keeping
			// the request itself canonical means nothing downstream can read
			// or write an un-normalized root value.
			if ( $has_css ) {
				$request->set_param( 'gb_style_css', $write['updates']['gb_style_css'] );
			}

			if ( $has_tokens ) {
				$request->set_param( self::TOKENS_META_KEY, $normalized_tokens );
			}
		}

		$prepared_post->post_title  = self::SELECTOR;
		$prepared_post->post_status = 'publish';

		// Stage only. Nothing is written and no recovery slot is consumed
		// until WordPress has updated the post row and the first managed root
		// field callback performs the aggregate write.
		self::$rest_aggregate[ $post_id ] = [
			'write'  => $write,
			'result' => null,
		];

		return $prepared_post;
	}

	/**
	 * Compare one client checksum against the current post state.
	 *
	 * Both the standard REST guard and trusted internal recovery writes use
	 * this primitive, so there is only one compare-and-swap implementation.
	 *
	 * @param WP_Post $post       Global Style post.
	 * @param string  $checksum   Client compare token.
	 * @param string  $error_code Error code for the calling surface.
	 * @param string  $message    Error message for the calling surface.
	 * @param array   $data       Additional error data.
	 * @return true|WP_Error
	 */
	private static function validate_checksum( WP_Post $post, string $checksum, string $error_code, string $message, array $data = [] ) {
		$current_checksum = self::get_post_checksum( $post );

		if ( '' !== $checksum && hash_equals( $current_checksum, $checksum ) ) {
			return true;
		}

		return new WP_Error(
			$error_code,
			$message,
			array_merge(
				[
					'status'          => 409,
					'currentChecksum' => $current_checksum,
				],
				$data
			)
		);
	}

	/**
	 * Rotate one already-built pre-save root payload.
	 *
	 * @param array $payload Snapshot payload.
	 */
	private static function rotate_snapshot( array $payload ): void {
		GenerateBlocks_Pro_Styles_Root_Snapshots::rotate( $payload );
	}

	/**
	 * Refresh root consumers after WordPress has written every REST field.
	 *
	 * @param WP_Post         $post     Updated style post.
	 * @param WP_REST_Request $request  REST request.
	 * @param bool            $creating Whether this was a create request.
	 */
	public function refresh_after_rest_write( $post, $request, $creating ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		$post_id = $post instanceof WP_Post ? (int) $post->ID : 0;

		if ( $post instanceof WP_Post && 'gblocks_styles' === $post->post_type ) {
			self::invalidate_resolve_cache();
		}

		if ( $creating || $post_id < 1 || empty( self::$pending_rest_refresh[ $post_id ] ) ) {
			return;
		}

		unset( self::$pending_rest_refresh[ $post_id ] );
		self::refresh_derivatives();
	}

	/**
	 * Derive names whose registry type or root value changed.
	 *
	 * @param array $before_tokens Registry before the request.
	 * @param array $after_tokens  Candidate registry.
	 * @param array $before_styles Root styles before the request.
	 * @param array $after_styles  Candidate root styles.
	 * @return string[]
	 */
	private static function get_changed_token_names( array $before_tokens, array $after_tokens, array $before_styles, array $after_styles ): array {
		$before_by_id   = [];
		$before_by_name = [];
		$changed        = [];

		foreach ( $before_tokens as $raw ) {
			$token = GenerateBlocks_Pro_Design_Tokens::sanitize_token( $raw );

			if ( null === $token ) {
				continue;
			}

			$before_by_id[ $token['id'] ]     = $token;
			$before_by_name[ $token['name'] ] = $token;
		}

		foreach ( $after_tokens as $raw ) {
			$token = GenerateBlocks_Pro_Design_Tokens::sanitize_token( $raw );

			if ( null === $token ) {
				continue;
			}

			$prior = $before_by_id[ $token['id'] ] ?? $before_by_name[ $token['name'] ] ?? null;
			$before_values = self::get_custom_property_values( $before_styles, $token['name'] );
			$after_values  = self::get_custom_property_values( $after_styles, $token['name'] );

			if (
				null === $prior
				|| $prior['name'] !== $token['name']
				|| $prior['type'] !== $token['type']
				|| $before_values !== $after_values
			) {
				$changed[] = $token['name'];
			}
		}

		return array_values( array_unique( $changed ) );
	}

	/**
	 * Validate values for tokens edited by this request. Unchanged legacy
	 * mismatches remain grandfathered.
	 *
	 * @param array $tokens Candidate registry.
	 * @param array $styles Candidate root styles.
	 * @param array $names  Changed token names.
	 * @return null|WP_Error
	 */
	private static function validate_changed_token_values( array $tokens, array $styles, array $names ) {
		$names = array_values( array_unique( array_filter( $names, 'is_string' ) ) );

		if ( [] === $names ) {
			return null;
		}

		$tokens_by_name = [];

		foreach ( $tokens as $raw ) {
			$token = GenerateBlocks_Pro_Design_Tokens::sanitize_token( $raw );

			if ( null !== $token ) {
				$tokens_by_name[ $token['name'] ] = $token;
			}
		}

		foreach ( $names as $name ) {
			if ( ! isset( $tokens_by_name[ $name ] ) ) {
				continue;
			}

			$token  = $tokens_by_name[ $name ];
			$values = self::get_custom_property_values( $styles, $name );

			foreach ( $values as $value ) {
				if ( ! GenerateBlocks_Pro_Design_Tokens::is_valid_value_for_type( $value, $token['type'] ) ) {
					return new WP_Error(
						'gb_design_tokens_invalid_value',
						sprintf(
							/* translators: %s: CSS custom property name. */
							__( '%s has a value that is not valid for its token type.', 'generateblocks-pro' ),
							$name
						),
						[ 'status' => 400 ]
					);
				}
			}
		}

		return null;
	}

	/**
	 * Prevent ordinary trash operations for every root candidate.
	 *
	 * @param mixed   $trash Whether to short-circuit trashing.
	 * @param WP_Post $post  Post being trashed.
	 * @return mixed
	 */
	public function guard_trash( $trash, $post ) {
		if ( self::$removing_candidate || ! $post instanceof WP_Post || 'gblocks_styles' !== $post->post_type ) {
			return $trash;
		}

		return self::is_root_post( (int) $post->ID ) ? false : $trash;
	}

	/**
	 * Prevent ordinary delete operations for every root candidate.
	 *
	 * @param mixed   $delete       Whether to short-circuit deletion.
	 * @param WP_Post $post         Post being deleted.
	 * @param bool    $force_delete Whether deletion is forced.
	 * @return mixed
	 */
	public function guard_delete( $delete, $post, $force_delete ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		if (
			self::$removing_candidate
			|| ! $post instanceof WP_Post
			|| 'gblocks_styles' !== $post->post_type
			|| 'trash' === $post->post_status
		) {
			return $delete;
		}

		return self::is_root_post( (int) $post->ID ) ? false : $delete;
	}

	/**
	 * Refresh derivatives when a trashed root is restored. Restoring is the one
	 * ordinary post lifecycle action we allow because it is the recovery path
	 * after choosing the wrong conflict candidate.
	 *
	 * @param int    $post_id         Restored post ID.
	 * @param string $previous_status Status saved when the post was trashed.
	 */
	public function refresh_after_untrash( $post_id, $previous_status = '' ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		$post = get_post( $post_id );

		if ( ! $post instanceof WP_Post || 'gblocks_styles' !== $post->post_type ) {
			return;
		}

		self::invalidate_resolve_cache();

		if ( self::is_root_post( (int) $post->ID ) ) {
			self::refresh_derivatives();
		}
	}

	/**
	 * Whether a specific record currently has the exact root selector.
	 *
	 * @param int $post_id Post ID.
	 */
	public static function is_root_post( int $post_id ): bool {
		return $post_id > 0
			&& self::SELECTOR === self::normalize_selector( (string) get_post_meta( $post_id, 'gb_style_selector', true ) );
	}

	/**
	 * Whether a managed candidate removal is currently in progress.
	 *
	 * The generic deletion hook uses this to avoid rebuilding derivatives in
	 * the middle of a repair when WordPress deletes instead of trashes posts.
	 */
	public static function is_removing_candidate(): bool {
		return self::$removing_candidate;
	}

	/**
	 * Trash or permanently delete one root candidate inside the managed repair
	 * boundary so the normal protection filters remain strict everywhere else.
	 *
	 * @param int  $post_id     Root post ID.
	 * @param bool $force_delete Whether to permanently delete instead of trash.
	 */
	private static function remove_root_candidate( int $post_id, bool $force_delete ): bool {
		$was_removing = self::$removing_candidate;
		self::$removing_candidate = true;

		try {
			$result = $force_delete
				? wp_delete_post( $post_id, true )
				: wp_trash_post( $post_id );
		} finally {
			self::$removing_candidate = $was_removing;
		}

		self::invalidate_resolve_cache();

		return false !== $result && null !== $result;
	}

	/**
	 * Restore meta captured before a failed logical save.
	 *
	 * @param int   $post_id Post ID.
	 * @param array $values  Meta values by key.
	 */
	private static function restore_meta( int $post_id, array $values ): void {
		foreach ( $values as $key => $slot ) {
			if ( ! $slot['exists'] ) {
				delete_post_meta( $post_id, $key );
				continue;
			}

			update_post_meta( $post_id, $key, wp_slash( $slot['value'] ) );
		}

		self::invalidate_resolve_cache();
	}

	/**
	 * Capture one meta value without losing whether the row was absent.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $key     Meta key.
	 * @return array{exists:bool,value:mixed}
	 */
	private static function capture_meta( int $post_id, string $key ): array {
		$value = get_post_meta( $post_id, $key, true );
		$exists = function_exists( 'metadata_exists' )
			? metadata_exists( 'post', $post_id, $key )
			: '' !== $value;

		return [
			'exists' => $exists,
			'value'  => $value,
		];
	}

	/**
	 * Wrap normalized Design Token rows for meta and snapshot storage.
	 *
	 * @param array $tokens Token registry rows.
	 */
	private static function token_envelope( array $tokens ): array {
		return class_exists( 'GenerateBlocks_Pro_Design_Tokens' )
			? GenerateBlocks_Pro_Design_Tokens::envelope( $tokens )
			: [
				'version' => 1,
				'tokens'  => array_values( $tokens ),
			];
	}

	/**
	 * Rebuild every derivative that consumes Global Styles or token usages.
	 */
	private static function refresh_derivatives(): void {
		if ( class_exists( 'GenerateBlocks_Pro_Enqueue_Styles' ) ) {
			GenerateBlocks_Pro_Enqueue_Styles::get_instance()->build_css();
		} elseif ( class_exists( 'GenerateBlocks_Pro_Design_Tokens_Usage' ) ) {
			GenerateBlocks_Pro_Design_Tokens_Usage::clear_cache();
		}
	}
}

GenerateBlocks_Pro_Styles_Root::get_instance()->init();
