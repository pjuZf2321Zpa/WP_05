<?php
/**
 * The Utility Class post type file.
 *
 * @package GenerateBlocksPro\Post_Types
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class to register post type Utility Classes.
 *
 * @since 1.7.0
 */
class GenerateBlocks_Pro_Styles_Post_Type extends GenerateBlocks_Pro_Singleton {

	/**
	 * Initialize the class filters.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'init', array( $this, 'register_post_type' ) );
		add_filter( 'rest_pre_insert_gblocks_styles', array( $this, 'guard_ordinary_rest_write' ), 9, 2 );
	}

	/**
	 * Validate an ordinary Global Style's selector ownership before REST writes.
	 *
	 * Core writes registered additional fields independently, so this pre-insert
	 * veto point validates the complete selector/target relationship before any
	 * field callback can run. The existing post controller fires its final
	 * wp_after_insert_post action after those callbacks, which keeps the generated
	 * stylesheet rebuild on the stable record.
	 *
	 * @param WP_Post|WP_Error $prepared_post Prepared post data.
	 * @param WP_REST_Request  $request       REST request.
	 * @return WP_Post|WP_Error
	 */
	public function guard_ordinary_rest_write( $prepared_post, $request ) {
		if ( is_wp_error( $prepared_post ) ) {
			return $prepared_post;
		}

		$requested_selector = $request->get_param( 'gb_style_selector' );
		$requested_targets = $request->get_param( 'gb_style_targets' );
		$requested_targets_css = $request->get_param( 'gb_style_targets_css' );

		$post_id = isset( $prepared_post->ID )
			? (int) $prepared_post->ID
			: (int) $request->get_param( 'id' );
		$post = $post_id > 0 ? get_post( $post_id ) : null;

		// An existing declaration-only save does not touch selector ownership.
		// A create must still validate its title fallback even when a crafted
		// request omits all custom fields.
		if (
			$post instanceof WP_Post
			&& null === $requested_selector
			&& null === $requested_targets
			&& null === $requested_targets_css
		) {
			return $prepared_post;
		}

		$stored_selector = $post instanceof WP_Post
			? get_post_meta( $post_id, 'gb_style_selector', true )
			: '';
		$current_title = $post instanceof WP_Post ? (string) $post->post_title : '';
		$submitted_title = $current_title;

		if ( isset( $prepared_post->post_title ) && is_string( $prepared_post->post_title ) ) {
			$submitted_title = $prepared_post->post_title;
		}

		$current_selector = ! empty( $stored_selector )
			? (string) $stored_selector
			: $current_title;
		$submitted_selector = null !== $requested_selector
			? $requested_selector
			: $stored_selector;
		$selector = ! empty( $submitted_selector )
			? $submitted_selector
			: $submitted_title;

		if ( ! is_string( $selector ) ) {
			return new WP_Error(
				'gb_style_selector_invalid',
				__( 'The Global Style selector is invalid.', 'generateblocks-pro' ),
				array( 'status' => 400 )
			);
		}

		$is_root = ':root' === strtolower( trim( $selector ) )
			|| (
				$post instanceof WP_Post
				&& class_exists( 'GenerateBlocks_Pro_Styles_Root' )
				&& GenerateBlocks_Pro_Styles_Root::is_root_post( $post_id )
			);

		// The managed :root service owns its aggregate. It never accepts selector
		// targets, and its existing guard/callback path handles every valid write.
		if ( $is_root ) {
			if ( null !== $requested_targets && array() !== $requested_targets ) {
				return new WP_Error(
					'gb_root_style_targets_forbidden',
					__( 'The managed :root Global Style cannot have additional selectors.', 'generateblocks-pro' ),
					array( 'status' => 400 )
				);
			}

			return $prepared_post;
		}

		$selector_changed = ! $post instanceof WP_Post || $selector !== $current_selector;

		if ( $selector_changed ) {
			$canonical_selector = GenerateBlocks_Pro_Styles::canonicalize_primary_selector( $selector );

			if ( '' === $canonical_selector ) {
				return new WP_Error(
					'gb_style_primary_selector_invalid',
					sprintf(
						/* translators: %s: submitted CSS selector. */
						__( 'The Global Style selector "%s" is not a supported base selector.', 'generateblocks-pro' ),
						$selector
					),
					array( 'status' => 400 )
				);
			}

			// Every ordinary client canonicalizes before writing. Reject crafted
			// requests instead of silently changing the entity key underneath them.
			if ( $canonical_selector !== $selector ) {
				return new WP_Error(
					'gb_style_primary_selector_not_canonical',
					sprintf(
						/* translators: %s: canonical CSS selector. */
						__( 'Use the canonical Global Style selector "%s".', 'generateblocks-pro' ),
						$canonical_selector
					),
					array(
						'status'    => 400,
						'canonical' => $canonical_selector,
					)
				);
			}
		}

		$current_targets = $post instanceof WP_Post ? get_post_meta( $post_id, 'gb_style_targets', true ) : array();
		$current_targets_css = $post instanceof WP_Post ? get_post_meta( $post_id, 'gb_style_targets_css', true ) : '';

		if ( ! is_array( $current_targets ) && ! metadata_exists( 'post', $post_id, 'gb_style_targets' ) ) {
			$current_targets = array();
		}

		$targets = null !== $requested_targets ? $requested_targets : $current_targets;
		$targets_css = null !== $requested_targets_css ? $requested_targets_css : $current_targets_css;

		if (
			null !== $requested_targets
			&& null === $requested_targets_css
			&& '' !== $current_targets_css
		) {
			return new WP_Error(
				'gb_style_targets_css_required',
				__( 'Additional selectors and their compiled CSS must be saved together.', 'generateblocks-pro' ),
				array( 'status' => 400 )
			);
		}

		if ( ! is_string( $targets_css ) ) {
			return new WP_Error(
				'gb_style_targets_css_invalid',
				__( 'The Global Style payload is invalid.', 'generateblocks-pro' ),
				array( 'status' => 400 )
			);
		}

		$targets = GenerateBlocks_Pro_Styles::validate_style_targets( $targets, $selector );

		if ( is_wp_error( $targets ) ) {
			return $targets;
		}

		if (
			array() === $targets
			&& '' !== wp_strip_all_tags( $targets_css )
			&& ( null !== $requested_targets || null !== $requested_targets_css )
		) {
			return new WP_Error(
				'gb_style_targets_css_without_targets',
				__( 'Additional selector CSS cannot be saved without additional selectors.', 'generateblocks-pro' ),
				array( 'status' => 400 )
			);
		}

		// Only structural writes claim selector ownership. A declaration-only save
		// must not become a repair gate for previously supported duplicate records.
		$current_normalized_targets = GenerateBlocks_Pro_Styles::sanitize_style_targets( $current_targets );
		$targets_changed = null !== $requested_targets && $targets !== $current_normalized_targets;
		$claimed_selector = $selector_changed ? $selector : '';
		$claimed_targets = $targets_changed
			? array_values( array_diff( $targets, $current_normalized_targets ) )
			: array();

		if ( '' !== $claimed_selector || array() !== $claimed_targets ) {
			$ownership = GenerateBlocks_Pro_Styles::validate_selector_ownership(
				$claimed_selector,
				$claimed_targets,
				$post_id
			);

			if ( is_wp_error( $ownership ) ) {
				return $ownership;
			}
		}

		if ( null !== $requested_targets ) {
			$request->set_param( 'gb_style_targets', $targets );
		}

		return $prepared_post;
	}

	/**
	 * Update one custom REST field without confusing an unchanged value for a
	 * failed database write.
	 *
	 * Core's REST meta controller performs the same equality pre-check before
	 * treating update_metadata() returning false as an error. These fields are
	 * registered with register_rest_field(), so they need to preserve that
	 * contract themselves.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $key     Meta key.
	 * @param mixed  $value   Unslashed value to persist.
	 * @return true|WP_Error
	 */
	private static function update_rest_meta( int $post_id, string $key, $value ) {
		if (
			metadata_exists( 'post', $post_id, $key )
			&& get_post_meta( $post_id, $key, true ) === $value
		) {
			return true;
		}

		if ( update_post_meta( $post_id, $key, wp_slash( $value ) ) ) {
			return true;
		}

		return new WP_Error(
			'gb_style_meta_update_failed',
			__( 'The Global Style could not be saved.', 'generateblocks-pro' ),
			array(
				'status' => 500,
				'key'    => $key,
			)
		);
	}

	/**
	 * Hand a managed :root field write to the one aggregate write path.
	 *
	 * The pre-insert guard validates the whole :root aggregate and stages it,
	 * and the first managed root field callback of the request writes all of
	 * it at once. Returns null for ordinary Global Styles, which keep using
	 * their established individual-field callbacks.
	 *
	 * @param mixed $post Post being updated.
	 * @return true|WP_Error|null
	 */
	private static function write_root_aggregate( $post ) {
		if ( ! class_exists( 'GenerateBlocks_Pro_Styles_Root' ) ) {
			return null;
		}

		return GenerateBlocks_Pro_Styles_Root::write_staged_rest_aggregate( $post );
	}

	/**
	 * Register the post type.
	 *
	 * @return void
	 */
	public function register_post_type() {
		register_post_type(
			'gblocks_styles',
			array(
				'labels' => array(
					'name'               => _x( 'Global Styles', 'Post Type General Name', 'generateblocks-pro' ),
					'singular_name'      => _x( 'Global Style', 'Post Type Singular Name', 'generateblocks-pro' ),
					'menu_name'          => __( 'Global Styles', 'generateblocks-pro' ),
					'parent_item_colon'  => __( 'Parent Global Style', 'generateblocks-pro' ),
					'all_items'          => __( 'Global Styles', 'generateblocks-pro' ),
					'view_item'          => __( 'View Global Style', 'generateblocks-pro' ),
					'add_new_item'       => __( 'Add New Global Style', 'generateblocks-pro' ),
					'add_new'            => __( 'Add New Global Style', 'generateblocks-pro' ),
					'edit_item'          => __( 'Edit Global Style', 'generateblocks-pro' ),
					'update_item'        => __( 'Update Global Style', 'generateblocks-pro' ),
					'search_items'       => __( 'Search Global Styles', 'generateblocks-pro' ),
					'not_found'          => __( 'Not Found', 'generateblocks-pro' ),
					'not_found_in_trash' => __( 'Not found in Trash', 'generateblocks-pro' ),
				),
				'public'              => false,
				'publicly_queryable'  => false,
				'has_archive'         => false,
				'show_ui'             => false,
				'show_in_menu'        => false,
				'exclude_from_search' => true,
				'show_in_nav_menus'   => false,
				'rewrite'             => false,
				'hierarchical'        => false,
				'show_in_admin_bar'   => false,
				'show_in_rest'        => true,
				'supports'            => array( 'title', 'page-attributes' ),
				'capabilities' => array(
					'publish_posts'       => GenerateBlocks_Pro_Styles::get_manage_styles_capability(),
					'edit_posts'          => GenerateBlocks_Pro_Styles::get_manage_styles_capability(),
					'edit_others_posts'   => GenerateBlocks_Pro_Styles::get_manage_styles_capability(),
					'delete_posts'        => GenerateBlocks_Pro_Styles::get_manage_styles_capability(),
					'delete_others_posts' => GenerateBlocks_Pro_Styles::get_manage_styles_capability(),
					'read_private_posts'  => GenerateBlocks_Pro_Styles::get_manage_styles_capability(),
					'edit_post'           => GenerateBlocks_Pro_Styles::get_manage_styles_capability(),
					'delete_post'         => GenerateBlocks_Pro_Styles::get_manage_styles_capability(),
					'read_post'           => GenerateBlocks_Pro_Styles::get_manage_styles_capability(),
				),
			)
		);

		register_post_meta(
			'gblocks_styles',
			'gb_style_selector',
			array(
				'type' => 'string',
				'default' => '',
				'show_in_rest' => false,
			)
		);

		register_post_meta(
			'gblocks_styles',
			'gb_style_css',
			array(
				'type' => 'string',
				'default' => '',
				'show_in_rest' => false,
			)
		);

		register_post_meta(
			'gblocks_styles',
			'gb_style_targets',
			array(
				'type'              => 'array',
				'default'           => array(),
				'show_in_rest'      => false,
				'sanitize_callback' => array( 'GenerateBlocks_Pro_Styles', 'sanitize_style_targets' ),
			)
		);

		register_post_meta(
			'gblocks_styles',
			'gb_style_targets_css',
			array(
				'type'         => 'string',
				'default'      => '',
				'show_in_rest' => false,
			)
		);

		// Display-only grouping metadata for the Global Styles list. It never
		// takes part in CSS emission — `menu_order` remains the sole source of
		// cascade order — so an empty or malformed value simply reads as
		// uncategorized.
		register_post_meta(
			'gblocks_styles',
			'gb_style_category',
			array(
				'type'              => 'string',
				'default'           => '',
				'show_in_rest'      => false,
				'sanitize_callback' => array( 'GenerateBlocks_Pro_Styles', 'sanitize_category' ),
			)
		);

		register_post_meta(
			'gblocks_styles',
			'gb_style_data',
			array(
				'type' => 'array',
				'show_in_rest' => false,
			)
		);

		register_post_meta(
			'gblocks_styles',
			'gb_style_tokens',
			array(
				'type' => 'array',
				'show_in_rest' => false,
			)
		);

		register_rest_field(
			'gblocks_styles',
			'gb_style_selector',
			array(
				'get_callback'    => function ( $data ) {
					return get_post_meta( $data['id'], 'gb_style_selector', true );
				},
				'update_callback' => function ( $value, $post ) {
					$aggregate = self::write_root_aggregate( $post );

					return null === $aggregate
						? self::update_rest_meta( $post->ID, 'gb_style_selector', $value )
						: $aggregate;
				},
				'schema'          => array(
					// The pre-insert guard validates the exact submitted identity;
					// do not silently sanitize it into a different selector first.
					'type' => 'string',
				),
			)
		);

		register_rest_field(
			'gblocks_styles',
			'gb_style_css',
			array(
				'get_callback'    => function ( $data ) {
					return get_post_meta( $data['id'], 'gb_style_css', true );
				},
				'update_callback' => function ( $value, $post ) {
					$aggregate = self::write_root_aggregate( $post );

					return null === $aggregate
						? self::update_rest_meta( $post->ID, 'gb_style_css', $value )
						: $aggregate;
				},
				'schema'          => array(
					'type'        => 'string',
					'arg_options' => array(
						'sanitize_callback' => function ( $value ) {
							return wp_strip_all_tags( $value );
						},
					),
				),
			)
		);

		register_rest_field(
			'gblocks_styles',
			'gb_style_targets',
			array(
				'get_callback'    => function ( $data ) {
					return GenerateBlocks_Pro_Styles::sanitize_style_targets(
						get_post_meta( $data['id'], 'gb_style_targets', true )
					);
				},
				'update_callback' => function ( $value, $post ) {
					$aggregate = self::write_root_aggregate( $post );

					if ( null !== $aggregate ) {
						return $aggregate;
					}

					$stored_primary = get_post_meta( $post->ID, 'gb_style_selector', true );
					$primary = ! empty( $stored_primary )
						? (string) $stored_primary
						: (string) $post->post_title;
					$targets = GenerateBlocks_Pro_Styles::validate_style_targets( $value, $primary );

					return is_wp_error( $targets )
						? $targets
						: self::update_rest_meta( $post->ID, 'gb_style_targets', $targets );
				},
				'schema'          => array(
					'type'    => 'array',
					'default' => array(),
					'items'   => array(
						'type' => 'string',
					),
				),
			)
		);

		register_rest_field(
			'gblocks_styles',
			'gb_style_targets_css',
			array(
				'get_callback'    => function ( $data ) {
					$value = get_post_meta( $data['id'], 'gb_style_targets_css', true );

					return is_string( $value ) ? $value : '';
				},
				'update_callback' => function ( $value, $post ) {
					$aggregate = self::write_root_aggregate( $post );

					return null === $aggregate
						? self::update_rest_meta( $post->ID, 'gb_style_targets_css', wp_strip_all_tags( $value ) )
						: $aggregate;
				},
				'schema'          => array(
					'type'    => 'string',
					'default' => '',
					'arg_options' => array(
						'sanitize_callback' => function ( $value ) {
							return wp_strip_all_tags( $value );
						},
					),
				),
			)
		);

		register_rest_field(
			'gblocks_styles',
			'gb_style_category',
			array(
				'get_callback'    => function ( $data ) {
					$category = get_post_meta( $data['id'], 'gb_style_category', true );

					return GenerateBlocks_Pro_Styles::sanitize_category( $category );
				},
				'update_callback' => function ( $value, $post ) {
					$category = GenerateBlocks_Pro_Styles::sanitize_category( $value );

					return self::update_rest_meta( $post->ID, 'gb_style_category', $category );
				},
				'schema'          => array(
					'type'        => 'string',
					'default'     => '',
					'arg_options' => array(
						'sanitize_callback' => function ( $value ) {
							return GenerateBlocks_Pro_Styles::sanitize_category( $value );
						},
					),
				),
			)
		);

		register_rest_field(
			'gblocks_styles',
			'gb_style_data',
			array(
				'get_callback'    => function ( $data ) {
					return get_post_meta( $data['id'], 'gb_style_data', true );
				},
				'update_callback' => function ( $value, $post ) {
					$aggregate = self::write_root_aggregate( $post );

					return null === $aggregate
						? self::update_rest_meta( $post->ID, 'gb_style_data', $value )
						: $aggregate;
				},
			)
		);

		register_rest_field(
			'gblocks_styles',
			'gb_style_tokens',
			array(
				'get_callback'    => function ( $data ) {
					$post = get_post( $data['id'] );

					if ( ! $post instanceof WP_Post || ! class_exists( 'GenerateBlocks_Pro_Design_Tokens' ) ) {
						return array();
					}

					$state = GenerateBlocks_Pro_Design_Tokens::read_state( $post );

					return $state['tokens'];
				},
				'update_callback' => function ( $value, $post ) {
					// Validation and normalization already ran in the pre-insert
					// guard, before WordPress wrote the post row.
					$aggregate = self::write_root_aggregate( $post );

					if ( null !== $aggregate ) {
						return $aggregate;
					}

					if ( ! is_array( $value ) || ! class_exists( 'GenerateBlocks_Pro_Design_Tokens' ) ) {
						return;
					}

					return self::update_rest_meta(
						$post->ID,
						'gb_style_tokens',
						GenerateBlocks_Pro_Design_Tokens::envelope( $value )
					);
				},
				'schema'          => array(
					'type' => 'array',
				),
			)
		);

		register_rest_field(
			'gblocks_styles',
			'gb_current_checksum',
			array(
				'get_callback' => function ( $data ) {
					$post = get_post( $data['id'] );

					if ( ! $post instanceof WP_Post || ! class_exists( 'GenerateBlocks_Pro_Styles_Root' ) ) {
						return '';
					}

					return GenerateBlocks_Pro_Styles_Root::get_post_checksum( $post );
				},
				'schema'       => array(
					'type'     => 'string',
					'readonly' => true,
				),
			)
		);

		register_rest_field(
			'gblocks_styles',
			'gb_base_checksum',
			array(
				'get_callback'    => function () {
					// This is deliberately request-only. The client adds it at the
					// REST save boundary instead of storing it in core-data, where an
					// Undo/Redo level could strand it as a checksum-only edit.
					// gb_current_checksum is the distinct persisted-state read source.
					return '';
				},
				'update_callback' => function () {
					// Consumed by rest_pre_insert_gblocks_styles. Never persisted.
					return true;
				},
				'schema'          => array(
					'type'    => 'string',
					'default' => '',
				),
			)
		);
	}
}

GenerateBlocks_Pro_Styles_Post_Type::get_instance()->init();
