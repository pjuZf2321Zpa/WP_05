<?php
/**
 * The Global Class file.
 *
 * @package GenerateBlocks\Global_Classes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class for handling global classes.
 *
 * @since 1.9.0
 */
class GenerateBlocks_Pro_Styles extends GenerateBlocks_Pro_Singleton {
	/**
	 * Maximum length of a Global Style category name.
	 */
	const CATEGORY_MAX_LENGTH = 100;

	/**
	 * Initialize the class filters.
	 *
	 * @return void
	 */
	public function init() {
		add_filter( 'block_editor_settings_all', [ $this, 'add_editor_styles_css' ], 21 );

		// Add global classes to dynamic elements.
		add_filter( 'generateblocks_attr_container', [ $this, 'add_global_class_names' ], 10, 2 );
		add_filter( 'generateblocks_attr_grid-wrapper', [ $this, 'add_global_class_names' ], 10, 2 );
		add_filter( 'generateblocks_attr_image', [ $this, 'add_global_class_names' ], 10, 2 );
		add_filter( 'generateblocks_attr_dynamic-headline', [ $this, 'add_global_class_names' ], 10, 2 );
		add_filter( 'generateblocks_attr_dynamic-button', [ $this, 'add_global_class_names' ], 10, 2 );
	}

	/**
	 * Get an array of our global styles.
	 * These styles are sorted so child styles show up immediately after their parents.
	 *
	 * @param array $custom_args Any custom args to be passed to the query.
	 */
	public static function get_styles( array $custom_args = [] ) {
		$styles = [];

		self::loop_styles(
			function ( $post, $meta ) use ( &$styles ) {
				$selector = ! empty( $meta['gb_style_selector'] ) ? $meta['gb_style_selector'] : $post->post_title;
				$kind     = self::get_selector_kind( $selector );
				$category = $meta['gb_style_category'] ?? '';
				$targets  = self::sanitize_style_targets( $meta['gb_style_targets'] ?? [] );
				$styles[] = [
					'ID'         => $post->ID,
					'style'      => 'root' === $kind ? $selector : $post->post_title,
					'selector'   => $selector,
					'targets'    => $targets,
					'kind'       => $kind,
					'status'     => $post->post_status,
					'menu_order' => $post->menu_order,
					// Display-only grouping metadata. It has no bearing on the
					// order styles are emitted in — that stays `menu_order` —
					// so anything unexpected reads as uncategorized.
					'category'   => self::sanitize_category( $category ),
				];
			},
			$custom_args,
			[ 'gb_style_selector', 'gb_style_category', 'gb_style_targets' ]
		);

		return $styles;
	}

	/**
	 * Build our global class CSS.
	 *
	 * @param boolean $cached Whether we should the cached data or not.
	 */
	public static function get_styles_css( $cached = true ) {
		$cached_css = get_option( 'generateblocks_style_css', '' );

		if ( $cached && ! empty( $cached_css ) ) {
			return $cached_css;
		}

		$root_css = '';
		$root_id  = 0;
		$css      = '';

		self::loop_styles(
			function ( $post, $meta ) use ( &$root_css, &$root_id, &$css ) {
				$selector = (string) ( $meta['gb_style_selector'] ?? '' );

				if ( ':root' === strtolower( trim( $selector ) ) ) {
					// The loop already selects published posts. Keep the lowest ID
					// if duplicate roots exist, without invoking the write resolver.
					if ( ! $root_id || (int) $post->ID < $root_id ) {
						$root_id  = (int) $post->ID;
						$root_css = (string) ( $meta['gb_style_css'] ?? '' );
					}

					return;
				}

				if ( isset( $meta['gb_style_css'] ) ) {
					// Targets share their authority's one cascade position, so their
					// derived CSS is emitted immediately after the primary CSS.
					$css .= $meta['gb_style_css'] . ( $meta['gb_style_targets_css'] ?? '' );
				}
			},
			[],
			[ 'gb_style_css', 'gb_style_targets_css', 'gb_style_selector' ]
		);

		$css = $root_css . $css;

		// Cache our results.
		update_option( 'generateblocks_style_css', $css );

		return $css;
	}

	/**
	 * Add our global CSS to the editor.
	 *
	 * This adds a single instance per class, which allows us to live edit each
	 * class in the editor without affecting the others.
	 *
	 * These entries intentionally carry the raw frontend CSS (the canonical
	 * `gb_style_css` plus its adjacent `gb_style_targets_css`). Core injects
	 * them into the canvas untransformed,
	 * so `scopePersistedEditorStyleCSS()` (global-classes-preview-sync.js)
	 * rescopes them client-side in the editor; scoping is not duplicated
	 * here in PHP.
	 *
	 * @param array $editor_settings Existing editor settings.
	 */
	public function add_editor_styles_css( $editor_settings ) {
		$root_styles = [];
		$other_styles = [];
		$root_id = 0;

		self::loop_styles(
			function ( $post, $meta ) use ( &$root_styles, &$other_styles, &$root_id ) {
				$primary_css = (string) ( $meta['gb_style_css'] ?? '' );
				$targets_css = (string) ( $meta['gb_style_targets_css'] ?? '' );
				$class_css  = $primary_css . $targets_css;
				$class_name = $meta['gb_style_selector'] ?? '';

				if ( '' === $class_css || '' === $class_name ) {
					return;
				}

				$style = [
					'css'    => $class_css,
					'source' => 'gb_class:' . $class_name,
				];

				if ( '' !== $targets_css ) {
					$style['gbStyleCssParts'] = [
						'primaryCss'     => $primary_css,
						'targetsCss'     => $targets_css,
						'targetSelectors' => is_array( $meta['gb_style_targets'] ?? null )
							? array_values( $meta['gb_style_targets'] )
							: [],
					];
				}

				if ( ':root' === strtolower( trim( $class_name ) ) ) {
					if ( ! $root_id || (int) $post->ID < $root_id ) {
						$root_id = (int) $post->ID;
						$style['source'] = 'gb_root';
						$root_styles = [ $style ];
					}

					return;
				}

				$other_styles[] = $style;
			},
			[],
			[ 'gb_style_css', 'gb_style_targets_css', 'gb_style_selector', 'gb_style_targets' ]
		);

		if ( ! isset( $editor_settings['styles'] ) || ! is_array( $editor_settings['styles'] ) ) {
			$editor_settings['styles'] = [];
		}

		$editor_settings['styles'] = array_merge( $editor_settings['styles'], $root_styles, $other_styles );

		return $editor_settings;
	}

	/**
	 * Add global classes to dynamic HTML blocks.
	 *
	 * @param array $htmlAttributes Current HTML attributes.
	 * @param array $blockAttributes Attributes for the current block.
	 */
	public function add_global_class_names( $htmlAttributes, $blockAttributes ) {
		if ( ! empty( $blockAttributes['globalClasses'] ) ) {
			$classes = implode( ' ', $blockAttributes['globalClasses'] );

			if ( ! empty( $classes ) ) {
				$htmlAttributes['class'] .= ' ' . esc_attr( $classes );
			}
		}

		return $htmlAttributes;
	}

	/**
	 * The default capability for users who can manage classes.
	 */
	public static function get_manage_styles_capability() {
		return apply_filters(
			'generateblocks_manage_classes_capability',
			'manage_options'
		);
	}

	/**
	 * Check if we can manage classes.
	 */
	public static function can_manage_styles() {
		$can_manage = current_user_can( self::get_manage_styles_capability() );
		$additional_checks = apply_filters(
			'generateblocks_can_manage_styles',
			true
		);

		return $can_manage && $additional_checks;
	}

	/**
	 * Normalize display-only Global Style category metadata.
	 *
	 * Category data can come from REST, old post meta, filters, or direct writes.
	 * Keep every read and write on the same small contract: scalar text only,
	 * tags stripped, surrounding whitespace removed, and at most 100 characters.
	 * mbstring is optional in WordPress, so fall back to byte-safe truncation
	 * rather than fatally requiring the extension.
	 *
	 * @param mixed $category Raw category value.
	 * @return string Normalized category name, or an empty string.
	 */
	public static function sanitize_category( $category ): string {
		if ( ! is_scalar( $category ) ) {
			return '';
		}

		$category = trim( wp_strip_all_tags( (string) $category ) );
		$category = function_exists( 'mb_substr' )
			? mb_substr( $category, 0, self::CATEGORY_MAX_LENGTH )
			: substr( $category, 0, self::CATEGORY_MAX_LENGTH );

		return trim( $category );
	}

	/**
	 * Reduce stored selector targets to the safe canonical read shape.
	 *
	 * REST writes use validate_style_targets() so invalid user input is rejected
	 * with a useful error. This read-side normalizer is deliberately defensive:
	 * malformed values from an unsupported direct write are inert instead of
	 * reaching CSS compilation, lookup, or the editor.
	 *
	 * @param mixed $targets Raw target metadata.
	 * @return string[]
	 */
	public static function sanitize_style_targets( $targets ): array {
		if ( ! is_array( $targets ) ) {
			return [];
		}

		$normalized = [];

		foreach ( $targets as $target ) {
			if ( ! is_string( $target ) ) {
				continue;
			}

			$target = trim( $target );

			if (
				'' === $target
				|| ':root' === strtolower( $target )
				|| ! self::is_valid_selector( $target, true )
				|| in_array( $target, $normalized, true )
			) {
				continue;
			}

			$normalized[] = $target;
		}

		return $normalized;
	}

	/**
	 * Get the selectors that can be assigned through a block class attribute.
	 *
	 * A Global Style may target any supported selector, but the block picker can
	 * only assign one standalone class. Keep this projection derived from the
	 * authority instead of creating independently writable alias records.
	 *
	 * @param string $primary_selector Authority selector.
	 * @param mixed  $targets          Raw target metadata.
	 * @return string[] Ordered standalone class selectors.
	 */
	public static function get_assignable_class_selectors( string $primary_selector, $targets = [] ): array {
		$selectors = array_merge(
			[ trim( $primary_selector ) ],
			self::sanitize_style_targets( $targets )
		);
		$assignable = [];

		foreach ( $selectors as $selector ) {
			if (
				! self::is_valid_selector( $selector, false )
				|| in_array( $selector, $assignable, true )
			) {
				continue;
			}

			$assignable[] = $selector;
		}

		return $assignable;
	}

	/**
	 * Validate and normalize one submitted selector-target list.
	 *
	 * Each row is one complete selector. Top-level selector lists are rejected by
	 * is_valid_selector(); commas inside balanced pseudo-classes and attributes
	 * remain valid. The primary selector is never repeated as one of its targets.
	 *
	 * @param mixed  $targets         Submitted target list.
	 * @param string $primary_selector Authority selector.
	 * @return string[]|WP_Error
	 */
	public static function validate_style_targets( $targets, string $primary_selector = '' ) {
		if ( ! is_array( $targets ) ) {
			return new WP_Error(
				'gb_style_targets_invalid_type',
				__( 'Additional selectors must be provided as a list.', 'generateblocks-pro' ),
				[ 'status' => 400 ]
			);
		}

		$primary_selector = trim( $primary_selector );
		$normalized = [];

		foreach ( $targets as $target ) {
			if ( ! is_string( $target ) ) {
				return new WP_Error(
					'gb_style_target_invalid',
					__( 'Each additional selector must be a string.', 'generateblocks-pro' ),
					[ 'status' => 400 ]
				);
			}

			$target = trim( $target );

			if ( '' === $target ) {
				return new WP_Error(
					'gb_style_target_empty',
					__( 'An additional selector cannot be empty.', 'generateblocks-pro' ),
					[ 'status' => 400 ]
				);
			}

			if ( ':root' === strtolower( $target ) ) {
				return new WP_Error(
					'gb_style_target_root',
					__( ':root cannot be used as an additional selector.', 'generateblocks-pro' ),
					[ 'status' => 400 ]
				);
			}

			if ( ! self::is_valid_selector( $target, true ) ) {
				return new WP_Error(
					'gb_style_target_invalid',
					__( 'An additional selector is not valid.', 'generateblocks-pro' ),
					[
						'status'   => 400,
						'selector' => $target,
					]
				);
			}

			if ( '' !== $primary_selector && $target === $primary_selector ) {
				return new WP_Error(
					'gb_style_target_matches_primary',
					__( 'An additional selector cannot match the style selector.', 'generateblocks-pro' ),
					[
						'status'   => 400,
						'selector' => $target,
					]
				);
			}

			if ( in_array( $target, $normalized, true ) ) {
				return new WP_Error(
					'gb_style_target_duplicate',
					__( 'An additional selector is listed more than once.', 'generateblocks-pro' ),
					[
						'status'   => 400,
						'selector' => $target,
					]
				);
			}

			$normalized[] = $target;
		}

		return $normalized;
	}

	/**
	 * Build the exact selector ownership map in one bounded style-library scan.
	 *
	 * Primary selectors are mapped first, so unsupported conflicting target meta
	 * can never hide a real style identity. Published and draft records are both
	 * included by the established `any` status query.
	 *
	 * @param int $exclude_post_id Style ID to exclude while validating an update.
	 * @return array<string, array{ownerId:int,ownerSelector:string,type:string,status:string}>
	 */
	public static function get_selector_ownership_map( int $exclude_post_id = 0 ): array {
		// Ownership is an invariant across the complete published/draft library,
		// not only the ordinary 5,000-record read window. loop_styles() still
		// processes this unlimited request in bounded batches.
		$styles = self::get_styles(
			[
				'post_status'    => 'any',
				'posts_per_page' => -1,
			]
		);
		$owners = [];

		foreach ( $styles as $style ) {
			$style_id = (int) ( $style['ID'] ?? 0 );
			$selector = is_string( $style['selector'] ?? null ) ? trim( $style['selector'] ) : '';

			if ( $style_id < 1 || $style_id === $exclude_post_id || '' === $selector ) {
				continue;
			}

			// First wins, exactly as the target loop below and both client maps
			// resolve it, so pre-existing duplicate primary data always names
			// the same owner wherever it is reported.
			if ( isset( $owners[ $selector ] ) ) {
				continue;
			}

			$owners[ $selector ] = [
				'ownerId'       => $style_id,
				'ownerSelector' => $selector,
				'type'          => 'primary',
				'status'        => (string) ( $style['status'] ?? '' ),
			];
		}

		foreach ( $styles as $style ) {
			$style_id = (int) ( $style['ID'] ?? 0 );
			$primary = is_string( $style['selector'] ?? null ) ? trim( $style['selector'] ) : '';

			if ( $style_id < 1 || $style_id === $exclude_post_id || '' === $primary ) {
				continue;
			}

			foreach ( self::sanitize_style_targets( $style['targets'] ?? [] ) as $target ) {
				if ( isset( $owners[ $target ] ) ) {
					continue;
				}

				$owners[ $target ] = [
					'ownerId'       => $style_id,
					'ownerSelector' => $primary,
					'type'          => 'target',
					'status'        => (string) ( $style['status'] ?? '' ),
				];
			}
		}

		return $owners;
	}

	/**
	 * Find the Global Style that exactly owns one selector.
	 *
	 * `ownerSelector` is the owning authority's PRIMARY selector, which is the
	 * selector the user can actually find in the list — for a `target` hit it is
	 * not the selector that was looked up.
	 *
	 * @param string $selector        Exact selector.
	 * @param int    $exclude_post_id Style ID to exclude while validating an update.
	 * @return array{post:WP_Post,type:string,ownerSelector:string}|null
	 */
	public static function get_selector_owner( string $selector, int $exclude_post_id = 0 ): ?array {
		$selector = trim( $selector );
		$owner = self::get_selector_ownership_map( $exclude_post_id )[ $selector ] ?? null;

		if ( null === $owner ) {
			return null;
		}

		$post = get_post( $owner['ownerId'] );

		if ( ! $post instanceof WP_Post ) {
			return null;
		}

		return [
			'post'          => $post,
			'type'          => $owner['type'],
			'ownerSelector' => (string) $owner['ownerSelector'],
		];
	}

	/**
	 * Reject selectors already owned by another published or draft style.
	 *
	 * @param string   $primary_selector Candidate authority selector.
	 * @param string[] $targets          Candidate targets.
	 * @param int      $exclude_post_id  Style being updated.
	 * @return true|WP_Error
	 */
	public static function validate_selector_ownership( string $primary_selector, array $targets, int $exclude_post_id = 0 ) {
		$selectors = array_merge( [ trim( $primary_selector ) ], $targets );
		$owners = self::get_selector_ownership_map( $exclude_post_id );

		foreach ( $selectors as $selector ) {
			if ( '' === $selector || ! isset( $owners[ $selector ] ) ) {
				continue;
			}

			$owner = $owners[ $selector ];

			return new WP_Error(
				'gb_style_selector_owned',
				__( 'That selector already belongs to another Global Style.', 'generateblocks-pro' ),
				[
					'status'        => 409,
					'selector'      => $selector,
					'ownerId'       => $owner['ownerId'],
					'ownerSelector' => $owner['ownerSelector'],
					'ownerType'     => $owner['type'],
				]
			);
		}

		return true;
	}

	/**
	 * Validate a CSS selector.
	 *
	 * Class-only mode (the default) requires a single class selector (`.foo`).
	 * Full-selector mode accepts any syntactically well-formed CSS selector
	 * minus characters that could break out of a `<style>` block or introduce
	 * at-rules / declarations, and minus selector lists (commas).
	 *
	 * Keep in sync with isValidSelector() in src/global-classes/utils.js.
	 *
	 * @param string $selector             Selector to validate.
	 * @param bool   $allow_full_selectors Allow non-class selectors.
	 * @return bool
	 */
	public static function is_valid_selector( string $selector, bool $allow_full_selectors = false ): bool {
		$selector = trim( $selector );

		if ( '' === $selector ) {
			return false;
		}

		if ( ! $allow_full_selectors ) {
			return (bool) preg_match( '/^\.[a-zA-Z_][a-zA-Z0-9_-]*$/', $selector );
		}

		// Reject characters that would break out of <style> or allow injecting
		// at-rules / declarations alongside the selector. `>` is the CSS child
		// combinator and is allowed.
		if ( preg_match( '/[<{};@]|\/\*|\*\//', $selector ) ) {
			return false;
		}

		// Reject selector lists — one stored style maps to one selector. Track
		// delimiter types, quotes, and CSS escapes so commas inside selector
		// functions or attribute values remain valid while escaped top-level
		// commas remain part of one selector.
		$stack = [];
		$quote = '';
		$escaped = false;
		$has_top_level_component = false;
		$expects_top_level_component = false;

		for ( $i = 0, $len = strlen( $selector ); $i < $len; $i++ ) {
			$char = $selector[ $i ];

			if ( $escaped ) {
				$escaped = false;

				if ( [] === $stack ) {
					$has_top_level_component = true;
					$expects_top_level_component = false;
				}

				continue;
			}

			if ( '\\' === $char ) {
				$escaped = true;
				continue;
			}

			if ( '' !== $quote ) {
				if ( $char === $quote ) {
					$quote = '';
				}

				continue;
			}

			if ( '"' === $char || "'" === $char ) {
				$quote = $char;
				continue;
			}

			if ( '(' === $char || '[' === $char ) {
				if ( [] === $stack ) {
					$has_top_level_component = true;
					$expects_top_level_component = false;
				}

				$stack[] = $char;
				continue;
			}

			if ( ')' === $char || ']' === $char ) {
				$expected = ')' === $char ? '(' : '[';

				if ( array_pop( $stack ) !== $expected ) {
					return false;
				}

				if ( [] === $stack ) {
					$has_top_level_component = true;
					$expects_top_level_component = false;
				}

				continue;
			}

			if ( [] === $stack ) {
				if ( ',' === $char ) {
					return false;
				}

				if ( preg_match( '/\s/', $char ) ) {
					continue;
				}

				if ( in_array( $char, [ '>', '+', '~' ], true ) ) {
					if ( ! $has_top_level_component || $expects_top_level_component ) {
						return false;
					}

					$expects_top_level_component = true;
					continue;
				}

				$has_top_level_component = true;
				$expects_top_level_component = false;
			}
		}

		if (
			$escaped
			|| '' !== $quote
			|| [] !== $stack
			|| ! $has_top_level_component
			|| $expects_top_level_component
		) {
			return false;
		}

		return true;
	}

	/**
	 * Canonicalize an ordinary Global Style's primary selector.
	 *
	 * A primary selector is deliberately narrower than an additional selector:
	 * it is one atomic selector, or one standalone lowercase :is()/:where()
	 * group whose members are all atomic. States, modifiers, and relationships
	 * belong in nested rules. Keep this grammar in sync with
	 * src/global-classes/primary-selector.js.
	 *
	 * @param string $selector Candidate primary selector.
	 * @return string Canonical selector, or an empty string when invalid.
	 */
	public static function canonicalize_primary_selector( string $selector ): string {
		if ( false !== strpos( $selector, "\0" ) ) {
			return '';
		}

		$selector = trim( $selector );

		if (
			'' === $selector
			|| ':root' === strtolower( $selector )
			|| ! self::is_valid_selector( $selector, true )
		) {
			return '';
		}

		if ( self::is_atomic_primary_selector( $selector ) ) {
			return $selector;
		}

		if ( ! preg_match( '/^:(is|where)\(([\s\S]*)\)$/', $selector, $matches ) ) {
			return '';
		}

		$members = self::split_primary_selector_group_members( $matches[2] );

		if ( ! is_array( $members ) || [] === $members ) {
			return '';
		}

		foreach ( $members as $member ) {
			if ( '' === $member || ! self::is_atomic_primary_selector( $member ) ) {
				return '';
			}
		}

		return ':' . $matches[1] . '(' . implode( ',', $members ) . ')';
	}

	/**
	 * Whether one selector can be an ordinary Global Style primary identity.
	 *
	 * @param string $selector Candidate selector.
	 * @return bool Whether the selector is accepted.
	 */
	public static function is_valid_primary_selector( string $selector ): bool {
		return '' !== self::canonicalize_primary_selector( $selector );
	}

	/**
	 * Whether a selector is one approved atomic primary.
	 *
	 * The attribute subset is intentionally conservative: no namespaces,
	 * escapes, modifiers, or whitespace outside quoted values. This makes the
	 * client and PHP validators byte-for-byte predictable and can be loosened
	 * later without invalidating saved data.
	 *
	 * @param string $selector Candidate selector.
	 * @return bool Whether the selector is atomic.
	 */
	private static function is_atomic_primary_selector( string $selector ): bool {
		$identifier = '[a-zA-Z_][a-zA-Z0-9_-]*';

		if (
			preg_match(
				'/^(?:\.' . $identifier . '|#' . $identifier . '|[a-zA-Z][a-zA-Z0-9-]*|\*)$/',
				$selector
			)
		) {
			return true;
		}

		return (bool) preg_match(
			'/^\[' . $identifier . '(?:(?:[~|^$*]?=)(?:' . $identifier . '|"[^"\\\\\x00-\x1F\x7F]*"|\'[^\'\\\\\x00-\x1F\x7F]*\'))?\]$/',
			$selector
		);
	}

	/**
	 * Split a grouping pseudo argument at top-level commas.
	 *
	 * @param string $value Group argument without the outer parentheses.
	 * @return string[]|null Members, or null for unbalanced input.
	 */
	private static function split_primary_selector_group_members( string $value ) {
		$members = [];
		$current = '';
		$quote = '';
		$escaped = false;
		$square_depth = 0;
		$round_depth = 0;

		for ( $i = 0, $length = strlen( $value ); $i < $length; $i++ ) {
			$character = $value[ $i ];

			if ( $escaped ) {
				$current .= $character;
				$escaped = false;
				continue;
			}

			if ( '\\' === $character ) {
				$current .= $character;
				$escaped = true;
				continue;
			}

			if ( '' !== $quote ) {
				$current .= $character;

				if ( $quote === $character ) {
					$quote = '';
				}

				continue;
			}

			if ( '"' === $character || "'" === $character ) {
				$current .= $character;
				$quote = $character;
				continue;
			}

			if ( '[' === $character ) {
				++$square_depth;
				$current .= $character;
				continue;
			}

			if ( ']' === $character ) {
				if ( $square_depth < 1 ) {
					return null;
				}

				--$square_depth;
				$current .= $character;
				continue;
			}

			if ( '(' === $character ) {
				++$round_depth;
				$current .= $character;
				continue;
			}

			if ( ')' === $character ) {
				if ( $round_depth < 1 ) {
					return null;
				}

				--$round_depth;
				$current .= $character;
				continue;
			}

			if ( ',' === $character && 0 === $square_depth && 0 === $round_depth ) {
				$members[] = trim( $current );
				$current = '';
				continue;
			}

			$current .= $character;
		}

		if ( $escaped || '' !== $quote || 0 !== $square_depth || 0 !== $round_depth ) {
			return null;
		}

		$members[] = trim( $current );

		return $members;
	}

	/**
	 * Classify a selector as 'class', 'element', 'id', or 'compound'.
	 *
	 * Assumes the selector has already passed is_valid_selector(). Returns
	 * 'unknown' for empty input.
	 *
	 * @param string $selector Canonical selector.
	 * @return string
	 */
	public static function get_selector_kind( string $selector ): string {
		$selector = trim( $selector );

		if ( '' === $selector ) {
			return 'unknown';
		}

		if ( ':root' === strtolower( $selector ) ) {
			return 'root';
		}

		if ( preg_match( '/^\.[a-zA-Z_][a-zA-Z0-9_-]*$/', $selector ) ) {
			return 'class';
		}

		if ( preg_match( '/^#[a-zA-Z_][a-zA-Z0-9_-]*$/', $selector ) ) {
			return 'id';
		}

		if ( preg_match( '/^[a-zA-Z][a-zA-Z0-9-]*$/', $selector ) ) {
			return 'element';
		}

		return 'compound';
	}

	/**
	 * Get our class post object using the class name.
	 *
	 * @param string $class_name The name of the class to query.
	 */
	public static function get_class_by_name( $class_name ) {
		$query = new WP_Query(
			[
				'post_type'      => 'gblocks_styles',
				'posts_per_page' => 1,
				'post_status'    => 'any',
				'meta_query'     => [
					[
						'key'     => 'gb_style_selector',
						'value'   => $class_name,
						'compare' => '=',
					],
				],
			]
		);

		if ( empty( $query->found_posts ) ) {
			return false;
		}

		return $query->posts[0];
	}

	/**
	 * Iterate over styles in batches to avoid memory issues with unlimited queries.
	 *
	 * @param callable $callback   Callback executed for every post. Receives the post object and an array of meta values.
	 * @param array    $custom_args Optional WP_Query args (supports all standard args).
	 * @param array    $meta_keys   Meta keys to retrieve for each post.
	 *
	 * @return void
	 */
	private static function loop_styles( callable $callback, array $custom_args = [], array $meta_keys = [] ) {
		$defaults = [
			'post_type'      => 'gblocks_styles',
			'post_status'    => 'publish',
			'order'          => 'ASC',
			'orderby'        => 'menu_order',
			'posts_per_page' => apply_filters( 'generateblocks_styles_posts_per_page', 5000 ), // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page
		];

		$args       = wp_parse_args( $custom_args, $defaults );
		$batch_size = apply_filters( 'generateblocks_styles_batch_size', 200 );
		$posts_per_page = isset( $args['posts_per_page'] ) ? (int) $args['posts_per_page'] : 0;
		$args['posts_per_page'] = $posts_per_page;

		// Batch if unlimited requested OR if limit is larger than batch size.
		if ( 0 === $posts_per_page || -1 === $posts_per_page || $posts_per_page > $batch_size ) {
			$original_posts_per_page = $posts_per_page;
			$offset                  = isset( $args['offset'] ) ? (int) $args['offset'] : 0;

			if ( ! empty( $args['paged'] ) && $original_posts_per_page > 0 ) {
				$offset += ( (int) $args['paged'] - 1 ) * $original_posts_per_page;
			}

			unset( $args['offset'], $args['paged'] );

			$remaining      = $original_posts_per_page > 0 ? $original_posts_per_page : null;
			$current_offset = $offset;

			do {
				$limit = null === $remaining ? $batch_size : min( $batch_size, $remaining );

				$query_args = $args;
				$query_args['posts_per_page'] = $limit;
				$query_args['offset']         = $current_offset;

				$query = new WP_Query( $query_args );

				if ( empty( $query->posts ) ) {
					break;
				}

				// Prime meta cache to avoid N+1 queries.
				if ( ! empty( $meta_keys ) ) {
					update_meta_cache( 'post', wp_list_pluck( $query->posts, 'ID' ) );
				}

				foreach ( $query->posts as $post ) {
					$meta = [];

					foreach ( $meta_keys as $key ) {
						$meta[ $key ] = get_post_meta( $post->ID, $key, true );
					}

					$callback( $post, $meta );
				}

				$posts_count = count( $query->posts );
				$current_offset += $posts_count;

				if ( null !== $remaining ) {
					$remaining -= $posts_count;

					if ( $remaining <= 0 ) {
						break;
					}
				}
			} while ( $posts_count === $limit );
		} else {
			// If specific limit requested, just do single query.
			$query = new WP_Query( $args );

			if ( ! empty( $meta_keys ) ) {
				update_meta_cache( 'post', wp_list_pluck( $query->posts, 'ID' ) );
			}

			foreach ( $query->posts as $post ) {
				$meta = [];

				foreach ( $meta_keys as $key ) {
					$meta[ $key ] = get_post_meta( $post->ID, $key, true );
				}

				$callback( $post, $meta );
			}
		}
	}
}

GenerateBlocks_Pro_Styles::get_instance()->init();
