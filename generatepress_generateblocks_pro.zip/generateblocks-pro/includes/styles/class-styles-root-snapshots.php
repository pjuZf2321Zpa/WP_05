<?php
/**
 * Rolling snapshots for the managed :root Global Style.
 *
 * @package GenerateBlocksPro\Styles
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores the three most recent pre-save :root payloads.
 */
class GenerateBlocks_Pro_Styles_Root_Snapshots {

	const PAYLOAD_VERSION = 2;
	const OPTION_BACKUP_1 = 'generateblocks_root_style_backup_1';
	const OPTION_BACKUP_2 = 'generateblocks_root_style_backup_2';
	const OPTION_BACKUP_3 = 'generateblocks_root_style_backup_3';

	/**
	 * Rotate a new pre-save snapshot into slot one.
	 *
	 * @param array $payload Snapshot payload.
	 */
	public static function rotate( array $payload ): void {
		$slots = self::option_names();
		$prior = [];

		foreach ( $slots as $slot ) {
			$value = get_option( $slot, null );

			if ( self::is_valid_payload( $value ) ) {
				$prior[] = $value;
			}
		}

		update_option( $slots[0], self::normalize_payload( $payload ), false );
		$slot_count = count( $slots );

		for ( $i = 1; $i < $slot_count; $i++ ) {
			if ( isset( $prior[ $i - 1 ] ) ) {
				update_option( $slots[ $i ], $prior[ $i - 1 ], false );
			} else {
				delete_option( $slots[ $i ] );
			}
		}
	}

	/**
	 * Read one snapshot slot.
	 *
	 * @param int $slot One-based slot number.
	 * @return array|null
	 */
	public static function get( int $slot ): ?array {
		$options = self::option_names();

		if ( $slot < 1 || $slot > count( $options ) ) {
			return null;
		}

		$value = get_option( $options[ $slot - 1 ], null );

		return self::is_valid_payload( $value ) ? self::normalize_payload( $value ) : null;
	}

	/**
	 * Whether a snapshot payload is readable.
	 *
	 * @param mixed $payload Candidate payload.
	 */
	private static function is_valid_payload( $payload ): bool {
		if ( ! is_array( $payload ) ) {
			return false;
		}

		$valid_version = ! isset( $payload['version'] )
			|| ( is_int( $payload['version'] ) && $payload['version'] <= self::PAYLOAD_VERSION );
		$valid_tokens = ! array_key_exists( 'tokens', $payload )
			|| null !== self::normalize_token_envelope( $payload['tokens'], false );

		return $valid_version
			&& $valid_tokens
			&& isset( $payload['selector'], $payload['styles'], $payload['css'] )
			&& ':root' === strtolower( trim( (string) $payload['selector'] ) )
			&& is_array( $payload['styles'] )
			&& is_string( $payload['css'] );
	}

	/**
	 * Normalize a trusted snapshot payload.
	 *
	 * @param array $payload Snapshot payload.
	 */
	private static function normalize_payload( array $payload ): array {
		return [
			'version'  => self::PAYLOAD_VERSION,
			'selector' => ':root',
			'styles'   => is_array( $payload['styles'] ?? null ) ? $payload['styles'] : [],
			'css'      => is_string( $payload['css'] ?? null ) ? $payload['css'] : '',
			'tokens'   => self::normalize_token_envelope( $payload['tokens'] ?? null, true ),
			'savedAt'  => isset( $payload['savedAt'] ) ? (string) $payload['savedAt'] : gmdate( 'c' ),
		];
	}

	/**
	 * Normalize the nested Design Token registry envelope.
	 *
	 * Version-one snapshots predate registry durability and normalize to an
	 * empty envelope. A present but unreadable envelope invalidates the slot.
	 *
	 * @param mixed $raw             Candidate registry envelope.
	 * @param bool  $default_if_null Whether a missing value becomes empty.
	 * @return array|null
	 */
	private static function normalize_token_envelope( $raw, bool $default_if_null ): ?array {
		if ( null === $raw ) {
			return $default_if_null
				? [
					'version' => 1,
					'tokens'  => [],
				]
				: null;
		}

		if ( class_exists( 'GenerateBlocks_Pro_Design_Tokens' ) ) {
			return GenerateBlocks_Pro_Design_Tokens::sanitize_envelope( $raw );
		}

		return is_array( $raw )
			&& isset( $raw['version'], $raw['tokens'] )
			&& is_int( $raw['version'] )
			&& is_array( $raw['tokens'] )
			? [
				'version' => $raw['version'],
				'tokens'  => array_values( $raw['tokens'] ),
			]
			: null;
	}

	/**
	 * Snapshot option names in newest-to-oldest order.
	 *
	 * @return string[]
	 */
	private static function option_names(): array {
		return [
			self::OPTION_BACKUP_1,
			self::OPTION_BACKUP_2,
			self::OPTION_BACKUP_3,
		];
	}
}
