<?php
/**
 * The Global Classes rest class file.
 *
 * @package GenerateBlocksPro\Global_Classes_Rest
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

require_once GENERATEBLOCKS_PRO_DIR . 'includes/utils/trait-usage-search.php';

/**
 * Main class for the Global Classes Rest functions.
 *
 * @since 1.9
 */
class GenerateBlocks_Pro_Styles_Rest extends GenerateBlocks_Pro_Singleton {

	use GenerateBlocks_Pro_Usage_Search;

	/**
	 * Option holding the dashboard's category display order.
	 *
	 * A flat list of category names. This is display-only chrome for the Global
	 * Styles list: it never influences `menu_order`, and therefore never
	 * influences the emitted CSS or its cascade.
	 */
	const CATEGORY_ORDER_OPTION = 'generateblocks_style_category_order';

	/**
	 * Maximum number of names kept in the category display order.
	 */
	const CATEGORY_ORDER_MAX_NAMES = 200;

	/**
	 * Initialize all hooks.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register the REST routes.
	 *
	 * @return void
	 */
	public function register_routes(): void {
		$namespace = 'generateblocks-pro/v1';

		register_rest_route(
			$namespace,
			'/styles/root',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_root_style' ],
					'permission_callback' => [ $this, 'can_manage' ],
				],
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'create_root_style' ],
					'permission_callback' => [ $this, 'can_manage' ],
				],
			]
		);

		register_rest_route(
			$namespace,
			'/styles/root/restore',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'restore_root_style' ],
				'permission_callback' => [ $this, 'can_manage' ],
			]
		);

		register_rest_route(
			$namespace,
			'/styles/root/resolve-conflict',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'resolve_root_conflict' ],
				'permission_callback' => [ $this, 'can_manage' ],
			]
		);

		register_rest_route(
			$namespace,
			'/global-classes/check_class_name',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'check_class_name' ),
				'permission_callback' => array( $this, 'can_create' ),
			)
		);

		register_rest_route(
			$namespace,
			'/global-classes/check_base_selector',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'check_base_selector' ),
				'permission_callback' => array( $this, 'can_manage' ),
				'args'                => array(
					'selector' => array(
						// Preserve the submitted identity so this route can reject,
						// rather than sanitize into, a different canonical selector.
						'required' => true,
						'type'     => 'string',
					),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/global-classes/get',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_global_styles' ),
				'permission_callback' => array( $this, 'can_create' ),
			)
		);

		register_rest_route(
			$namespace,
			'/global-classes/get_css',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_global_class_css' ),
				'permission_callback' => array( $this, 'can_create' ),
				'args'                => array(
					'preview' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/global-classes/get_styles',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_global_class_styles' ),
				'permission_callback' => array( $this, 'can_create' ),
			)
		);

		register_rest_route(
			$namespace,
			'/global-styles/update_menu_order',
			array(
				'methods'             => WP_REST_Server::EDITABLE,
				'callback'            => array( $this, 'update_menu_order' ),
				'permission_callback' => array( $this, 'can_manage' ),
			)
		);

		register_rest_route(
			$namespace,
			'/global-styles/update_category_order',
			array(
				'methods'             => WP_REST_Server::EDITABLE,
				'callback'            => array( $this, 'update_category_order' ),
				'permission_callback' => array( $this, 'can_manage' ),
			)
		);

		register_rest_route(
			$namespace,
			'/global-classes/(?P<id>\d+)/usage',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_global_style_usage' ),
				'permission_callback' => array( $this, 'can_manage' ),
				'args'                => array(
					'id'       => array(
						'required'          => true,
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					),
					'limit'    => array(
						'required'          => false,
						'type'              => 'integer',
						'default'           => 50,
						'sanitize_callback' => 'absint',
					),
					'refresh'  => array(
						'required'          => false,
						'type'              => 'boolean',
						'default'           => false,
						'sanitize_callback' => 'rest_sanitize_boolean',
					),
				),
			)
		);
	}

	/**
	 * Manage options permission callback.
	 *
	 * @return bool
	 */
	public function can_create(): bool {
		return current_user_can( 'edit_posts' );
	}

	/**
	 * Permission callback for endpoints that require elevated management access.
	 *
	 * @return bool
	 */
	public function can_manage(): bool {
		return GenerateBlocks_Pro_Styles::can_manage_styles();
	}

	/**
	 * Read the managed :root style without creating it.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_root_style() {
		$result = GenerateBlocks_Pro_Styles_Root::read_for_dashboard();

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Create the managed :root style after an explicit user action.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function create_root_style() {
		$result = GenerateBlocks_Pro_Styles_Root::create_for_dashboard();

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return new WP_REST_Response( $result, $result['created'] ? 201 : 200 );
	}

	/**
	 * Restore a prior :root snapshot.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function restore_root_style( WP_REST_Request $request ) {
		$slot     = absint( $request->get_param( 'slot' ) );
		$checksum = $request->get_param( 'checksum' );

		if ( $slot < 1 || $slot > 3 || ! is_string( $checksum ) ) {
			return new WP_Error(
				'gb_root_style_invalid_restore',
				__( 'Invalid :root restore request.', 'generateblocks-pro' ),
				[ 'status' => 400 ]
			);
		}

		$result = GenerateBlocks_Pro_Styles_Root::restore_snapshot( $slot, $checksum );

		return is_wp_error( $result ) ? $result : new WP_REST_Response( $result, 200 );
	}

	/**
	 * Keep one root candidate and trash the other conflicting records.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function resolve_root_conflict( WP_REST_Request $request ) {
		$keep_post_id = absint( $request->get_param( 'keepPostId' ) );

		if ( $keep_post_id < 1 ) {
			return new WP_Error(
				'gb_root_style_invalid_conflict_resolution',
				__( 'Choose a :root record to keep.', 'generateblocks-pro' ),
				[ 'status' => 400 ]
			);
		}

		$result = GenerateBlocks_Pro_Styles_Root::resolve_conflict( $keep_post_id );

		return is_wp_error( $result ) ? $result : new WP_REST_Response( $result, 200 );
	}

	/**
	 * Report an exact selector that is already owned.
	 *
	 * A `target` hit is not a style the user can find under the name they typed:
	 * the selector belongs to another authority's "Also applies to" list, so the
	 * message has to name that authority's primary selector instead.
	 *
	 * @param array  $owner        Owner details from get_selector_owner().
	 * @param string $primary_copy Message used when the selector is a primary identity.
	 * @return string
	 */
	private function owned_selector_message( array $owner, string $primary_copy ): string {
		if ( 'target' !== ( $owner['type'] ?? '' ) ) {
			return $primary_copy;
		}

		return sprintf(
			/* translators: %s: Owning Global Style selector. */
			__( 'That selector already belongs to %s.', 'generateblocks-pro' ),
			(string) ( $owner['ownerSelector'] ?? '' )
		);
	}

	/**
	 * Check if a class name already exists.
	 *
	 * @param WP_REST_Request $request The request.
	 *
	 * @return WP_REST_Response
	 */
	public function check_class_name( WP_REST_Request $request ): WP_REST_RESPONSE {
		$class_name = $request->get_param( 'className' );

		if ( empty( $class_name ) ) {
			return $this->failed( __( 'Style name cannot be empty', 'generateblocks-pro' ) );
		}

		$owner = GenerateBlocks_Pro_Styles::get_selector_owner( (string) $class_name );

		if ( null !== $owner ) {
			return $this->failed(
				$this->owned_selector_message(
					$owner,
					__( 'Style name already exists', 'generateblocks-pro' )
				)
			);
		}

		return $this->success( [ 'success' ] );
	}

	/**
	 * Check if a primary CSS selector is valid, canonical, and unique.
	 *
	 * Additional selectors intentionally use the broader target grammar. This
	 * route is only for the base authority stored in gb_style_selector.
	 *
	 * @param WP_REST_Request $request The request.
	 * @return WP_REST_Response
	 */
	public function check_base_selector( WP_REST_Request $request ): WP_REST_Response {
		$selector = (string) $request->get_param( 'selector' );

		if ( '' === trim( $selector ) ) {
			return $this->failed( __( 'Selector cannot be empty.', 'generateblocks-pro' ) );
		}

		$canonical_selector = GenerateBlocks_Pro_Styles::canonicalize_primary_selector( $selector );

		if ( '' === $canonical_selector ) {
			return $this->failed(
				sprintf(
					/* translators: %s: submitted CSS selector. */
					__( 'The selector "%s" is not a supported Global Style base selector.', 'generateblocks-pro' ),
					trim( $selector )
				)
			);
		}

		if ( $canonical_selector !== $selector ) {
			return $this->failed(
				sprintf(
					/* translators: %s: canonical CSS selector. */
					__( 'Use the canonical selector "%s".', 'generateblocks-pro' ),
					$canonical_selector
				)
			);
		}

		$owner = GenerateBlocks_Pro_Styles::get_selector_owner( $canonical_selector );

		if ( null !== $owner ) {
			return $this->failed(
				$this->owned_selector_message(
					$owner,
					__( 'A style with this selector already exists.', 'generateblocks-pro' )
				)
			);
		}

		return $this->success(
			[
				'selector' => $canonical_selector,
			]
		);
	}

	/**
	 * Returns a list of active or inactive classes.
	 *
	 * @param WP_REST_Request $request The request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_global_styles( WP_REST_Request $request ): WP_REST_Response {
		$status = $request->get_param( 'status' ) ?? 'publish';
		$custom_args = [
			'post_status' => $status,
		];

		$styles = GenerateBlocks_Pro_Styles::get_styles( $custom_args );
		$include_root = rest_sanitize_boolean( $request->get_param( 'includeRoot' ) );

		if ( ! $include_root ) {
			$styles = array_values(
				array_filter(
					$styles,
					static fn( $style ) => 'root' !== ( $style['kind'] ?? '' )
				)
			);
		}

		$class_data = [
			'styles'        => $styles,
			// Display order of the dashboard's category sections. Sanitized on
			// the way out as well as in: the option is ordinary site data and a
			// malformed value must never reach the list.
			'categoryOrder' => $this->get_category_order(),
		];

		return $this->success( $class_data );
	}

	/**
	 * Returns the CSS for the complete set of global classes or a specific class if specified.
	 *
	 * @param WP_REST_Request $request The request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_global_class_css( WP_REST_Request $request ): WP_REST_Response {
		$class_name = $request->get_param( 'className' );

		if ( $class_name ) {
			$class = GenerateBlocks_Pro_Styles::get_class_by_name( $class_name );

			if ( ! isset( $class->ID ) ) {
				return $this->failed( 'No CSS found.' );
			}

			$css = (string) get_post_meta( $class->ID, 'gb_style_css', true )
				. (string) get_post_meta( $class->ID, 'gb_style_targets_css', true );
		} else {
			// The Style Book preview replaces the frontend's original Global
			// Styles handle with this complete blob so staged removals can be
			// represented. Keep the replacement on the same public filter boundary
			// as both frontend emission modes; otherwise filtered additions vanish
			// from the preview as soon as the original handle is removed.
			$css = GenerateBlocks_Pro_Styles::get_styles_css();

			if ( true === $request->get_param( 'preview' ) ) {
				// Only the dashboard needs a root-free variant. Use the same
				// lowest published ID as the collector, without its lifecycle
				// resolver or a second whole-library scan.
				$roots = get_posts(
					array(
						'post_type'      => 'gblocks_styles',
						'post_status'    => 'publish',
						'posts_per_page' => 1,
						'orderby'        => 'ID',
						'order'          => 'ASC',
						'meta_key'       => 'gb_style_selector',
						'meta_value'     => ':root',
					)
				);
				$root_css = $roots ? (string) get_post_meta( $roots[0]->ID, 'gb_style_css', true ) : '';

				// A save may be rebuilding the combined artifact. Keep the last
				// valid preview until both reads describe the same published root.
				if ( '' !== $root_css && 0 !== strpos( $css, $root_css ) ) {
					return $this->failed( __( 'The Global Styles stylesheet is being updated. Please try again.', 'generateblocks-pro' ) );
				}

				// Remove the known prefix BEFORE filtering. Filters may reformat
				// CSS, so matching raw record bytes against filtered CSS is unsafe.
				$without_root = substr( $css, strlen( $root_css ) );

				return $this->success(
					array(
						(string) apply_filters( 'generateblocks_global_css', $css ),
						(string) apply_filters( 'generateblocks_global_css', $without_root ),
					)
				);
			}

			$css = (string) apply_filters( 'generateblocks_global_css', $css );
		}

		return $this->success( [ $css ] );
	}

	/**
	 * Returns the styles for a specific class name.
	 *
	 * @param WP_REST_Request $request The request.
	 *
	 * @return WP_REST_Response
	 */
	public function get_global_class_styles( WP_REST_Request $request ): WP_REST_Response {
		$class_name = $request->get_param( 'globalClass' );
		$class = GenerateBlocks_Pro_Styles::get_class_by_name( $class_name );

		// get_class_by_name() returns false — not null — on a miss, so the ID is
		// what actually says whether a record was found. Same check as
		// get_global_class_css() above.
		if ( ! isset( $class->ID ) ) {
			return $this->failed( __( 'Style does not exist', 'generateblocks-pro' ) );
		}

		$post_id = $class->ID;
		$styles   = get_post_meta( $post_id, 'gb_style_data', true );
		$category = get_post_meta( $post_id, 'gb_style_category', true );
		$selector = get_post_meta( $post_id, 'gb_style_selector', true );
		$targets  = GenerateBlocks_Pro_Styles::sanitize_style_targets(
			get_post_meta( $post_id, 'gb_style_targets', true )
		);

		return $this->success(
			[
				'postId'          => $post_id,
				'selector'        => is_string( $selector ) ? $selector : '',
				'matchedSelector' => is_string( $class_name ) ? $class_name : '',
				'targets'         => $targets,
				'styles'          => $styles ?? [],
				'category'        => GenerateBlocks_Pro_Styles::sanitize_category( $category ),
			]
		);
	}

	/**
	 * Handles updating global style menu order
	 *
	 * @param WP_REST_Request $request WP Request object.
	 * @return WP_REST_RESPONSE;
	 */
	public function update_menu_order( WP_REST_Request $request ): WP_REST_Response {
		$order = $request->get_param( 'order' );
		if ( empty( $order ) || ! is_array( $order ) ) {
			return $this->failed( __( 'Order parameter is invalid.', 'generateblocks-pro' ) );
		}

		global $wpdb;
		$sql = '';
		$rows_affected = 0;

		foreach ( $order as $index => $post_id ) {
			$post_id = absint( $post_id );

			if ( ! $post_id ) {
				continue;
			}

			$query = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$wpdb->posts} SET menu_order = %d WHERE ID = %d AND post_type = %s;",
					[
						$index,
						$post_id,
						'gblocks_styles',
					]
				)
			);

			if ( false === $query ) {
				return $this->failed( __( 'Failed to update menu order.', 'generateblocks-pro' ) );
			} else {
				$rows_affected += $query;
			}
		}

		$wpdb->flush();

		// Flush the cache after the operation completes.
		GenerateBlocks_Pro_Enqueue_Styles::get_instance()->build_css();

		return $this->success(
			[
				'message'       => __( 'Menu order updated', 'generateblocks-pro' ),
				'rows_affected' => $rows_affected,
			]
		);
	}

	/**
	 * Handles updating the display order of the dashboard's category sections.
	 *
	 * Category order is display-only chrome. Nothing in here touches
	 * `menu_order`, so the CSS this site emits is byte-identical before and
	 * after the write.
	 *
	 * The client always sends the COMPLETE effective order, so every write
	 * self-heals: names that were renamed away, ungrouped or never filled simply
	 * drop out of the stored list.
	 *
	 * @param WP_REST_Request $request WP Request object.
	 * @return WP_REST_Response
	 */
	public function update_category_order( WP_REST_Request $request ): WP_REST_Response {
		$order = $request->get_param( 'order' );

		// An empty list is a legitimate order — it is what removing the last
		// category looks like. Anything that is not a list is not.
		if ( ! is_array( $order ) ) {
			return $this->failed( __( 'Category order parameter is invalid.', 'generateblocks-pro' ) );
		}

		$sanitized = $this->sanitize_category_order( $order );

		// Not autoloaded: only the dashboard reads it, and it has no bearing on
		// anything rendered on the front end.
		$saved = update_option( self::CATEGORY_ORDER_OPTION, $sanitized, false );

		// WordPress also returns false for an unchanged value. Only acknowledge
		// the save when the write succeeded or the requested order is stored.
		if ( ! $saved && $sanitized !== $this->get_category_order() ) {
			return $this->failed( __( 'Failed to save the category order.', 'generateblocks-pro' ) );
		}

		return $this->success(
			array(
				'message' => __( 'Category order updated', 'generateblocks-pro' ),
				'order'   => $sanitized,
			)
		);
	}

	/**
	 * Read the stored category display order.
	 *
	 * @return array
	 */
	private function get_category_order(): array {
		return $this->sanitize_category_order( get_option( self::CATEGORY_ORDER_OPTION, array() ) );
	}

	/**
	 * Reduce any stored or submitted value to a safe list of category names.
	 *
	 * Assume the worst of the input: an old option, a hand-written request, a
	 * partially migrated site. Anything that is not a usable name is dropped
	 * rather than repaired — an unknown name is inert on the client and is
	 * pruned by the next write.
	 *
	 * @param mixed $order The value to sanitize.
	 * @return array
	 */
	private function sanitize_category_order( $order ): array {
		if ( ! is_array( $order ) ) {
			return array();
		}

		$names = array();

		foreach ( $order as $name ) {
			if ( ! is_string( $name ) ) {
				continue;
			}

			$name = GenerateBlocks_Pro_Styles::sanitize_category( $name );

			if ( '' === $name || in_array( $name, $names, true ) ) {
				continue;
			}

			$names[] = $name;

			if ( count( $names ) >= self::CATEGORY_ORDER_MAX_NAMES ) {
				break;
			}
		}

		return $names;
	}

	/**
	 * Get global style usage across the site.
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function get_global_style_usage( WP_REST_Request $request ): WP_REST_Response {
		$style_id = $request->get_param( 'id' );
		$limit = $request->get_param( 'limit' );
		$refresh = $request->get_param( 'refresh' );

		if ( empty( $style_id ) ) {
			return $this->failed( __( 'Style ID is required.', 'generateblocks-pro' ) );
		}

		// Verify the style exists and get the class name.
		$style_post = get_post( $style_id );
		if ( ! $style_post || 'gblocks_styles' !== $style_post->post_type ) {
			return $this->failed( __( 'Style not found.', 'generateblocks-pro' ) );
		}

		$class_name = get_post_meta( $style_id, 'gb_style_selector', true );
		if ( empty( $class_name ) ) {
			return $this->failed( __( 'Style class name not found.', 'generateblocks-pro' ) );
		}

		$saved_targets        = GenerateBlocks_Pro_Styles::sanitize_style_targets(
			get_post_meta( $style_id, 'gb_style_targets', true )
		);
		$assignable_selectors = GenerateBlocks_Pro_Styles::get_assignable_class_selectors(
			(string) $class_name,
			$saved_targets
		);

		// Automatic element / id / compound selectors cannot be counted as class
		// tokens. The aggregate remains class_based only when the primary and every
		// target are standalone classes. Saved standalone-class aliases are still
		// scanned even when another selector makes the complete report uncertain.
		$selector_kind       = GenerateBlocks_Pro_Styles::get_selector_kind( (string) $class_name );
		$primary_class_based = GenerateBlocks_Pro_Styles::is_valid_selector( (string) $class_name, false );
		$class_based         = $primary_class_based;

		foreach ( $saved_targets as $saved_target ) {
			if ( ! GenerateBlocks_Pro_Styles::is_valid_selector( $saved_target, false ) ) {
				$class_based = false;
				break;
			}
		}

		// Check cache unless refresh is requested.
		$cache_selectors = array_merge( [ (string) $class_name ], $saved_targets );
		$cache_key = sprintf(
			'gb_style_usage_v2_%d_%s_limit%d',
			$style_id,
			md5( implode( "\0", $cache_selectors ) ),
			$limit
		);
		if ( ! $refresh ) {
			$cached_data = $this->get_usage_cache( $cache_key );
			if ( false !== $cached_data ) {
				$cached_data['cached'] = true;
				$cached_data['cached_at'] = $cached_data['cached_at'] ?? time();
				$cached_data['selector_kind'] = $cached_data['selector_kind'] ?? $selector_kind;
				$cached_data['class_based'] = $cached_data['class_based'] ?? $class_based;
				return $this->success( $cached_data );
			}
		}

		if ( ! empty( $assignable_selectors ) ) {
			$usage_data = $this->search_global_style_usage( $class_name, $assignable_selectors, $limit );
		} else {
			$usage_data = array(
				'usage'       => array(),
				'total'       => 0,
				'has_more'    => false,
				'limited'     => false,
				'limitations' => array(),
				'primary_usage' => array(
					'total'       => 0,
					'has_more'    => false,
					'class_based' => $primary_class_based,
				),
			);
		}

		$usage_data['selector_kind'] = $selector_kind;
		$usage_data['class_based']   = $class_based;
		$usage_data['primary_usage'] = array_merge(
			array(
				'total'       => 0,
				'has_more'    => false,
				'class_based' => $primary_class_based,
			),
			is_array( $usage_data['primary_usage'] ?? null ) ? $usage_data['primary_usage'] : array(),
			array( 'class_based' => $primary_class_based )
		);

		// Cache for 15 minutes (900 seconds).
		// Note: Cache invalidation is intentionally manual (via refresh button in UI).
		// Automatic invalidation on post save/delete was deemed too complex and risky
		// due to the need to clear caches across all styles when any post changes.
		// Users can click refresh to get updated results when needed.
		$usage_data['cached_at'] = time();
		$this->set_usage_cache( $cache_key, $usage_data, 900 );

		$usage_data['cached'] = false;

		return $this->success( $usage_data );
	}

	/**
	 * Search for global style usage across different data sources.
	 *
	 * @param string   $class_name           Primary class name passed to existing handlers.
	 * @param string[] $assignable_selectors Saved standalone class selectors owned by the style.
	 * @param int      $limit                Maximum total results to return (default: 50).
	 * @return array
	 */
	private function search_global_style_usage( string $class_name, array $assignable_selectors, int $limit = 50 ): array {
		$all_usage = array();
		$total_found = 0;
		$primary_total = 0;
		$primary_has_more = false;
		$has_more = false;
		$limitations = array();
		$has_limitations = false;

		// Define search handlers - easily extensible for future use cases.
		$search_handlers = array(
			'style_usage' => array(
				'method' => 'search_global_style_attribute_usage',
				'label'  => __( 'Style Usage', 'generateblocks-pro' ),
			),
		);

		// Apply filters to allow other plugins/themes to add search handlers.
		$search_handlers = apply_filters(
			'generateblocks_global_style_usage_handlers',
			$search_handlers,
			$class_name,
			$assignable_selectors
		);

		foreach ( $search_handlers as $handler_key => $handler_config ) {
			// Stop processing if we've found enough results.
			if ( $total_found >= $limit ) {
				$has_more = true;
				$primary_has_more = true;
				break;
			}

			if ( ! method_exists( $this, $handler_config['method'] ) ) {
				continue;
			}

			// Calculate how many more results we need.
			$remaining = $limit - $total_found;
			// The first two arguments preserve the existing handler contract. The
			// selector array is additive: older handlers can ignore it, while the
			// built-in scanner uses it to search the authority and its aliases in
			// one bounded content query.
			$handler_results = $this->{$handler_config['method']}(
				$class_name,
				$remaining,
				$assignable_selectors
			);

			if (
				! empty( $handler_results['items'] )
				|| ! empty( $handler_results['has_more'] )
				|| ! empty( $handler_results['limited'] )
			) {
				// Take only what we need.
				$items = array_slice( $handler_results['items'], 0, $remaining );

				$handler_has_more = ! empty( $handler_results['has_more'] )
					|| ( count( $handler_results['items'] ) > $remaining );

				foreach ( $items as &$item ) {
					// Alias-aware handlers can identify which returned locations
					// reference the primary selector. Existing custom handlers only
					// receive the primary selector, so their unmarked items retain
					// the historical primary-usage meaning.
					if (
						! array_key_exists( 'primary_block_count', $item )
						|| ! empty( $item['primary_block_count'] )
					) {
						++$primary_total;
					}

					// This is an internal aggregation marker, not an independent
					// alias usage result or a new public item field.
					unset( $item['primary_block_count'] );
				}
				unset( $item );

				$all_usage[ $handler_key ] = array(
					'label'    => $handler_config['label'],
					'items'    => $items,
					'has_more' => $handler_has_more,
				);
				$total_found += count( $items );

				// If any handler has more results, set the overall has_more flag.
				if ( $handler_has_more ) {
					$has_more = true;
				}

				if (
					array_key_exists( 'primary_has_more', $handler_results )
						? ! empty( $handler_results['primary_has_more'] )
						: $handler_has_more
				) {
					$primary_has_more = true;
				}

				if ( ! empty( $handler_results['limited'] ) ) {
					$has_limitations = true;
				}

				if ( ! empty( $handler_results['limits'] ) && is_array( $handler_results['limits'] ) ) {
					foreach ( $handler_results['limits'] as $limit_key => $limit_data ) {
						if ( ! isset( $limitations[ $limit_key ] ) ) {
							$limitations[ $limit_key ] = $limit_data;
							continue;
						}

						$current = $limitations[ $limit_key ];

						if ( isset( $limit_data['max_posts'] ) ) {
							$current['max_posts'] = isset( $current['max_posts'] )
								? max( $current['max_posts'], $limit_data['max_posts'] )
								: $limit_data['max_posts'];
						}

						if ( isset( $limit_data['scanned_posts'] ) ) {
							$current['scanned_posts'] = isset( $current['scanned_posts'] )
								? max( $current['scanned_posts'], $limit_data['scanned_posts'] )
								: $limit_data['scanned_posts'];
						}

						if ( isset( $limit_data['total_posts'] ) ) {
							$current['total_posts'] = isset( $current['total_posts'] )
								? max( $current['total_posts'], $limit_data['total_posts'] )
								: $limit_data['total_posts'];
						}

						$limitations[ $limit_key ] = $current;
					}
				}
			}
		}

		return array(
			'usage'       => $all_usage,
			'total'       => $total_found,
			'has_more'    => $has_more,
			'limited'     => $has_limitations,
			'limitations' => $limitations,
			'primary_usage' => array(
				'total'    => $primary_total,
				'has_more' => $primary_has_more,
			),
		);
	}

	/**
	 * Search for blocks using this style via the globalClasses attribute.
	 *
	 * @param string   $class_name           Primary class name to search for.
	 * @param int      $limit                Maximum results to return.
	 * @param string[] $assignable_selectors Saved standalone class selectors owned by the style.
	 * @return array
	 */
	private function search_global_style_attribute_usage( string $class_name, int $limit, array $assignable_selectors = array() ): array {
		global $wpdb;

		// Validate and sanitize inputs.
		$limit = absint( $limit );
		$assignable_selectors = GenerateBlocks_Pro_Styles::get_assignable_class_selectors(
			$class_name,
			$assignable_selectors
		);

		if ( empty( $assignable_selectors ) ) {
			return array(
				'items'    => array(),
				'has_more' => false,
				'primary_has_more' => false,
			);
		}

		// Get post types that support the block editor.
		$post_types = get_post_types_by_support( 'editor' );
		$excluded_types = array( 'revision', 'attachment', 'nav_menu_item' );
		$post_types = array_diff( $post_types, $excluded_types );
		$post_types = apply_filters( 'generateblocks_usage_search_post_types', $post_types, 'styles' );

		if ( empty( $post_types ) ) {
			return array(
				'items'    => array(),
				'has_more' => false,
			);
		}

		$post_statuses = array( 'publish', 'private', 'draft' );

		// HTML class attributes do not include the selector's leading dot.
		$class_tokens = array_map(
			static function ( $selector ) {
				return ltrim( $selector, '.' );
			},
			$assignable_selectors
		);
		$class_lookup = array_fill_keys( $class_tokens, true );
		$primary_token = GenerateBlocks_Pro_Styles::is_valid_selector( $class_name, false )
			? ltrim( $class_name, '.' )
			: '';

		// Search in the rendered HTML (class="...") instead of the JSON.
		// This avoids unicode encoding issues and is much simpler and more reliable.
		// Pattern: class="...class-name..." (with word boundaries for accuracy).
		$search_patterns = array_map(
			static function ( $class_token ) use ( $wpdb ) {
				return '%class="%' . $wpdb->esc_like( $class_token ) . '%"%';
			},
			$class_tokens
		);

		// Query one more than requested to determine if there are more results.
		$query_limit = $limit + 1;

		// Cap the number of posts scanned (prevents slow queries on large sites).
		// Users can adjust this via filter if needed.
		$max_posts_to_scan = apply_filters( 'generateblocks_usage_search_max_posts', 5000 );

		$post_types_placeholders = implode( ', ', array_fill( 0, count( $post_types ), '%s' ) );
		$status_placeholders     = implode( ', ', array_fill( 0, count( $post_statuses ), '%s' ) );
		$search_placeholders     = implode( ' OR ', array_fill( 0, count( $search_patterns ), 'post_content LIKE %s' ) );

		// Determine dataset size so we can surface limitations to the UI.
		$total_posts_sql = sprintf(
			"SELECT COUNT(ID)
			FROM {$wpdb->posts}
			WHERE post_status IN (%s)
			AND post_type IN (%s)",
			$status_placeholders,
			$post_types_placeholders
		);
		$total_posts_query = $wpdb->prepare(
			$total_posts_sql, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			array_merge( $post_statuses, $post_types )
		);
		$total_posts   = absint( $wpdb->get_var( $total_posts_query ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$scanned_posts = min( $total_posts, $max_posts_to_scan );
		$limited_scan  = $total_posts > $max_posts_to_scan;

		// Two-phase query: First get recent posts, then search within them.
		// This prevents full table scans on large sites.
		// phpcs:disable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$sql = sprintf(
			"SELECT ID, post_title, post_type, post_status, post_content
			FROM (
				SELECT ID, post_title, post_type, post_status, post_content, post_modified
				FROM {$wpdb->posts}
				WHERE post_status IN ('publish', 'private', 'draft')
				AND post_type IN (%s)
				ORDER BY post_modified DESC
				LIMIT %%d
			) AS recent_posts
			WHERE (%s)
			LIMIT %%d",
			$post_types_placeholders,
			$search_placeholders
		);
		$results_query = $wpdb->prepare(
			$sql, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			array_merge( $post_types, array( $max_posts_to_scan ), $search_patterns, array( $query_limit ) )
		);
		// phpcs:enable WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

		$results = $wpdb->get_results( $results_query ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		// Check if there are more results.
		$has_more = count( $results ) > $limit;

		// Remove the extra result if we got it.
		if ( $has_more ) {
			array_pop( $results );
		}

		$formatted_results = array();
		foreach ( $results as $result ) {
			// Extract class attribute values so we can inspect individual tokens.
			preg_match_all( '/class=(["\'])([^"\']+)\1/i', $result->post_content, $class_attr_matches );

			$match_count = 0;
			$selector_match_counts = array();
			if ( ! empty( $class_attr_matches[2] ) ) {
				foreach ( $class_attr_matches[2] as $class_attr ) {
					$tokens = preg_split( '/\s+/', trim( $class_attr ) );

					if ( empty( $tokens ) ) {
						continue;
					}

					foreach ( $tokens as $token ) {
						if ( ! isset( $class_lookup[ $token ] ) ) {
							continue;
						}

						++$match_count;
						$selector_match_counts[ '.' . $token ] = ( $selector_match_counts[ '.' . $token ] ?? 0 ) + 1;
					}
				}
			}

			if ( 0 === $match_count ) {
				continue;
			}

			$post_type_object = get_post_type_object( $result->post_type );
			$post_type_label = $post_type_object ? $post_type_object->labels->singular_name : $result->post_type;

			// Check if post type is publicly viewable.
			$is_public = $post_type_object && ( $post_type_object->public || $post_type_object->publicly_queryable );

			// translators: %1$s: Post type label, %2$d: Post ID.
			$fallback_title = $result->post_title ? $result->post_title : sprintf( __( '%1$s #%2$d', 'generateblocks-pro' ), $post_type_label, $result->ID );

			$formatted_results[] = array(
				'id'          => absint( $result->ID ),
				'title'       => $fallback_title,
				'type'        => $result->post_type,
				'type_label'  => $post_type_label,
				'status'      => $result->post_status,
				'edit_url'    => get_edit_post_link( $result->ID, 'raw' ),
				'view_url'    => ( 'publish' === $result->post_status && $is_public ) ? get_permalink( $result->ID ) : null,
				'usage_type'  => 'global_style_usage',
				'block_count' => $match_count,
				'primary_block_count' => '' !== $primary_token
					? ( $selector_match_counts[ '.' . $primary_token ] ?? 0 )
					: 0,
			);
		}

		return array(
			'items'    => $formatted_results,
			'has_more' => $has_more || $limited_scan,
			// Once the bounded result set or recent-post window is exhausted,
			// undiscovered primary references remain possible even when the
			// visible rows happen to contain aliases only.
			'primary_has_more' => $has_more || $limited_scan,
			'limited'  => $limited_scan,
			'limits'   => $limited_scan
				? array(
					'recent_post_scan' => array(
						'max_posts'     => $max_posts_to_scan,
						'scanned_posts' => $scanned_posts,
						'total_posts'   => $total_posts,
					),
				)
				: array(),
		);
	}

	/**
	 * Returns a success response.
	 *
	 * @param array $data The data.
	 *
	 * @return WP_REST_Response
	 */
	private function success( array $data ): WP_REST_Response {
		return new WP_REST_Response(
			array(
				'success'  => true,
				'response' => array(
					'data' => $data,
				),
			),
			200
		);
	}

	/**
	 * Returns a failure response.
	 *
	 * @param string $message The error message.
	 *
	 * @return WP_REST_Response
	 */
	private function failed( string $message ): WP_REST_Response {
		return new WP_REST_Response(
			array(
				'success'  => false,
				'response' => $message,
			),
			200
		);
	}

	/**
	 * Returns a error response.
	 *
	 * @param int    $code Error code.
	 * @param string $message Error message.
	 *
	 * @return WP_REST_Response
	 */
	private function error( int $code, string $message = '' ): WP_REST_Response {
		return new WP_REST_Response(
			array(
				'error'      => true,
				'success'    => false,
				'error_code' => $code,
				'response'   => $message,
			),
			$code
		);
	}
}

GenerateBlocks_Pro_Styles_Rest::get_instance()->init();
