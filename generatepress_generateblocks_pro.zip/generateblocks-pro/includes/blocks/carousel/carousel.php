<?php
/**
 * Handle the carousel block.
 *
 * @package GenerateBlocks Pro
 */

// Include our files.
require_once 'class-carousel.php';

add_filter( 'block_editor_settings_all', 'generateblocks_pro_carousel_block_editor_settings', 20 );
/**
 * Add block editor settings for the carousel block.
 *
 * @param array $settings The block editor settings.
 */
function generateblocks_pro_carousel_block_editor_settings( $settings ) {
	$blocks_to_reset = [
		'.editor-styles-wrapper .wp-block-generateblocks-pro-carousel',
		'.editor-styles-wrapper .wp-block-generateblocks-pro-carousel-pagination',
		'.editor-styles-wrapper .wp-block-generateblocks-pro-carousel-items',
		'.editor-styles-wrapper .wp-block-generateblocks-pro-carousel-item',
		'.editor-styles-wrapper .wp-block-generateblocks-pro-carousel-control',
	];
	$css = implode( ',', $blocks_to_reset ) . ' {max-width:unset;margin:0}';
	$settings['styles'][] = [ 'css' => $css ];

	return $settings;
}

add_filter( 'generateblocks_block_css', 'generateblocks_pro_carousel_block_css', 10, 2 );
/**
 * Add block CSS for the carousel block.
 *
 * @param string $css    The CSS to add.
 * @param array  $block  The block data.
 *
 * @return string
 */
function generateblocks_pro_carousel_block_css( $css, $block ) {
	if ( ! isset( $block['attributes']['uniqueId'] ) ) {
		return $css;
	}

	$block_name = $block['block_name'] ?? '';

	if ( 'generateblocks-pro/carousel' !== $block_name ) {
		return $css;
	}

	$html_attributes = $block['attributes']['htmlAttributes'] ?? [];

	if ( ! is_array( $html_attributes ) ) {
		$html_attributes = [];
	}

	$selector    = '.gb-carousel-' . $block['attributes']['uniqueId'];
	$init_at_raw = $html_attributes['data-init-at'] ?? '';
	$init_at     = '';

	if ( is_string( $init_at_raw ) ) {
		$init_at_raw = trim( $init_at_raw );

		// Reject CSS structural characters so the value cannot escape the
		// media query prelude. Parentheses stay allowed, so calc()/min()/clamp()
		// using +/- still work. Rejecting "/" and "*" blocks comment sequences,
		// and with them calc multiplication/division — deliberate: media query
		// operands are always static, so those forms are precomputable.
		if ( '' !== $init_at_raw && false === strpbrk( $init_at_raw, '{};/*' ) ) {
			$init_at = $init_at_raw;

			if ( is_numeric( $init_at ) ) {
				$init_at .= 'px';
			}
		}
	}

	if ( $init_at ) {
		$css_rules = [
			$selector . ':not([data-gb-carousel-initialized="true"]):not([data-gb-carousel-pending="true"]) .gb-carousel-items' => [
				'position' => 'relative',
				'width' => '100%',
				'height' => '100%',
				'z-index' => '1',
				'display' => 'flex',
				'overflow-x' => 'hidden',
				'gap' => 'var(--gb-carousel-slide-gap, 0)',
			],
			$selector . ':not([data-gb-carousel-initialized="true"]) .gb-carousel-items > .gb-carousel-item' => [
				'flex' => '0 0 calc((100% - var(--gb-carousel-slide-gap, 0px) * (var(--gb-carousel-slides-per-view, 1) - 1)) / var(--gb-carousel-slides-per-view, 1))',
				'width' => '100%',
				'height' => '100%',
				'position' => 'relative',
				'transition-property' => 'transform',
				'display' => 'block',
				'user-select' => 'none',
			],
		];
		$media_query_css = generateblocks_pro_build_css_from_array( $css_rules );
		$css .= "@media (max-width: {$init_at}) {{$media_query_css}}";

		$not_at_rule_css_rules = [
			$selector . ':not([data-gb-carousel-initialized="true"]) .gb-carousel-control' => [
				'display' => 'none',
			],
			$selector . ':not([data-gb-carousel-initialized="true"]) .gb-carousel-pagination' => [
				'display' => 'none',
			],
		];

		$not_at_rule_css = generateblocks_pro_build_css_from_array( $not_at_rule_css_rules );
		$css .= "@media (width > {$init_at}) {{$not_at_rule_css}}";
	}

	$grid_rows = $html_attributes['data-grid-rows'] ?? '';

	if ( is_numeric( $grid_rows ) && (float) $grid_rows > 0 ) {
		$slides_per_view = $html_attributes['data-slides-per-view'] ?? '1';

		if ( ! is_numeric( $slides_per_view ) || (float) $slides_per_view <= 0 ) {
			$slides_per_view = '1';
		}

		$total_items    = (int) ceil( (float) $grid_rows * (float) $slides_per_view );
		$selected_items = $total_items + 1;

		$css_rules = [
			$selector . ':not([data-gb-carousel-initialized="true"]):not([data-gb-carousel-pending="true"]) > .gb-carousel-items > .gb-carousel-item:nth-child(n+' . $selected_items . ')' => [
				'display' => 'none',
			],
		];

		$built_css = generateblocks_pro_build_css_from_array( $css_rules );

		if ( $init_at ) {
			$css .= "@media (max-width: {$init_at}) {{$built_css}}";
		} else {
			$css .= $built_css;
		}
	}

	return $css;
}
