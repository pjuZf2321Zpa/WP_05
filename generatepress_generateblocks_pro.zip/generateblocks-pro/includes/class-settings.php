<?php
/**
 * General actions and filters.
 *
 * @package GenerateBlocks
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Build our settings area.
 *
 * @since 1.0
 */
class GenerateBlocks_Pro_Settings {
	/**
	 * WordPress hook name for the GenerateBlocks Settings screen.
	 */
	const SETTINGS_PAGE_HOOK = 'generateblocks_page_generateblocks-settings';

	/**
	 * Instance.
	 *
	 * @access private
	 * @var object Instance
	 */
	private static $instance;

	/**
	 * Whether Pro registers and renders the Settings screen.
	 *
	 * GenerateBlocks 2.5.0 and later step aside when asked through the
	 * `generateblocks_should_register_settings_page` filter. Earlier versions
	 * keep rendering their own screen and Pro adds its controls to it.
	 *
	 * @var bool
	 */
	private $owns_settings_page = false;

	/**
	 * Initiator.
	 *
	 * @return object initialized object of class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Initiate our class.
	 */
	public function __construct() {
		// GenerateBlocks loads its helpers before plugins_loaded, where Pro
		// initializes. Older Free releases simply do not announce this support.
		$this->owns_settings_page = function_exists( 'generateblocks_supports' )
			&& generateblocks_supports( 'settings-page-owner' );

		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

		if ( $this->owns_settings_page ) {
			add_filter( 'generateblocks_should_register_settings_page', '__return_false' );
			add_action( 'admin_menu', array( $this, 'add_menu' ) );
			add_filter( 'admin_body_class', array( $this, 'add_settings_page_body_class' ) );

			return;
		}

		// GenerateBlocks renders the screen; add Pro's controls to it.
		add_action( 'generateblocks_settings_area', array( $this, 'add_license_key_area' ), 5 );
		add_action( 'generateblocks_settings_area', array( $this, 'add_template_library_settings' ), 20 );
	}

	/**
	 * Register the Settings screen in place of the GenerateBlocks one.
	 *
	 * Same parent, slug, capability, and position as GenerateBlocks uses, so
	 * the URL and the screen id do not change.
	 */
	public function add_menu() {
		add_submenu_page(
			'generateblocks',
			__( 'Settings', 'generateblocks-pro' ),
			__( 'Settings', 'generateblocks-pro' ),
			'manage_options',
			'generateblocks-settings',
			array( $this, 'render_settings_page' ),
			1
		);
	}

	/**
	 * Identify the Settings screen when Pro renders it.
	 *
	 * @param string $classes Current admin body classes.
	 * @return string Admin body classes.
	 */
	public function add_settings_page_body_class( $classes ) {
		$screen = get_current_screen();

		if ( $this->owns_settings_page && $screen && self::SETTINGS_PAGE_HOOK === $screen->id ) {
			$classes .= ' gb-pro-owns-settings-page gb-admin-page-active';
		}

		return $classes;
	}

	/**
	 * Render the Pro-owned Settings page.
	 */
	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to access this page.', 'generateblocks-pro' ) );
		}
		?>
		<div class="wrap gb-settings-dashboard-wrap">
			<div id="gblocks-pro-settings-dashboard"></div>

			<?php if ( false !== has_action( 'generateblocks_settings_area' ) ) : ?>
				<div class="generateblocks-settings-area gb-settings-dashboard-extensions">
					<?php do_action( 'generateblocks_settings_area' ); ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Enqueue our scripts.
	 */
	public function enqueue_scripts() {
		$screen = get_current_screen();

		if ( $screen && self::SETTINGS_PAGE_HOOK === $screen->id ) {
			$license_settings = $this->get_license_settings_for_script();
			$use_customizer_container_width = function_exists( 'generateblocks_use_customizer_container_width' )
				? generateblocks_use_customizer_container_width()
				: function_exists( 'generate_get_option' );
			$fallback_dependencies = array( 'wp-api', 'wp-i18n', 'wp-components', 'wp-element', 'wp-api-fetch' );

			if ( ! $this->owns_settings_page ) {
				$fallback_dependencies[] = 'generateblocks-settings';
			}

			$assets = generateblocks_pro_get_enqueue_assets(
				'dashboard',
				[
					'dependencies' => $fallback_dependencies,
					'version' => GENERATEBLOCKS_PRO_VERSION,
				]
			);

			wp_enqueue_script(
				'generateblocks-pro-settings',
				GENERATEBLOCKS_PRO_DIR_URL . 'dist/dashboard.js',
				$assets['dependencies'],
				$assets['version'],
				true
			);

			wp_set_script_translations( 'generateblocks-pro-settings', 'generateblocks-pro', GENERATEBLOCKS_PRO_DIR . 'languages' );

			wp_localize_script(
				'generateblocks-pro-settings',
				'generateBlocksProSettings',
				array(
					'settings' => wp_parse_args(
						get_option( 'generateblocks', array() ),
						generateblocks_get_option_defaults()
					),
					'adminSettings' => wp_parse_args(
						get_option( 'generateblocks_admin', array() ),
						generateblocks_pro_get_admin_option_defaults()
					),
					'licenseSettings' => $license_settings,
					'useLegacyPatternLibrary' => generateblocks_pro_has_legacy_patterns(),
					'gpContainerWidth' => $use_customizer_container_width ? generate_get_option( 'container_width' ) : false,
					'gpContainerWidthLink' => $use_customizer_container_width
						? add_query_arg(
							rawurlencode( 'autofocus[control]' ),
							rawurlencode( 'generate_settings[container_width]' ),
							wp_customize_url()
						)
						: false,
					'showContainerWidthSetting' => function_exists( 'generateblocks_should_set_container_width' )
						? generateblocks_should_set_container_width()
						: true,
					'useV1Blocks' => function_exists( 'generateblocks_use_v1_blocks' )
						? generateblocks_use_v1_blocks()
						: false,
				)
			);

			wp_enqueue_style(
				'generateblocks-pro-settings',
				GENERATEBLOCKS_PRO_DIR_URL . 'dist/dashboard.css',
				array( 'generateblocks-pro-admin-ui' ),
				GENERATEBLOCKS_PRO_VERSION
			);
		}
	}

	/**
	 * Get license settings safe for the browser.
	 *
	 * The complete active key remains server-side so it cannot be copied from
	 * the localized Dashboard data.
	 *
	 * @return array
	 */
	private function get_license_settings_for_script() {
		$license_settings = wp_parse_args(
			get_option( 'generateblocks_pro_licensing', array() ),
			generateblocks_pro_get_license_defaults()
		);

		$license_settings['key'] = is_string( $license_settings['key'] ) ? $license_settings['key'] : '';
		$license_settings['status'] = is_string( $license_settings['status'] ) ? $license_settings['status'] : '';

		// An active key is only ever shown masked: 24 bullets and its last four.
		if ( 'valid' === $license_settings['status'] && '' !== $license_settings['key'] ) {
			$key = $license_settings['key'];

			$license_settings['key'] = str_repeat( '•', 24 ) . ( strlen( $key ) > 4 ? substr( $key, -4 ) : '' );
		}

		return $license_settings;
	}

	/**
	 * Add license key container.
	 *
	 * @since 1.2.0
	 */
	public function add_license_key_area() {
		echo '<div id="gblocks-license-key-settings"></div>';
	}

	/**
	 * Add Template Library container.
	 *
	 * @since 1.2.0
	 */
	public function add_template_library_settings() {
		echo '<div id="gblocks-template-library-settings"></div>';
	}
}

GenerateBlocks_Pro_Settings::get_instance();
