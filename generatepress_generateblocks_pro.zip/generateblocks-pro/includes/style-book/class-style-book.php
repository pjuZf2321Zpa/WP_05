<?php
/**
 * The shared Global Styles and Design Tokens dashboard.
 *
 * @package GenerateBlocksPro\Style_Book
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Register the shared Design dashboard and its Style Book preview interceptor.
 *
 * The admin panel hosts a live iframe that defaults to the site's home URL.
 * When the user toggles the Style Book mode, the iframe loads the site root
 * with `?gb_style_book=1`, which this class intercepts on `template_redirect`
 * and renders inline (see `render_style_book_preview`).
 *
 * @since 2.6.0
 */
class GenerateBlocks_Pro_Style_Book extends GenerateBlocks_Pro_Singleton {

	const QUERY_VAR         = 'gb_style_book';
	const MENU_SLUG         = 'generateblocks-styles';

	/**
	 * Marker query var appended to every Studio preview iframe URL (Global
	 * Styles and Design Tokens). Flags "this frontend request is
	 * rendering inside one of our admin preview frames" so the admin bar can
	 * be suppressed server-side without touching any other request — other
	 * plugins' iframes of the frontend keep their existing behavior.
	 */
	const PREVIEW_QUERY_VAR = 'gb_studio_preview';

	/**
	 * Screen ID under the GenerateBlocks parent. The MENU_SLUG (and therefore
	 * the `?page=generateblocks-styles` URL) is preserved so released
	 * bookmarks keep working.
	 */
	const SCREEN_ID = 'generateblocks_page_generateblocks-styles';

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'admin_menu', [ $this, 'add_menu' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
		add_filter( 'generateblocks_dashboard_tabs', [ $this, 'add_tab' ] );
		add_filter( 'generateblocks_dashboard_screens', [ $this, 'add_to_dashboard_pages' ] );
		add_filter( 'submenu_file', [ $this, 'set_current_submenu_file' ], 10, 2 );
		add_filter( 'admin_title', [ $this, 'set_admin_title' ], 10, 2 );

		add_filter( 'query_vars', [ $this, 'register_query_var' ] );
		add_action( 'template_redirect', [ $this, 'send_preview_frame_headers' ], 0 );
		add_action( 'template_redirect', [ $this, 'render_style_book_preview' ], 1 );
		add_filter( 'show_admin_bar', [ $this, 'maybe_hide_admin_bar' ] );
	}

	/**
	 * Register the Design dashboard under the GenerateBlocks parent.
	 *
	 * Design Tokens is an internal workspace of this page, not a second admin
	 * screen. Its link-only submenu entry routes into this same callback. The
	 * MENU_SLUG is unchanged, so the released `?page=generateblocks-styles` URL
	 * keeps resolving.
	 *
	 * @return void
	 */
	public function add_menu() {
		if ( ! GenerateBlocks_Pro_Styles::can_manage_styles() ) {
			return;
		}

		$manage_styles_capability = GenerateBlocks_Pro_Styles::get_manage_styles_capability();

		add_submenu_page(
			GenerateBlocks_Pro_Design_Menu::PARENT_SLUG,
			__( 'Global Styles', 'generateblocks-pro' ),
			__( 'Global Styles', 'generateblocks-pro' ),
			$manage_styles_capability,
			self::MENU_SLUG,
			[ $this, 'render_dashboard_page' ]
		);

		if ( ! GenerateBlocks_Pro_Design_Tokens::can_manage_tokens() ) {
			return;
		}

		global $submenu;

		$submenu[ GenerateBlocks_Pro_Design_Menu::PARENT_SLUG ][] = [ // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- WordPress has no API for a link-only submenu item.
			__( 'Design Tokens', 'generateblocks-pro' ),
			GenerateBlocks_Pro_Design_Tokens::get_manage_tokens_capability(),
			GenerateBlocks_Pro_Design_Menu::DESIGN_TOKENS_SUBMENU_URL,
			__( 'Design Tokens', 'generateblocks-pro' ),
		];
	}

	/**
	 * Highlight Design Tokens in the WordPress submenu on a direct page load.
	 *
	 * WordPress otherwise sees both workspaces as the registered Global Styles
	 * plugin page. In-app tab switches synchronize the already-rendered menu in
	 * JavaScript; this filter handles refreshes, bookmarks, and modified clicks.
	 *
	 * @param string|null $submenu_file Current submenu file.
	 * @param string|null $parent_file  Current parent menu file.
	 * @return string|null
	 */
	public function set_current_submenu_file( $submenu_file, $parent_file ) {
		if ( GenerateBlocks_Pro_Design_Menu::PARENT_SLUG !== $parent_file ) {
			return $submenu_file;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only workspace routing.
		$is_design_tokens = isset( $_GET['page'], $_GET['view'] )
			&& self::MENU_SLUG === sanitize_key( wp_unslash( $_GET['page'] ) )
			&& 'design-tokens' === sanitize_key( wp_unslash( $_GET['view'] ) );
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		if ( $is_design_tokens && GenerateBlocks_Pro_Design_Tokens::can_manage_tokens() ) {
			return GenerateBlocks_Pro_Design_Menu::DESIGN_TOKENS_SUBMENU_URL;
		}

		return $submenu_file;
	}

	/**
	 * Use the active Design workspace in the browser document title.
	 *
	 * The registered admin page remains Global Styles so its released slug and
	 * menu entry stay intact. Design Tokens is a link-only route into that page,
	 * so WordPress otherwise prefixes its document title with Global Styles.
	 * Replace only that prefix and preserve the site and WordPress suffixes.
	 *
	 * @param string $admin_title Full filtered admin document title.
	 * @param string $page_title  Registered admin page title.
	 * @return string
	 */
	public function set_admin_title( $admin_title, $page_title ) {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only workspace routing.
		$is_design_tokens = isset( $_GET['page'], $_GET['view'] )
			&& self::MENU_SLUG === sanitize_key( wp_unslash( $_GET['page'] ) )
			&& 'design-tokens' === sanitize_key( wp_unslash( $_GET['view'] ) );
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		if (
			! $is_design_tokens ||
			! GenerateBlocks_Pro_Design_Tokens::can_manage_tokens() ||
			'' === $page_title ||
			0 !== strpos( $admin_title, $page_title )
		) {
			return $admin_title;
		}

		return __( 'Design Tokens', 'generateblocks-pro' ) . substr( $admin_title, strlen( $page_title ) );
	}

	/**
	 * Add the Design dashboard tabs to the legacy GB Dashboard tabs.
	 *
	 * @param array $tabs Existing tabs.
	 * @return array
	 */
	public function add_tab( $tabs ) {
		if ( ! GenerateBlocks_Pro_Styles::can_manage_styles() ) {
			return $tabs;
		}

		$screen = get_current_screen();

		$tabs['styles'] = [
			'name'  => __( 'Global Styles', 'generateblocks-pro' ),
			'url'   => admin_url( 'admin.php?page=' . self::MENU_SLUG ),
			'class' => $screen && self::SCREEN_ID === $screen->id ? 'active' : '',
		];

		return $tabs;
	}

	/**
	 * Expose the Design screen to other dashboard-aware integrations.
	 *
	 * @param array $pages Existing dashboard screen IDs.
	 * @return array
	 */
	public function add_to_dashboard_pages( $pages ) {
		if ( ! GenerateBlocks_Pro_Styles::can_manage_styles() ) {
			return $pages;
		}

		$pages[] = self::SCREEN_ID;

		return $pages;
	}

	/**
	 * Render the shared Design dashboard container.
	 *
	 * @return void
	 */
	public function render_dashboard_page() {
		if ( ! GenerateBlocks_Pro_Styles::can_manage_styles() ) {
			wp_die(
				esc_html__( 'You do not have permission to manage Global Styles.', 'generateblocks-pro' ),
				'',
				[ 'response' => 403 ]
			);
		}

		// The Design workspace has one intentionally LTR layout in every locale.
		echo '<div id="gb-design-dashboard" class="gb-design-dashboard-app gb-style-book-app gb-design-tokens-app" dir="ltr"></div>';
	}

	/**
	 * Enqueue the shared dashboard assets for the Design screen.
	 *
	 * The filtered Global Styles management check mirrors the editor. A user
	 * denied by `generateblocks_can_manage_styles` must not receive a partial
	 * or read-only dashboard, even if they hold the underlying capability.
	 *
	 * @return void
	 */
	public function enqueue_admin_assets() {
		$screen = get_current_screen();

		if ( ! $screen || self::SCREEN_ID !== $screen->id ) {
			return;
		}

		$can_manage_styles = GenerateBlocks_Pro_Styles::can_manage_styles();

		if ( ! $can_manage_styles ) {
			return;
		}

		$can_manage_tokens = GenerateBlocks_Pro_Design_Tokens::can_manage_tokens();
		$initial_area      = 'global-styles';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only workspace routing.
		$focused_style = isset( $_GET['edit-style'] ) ? sanitize_text_field( wp_unslash( $_GET['edit-style'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only workspace routing.
		$focused_view = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : '';

		if (
			$can_manage_tokens &&
			(
				'design-tokens' === $focused_view ||
				':root' === strtolower( trim( $focused_style ) )
			)
		) {
			$initial_area = 'design-tokens';
		}

		$color_palette = self::get_editor_color_palette();
		$assets        = generateblocks_pro_get_enqueue_assets( 'design-dashboard' );

		wp_enqueue_script(
			'generateblocks-pro-design-dashboard',
			GENERATEBLOCKS_PRO_DIR_URL . 'dist/design-dashboard.js',
			$assets['dependencies'],
			$assets['version'],
			true
		);

		wp_set_script_translations( 'generateblocks-pro-design-dashboard', 'generateblocks-pro', GENERATEBLOCKS_PRO_DIR . 'languages' );

		wp_localize_script(
			'generateblocks-pro-design-dashboard',
			'gbDesignDashboard',
			[
				'initialArea'      => $initial_area,
				'homeUrl'          => self::get_preview_home_url(),
				'styleBookUrl'     => self::get_style_book_url(),
				'siteOrigin'       => self::get_site_origin(),
				'studioPages'      => GenerateBlocks_Pro_Design_Menu::get_studio_navigation(),
				'canAccessStyles'  => $can_manage_styles,
				'canManageTokens'  => $can_manage_tokens,
				'rootStylePostId'  => class_exists( 'GenerateBlocks_Pro_Styles_Root' )
					? GenerateBlocks_Pro_Styles_Root::get_resolved_post_id()
					: 0,
				'globalStylesUrl'  => self::get_dashboard_url(),
				'designTokensUrl'  => $can_manage_tokens
					? self::get_dashboard_url( 'design-tokens' )
					: '',
				'colorPalette'     => $color_palette,
			]
		);

		wp_localize_script(
			'generateblocks-pro-design-dashboard',
			'gbDesignTokens',
			GenerateBlocks_Pro_Design_Tokens::get_localized_token_data()
		);

		wp_localize_script(
			'generateblocks-pro-design-dashboard',
			'generateBlocksPro',
			[
				'canManageStyles'         => $can_manage_styles,
				'legacyGlobalStylesUrl'   => admin_url( 'edit.php?post_type=gblocks_global_style' ),
				'legacyGlobalStylesCount' => wp_count_posts( 'gblocks_global_style' ),
			]
		);

		// @edge22/styles-builder expects a `generateBlocksEditor` global that
		// the core GenerateBlocks plugin localizes onto its block-editor script.
		// The block editor isn't loaded here, so provide a minimal surface with
		// the fields the StylesBuilder reads at render time.
		wp_localize_script(
			'generateblocks-pro-design-dashboard',
			'generateBlocksEditor',
			[
				'useV1Blocks'              => false,
				'dynamicTags'              => [],
				'hasGPFontLibrary'         => function_exists( 'generatepress_is_module_active' )
					? generatepress_is_module_active( 'generate_package_font_library', 'GENERATE_FONT_LIBRARY' )
					: false,
				'dateFormat'               => get_option( 'date_format' ),
				'wpContentUrl'             => content_url(),
				'typographyFontFamilyList' => function_exists( 'generateblocks_get_font_family_list' )
					? generateblocks_get_font_family_list()
					: [],
				'dynamicTagsPreview'       => 'disabled',
			]
		);

		// Core GenerateBlocks ships its own packages.css that contains visual
		// cues used by the Styles Builder (indicator dots, etc.). It is only
		// registered on the block-editor screen, so enqueue it directly here.
		if ( defined( 'GENERATEBLOCKS_DIR_URL' ) && defined( 'GENERATEBLOCKS_DIR' ) ) {
			$core_packages_css = GENERATEBLOCKS_DIR . 'dist/packages.css';

			if ( file_exists( $core_packages_css ) ) {
				wp_enqueue_style(
					'generateblocks-packages',
					GENERATEBLOCKS_DIR_URL . 'dist/packages.css',
					[],
					filemtime( $core_packages_css )
				);
			}
		}

		wp_enqueue_style(
			'generateblocks-pro-design-dashboard',
			GENERATEBLOCKS_PRO_DIR_URL . 'dist/design-dashboard.css',
			array_merge(
				[ 'wp-components' ],
				generateblocks_pro_get_package_style_deps(),
				wp_style_is( 'generateblocks-packages', 'enqueued' ) ? [ 'generateblocks-packages' ] : []
			),
			GENERATEBLOCKS_PRO_VERSION
		);

		$palette_variable_css = self::get_palette_variable_css( $color_palette );

		if ( '' !== $palette_variable_css ) {
			wp_add_inline_style( 'generateblocks-pro-design-dashboard', $palette_variable_css );
		}
	}

	/**
	 * Get the theme and custom color palettes the block editor would offer.
	 *
	 * The Styles Builder color picker reads these from the block editor's
	 * settings, which only an editor screen populates. This is the same source
	 * `get_block_editor_settings()` uses, so the dashboard offers exactly the
	 * editor's palette — including whatever a theme or plugin has removed from
	 * it. Values are passed through untouched: the picker writes the chosen
	 * value into the style, so `var()` references must stay references.
	 *
	 * @return array{theme: array, custom: array}
	 */
	private static function get_editor_color_palette(): array {
		$palette = wp_get_global_settings( [ 'color', 'palette' ] );

		return [
			'theme'  => isset( $palette['theme'] ) && is_array( $palette['theme'] ) ? array_values( $palette['theme'] ) : [],
			'custom' => isset( $palette['custom'] ) && is_array( $palette['custom'] ) ? array_values( $palette['custom'] ) : [],
		];
	}

	/**
	 * Define the GeneratePress color variables the dashboard palette references.
	 *
	 * GeneratePress registers its palette as `var(--slug)` references and only
	 * defines those variables on the front end and in the block editor, so the
	 * swatches would render blank here. The palette itself decides what gets
	 * defined: once it stops referencing a variable (GP Premium's Zero Mode
	 * removes the `editor-color-palette` support, a child theme replaces it)
	 * nothing is output for it, with no need to ask any plugin what mode it is in.
	 *
	 * @param array $color_palette The palette from get_editor_color_palette().
	 * @return string
	 */
	private static function get_palette_variable_css( array $color_palette ): string {
		if ( ! function_exists( 'generate_get_global_colors' ) ) {
			return '';
		}

		$values = [];

		foreach ( (array) generate_get_global_colors() as $global_color ) {
			if (
				is_array( $global_color ) &&
				! empty( $global_color['slug'] ) &&
				! empty( $global_color['color'] ) &&
				is_string( $global_color['slug'] ) &&
				is_string( $global_color['color'] )
			) {
				$values[ '--' . $global_color['slug'] ] = $global_color['color'];
			}
		}

		$declarations = [];

		foreach ( array_merge( $color_palette['theme'] ?? [], $color_palette['custom'] ?? [] ) as $color ) {
			if (
				! is_array( $color ) ||
				empty( $color['color'] ) ||
				! is_string( $color['color'] ) ||
				! preg_match( '/^var\(\s*(--[a-zA-Z0-9_-]+)\s*\)$/', trim( $color['color'] ), $matches )
			) {
				continue;
			}

			$variable = $matches[1];

			// Only plain color values: nothing that could close the declaration.
			if ( isset( $values[ $variable ] ) && preg_match( '/^[a-zA-Z0-9#(),.%\/\s-]+$/', $values[ $variable ] ) ) {
				$declarations[ $variable ] = $variable . ':' . trim( $values[ $variable ] ) . ';';
			}
		}

		if ( empty( $declarations ) ) {
			return '';
		}

		// Popovers render at the body level, so the variables can't be scoped
		// to the dashboard root.
		return ':root{' . implode( '', $declarations ) . '}';
	}

	/**
	 * Get the canonical URL for a dashboard workspace.
	 *
	 * @param string $area Dashboard workspace ID.
	 * @return string
	 */
	public static function get_dashboard_url( string $area = 'global-styles' ): string {
		$args = [
			'page' => self::MENU_SLUG,
		];

		if ( 'design-tokens' === $area ) {
			$args['view'] = 'design-tokens';
		}

		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	/**
	 * Register the Style Book preview query variable.
	 *
	 * @param array $vars Registered public query vars.
	 * @return array
	 */
	public function register_query_var( $vars ) {
		$vars[] = self::QUERY_VAR;

		return $vars;
	}

	/**
	 * Style Book URL used by the admin iframe when the "Book" mode is on.
	 *
	 * @return string
	 */
	public static function get_style_book_url(): string {
		return add_query_arg( self::QUERY_VAR, '1', home_url( '/' ) );
	}

	/**
	 * Home URL carrying the Studio preview marker. Every Studio dashboard
	 * (Global Styles and Design Tokens) uses this as its iframe
	 * base URL; the marker is what scopes the admin-bar suppression to our
	 * own preview frames. The frame chrome preserves the marker across
	 * same-origin in-iframe navigation.
	 *
	 * @return string
	 */
	public static function get_preview_home_url(): string {
		return add_query_arg( self::PREVIEW_QUERY_VAR, '1', home_url( '/' ) );
	}

	/**
	 * Origin (scheme + host + port) of the site — used by the iframe to tell
	 * internal navigation from external and block the latter.
	 *
	 * @return string
	 */
	public static function get_site_origin(): string {
		$parts = wp_parse_url( home_url( '/' ) );

		if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return '';
		}

		$origin = $parts['scheme'] . '://' . $parts['host'];

		if ( ! empty( $parts['port'] ) ) {
			$origin .= ':' . $parts['port'];
		}

		return $origin;
	}

	/**
	 * Whether the current request is the Style Book preview.
	 *
	 * @return bool
	 */
	public static function is_preview_request(): bool {
		if ( is_admin() ) {
			return false;
		}

		$value = get_query_var( self::QUERY_VAR );

		return is_scalar( $value ) && '1' === (string) $value;
	}

	/**
	 * Protect Studio preview requests and allow same-origin admin embedding.
	 *
	 * Run after WordPress's send_headers action, before the Style Book renders.
	 * Both preview modes require access and are non-indexable, including denials.
	 * Like the Customizer, previews own their framing policy. Preserve all other
	 * CSP directives, including separate policies sent by plugins through header().
	 * A later web-server or proxy policy can still prevent framing.
	 */
	public function send_preview_frame_headers() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only preview markers; authorization is checked separately.
		$is_preview = self::is_preview_request()
			|| '1' === ( $_GET[ self::PREVIEW_QUERY_VAR ] ?? null );
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		if ( ! $is_preview || is_admin() ) {
			return;
		}

		nocache_headers();
		add_filter( 'wp_robots', 'wp_robots_no_robots' );

		if ( ! headers_sent() ) {
			header( 'X-Robots-Tag: noindex, nofollow', true );
		}

		if ( ! is_user_logged_in() || ! GenerateBlocks_Pro_Styles::can_manage_styles() ) {
			wp_die(
				esc_html__( 'You do not have permission to view this preview.', 'generateblocks-pro' ),
				'',
				[ 'response' => 403 ]
			);
		}

		if ( headers_sent() ) {
			return;
		}

		$policies = [];

		foreach ( headers_list() as $header ) {
			if ( 0 === stripos( $header, 'Content-Security-Policy:' ) ) {
				$policies[] = self::get_preview_frame_policy( substr( $header, strlen( 'Content-Security-Policy:' ) ) );
			}
		}

		if ( ! $policies ) {
			$policies[] = "frame-ancestors 'self'";
		}

		header( 'X-Frame-Options: SAMEORIGIN' );

		foreach ( $policies as $index => $policy ) {
			header( 'Content-Security-Policy: ' . $policy, 0 === $index );
		}
	}

	/**
	 * Replace only frame-ancestors in each policy of a CSP header.
	 *
	 * Multiple policies are intersected by browsers, so each must allow 'self'.
	 * Commas separate policies and semicolons separate directives in CSP headers.
	 *
	 * @param string $value Existing Content-Security-Policy header value.
	 * @return string
	 */
	private static function get_preview_frame_policy( string $value ): string {
		$policies = explode( ',', $value );

		foreach ( $policies as &$policy ) {
			$policy = preg_replace( '/(^|;)\s*frame-ancestors(?:\s+[^;]*)?(?=;|$)/i', '$1', $policy );
			$policy = trim( $policy, " \t\n\r\0\x0B;" );
			$policy = ( '' !== $policy ? $policy . '; ' : '' ) . "frame-ancestors 'self'";
		}

		return implode( ',', $policies );
	}

	/**
	 * Suppress the admin bar inside our own preview iframes only.
	 *
	 * Scoped to requests explicitly carrying one of our preview markers —
	 * the Style Book route var or the Studio marker every dashboard appends
	 * to its iframe URL (and the frame chrome preserves across in-iframe
	 * navigation). Any other frontend request, including other plugins'
	 * iframes of the site, keeps its existing admin-bar behavior. If a
	 * marker gets lost (hand-edited URL, cross-origin frame), the
	 * client-side CSS injection in StudioPreviewFrame still hides the bar
	 * after load.
	 *
	 * @param bool $show Whether the admin bar should show.
	 * @return bool
	 */
	public function maybe_hide_admin_bar( $show ) {
		if ( is_admin() ) {
			return $show;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display toggle scoped to the current request.
		if ( isset( $_GET[ self::QUERY_VAR ] ) || isset( $_GET[ self::PREVIEW_QUERY_VAR ] ) ) {
			return false;
		}

		return $show;
	}

	/**
	 * Output the dynamic Style Book preview document and terminate the request.
	 *
	 * The preview renders a minimal standalone HTML document — `wp_head()` and
	 * `wp_footer()` pull in theme styles and the Global Styles CSS, but the
	 * theme's header/footer templates are intentionally skipped so the preview
	 * isn't wrapped in site chrome.
	 *
	 * @return void
	 */
	public function render_style_book_preview() {
		if ( ! self::is_preview_request() ) {
			return;
		}

		// Keep content protected even if the preview header hook is removed.
		if ( ! is_user_logged_in() || ! GenerateBlocks_Pro_Styles::can_manage_styles() ) {
			wp_die(
				esc_html__( 'You do not have permission to view this preview.', 'generateblocks-pro' ),
				'',
				[ 'response' => 403 ]
			);
		}

		show_admin_bar( false );

		?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, nofollow">
		<?php wp_head(); ?>
	<style id="gb-style-book-preview-base">
		html, body { margin: 0; padding: 0; }
		.gb-style-book-preview { padding: 2.5rem 2rem; max-width: 72rem; margin: 0 auto; }
		.gb-style-book-preview__section { scroll-margin-top: 2rem; margin: 0 0 3rem; }
		/* The rule under the section heading moved from the title to this row
			so a section's group affordance can sit beside the title above it.
			A section without a group renders an identical-looking header. */
		.gb-style-book-preview__section-header {
			display: flex;
			align-items: baseline;
			justify-content: space-between;
			gap: 1rem;
			margin: 0 0 1rem;
			padding-bottom: 0.5rem;
			border-bottom: 1px solid currentColor;
		}
		.gb-style-book-preview__section-title {
			font-size: 0.75rem;
			letter-spacing: 0.08em;
			text-transform: uppercase;
			opacity: 0.6;
			margin: 0;
		}
		/* Grouped selector entry point — same typographic family as the example
			labels, since it is the same kind of affordance one level up. */
		.gb-style-book-preview .gb-style-book-preview__section-group {
			font-size: 0.7rem;
			letter-spacing: 0.05em;
			text-transform: uppercase;
			opacity: 0.45;
			white-space: nowrap;
			cursor: pointer;
		}
		.gb-style-book-preview .gb-style-book-preview__section-group:hover {
			opacity: 0.9;
			text-decoration: underline;
		}
		.gb-style-book-preview .gb-style-book-preview__section-group:focus-visible {
			outline: 2px solid #2271b1;
			outline-offset: 2px;
		}
		.gb-style-book-preview__example {
			padding: 1rem 0;
			border-bottom: 1px dashed rgba(127, 127, 127, 0.25);
		}
		.gb-style-book-preview__example:last-child { border-bottom: 0; }
		.gb-style-book-preview__example-label {
			font-size: 0.7rem;
			letter-spacing: 0.05em;
			text-transform: uppercase;
			opacity: 0.45;
			margin-bottom: 0.5rem;
		}
		/* Click-to-edit affordance. Everything below is scoped under the
			preview wrapper or body so the theme's own outline rules can't win
			on specificity alone, and so none of it can leak into the site's
			real markup.

			The hover highlight and the floating label are driven entirely by
			the admin-side delegation in StudioDesignPreview.jsx, which adds and
			removes these classes on this document as the pointer moves. There
			is no wrapper :hover outline: the highlight lands on the exact
			element that would be edited, and two nested outlines at once reads
			as a rendering bug. */
		/* The label is a target in its own right: it opens the example's base
			selector, which is the reliable way in for an element its own
			children have covered up — a table's cells fill it completely. */
		.gb-style-book-preview .gb-style-book-preview__example-label { cursor: pointer; }
		/* Keyboard activation always targets the base element — only the
			wrapper is focusable — so the wrapper keeps its own focus ring. It
			deliberately has NO cursor: pointer, because most of its area is not
			a pointer target at all; only real base elements and their
			descendants are, and those get the cursor with the outline below. */
		.gb-style-book-preview .gb-style-book-preview__example-target:focus-visible {
			outline: 2px solid #2271b1;
			outline-offset: 4px;
		}
		.gb-style-book-preview-body .gb-style-book-target-hover {
			outline: 2px solid #2271b1;
			outline-offset: 2px;
			border-radius: 2px;
			cursor: pointer;
		}
		/* ── Base section ──
			The foundations that lead the sheet. Everything here is fixed px and
			scoped under the preview wrapper on purpose: this is chrome rather
			than a specimen, so it must not reflow with the theme's root font
			size, and it must outrank whatever the user writes for `button`,
			`a`, or `span`. The Forms section demonstrates `button`, so a
			single-element selector really can land on these rows. */
		.gb-style-book-preview .gb-style-book-base {
			--gb-style-book-ui-font: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;

			margin: 0 0 36px;
		}
		/* Same typographic family as the section group affordance beside it —
			the same kind of header-right label, minus the interaction. */
		.gb-style-book-preview .gb-style-book-base__meta {
			font-size: 11px;
			letter-spacing: 0.05em;
			text-transform: uppercase;
			opacity: 0.45;
			white-space: nowrap;
		}
		.gb-style-book-preview .gb-style-book-base__lead {
			max-width: 520px;
			margin: 14px 0 12px;
			font-family: var(--gb-style-book-ui-font);
			font-size: 13px;
			line-height: 1.6;
			color: inherit;
		}
		.gb-style-book-preview .gb-style-book-base__band {
			border-radius: 4px;
			background: #f7f8f8;
		}
		/* A full button reset, not a partial one: whatever the site's `button`
			style sets, the row has to look like a row. */
		.gb-style-book-preview .gb-style-book-base__row {
			-webkit-appearance: none;
			appearance: none;
			display: flex;
			align-items: center;
			gap: 20px;
			width: 100%;
			margin: 0;
			padding: 13px 16px;
			border: 0;
			border-radius: 3px;
			background: transparent;
			box-shadow: none;
			/* The row's name is a specimen of the site's own type, so the row
				inherits the body font and only the caption opts out of it. */
			font: inherit;
			color: inherit;
			text-align: left;
			text-decoration: none;
			text-transform: none;
			letter-spacing: normal;
			cursor: pointer;
			transition: background 0.1s, box-shadow 0.1s;
		}
		.gb-style-book-preview .gb-style-book-base__name {
			flex: 0 0 104px;
			font-size: 16px;
			line-height: 1.3;
			font-weight: 500;
			color: #1d2327;
			white-space: nowrap;
		}
		.gb-style-book-preview .gb-style-book-base__caption {
			flex: 1 1 auto;
			min-width: 0;
			font-family: var(--gb-style-book-ui-font);
			font-size: 13px;
			line-height: 1.5;
			color: #757575;
			/* In a narrow frame the caption gives up its tail rather than
				wrapping the row onto a second line. The name never truncates
				before it does — it is the thing being named. */
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
		.gb-style-book-preview .gb-style-book-base__pencil {
			flex: 0 0 auto;
			stroke: #1d2327;
			opacity: 0.3;
			transition: opacity 0.1s, stroke 0.1s;
		}
		/* Every state ring is a box-shadow rather than a border or an outline
			with an offset, so nothing in the band shifts as the pointer runs
			down it. The caption's TEXT is identical in all three states; only
			its color moves. */
		.gb-style-book-preview .gb-style-book-base__row:hover {
			background: #fff;
			box-shadow: 0 0 0 1px #2271b1;
		}
		.gb-style-book-preview .gb-style-book-base__row:hover .gb-style-book-base__pencil {
			stroke: #2271b1;
			opacity: 1;
		}
		/* Two rings: a white one to clear the band, then the accent outside it,
			so the focus ring stays legible against the tinted background. */
		.gb-style-book-preview .gb-style-book-base__row:focus-visible {
			background: #fff;
			outline: none;
			box-shadow: 0 0 0 2px #fff, 0 0 0 4px #2271b1;
		}
		/* Selected is set and cleared by the admin-side delegation, from the
			style the side panel currently has open. The two must never disagree
			about what is being edited. */
		.gb-style-book-preview .gb-style-book-base--selected {
			background: #eef4fb;
			box-shadow: 0 0 0 1px #2271b1;
		}
		.gb-style-book-preview .gb-style-book-base--selected .gb-style-book-base__name {
			font-weight: 600;
			color: #0a4b78;
		}
		.gb-style-book-preview .gb-style-book-base--selected .gb-style-book-base__caption {
			color: #2271b1;
		}
		.gb-style-book-preview .gb-style-book-base--selected .gb-style-book-base__pencil {
			stroke: #2271b1;
		}
		.gb-style-book-preview-body .gb-style-book-tooltip {
			position: fixed;
			z-index: 2147483647;
			display: none;
			margin: 0;
			padding: 2px 6px;
			border-radius: 3px;
			background: #1e1e1e;
			color: #fff;
			font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
			font-size: 11px;
			line-height: 1.5;
			white-space: nowrap;
			pointer-events: none;
		}
	</style>
</head>
<body dir="ltr" <?php body_class( 'gb-style-book-preview-body' ); ?>>
	<div class="gb-style-book-preview">
		<?php include GENERATEBLOCKS_PRO_DIR . 'includes/style-book/templates/content.php'; ?>
	</div>
		<?php wp_footer(); ?>
</body>
</html>
		<?php
		exit;
	}
}

GenerateBlocks_Pro_Style_Book::get_instance()->init();
