<?php
/**
 * Style Book preview content.
 *
 * Curated examples per category, rendered inside the Style Book preview
 * document at request time. Every example sits inside a click target carrying
 * the selector it demonstrates in `data-gb-selector`; the admin app delegates
 * clicks and Enter/Space on those targets into the Styles Builder side panel.
 *
 * @package GenerateBlocksPro\Style_Book
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Helper: render one example with its label, click target and HTML.
 *
 * @param string $selector The CSS selector the example represents.
 * @param string $label    Human label for the example.
 * @param string $html     Inner HTML markup.
 * @return void
 */
$render_example = static function ( string $selector, string $label, string $html ): void {
	printf(
		'<div class="gb-style-book-preview__example"><div class="gb-style-book-preview__example-label">%1$s</div><div class="gb-style-book-preview__example-target" data-gb-selector="%2$s" tabindex="0" role="button" aria-label="%3$s">%4$s</div></div>',
		esc_html( $label ),
		esc_attr( $selector ),
		esc_attr(
			sprintf(
				/* translators: %s: CSS selector the example demonstrates. */
				__( 'Edit %s styles', 'generateblocks-pro' ),
				$selector
			)
		),
		// $html is trusted template output below — the helper is only called
		// with literal strings from this file, not user input.
		$html // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	);
};

/**
 * Helper: render one Base row.
 *
 * A real <button>, unlike the `role="button"` example targets: a Base row is a
 * plain control with no specimen inside it, so the browser's own Enter/Space
 * activation is all it needs. That is deliberate — it is the one affordance in
 * the sheet whose keyboard behavior the admin app does NOT have to synthesize.
 *
 * @param array  $row    Row definition: attribute, selector, name, caption.
 * @param string $pencil Inline pencil markup shared by every row.
 * @return void
 */
$render_base_row = static function ( array $row, string $pencil ): void {
	printf(
		'<button type="button" class="gb-style-book-base__row" data-gb-base-target %1$s="%2$s" aria-label="%3$s"><span class="gb-style-book-base__name">%4$s</span><span class="gb-style-book-base__caption">%5$s</span>%6$s</button>',
		esc_attr( $row['attribute'] ),
		esc_attr( $row['selector'] ),
		esc_attr(
			sprintf(
				/* translators: 1: name of the foundation, e.g. "Body". 2: the CSS selector it opens, e.g. "body". */
				__( 'Edit %1$s style (%2$s)', 'generateblocks-pro' ),
				$row['name'],
				$row['selector']
			)
		),
		esc_html( $row['name'] ),
		esc_html( $row['caption'] ),
		// Literal template markup defined below, not user input.
		$pencil // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	);
};

/**
 * The one grouped headings selector.
 *
 * Written in the compact form the primary-selector canonicalizer stores.
 * Hand-typed member whitespace now converges on this same identity.
 *
 * Read from one variable by BOTH the Base section's "Headings" row and the
 * Headings section's own "All headings" affordance. They have to open the
 * identical record, and one literal prevents membership or order from drifting.
 */
$heading_group_selector = ':is(h1,h2,h3,h4,h5,h6)';

// The core `edit` glyph, inlined: the preview is a standalone document that
// deliberately loads no admin assets. Drawn as a stroke rather than a fill so
// the row's hover, focus, and selected states can recolor it from the
// stylesheet in `class-style-book.php`.
$base_pencil = '<svg class="gb-style-book-base__pencil" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="m19 7-3-3-8.5 8.5-1 4 4-1L19 7Zm-7 11.5H5V20h7v-1.5Z" /></svg>';

/*
 * The foundations, and only the foundations.
 *
 * A "Buttons" row was considered and cut: pattern buttons are
 * `.gb-button--primary` class styles and are frequently anchors, so the
 * `button` element misses them and no single selector honestly represents
 * "all buttons". Rationale and the revisit condition live in
 * docs/style-book-base-section.md.
 */
$base_rows = [
	[
		'attribute' => 'data-gb-selector',
		'selector'  => 'body',
		'name'      => __( 'Body', 'generateblocks-pro' ),
		'caption'   => __( 'Background, font, size and text color', 'generateblocks-pro' ),
	],
	[
		'attribute' => 'data-gb-selector',
		'selector'  => 'a',
		'name'      => __( 'Links', 'generateblocks-pro' ),
		'caption'   => __( 'Link color, underline and hover', 'generateblocks-pro' ),
	],
	[
		'attribute' => 'data-gb-group-selector',
		'selector'  => $heading_group_selector,
		'name'      => __( 'Headings', 'generateblocks-pro' ),
		'caption'   => __( 'Shared family and weight for h1–h6', 'generateblocks-pro' ),
	],
];

// The count only answers whether the user has ordinary Global Styles. Drafts
// count as user work, while the internal managed :root record does not. Root
// resolution is request-memoized and is normally already warm from wp_head().
$style_counts = wp_count_posts( 'gblocks_styles' );
$style_count = is_object( $style_counts )
	? (int) ( $style_counts->publish ?? 0 ) + (int) ( $style_counts->draft ?? 0 )
	: 0;

if ( $style_count > 0 && class_exists( 'GenerateBlocks_Pro_Styles_Root' ) ) {
	$root = GenerateBlocks_Pro_Styles_Root::resolve();

	foreach ( $root['ids'] as $root_id ) {
		$root_post = get_post( $root_id );

		if ( $root_post instanceof WP_Post && in_array( $root_post->post_status, [ 'publish', 'draft' ], true ) ) {
			--$style_count;
		}
	}
}

$has_any_styles = $style_count > 0;

$sections = [
	'headings' => [
		'title'    => __( 'Headings', 'generateblocks-pro' ),
		// Optional per-section grouped selector, shared with the Base row above.
		'group'    => [
			'selector' => $heading_group_selector,
			'label'    => __( 'All headings', 'generateblocks-pro' ),
		],
		'examples' => [
			[ 'h1', 'h1', '<h1>The quick brown fox jumps over the lazy dog</h1>' ],
			[ 'h2', 'h2', '<h2>The quick brown fox jumps over the lazy dog</h2>' ],
			[ 'h3', 'h3', '<h3>The quick brown fox jumps over the lazy dog</h3>' ],
			[ 'h4', 'h4', '<h4>The quick brown fox jumps over the lazy dog</h4>' ],
			[ 'h5', 'h5', '<h5>The quick brown fox jumps over the lazy dog</h5>' ],
			[ 'h6', 'h6', '<h6>The quick brown fox jumps over the lazy dog</h6>' ],
		],
	],
	'text' => [
		'title'    => __( 'Text', 'generateblocks-pro' ),
		'examples' => [
			[ 'p', 'Paragraph', '<p>GenerateBlocks makes it easy to build fast, accessible websites with the tools you already love. This paragraph demonstrates body-copy styling across line height, spacing, and color.</p>' ],
			[ 'a', 'Link', '<p>Read the <a href="#preview">documentation</a> or browse the <a href="#preview">pattern library</a>.</p>' ],
			[ 'strong', 'Strong', '<p>Use <strong>strong emphasis</strong> to highlight important terms inside running prose.</p>' ],
			[ 'em', 'Emphasis', '<p>And <em>italic emphasis</em> for titles, tone, or technical terms.</p>' ],
			[ 'small', 'Small', '<p><small>Small text is useful for fine print, captions, and legal copy.</small></p>' ],
			[ 'mark', 'Highlight', '<p>You can <mark>highlight relevant text</mark> to draw the reader\'s eye.</p>' ],
			[ 'blockquote', 'Blockquote', '<blockquote><p>Design is not just what it looks like and feels like. Design is how it works.</p></blockquote>' ],
			[ 'code', 'Inline code', '<p>Install via <code>npm install @generateblocks/pro</code>.</p>' ],
			[ 'pre', 'Code block', '<pre><code>function hello() {' . "\n" . '    return "world";' . "\n" . '}</code></pre>' ],
			[ 'hr', 'Divider', '<hr />' ],
		],
	],
	'layout' => [
		'title'    => __( 'Layout elements', 'generateblocks-pro' ),
		'examples' => [
			[ 'section', 'Section', '<section aria-label="Section example">A section groups related content.</section>' ],
			[ 'article', 'Article', '<article aria-label="Article example">An article is a self-contained piece of content.</article>' ],
			[ 'aside', 'Aside', '<aside aria-label="Aside example">An aside contains supporting content.</aside>' ],
			[ 'main', 'Main', '<main aria-label="Main example">The main element contains the primary page content.</main>' ],
		],
	],
	'lists' => [
		'title'    => __( 'Lists', 'generateblocks-pro' ),
		'examples' => [
			[ 'ul', 'Unordered list', '<ul><li>First item</li><li>Second item</li><li>Third item</li></ul>' ],
			[ 'ol', 'Ordered list', '<ol><li>Open the Style Book</li><li>Click an element</li><li>Edit its styles</li></ol>' ],
		],
	],
	'forms' => [
		'title'    => __( 'Forms', 'generateblocks-pro' ),
		'examples' => [
			[ 'label', 'Label', '<label for="sb-text-input">Text input</label>' ],
			[ 'input', 'Text input', '<input id="sb-text-input" type="text" placeholder="Type here…" />' ],
			[ 'textarea', 'Textarea', '<textarea rows="3" placeholder="Tell us more…"></textarea>' ],
			[ 'select', 'Select', '<select><option>Option A</option><option>Option B</option></select>' ],
			[ 'button', 'Button', '<button type="button">Primary action</button>' ],
			[ 'fieldset', 'Fieldset', '<fieldset><legend>Preferences</legend><label><input type="checkbox" /> Subscribe</label></fieldset>' ],
		],
	],
	'tables' => [
		'title'    => __( 'Tables', 'generateblocks-pro' ),
		'examples' => [
			[ 'table', 'Table', '<table><thead><tr><th>Plan</th><th>Price</th><th>Sites</th></tr></thead><tbody><tr><td>Starter</td><td>$39</td><td>1</td></tr><tr><td>Growth</td><td>$79</td><td>10</td></tr><tr><td>Pro</td><td>$199</td><td>Unlimited</td></tr></tbody></table>' ],
		],
	],
	'media' => [
		'title'    => __( 'Media', 'generateblocks-pro' ),
		'examples' => [
			// Inline SVG data URI placeholder — no external request, so the
			// preview works offline and never phones home to a third party.
			//
			// `img` stands on its own AND appears inside the figure below. They
			// are different styles: this one is every image on the site, the
			// figure's is `figure img`, reached by pointing at the image inside
			// it. Both stay reachable because each example targets its own base.
			[ 'img', 'Image', '<img src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22640%22%20height=%22360%22%20viewBox=%220%200%20640%20360%22%3E%3Crect%20width=%22640%22%20height=%22360%22%20fill=%22%23dfe3e8%22/%3E%3Crect%20x=%22260%22%20y=%22130%22%20width=%22120%22%20height=%22100%22%20rx=%228%22%20fill=%22%23b6bfca%22/%3E%3Ccircle%20cx=%22296%22%20cy=%22164%22%20r=%2214%22%20fill=%22%23dfe3e8%22/%3E%3Cpath%20d=%22M272%20214l30-32%2022%2024%2020-18%2024%2026z%22%20fill=%22%23dfe3e8%22/%3E%3C/svg%3E" alt="Example placeholder image" width="640" height="360" />' ],
			[ 'figure', 'Figure with caption', '<figure><img src="data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%22640%22%20height=%22360%22%20viewBox=%220%200%20640%20360%22%3E%3Crect%20width=%22640%22%20height=%22360%22%20fill=%22%23dfe3e8%22/%3E%3Crect%20x=%22260%22%20y=%22130%22%20width=%22120%22%20height=%22100%22%20rx=%228%22%20fill=%22%23b6bfca%22/%3E%3Ccircle%20cx=%22296%22%20cy=%22164%22%20r=%2214%22%20fill=%22%23dfe3e8%22/%3E%3Cpath%20d=%22M272%20214l30-32%2022%2024%2020-18%2024%2026z%22%20fill=%22%23dfe3e8%22/%3E%3C/svg%3E" alt="Example placeholder image" width="640" height="360" /><figcaption>A caption describes the image above.</figcaption></figure>' ],
		],
	],
];

/*
 * The Base section leads the sheet. Everything below it is a specimen OF these
 * three styles, so they are named first and reached in one click rather than
 * hunted for among the examples that inherit from them.
 */
?>
<div class="gb-style-book-preview__section gb-style-book-base<?php echo $has_any_styles ? '' : ' gb-style-book-base--first-run'; ?>">
	<div class="gb-style-book-preview__section-header">
		<?php // NOT an <h2>, for the same reason as every other section title below. ?>
		<div class="gb-style-book-preview__section-title" role="heading" aria-level="2"><?php esc_html_e( 'Base', 'generateblocks-pro' ); ?></div>
		<?php // Plain text, deliberately not an affordance: the three rows are the way in, and a fourth clickable thing in the header would only compete with them. ?>
		<div class="gb-style-book-base__meta">
			<?php
			echo esc_html(
				$has_any_styles
					? sprintf(
						/* translators: %d: number of foundation styles listed in the Base section. */
						_n( '%d style', '%d styles', count( $base_rows ), 'generateblocks-pro' ),
						count( $base_rows )
					)
					: __( 'Start here', 'generateblocks-pro' )
			);
			?>
		</div>
	</div>
	<?php // NOT a <p>: a paragraph here would take on the site's own `p` Global Style, and the book's chrome must never match the styles being edited. ?>
	<div class="gb-style-book-base__lead">
		<?php
		echo esc_html(
			$has_any_styles
				? __( 'Your site\'s foundations. Click one to edit it — every sample below inherits from these.', 'generateblocks-pro' )
				: __( 'Nothing here is customized yet — the samples below are your theme\'s defaults. Click a foundation to change it everywhere at once.', 'generateblocks-pro' )
		);
		?>
	</div>
	<div class="gb-style-book-base__band">
		<?php
		foreach ( $base_rows as $base_row ) {
			$render_base_row( $base_row, $base_pencil );
		}
		?>
	</div>
</div>
<?php
foreach ( $sections as $slug => $section ) :
	?>
	<div class="gb-style-book-preview__section">
		<div class="gb-style-book-preview__section-header">
			<?php // NOT an <h2>: the book's chrome must never match the element styles being edited. A real heading here picks up every h2 / :is(h1,…) Global Style the user writes — an italic "Headings" title while previewing italic headings, or invisible chrome if they set heading color to the background. role/aria-level keep the outline for screen readers. ?>
			<div class="gb-style-book-preview__section-title" role="heading" aria-level="2"><?php echo esc_html( $section['title'] ); ?></div>
			<?php
			if ( ! empty( $section['group']['selector'] ) ) {
				$group_label = $section['group']['label'];
				$group_aria  = sprintf(
					/* translators: %s: group of elements, e.g. "All headings". */
					__( 'Edit %s styles', 'generateblocks-pro' ),
					$group_label
				);

				printf(
					'<div class="gb-style-book-preview__section-group" data-gb-group-selector="%1$s" role="button" tabindex="0" aria-label="%2$s">%3$s</div>',
					esc_attr( $section['group']['selector'] ),
					esc_attr( $group_aria ),
					esc_html( $group_label )
				);
			}
			?>
		</div>
		<?php
		foreach ( $section['examples'] as $example ) {
			[ $selector, $label, $html ] = $example;
			$render_example( $selector, $label, $html );
		}
		?>
	</div>
	<?php
endforeach;
