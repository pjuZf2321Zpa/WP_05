<?php
/**
 * REST response utilities trait.
 *
 * @package GenerateBlocksPro\Utils
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shared REST response helpers.
 */
trait GenerateBlocks_Pro_REST_Response {

	/**
	 * Success response.
	 *
	 * @param mixed $response Response data.
	 * @return WP_REST_Response
	 */
	public function success( $response ) {
		return new WP_REST_Response(
			[
				'success'  => true,
				'response' => $response,
			],
			200
		);
	}

	/**
	 * Error response.
	 *
	 * @param string $code     Error code.
	 * @param string $response Error message.
	 * @param int    $status   HTTP status code.
	 * @return WP_REST_Response
	 */
	public function error( $code, $response, $status = 400 ) {
		return new WP_REST_Response(
			[
				'error'      => true,
				'success'    => false,
				'error_code' => $code,
				'response'   => $response,
			],
			$status
		);
	}

	/**
	 * Normalize list pagination to avoid unbounded editor-side responses.
	 *
	 * @param mixed $per_page        Requested per-page value.
	 * @param bool  $allow_unbounded Whether -1 should be allowed.
	 * @return int
	 */
	private function normalize_per_page( $per_page, $allow_unbounded = false ) {
		$per_page = intval( $per_page );

		if ( -1 === $per_page && $allow_unbounded ) {
			return -1;
		}

		if ( $per_page < 1 ) {
			$per_page = 100;
		}

		return min( $per_page, 100 );
	}

	/**
	 * Sanitize a per_page route arg, preserving -1 as "no limit".
	 *
	 * Public because WP REST invokes sanitize_callback externally.
	 * Route-arg sanitizing only — normalize_per_page() still applies the
	 * hard cap when the handler builds its query.
	 *
	 * @param mixed $value Requested per-page value.
	 * @return int
	 */
	public function sanitize_per_page( $value ) {
		$value = intval( $value );

		return -1 === $value ? -1 : absint( $value );
	}

	/**
	 * Format a MySQL GMT datetime as an ISO 8601 UTC string for REST responses.
	 *
	 * Client-side relative-time helpers need an explicit UTC designator - a bare
	 * MySQL datetime gets parsed in the browser's local timezone.
	 *
	 * @param mixed $gmt_datetime MySQL 'Y-m-d H:i:s' datetime string in GMT.
	 * @return string ISO 8601 'Y-m-d\TH:i:sZ' string, or '' when unset.
	 */
	private function format_gmt_datetime( $gmt_datetime ) {
		if ( ! is_string( $gmt_datetime ) || '' === trim( $gmt_datetime ) || 0 === strpos( $gmt_datetime, '0000-00-00' ) ) {
			return '';
		}

		return str_replace( ' ', 'T', trim( $gmt_datetime ) ) . 'Z';
	}

	/**
	 * Check whether a value was explicitly submitted with the request.
	 *
	 * Unlike WP_REST_Request::has_param(), this ignores schema defaults so
	 * partial updates only touch fields the client actually sent. JSON and
	 * form bodies as well as query args count as submitted.
	 *
	 * @param WP_REST_Request $request The request object.
	 * @param string          $param   The parameter name.
	 * @return bool
	 */
	private function has_submitted_param( WP_REST_Request $request, $param ) {
		$json_params = $request->get_json_params();

		if ( is_array( $json_params ) && array_key_exists( $param, $json_params ) ) {
			return true;
		}

		$body_params = $request->get_body_params();

		if ( is_array( $body_params ) && array_key_exists( $param, $body_params ) ) {
			return true;
		}

		$query_params = $request->get_query_params();

		return is_array( $query_params ) && array_key_exists( $param, $query_params );
	}
}
