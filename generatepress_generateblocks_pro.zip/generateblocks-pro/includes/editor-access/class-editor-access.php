<?php
/**
 * The Editor Access main class.
 *
 * @package GenerateBlocks Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main class for the Editor Access system.
 */
class GenerateBlocks_Pro_Editor_Access extends GenerateBlocks_Pro_Singleton {
	/**
	 * Initialize the Editor Access system.
	 */
	public function init() {
		// Nothing to initialize at this time. Sub-classes handle their own hooks.
	}

	/**
	 * Get the capability required for Editor Access.
	 *
	 * @param string $context The context: 'use' (apply existing) or 'manage' (create/edit/delete).
	 * @return string The capability required.
	 */
	public static function get_editor_access_capability( $context = 'use' ) {
		if ( 'manage' === $context ) {
			$capability = 'manage_options';
		} else {
			$capability = 'edit_posts';
		}

		/**
		 * Filter the capability required for Editor Access.
		 *
		 * @param string $capability The capability required.
		 * @param string $context    The context: 'use' or 'manage'.
		 */
		$filtered_capability = apply_filters( 'generateblocks_editor_access_capability', $capability, $context );

		return is_string( $filtered_capability ) && '' !== $filtered_capability
			? $filtered_capability
			: $capability;
	}

	/**
	 * Check if current user can use Editor Access.
	 *
	 * @param string $context The context: 'use' (apply existing) or 'manage' (create/edit/delete).
	 * @return bool
	 */
	public static function current_user_can_use_editor_access( $context = 'use' ) {
		$capability = self::get_editor_access_capability( $context );

		return current_user_can( $capability );
	}

	/**
	 * Invalidate cached Editor Access data.
	 */
	public static function invalidate_editor_access_cache() {
		delete_transient( 'gb_access_profile_data' );
		delete_transient( 'gb_access_profile_preview_data' );
	}

	/**
	 * Get the default access profile shape.
	 *
	 * @return array Default access profile data.
	 */
	public static function get_default_profile() {
		return [
			'scope'        => [
				'roles'     => [],
				'postTypes' => [],
			],
			'fallbackMode' => '',
			'rules'        => [],
			'inserter'     => self::get_default_inserter_policy(),
		];
	}

	/**
	 * Get the default inserter policy shape.
	 *
	 * @return array
	 */
	public static function get_default_inserter_policy() {
		return [
			'mode'  => 'all',
			'items' => [],
		];
	}

	/**
	 * Get known GenerateBlocks-owned inserter entries.
	 *
	 * This list is owned by Pro for Editor Access governance. It does not
	 * require a matching registry in GenerateBlocks, so older/free versions
	 * continue to load safely and missing blocks are filtered by registration.
	 *
	 * @return array
	 */
	public static function get_known_inserter_entries() {
		return [
			[
				'id'            => 'variation:generateblocks/text:generateblocks/heading',
				'blockName'     => 'generateblocks/text',
				'variationName' => 'generateblocks/heading',
				'title'         => __( 'Headline', 'generateblocks-pro' ),
				'category'      => 'generateblocks',
				'isDefault'     => false,
			],
			[
				'id'            => 'variation:generateblocks/text:generateblocks/button',
				'blockName'     => 'generateblocks/text',
				'variationName' => 'generateblocks/button',
				'title'         => __( 'Button', 'generateblocks-pro' ),
				'category'      => 'generateblocks',
				'isDefault'     => false,
			],
			[
				'id'            => 'variation:generateblocks/element:generateblocks/container',
				'blockName'     => 'generateblocks/element',
				'variationName' => 'generateblocks/container',
				'title'         => __( 'Container', 'generateblocks-pro' ),
				'category'      => 'generateblocks',
				'isDefault'     => true,
			],
			[
				'id'            => 'variation:generateblocks/element:generateblocks/grid',
				'blockName'     => 'generateblocks/element',
				'variationName' => 'generateblocks/grid',
				'title'         => __( 'Grid', 'generateblocks-pro' ),
				'category'      => 'generateblocks',
				'isDefault'     => false,
			],
			[
				'id'            => 'variation:generateblocks/media:generateblocks/image',
				'blockName'     => 'generateblocks/media',
				'variationName' => 'generateblocks/image',
				'title'         => __( 'Image', 'generateblocks-pro' ),
				'category'      => 'generateblocks',
				'isDefault'     => true,
			],
			[
				'id'            => 'variation:generateblocks/shape:generateblocks/shape',
				'blockName'     => 'generateblocks/shape',
				'variationName' => 'generateblocks/shape',
				'title'         => __( 'Shape', 'generateblocks-pro' ),
				'category'      => 'generateblocks',
				'isDefault'     => true,
			],
			[
				'id'            => 'variation:generateblocks/query:query',
				'blockName'     => 'generateblocks/query',
				'variationName' => 'query',
				'title'         => __( 'Query', 'generateblocks-pro' ),
				'category'      => 'generateblocks',
				'isDefault'     => true,
			],
			[
				'id'            => 'variation:generateblocks-pro/accordion:generateblocks/accordion',
				'blockName'     => 'generateblocks-pro/accordion',
				'variationName' => 'generateblocks/accordion',
				'title'         => __( 'Accordion', 'generateblocks-pro' ),
				'category'      => 'generateblocks',
				'isDefault'     => true,
			],
			[
				'id'            => 'variation:generateblocks-pro/tabs:tabs',
				'blockName'     => 'generateblocks-pro/tabs',
				'variationName' => 'tabs',
				'title'         => __( 'Tabs', 'generateblocks-pro' ),
				'category'      => 'generateblocks',
				'isDefault'     => true,
			],
			[
				'id'            => 'variation:generateblocks-pro/carousel:carousel',
				'blockName'     => 'generateblocks-pro/carousel',
				'variationName' => 'carousel',
				'title'         => __( 'Carousel', 'generateblocks-pro' ),
				'category'      => 'generateblocks',
				'isDefault'     => true,
			],
			[
				'id'            => 'variation:generateblocks-pro/carousel-control:carousel-control',
				'blockName'     => 'generateblocks-pro/carousel-control',
				'variationName' => 'carousel-control',
				'title'         => __( 'Carousel Control', 'generateblocks-pro' ),
				'category'      => 'generateblocks',
				'isDefault'     => true,
			],
			[
				'id'            => 'variation:generateblocks-pro/navigation:navigation',
				'blockName'     => 'generateblocks-pro/navigation',
				'variationName' => 'navigation',
				'title'         => __( 'Navigation', 'generateblocks-pro' ),
				'category'      => 'generateblocks',
				'isDefault'     => true,
			],
			[
				'id'            => 'variation:generateblocks-pro/menu-toggle:menu-toggle',
				'blockName'     => 'generateblocks-pro/menu-toggle',
				'variationName' => 'menu-toggle',
				'title'         => __( 'Menu Toggle', 'generateblocks-pro' ),
				'category'      => 'generateblocks',
				'isDefault'     => true,
			],
			[
				'id'            => 'variation:generateblocks-pro/form:form',
				'blockName'     => 'generateblocks-pro/form',
				'variationName' => 'form',
				'title'         => __( 'Form', 'generateblocks-pro' ),
				'category'      => 'generateblocks',
				'isDefault'     => true,
			],
		];
	}

	/**
	 * Get child block types each composite block needs to stay functional.
	 *
	 * Core's canInsertBlockType consults the editor-wide allow list before
	 * parent/ancestor constraints, so an allowed composite block needs its
	 * child types in the list or its own add-item flows silently fail. Most
	 * children declare parent/ancestor metadata and are expanded from the
	 * registry; this map covers the ones that are standalone-capable, where
	 * adding that metadata in block.json would restrict legitimate use.
	 *
	 * Owned by Pro for Editor Access governance, like the known inserter
	 * entries above.
	 *
	 * @return array Map of block type name to child block type names.
	 */
	public static function get_companion_block_types() {
		$companions = apply_filters(
			'generateblocks_editor_access_companion_block_types',
			[
				'generateblocks/query'          => [ 'generateblocks/looper' ],
				'generateblocks-pro/carousel'   => [ 'generateblocks-pro/carousel-control' ],
				'generateblocks-pro/navigation' => [ 'generateblocks-pro/menu-container' ],
			]
		);

		if ( ! is_array( $companions ) ) {
			return [];
		}

		$sanitized = [];

		foreach ( $companions as $block_name => $children ) {
			if ( ! is_string( $block_name ) || '' === $block_name || ! is_array( $children ) ) {
				continue;
			}

			$children = array_values(
				array_filter(
					$children,
					static function ( $child ) {
						return is_string( $child ) && '' !== $child;
					}
				)
			);

			if ( ! empty( $children ) ) {
				$sanitized[ $block_name ] = $children;
			}
		}

		return $sanitized;
	}

	/**
	 * Sanitize an array of text values.
	 *
	 * @param mixed $values Values to sanitize.
	 * @return array
	 */
	private static function sanitize_text_list( $values ) {
		if ( ! is_array( $values ) ) {
			return [];
		}

		return array_values(
			array_filter(
				array_unique(
					array_map( 'sanitize_text_field', $values )
				)
			)
		);
	}

	/**
	 * Sanitize an ordered list of positive integer IDs.
	 *
	 * @param mixed $values Values to sanitize.
	 * @return array
	 */
	private static function sanitize_absint_list( $values ) {
		if ( ! is_array( $values ) ) {
			return [];
		}

		$sanitized = [];

		foreach ( $values as $value ) {
			$id = absint( $value );

			if ( ! $id || in_array( $id, $sanitized, true ) ) {
				continue;
			}

			$sanitized[] = $id;
		}

		return $sanitized;
	}

	/**
	 * Sanitize an inserter policy for storage.
	 *
	 * @param mixed $policy The submitted policy.
	 * @return array
	 */
	public static function sanitize_inserter_policy( $policy ) {
		$defaults = self::get_default_inserter_policy();

		if ( ! is_array( $policy ) ) {
			return $defaults;
		}

		$mode = isset( $policy['mode'] ) ? sanitize_text_field( $policy['mode'] ) : $defaults['mode'];

		if ( ! in_array( $mode, [ 'all', 'selected', 'none' ], true ) ) {
			$mode = $defaults['mode'];
		}

		return [
			'mode'  => $mode,
			'items' => self::sanitize_text_list( $policy['items'] ?? [] ),
		];
	}

	/**
	 * Sanitize an Access Profile for storage.
	 *
	 * @param mixed $profile The profile data to sanitize.
	 * @return array Sanitized profile array.
	 */
	public static function sanitize_profile( $profile ) {
		$defaults = self::get_default_profile();

		if ( ! is_array( $profile ) ) {
			return $defaults;
		}

		$scope = isset( $profile['scope'] ) && is_array( $profile['scope'] )
			? $profile['scope']
			: [];

		$sanitized = [
			'scope'        => [
				'roles'     => self::sanitize_text_list( $scope['roles'] ?? [] ),
				'postTypes' => self::sanitize_text_list( $scope['postTypes'] ?? [] ),
			],
			'fallbackMode' => self::sanitize_mode( $profile['fallbackMode'] ?? '' ),
			'rules'        => [],
			'inserter'     => self::sanitize_inserter_policy( $profile['inserter'] ?? [] ),
		];

		if ( isset( $profile['rules'] ) && is_array( $profile['rules'] ) ) {
			$sanitized['rules'] = array_values(
				array_filter(
					array_map( [ self::class, 'sanitize_profile_rule' ], $profile['rules'] )
				)
			);
		}

		return $sanitized;
	}

	/**
	 * Sanitize a single ordered Access Profile rule.
	 *
	 * @param mixed $rule The submitted rule.
	 * @return array|null
	 */
	public static function sanitize_profile_rule( $rule ) {
		if ( ! is_array( $rule ) ) {
			return null;
		}

		$target = isset( $rule['target'] ) && is_array( $rule['target'] )
			? $rule['target']
			: [];

		$block_type = sanitize_text_field( $target['blockType'] ?? '' );
		$mode       = self::sanitize_rule_mode( $rule['mode'] ?? '' );

		// Empty block types are preserved for drafts.
		// Runtime matching and publish validation fail closed.
		if ( array_key_exists( 'conditions', $target ) ) {
			$conditions = $target['conditions'];
		} elseif ( array_key_exists( 'attributeConditions', $rule ) ) {
			$conditions = $rule['attributeConditions'];
		} else {
			$conditions = [];
		}

		return [
			'id'           => isset( $rule['id'] ) ? sanitize_key( $rule['id'] ) : '',
			'label'        => isset( $rule['label'] ) ? sanitize_text_field( $rule['label'] ) : '',
			'target'       => [
				'blockType'  => $block_type,
				'kind'       => isset( $target['kind'] ) ? sanitize_key( $target['kind'] ) : '',
				'conditions' => self::sanitize_attribute_conditions( $conditions ),
			],
			'mode'          => $mode,
			'controlSetIds' => self::sanitize_absint_list( $rule['controlSetIds'] ?? [] ),
		];
	}

	/**
	 * Sanitize attribute conditions array for storage.
	 *
	 * Expects flat AND-only format: [ { attribute, operator, value } ].
	 * Incomplete rows are preserved as empty sanitized rows so runtime matching
	 * fails closed instead of broadening the rule.
	 *
	 * @param mixed $conditions The conditions data to sanitize.
	 * @return array Sanitized conditions array.
	 */
	public static function sanitize_attribute_conditions( $conditions ) {
		$fail_closed       = [
			'attribute' => '',
			'operator'  => 'is',
			'value'     => '',
		];
		$allowed_operators = [ 'exists', 'is', 'is not', 'contains', 'does not contain', 'includes', 'does not include' ];

		if ( ! is_array( $conditions ) ) {
			return [ $fail_closed ];
		}

		return array_values(
			array_map(
				function ( $condition ) use ( $allowed_operators, $fail_closed ) {
					if ( ! is_array( $condition ) ) {
						return $fail_closed;
					}

					$attribute = isset( $condition['attribute'] ) && is_scalar( $condition['attribute'] )
						? sanitize_text_field( (string) $condition['attribute'] )
						: '';
					$operator  = isset( $condition['operator'] ) && is_scalar( $condition['operator'] )
						? sanitize_text_field( (string) $condition['operator'] )
						: 'is';

					if ( ! in_array( $operator, $allowed_operators, true ) ) {
						$operator = 'is';
					}

					$value = isset( $condition['value'] ) && is_scalar( $condition['value'] )
						? sanitize_text_field( (string) $condition['value'] )
						: '';

					if ( 'exists' === $operator ) {
						$value = '1';
					}

					return compact( 'attribute', 'operator', 'value' );
				},
				$conditions
			)
		);
	}

	/**
	 * Sanitize Editor Access mode for storage.
	 *
	 * @param mixed $mode The mode value.
	 * @return string Sanitized mode or empty string.
	 */
	public static function sanitize_mode( $mode ) {
		$mode          = sanitize_text_field( $mode );
		$allowed_modes = [ 'unchanged', 'contentOnly', 'readOnly' ];

		return in_array( $mode, $allowed_modes, true ) && 'unchanged' !== $mode ? $mode : '';
	}

	/**
	 * Sanitize an Editor Access rule mode for storage.
	 *
	 * @param mixed $mode The mode value.
	 * @return string Sanitized mode.
	 */
	public static function sanitize_rule_mode( $mode ) {
		$mode          = sanitize_text_field( $mode );
		$allowed_modes = [ 'unchanged', 'contentOnly', 'readOnly', 'custom' ];

		return in_array( $mode, $allowed_modes, true ) ? $mode : 'unchanged';
	}

	/**
	 * Get the list of allowed component names.
	 *
	 * @return array
	 */
	public static function get_allowed_components() {
		$components = [
			'ColorPicker',
			'ColorPalette',
			'UnitControl',
			'DimensionsControl',
			'BackgroundControl',
			'BoxShadowControl',
			'FilterControl',
			'TransformControl',
			'TransitionControl',
			'TextControl',
			'SelectControl',
			'ButtonGroup',
			'ToggleControl',
			'MediaUpload',
		];

		/**
		 * Filter the control components allowed in Editor Access control sets.
		 *
		 * This is a PHP-side allow-list for v1. Third-party JavaScript component
		 * registration can build on the same component names later.
		 *
		 * @param array $components Allowed component names.
		 */
		$filtered_components = apply_filters( 'generateblocks_editor_access_control_components', $components );

		return is_array( $filtered_components ) ? array_values( array_unique( array_filter( array_map( 'sanitize_text_field', $filtered_components ) ) ) ) : $components;
	}

	/**
	 * Get the supported multi-property dimension groups.
	 *
	 * @return array
	 */
	public static function get_dimension_control_groups() {
		return [
			'padding'       => [
				'aliases' => [ 'padding' ],
				'props'   => [ 'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft' ],
			],
			'margin'        => [
				'aliases' => [ 'margin' ],
				'props'   => [ 'marginTop', 'marginRight', 'marginBottom', 'marginLeft' ],
			],
			'borderWidth'   => [
				'aliases' => [ 'borderWidth', 'border-width' ],
				'props'   => [ 'borderTopWidth', 'borderRightWidth', 'borderBottomWidth', 'borderLeftWidth' ],
			],
			'borderRadius'  => [
				'aliases' => [ 'borderRadius', 'border-radius' ],
				'props'   => [ 'borderTopLeftRadius', 'borderTopRightRadius', 'borderBottomRightRadius', 'borderBottomLeftRadius' ],
			],
			'inset'         => [
				'aliases' => [ 'inset' ],
				'props'   => [ 'top', 'right', 'bottom', 'left' ],
			],
			'scrollMargin'  => [
				'aliases' => [ 'scrollMargin', 'scroll-margin' ],
				'props'   => [ 'scrollMarginTop', 'scrollMarginRight', 'scrollMarginBottom', 'scrollMarginLeft' ],
			],
			'scrollPadding' => [
				'aliases' => [ 'scrollPadding', 'scroll-padding' ],
				'props'   => [ 'scrollPaddingTop', 'scrollPaddingRight', 'scrollPaddingBottom', 'scrollPaddingLeft' ],
			],
		];
	}

	/**
	 * Normalize a DimensionsControl group key.
	 *
	 * @param string $property The submitted property/group key.
	 * @return string Normalized group key, or empty string when unsupported.
	 */
	public static function normalize_dimension_control_group( $property ) {
		$property = is_scalar( $property ) ? sanitize_text_field( $property ) : '';

		if ( '' === $property ) {
			return '';
		}

		foreach ( self::get_dimension_control_groups() as $group_key => $group ) {
			$aliases = isset( $group['aliases'] ) && is_array( $group['aliases'] ) ? $group['aliases'] : [];

			if ( $property === $group_key || in_array( $property, $aliases, true ) ) {
				return $group_key;
			}
		}

		return '';
	}

	/**
	 * Check whether a property is a supported DimensionsControl group.
	 *
	 * @param string $property The submitted property/group key.
	 * @return bool Whether the property is supported.
	 */
	public static function is_dimension_control_group( $property ) {
		return '' !== self::normalize_dimension_control_group( $property );
	}

	/**
	 * Get the list of allowed component names for settings controls.
	 *
	 * @return array
	 */
	public static function get_allowed_settings_components() {
		return [
			'TextControl',
			'SelectControl',
			'ButtonGroup',
			'ToggleControl',
			'LinkControl',
			'MediaUpload',
			'IconControl',
		];
	}

	/**
	 * Sanitize control set controls.
	 *
	 * @param mixed $controls The controls data to sanitize.
	 * @return array Sanitized controls array.
	 */
	public static function sanitize_control_set_controls( $controls ) {
		if ( ! is_array( $controls ) ) {
			return [];
		}

		return array_values(
			array_filter(
				array_map( [ self::class, 'sanitize_single_control' ], $controls )
			)
		);
	}

	/**
	 * Sanitize control set panel items.
	 *
	 * @param mixed $items The panel items to sanitize.
	 * @return array Sanitized item array.
	 */
	public static function sanitize_control_set_items( $items ) {
		if ( ! is_array( $items ) ) {
			return [];
		}

		$sanitized = [];

		foreach ( $items as $index => $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$type = isset( $item['type'] ) ? sanitize_text_field( $item['type'] ) : 'control';

			if ( 'group' === $type ) {
				$id = isset( $item['id'] ) ? sanitize_key( $item['id'] ) : '';

				if ( empty( $id ) ) {
					$id = 'group-' . ( absint( $index ) + 1 );
				}

				$layout = isset( $item['layout'] ) ? sanitize_text_field( $item['layout'] ) : 'columns';

				if ( ! in_array( $layout, [ 'stack', 'columns' ], true ) ) {
					$layout = 'columns';
				}

				$columns = isset( $item['columns'] ) ? absint( $item['columns'] ) : 2;

				if ( ! in_array( $columns, [ 2, 3, 4 ], true ) ) {
					$columns = 2;
				}

				$sanitized[] = [
					'id'      => $id,
					'type'    => 'group',
					'label'   => isset( $item['label'] ) ? sanitize_text_field( $item['label'] ) : '',
					'layout'  => $layout,
					'columns' => $columns,
					'items'   => self::sanitize_control_set_controls( $item['items'] ?? [] ),
				];

				continue;
			}

			$control = self::sanitize_single_control( $item );

			if ( ! empty( $control ) ) {
				$sanitized[] = $control;
			}
		}

		return $sanitized;
	}

	/**
	 * Sanitize control set panels.
	 *
	 * @param mixed $panels The panel data to sanitize.
	 * @return array Sanitized panels array.
	 */
	public static function sanitize_control_set_panels( $panels ) {
		$sanitized = [];

		if ( is_array( $panels ) ) {
			foreach ( $panels as $index => $panel ) {
				if ( ! is_array( $panel ) ) {
					continue;
				}

				$id = isset( $panel['id'] ) ? sanitize_key( $panel['id'] ) : '';

				if ( empty( $id ) || isset( $sanitized[ $id ] ) ) {
					$id = 'panel-' . ( absint( $index ) + 1 );
				}

				while ( isset( $sanitized[ $id ] ) ) {
					$id .= '-1';
				}

				$sanitized[ $id ] = [
					'id'    => $id,
					'label' => isset( $panel['label'] ) ? sanitize_text_field( $panel['label'] ) : '',
					'items' => self::sanitize_control_set_items( $panel['items'] ?? [] ),
				];
			}
		}

		if ( empty( $sanitized ) ) {
			return [
				[
					'id'    => 'panel-1',
					'label' => '',
					'items' => [],
				],
			];
		}

		return array_values( $sanitized );
	}

	/**
	 * Sanitize a single control.
	 *
	 * Handles both style and setting control types via the controlType field.
	 *
	 * @param mixed $control The control data to sanitize.
	 * @return array|null Sanitized control array, or null if invalid.
	 */
	public static function sanitize_single_control( $control ) {
		if ( ! is_array( $control ) ) {
			return null;
		}

		$control_type = isset( $control['controlType'] ) ? sanitize_text_field( $control['controlType'] ) : 'style';

		if ( ! in_array( $control_type, [ 'style', 'setting' ], true ) ) {
			$control_type = 'style';
		}

		$target_type = isset( $control['targetType'] ) ? sanitize_text_field( $control['targetType'] ) : '';

		if ( 'style' === $control_type ) {
			$target_type = 'style';
		} elseif ( ! in_array( $target_type, [ 'blockAttribute', 'htmlAttribute' ], true ) ) {
			$target_type = ! empty( $control['blockAttribute'] ) ? 'blockAttribute' : 'htmlAttribute';
		}

		$allowed_components = 'setting' === $control_type
			? self::get_allowed_settings_components()
			: self::get_allowed_components();

		$component = isset( $control['component'] ) ? sanitize_text_field( $control['component'] ) : '';

		if ( ! empty( $component ) && ! in_array( $component, $allowed_components, true ) ) {
			$component = '';
		}

		if ( 'blockAttribute' === $target_type && 'LinkControl' === $component ) {
			$component = '';
		}

		if ( 'htmlAttribute' === $target_type && 'IconControl' === $component ) {
			$component = '';
		}

		$sanitized = [
			'type'        => 'control',
			'id'          => isset( $control['id'] ) ? sanitize_key( $control['id'] ) : '',
			'controlType' => $control_type,
			'targetType'  => $target_type,
			'label'       => isset( $control['label'] ) ? sanitize_text_field( $control['label'] ) : '',
			'component'   => $component,
			'options'     => isset( $control['options'] ) ? sanitize_text_field( $control['options'] ) : '',
		];

		if ( 'setting' === $control_type ) {
			$sanitized['htmlAttribute']  = isset( $control['htmlAttribute'] ) ? sanitize_text_field( $control['htmlAttribute'] ) : '';
			$sanitized['blockAttribute'] = isset( $control['blockAttribute'] ) ? sanitize_text_field( $control['blockAttribute'] ) : '';
		} else {
			$sanitized['property']    = isset( $control['property'] ) ? sanitize_text_field( $control['property'] ) : '';
			$sanitized['selector']    = isset( $control['selector'] ) ? sanitize_text_field( $control['selector'] ) : '';
			$sanitized['atRule']      = isset( $control['atRule'] ) ? sanitize_text_field( $control['atRule'] ) : '';
			$sanitized['colorSource'] = isset( $control['colorSource'] ) ? sanitize_text_field( $control['colorSource'] ) : 'theme';
			$sanitized['colors']      = isset( $control['colors'] ) ? sanitize_text_field( $control['colors'] ) : '';

			if ( 'DimensionsControl' === $component ) {
				$normalized_property = self::normalize_dimension_control_group( $sanitized['property'] );

				if ( '' !== $normalized_property ) {
					$sanitized['property'] = $normalized_property;
				}
			}
		}

		if ( empty( $sanitized['id'] ) ) {
			return null;
		}

		// Style controls require a component; setting controls don't.
		if ( 'style' === $control_type && empty( $sanitized['component'] ) ) {
			return null;
		}

		return $sanitized;
	}

	/**
	 * Check whether a sanitized control can render in the editor.
	 *
	 * @param mixed $control The control definition.
	 * @return bool Whether the control can render.
	 */
	public static function is_renderable_control( $control ) {
		if ( ! is_array( $control ) ) {
			return false;
		}

		$control_type = 'setting' === ( $control['controlType'] ?? '' ) ? 'setting' : 'style';

		if ( 'style' === $control_type ) {
			if ( empty( $control['component'] ) || empty( $control['property'] ) ) {
				return false;
			}

			if ( 'DimensionsControl' === $control['component'] ) {
				return self::is_dimension_control_group( $control['property'] );
			}

			return true;
		}

		$target_type = $control['targetType'] ?? ( ! empty( $control['blockAttribute'] ) ? 'blockAttribute' : 'htmlAttribute' );

		if ( 'blockAttribute' === $target_type ) {
			return ! empty( $control['blockAttribute'] );
		}

		if ( 'LinkControl' === ( $control['component'] ?? '' ) ) {
			return true;
		}

		return ! empty( $control['component'] ) && ! empty( $control['htmlAttribute'] );
	}

	/**
	 * Check whether a list of controls contains at least one renderable control.
	 *
	 * @param mixed $controls The control definitions.
	 * @return bool Whether at least one control can render.
	 */
	public static function has_renderable_controls( $controls ) {
		$controls = self::sanitize_control_set_controls( $controls );

		foreach ( $controls as $control ) {
			if ( self::is_renderable_control( $control ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check whether a list of panel items contains at least one renderable control.
	 *
	 * @param mixed $items The panel item definitions.
	 * @return bool Whether at least one control can render.
	 */
	public static function has_renderable_items( $items ) {
		$items = self::sanitize_control_set_items( $items );

		foreach ( $items as $item ) {
			if ( 'group' === ( $item['type'] ?? '' ) ) {
				if ( self::has_renderable_controls( $item['items'] ?? [] ) ) {
					return true;
				}

				continue;
			}

			if ( self::is_renderable_control( $item ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check whether a list of panels contains at least one renderable control.
	 *
	 * @param mixed $panels The panel definitions.
	 * @return bool Whether at least one control can render.
	 */
	public static function has_renderable_control_set_panels( $panels ) {
		$panels = self::sanitize_control_set_panels( $panels );

		foreach ( $panels as $panel ) {
			if ( self::has_renderable_items( $panel['items'] ?? [] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check whether a profile rule targets a block that supports the selected mode.
	 *
	 * @param mixed $rule The sanitized rule data.
	 * @return bool Whether the rule can apply.
	 */
	public static function profile_rule_target_supports_mode( $rule ) {
		if ( ! is_array( $rule ) ) {
			return false;
		}

		$mode = self::sanitize_rule_mode( $rule['mode'] ?? '' );

		$target     = isset( $rule['target'] ) && is_array( $rule['target'] ) ? $rule['target'] : [];
		$block_type = isset( $target['blockType'] ) ? sanitize_text_field( $target['blockType'] ) : '';

		if ( empty( $block_type ) ) {
			return false;
		}

		if ( 'unchanged' === $mode ) {
			return true;
		}

		if ( ! function_exists( 'generateblocks_pro_is_editor_access_supported_block_type' ) ) {
			return false;
		}

		return generateblocks_pro_is_editor_access_supported_block_type( $block_type, $mode );
	}
}

GenerateBlocks_Pro_Editor_Access::get_instance()->init();
