<?php
/**
 * Editor Access and Control Sets.
 *
 * @package GenerateBlocks Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Main class.
require_once __DIR__ . '/class-editor-access.php';

// REST API.
require_once __DIR__ . '/class-editor-access-rest.php';

// Post type registration.
require_once __DIR__ . '/class-editor-access-profile-post-type.php';

// Control Set CPT.
require_once __DIR__ . '/class-editor-access-control-set-post-type.php';

// Control Set REST API.
require_once __DIR__ . '/class-editor-access-control-set-rest.php';

// Admin dashboard.
require_once __DIR__ . '/class-editor-access-dashboard.php';
