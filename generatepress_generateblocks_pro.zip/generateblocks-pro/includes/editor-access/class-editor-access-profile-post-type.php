<?php
/**
 * Editor Access Profile Post Type Registration.
 *
 * @package GenerateBlocks Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class GenerateBlocks_Pro_Editor_Access_Profile_Post_Type
 */
class GenerateBlocks_Pro_Editor_Access_Profile_Post_Type extends GenerateBlocks_Pro_Singleton {
	/**
	 * Initialize class.
	 */
	public function init() {
		add_action( 'init', [ $this, 'register_post_type' ] );
		add_action( 'init', [ $this, 'register_post_meta' ] );
	}

	/**
	 * Build the access profile post type args.
	 *
	 * Capabilities are pinned to the Editor Access 'manage' context so the
	 * private storage posts cannot be created, edited, published, or deleted by
	 * normal edit_posts users outside the custom REST UI.
	 *
	 * @return array
	 */
	public function get_access_profile_cpt_args() {
		$labels = [
			'name'               => __( 'Access Profiles', 'generateblocks-pro' ),
			'singular_name'      => __( 'Access Profile', 'generateblocks-pro' ),
			'menu_name'          => __( 'Editor Access', 'generateblocks-pro' ),
			'add_new'            => __( 'Add New', 'generateblocks-pro' ),
			'add_new_item'       => __( 'Add New Access Profile', 'generateblocks-pro' ),
			'edit_item'          => __( 'Edit Access Profile', 'generateblocks-pro' ),
			'new_item'           => __( 'New Access Profile', 'generateblocks-pro' ),
			'view_item'          => __( 'View Access Profile', 'generateblocks-pro' ),
			'search_items'       => __( 'Search Access Profiles', 'generateblocks-pro' ),
			'not_found'          => __( 'No access profiles found.', 'generateblocks-pro' ),
			'not_found_in_trash' => __( 'No access profiles found in Trash.', 'generateblocks-pro' ),
		];

		$manage_cap = GenerateBlocks_Pro_Editor_Access::get_editor_access_capability( 'manage' );
		$use_cap    = GenerateBlocks_Pro_Editor_Access::get_editor_access_capability( 'use' );

		return [
			'labels'              => $labels,
			'public'              => false,
			'show_ui'             => false,
			'show_in_menu'        => false,
			'show_in_admin_bar'   => false,
			'show_in_nav_menus'   => false,
			'can_export'          => true,
			'has_archive'         => false,
			'exclude_from_search' => true,
			'publicly_queryable'  => false,
			'capability_type'     => 'post',
			'map_meta_cap'        => true,
			'capabilities'        => [
				'edit_posts'             => $manage_cap,
				'edit_others_posts'      => $manage_cap,
				'delete_posts'           => $manage_cap,
				'delete_others_posts'    => $manage_cap,
				'delete_private_posts'   => $manage_cap,
				'delete_published_posts' => $manage_cap,
				'edit_private_posts'     => $manage_cap,
				'edit_published_posts'   => $manage_cap,
				'publish_posts'          => $manage_cap,
				'read_private_posts'     => $manage_cap,
				'create_posts'           => $manage_cap,
				'read'                   => $use_cap,
			],
			'show_in_rest'        => false,
			'supports'            => [ 'title' ],
		];
	}

	/**
	 * Register the access profile post type.
	 */
	public function register_post_type() {
		register_post_type( 'gb_access_profile', $this->get_access_profile_cpt_args() );
	}

	/**
	 * Register post meta for access profiles.
	 */
	public function register_post_meta() {
		$attribute_condition_schema = [
			'type'       => 'object',
			'properties' => [
				'attribute' => [ 'type' => 'string' ],
				'operator'  => [ 'type' => 'string' ],
				'value'     => [ 'type' => 'string' ],
			],
		];

		$rules_schema = [
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => [
				'scope' => [
					'type'       => 'object',
					'properties' => [
						'roles' => [
							'type'  => 'array',
							'items' => [ 'type' => 'string' ],
						],
						'postTypes' => [
							'type'  => 'array',
							'items' => [ 'type' => 'string' ],
						],
					],
				],
				'fallbackMode' => [
					'type' => 'string',
					'enum' => [ '', 'unchanged', 'contentOnly', 'readOnly' ],
				],
				'inserter' => [
					'type'       => 'object',
					'properties' => [
						'mode' => [
							'type' => 'string',
							'enum' => [ 'all', 'selected', 'none' ],
						],
						'items' => [
							'type'  => 'array',
							'items' => [ 'type' => 'string' ],
						],
					],
				],
				'rules' => [
					'type'  => 'array',
					'items'   => [
						'type'       => 'object',
						'properties' => [
							'id' => [ 'type' => 'string' ],
							'label' => [ 'type' => 'string' ],
							'target' => [
								'type'       => 'object',
								'properties' => [
									'blockType' => [ 'type' => 'string' ],
									'kind' => [ 'type' => 'string' ],
									'conditions' => [
										'type'  => 'array',
										'items' => $attribute_condition_schema,
									],
								],
							],
							'mode' => [
								'type' => 'string',
								'enum' => [ 'unchanged', 'contentOnly', 'readOnly', 'custom' ],
							],
							'controlSetIds' => [
								'type'  => 'array',
								'items' => [
									'type' => 'integer',
								],
							],
						],
					],
				],
			],
		];

		register_post_meta(
			'gb_access_profile',
			'_gb_access_profile',
			[
				'show_in_rest'      => [
					'schema' => $rules_schema,
				],
				'single'            => true,
				'type'              => 'object',
				'default'           => GenerateBlocks_Pro_Editor_Access::get_default_profile(),
				'sanitize_callback' => [ 'GenerateBlocks_Pro_Editor_Access', 'sanitize_profile' ],
				'auth_callback'     => function () {
					return GenerateBlocks_Pro_Editor_Access::current_user_can_use_editor_access( 'manage' );
				},
			]
		);
	}
}

GenerateBlocks_Pro_Editor_Access_Profile_Post_Type::get_instance()->init();
