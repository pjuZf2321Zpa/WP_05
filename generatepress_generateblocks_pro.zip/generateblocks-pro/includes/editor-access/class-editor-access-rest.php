<?php
/**
 * Editor Access REST API endpoints.
 *
 * @package GenerateBlocks Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once GENERATEBLOCKS_PRO_DIR . 'includes/utils/trait-rest-response.php';

/**
 * Class GenerateBlocks_Pro_Editor_Access_REST
 */
class GenerateBlocks_Pro_Editor_Access_REST extends GenerateBlocks_Pro_Singleton {

	use GenerateBlocks_Pro_REST_Response;

	/**
	 * Namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'generateblocks-pro/editor-access/v';

	/**
	 * Version.
	 *
	 * @var string
	 */
	protected $version = '1';

	/**
	 * Initialize class.
	 */
	public function init() {
		if ( ! generateblocks_pro_editor_access_enabled() ) {
			return;
		}

		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 */
	public function register_routes() {
		$namespace = $this->namespace . $this->version;

		register_rest_route(
			$namespace,
			'/access-profiles/',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_access_profiles' ],
					'permission_callback' => [ $this, 'manage_permission' ],
					'args'                => [
						'page' => [
							'required'          => false,
							'type'              => 'integer',
							'default'           => 1,
							'sanitize_callback' => 'absint',
						],
						'per_page' => [
							'required'          => false,
							'type'              => 'integer',
							'default'           => 100,
							'sanitize_callback' => [ $this, 'sanitize_per_page' ],
						],
					],
				],
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'create_access_profile' ],
					'permission_callback' => [ $this, 'manage_permission' ],
					'args'                => $this->get_write_args( true ),
				],
			]
		);

		register_rest_route(
			$namespace,
			'/access-profiles/(?P<id>[1-9]\d*)',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_access_profile' ],
					'permission_callback' => [ $this, 'manage_permission' ],
					'args'                => [
						'id' => [
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						],
					],
				],
				[
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => [ $this, 'update_access_profile' ],
					'permission_callback' => [ $this, 'manage_permission' ],
					'args'                => $this->get_write_args( false ),
				],
				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'delete_access_profile' ],
					'permission_callback' => [ $this, 'manage_permission' ],
					'args'                => [
						'id' => [
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						],
					],
				],
			]
		);
	}

	/**
	 * Get shared write args.
	 *
	 * @param bool $is_create Whether this is the create route.
	 * @return array
	 */
	private function get_write_args( $is_create ) {
		$args = [
			'title' => [
				'required'          => $is_create,
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			],
			'profile' => [
				'required'          => false,
				'type'              => 'object',
				'sanitize_callback' => [ 'GenerateBlocks_Pro_Editor_Access', 'sanitize_profile' ],
			],
			'status' => [
				'required'          => false,
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
				'enum'              => [ 'publish', 'draft' ],
			],
			'description' => [
				'required'          => false,
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => 'wp_kses_post',
			],
		];

		if ( $is_create ) {
			$args['status']['default'] = 'publish';
		} else {
			// The update route's id comes from the URL; declare it so the
			// path param is typed and sanitized like the GET/DELETE routes.
			$args['id'] = [
				'required'          => true,
				'type'              => 'integer',
				'sanitize_callback' => 'absint',
			];
		}

		return $args;
	}

	/**
	 * Permission callback for manage operations.
	 *
	 * @return bool
	 */
	public function manage_permission() {
		return GenerateBlocks_Pro_Editor_Access::current_user_can_use_editor_access( 'manage' );
	}

	/**
	 * Check whether a control set exists and contains renderable controls.
	 *
	 * @param int $control_set_id The control set post ID.
	 * @return bool
	 */
	private function control_set_has_renderable_controls( $control_set_id ) {
		$control_set_id = absint( $control_set_id );

		if ( ! $control_set_id || 'publish' !== get_post_status( $control_set_id ) ) {
			return false;
		}

		$post = get_post( $control_set_id );

		if ( ! $post || 'gb_access_set' !== $post->post_type ) {
			return false;
		}

		$panels = get_post_meta( $control_set_id, '_gb_access_set_panels', true );

		return GenerateBlocks_Pro_Editor_Access::has_renderable_control_set_panels( $panels );
	}

	/**
	 * Validate an access profile before it can be published.
	 *
	 * @param array  $profile The sanitized profile.
	 * @param string $status  The target post status.
	 * @return true|WP_Error
	 */
	private function validate_profile_for_status( $profile, $status ) {
		if ( 'publish' !== $status ) {
			return true;
		}

		if ( ! is_array( $profile ) ) {
			return new WP_Error(
				'invalid_access_profile',
				__( 'Access profile data is invalid.', 'generateblocks-pro' )
			);
		}

		$inserter_policy = GenerateBlocks_Pro_Editor_Access::sanitize_inserter_policy( $profile['inserter'] ?? [] );

		if ( 'selected' === $inserter_policy['mode'] && empty( $inserter_policy['items'] ) ) {
			return new WP_Error(
				'empty_selected_inserter_policy',
				__( 'Select at least one block for the inserter, or choose a different inserter mode.', 'generateblocks-pro' )
			);
		}

		foreach ( $profile['rules'] ?? [] as $rule ) {
			if ( ! GenerateBlocks_Pro_Editor_Access::profile_rule_target_supports_mode( $rule ) ) {
				return new WP_Error(
					'unsupported_access_rule_target',
					__( 'Access profile rules must target blocks that support the selected mode before the profile can be published.', 'generateblocks-pro' )
				);
			}

			if ( $this->profile_rule_has_incomplete_conditions( $rule ) ) {
				return new WP_Error(
					'incomplete_access_rule_condition',
					__( 'Access profile rule conditions must be complete before the profile can be published.', 'generateblocks-pro' )
				);
			}

			if ( 'custom' !== ( $rule['mode'] ?? '' ) ) {
				continue;
			}

			$control_set_ids = isset( $rule['controlSetIds'] ) && is_array( $rule['controlSetIds'] )
				? $rule['controlSetIds']
				: [];

			$has_renderable_control_set = false;

			foreach ( $control_set_ids as $control_set_id ) {
				if ( $this->control_set_has_renderable_controls( $control_set_id ) ) {
					$has_renderable_control_set = true;
					break;
				}
			}

			if ( ! $has_renderable_control_set ) {
				return new WP_Error(
					'missing_custom_rule_control_set',
					__( 'Custom control rules must use a control set with at least one renderable control before the profile can be published.', 'generateblocks-pro' )
				);
			}
		}

		return true;
	}

	/**
	 * Check whether a sanitized rule has incomplete attribute conditions.
	 *
	 * @param array $rule The sanitized rule.
	 * @return bool
	 */
	private function profile_rule_has_incomplete_conditions( $rule ) {
		$conditions = $rule['target']['conditions'] ?? [];

		if ( empty( $conditions ) ) {
			return false;
		}

		if ( ! is_array( $conditions ) ) {
			return true;
		}

		foreach ( $conditions as $condition ) {
			if ( ! is_array( $condition ) ) {
				return true;
			}

			$attribute = isset( $condition['attribute'] ) && is_scalar( $condition['attribute'] )
				? trim( (string) $condition['attribute'] )
				: '';
			$operator  = isset( $condition['operator'] ) && is_scalar( $condition['operator'] )
				? (string) $condition['operator']
				: 'is';

			if ( '' === $attribute ) {
				return true;
			}

			if ( 'exists' === $operator ) {
				continue;
			}

			$value = isset( $condition['value'] ) && is_scalar( $condition['value'] )
				? trim( (string) $condition['value'] )
				: '';

			if ( '' === $value ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get all access profiles.
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function get_access_profiles( WP_REST_Request $request ) {
		// All routes are gated by manage_permission(), so drafts are always visible here.
		$page     = max( 1, absint( $request->get_param( 'page' ) ) );
		$per_page = $this->normalize_per_page( $request->get_param( 'per_page' ), true );

		$args = [
			'post_type'      => 'gb_access_profile',
			'post_status'    => [ 'publish', 'draft' ],
			'posts_per_page' => $per_page,
			'orderby'        => [
				'title' => 'ASC',
				'ID'    => 'ASC',
			],
		];

		if ( -1 !== $per_page ) {
			$args['paged'] = $page;
		}

		$query = new WP_Query( $args );
		$posts = $query->posts;

		$access_profiles = [];

		foreach ( $posts as $post ) {
			$access_profiles[] = $this->format_access_profile_response( $post );
		}

		return $this->success(
			[
				'accessProfiles' => $access_profiles,
				'total'          => $query->found_posts,
				'pages'          => $query->max_num_pages,
			]
		);
	}

	/**
	 * Get a single access profile.
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function get_access_profile( WP_REST_Request $request ) {
		$id   = $request->get_param( 'id' );
		$post = get_post( $id );

		if ( ! $post || 'gb_access_profile' !== $post->post_type ) {
			return $this->error( 'access_profile_not_found', __( 'Access profile not found.', 'generateblocks-pro' ), 404 );
		}

		return $this->success( $this->format_access_profile_response( $post ) );
	}

	/**
	 * Create a new access profile.
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function create_access_profile( WP_REST_Request $request ) {
		$title       = $request->get_param( 'title' );
		$status      = $request->get_param( 'status' );
		$description = $request->get_param( 'description' );
		$profile     = GenerateBlocks_Pro_Editor_Access::sanitize_profile( $request->get_param( 'profile' ) );

		if ( '' === trim( (string) $title ) ) {
			return $this->error( 'missing_title', __( 'Title is required.', 'generateblocks-pro' ) );
		}

		if ( ! empty( $status ) && ! in_array( $status, [ 'publish', 'draft' ], true ) ) {
			$status = 'publish';
		}

		$post_status = $status ? $status : 'publish';
		$validation  = $this->validate_profile_for_status( $profile, $post_status );

		if ( is_wp_error( $validation ) ) {
			return $this->error( $validation->get_error_code(), $validation->get_error_message() );
		}

		// Core unslashes post data on write; slash so backslashes survive.
		$post_id = wp_insert_post(
			wp_slash(
				[
					'post_title'   => $title,
					'post_type'    => 'gb_access_profile',
					'post_status'  => $post_status,
					'post_content' => null === $description ? '' : $description,
				]
			)
		);

		if ( is_wp_error( $post_id ) || ! $post_id ) {
			return $this->error(
				'creation_failed',
				is_wp_error( $post_id )
					? $post_id->get_error_message()
					: __( 'Failed to create access profile.', 'generateblocks-pro' )
			);
		}

		update_post_meta( $post_id, '_gb_access_profile', wp_slash( $profile ) );

		GenerateBlocks_Pro_Editor_Access::invalidate_editor_access_cache();

		return $this->success( $this->format_access_profile_response( get_post( $post_id ) ) );
	}

	/**
	 * Update an existing access profile.
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function update_access_profile( WP_REST_Request $request ) {
		$id          = $request->get_param( 'id' );
		$title       = $request->get_param( 'title' );
		$status      = $request->get_param( 'status' );
		$description = $request->get_param( 'description' );
		$post        = get_post( $id );

		if ( ! $post || 'gb_access_profile' !== $post->post_type ) {
			return $this->error( 'access_profile_not_found', __( 'Access profile not found.', 'generateblocks-pro' ), 404 );
		}

		$should_invalidate = false;
		$update_data       = [ 'ID' => $id ];
		$existing_profile  = GenerateBlocks_Pro_Editor_Access::sanitize_profile( get_post_meta( $id, '_gb_access_profile', true ) );
		$effective_profile = $this->has_submitted_param( $request, 'profile' )
			? GenerateBlocks_Pro_Editor_Access::sanitize_profile( $request->get_param( 'profile' ) )
			: $existing_profile;
		$effective_status = $post->post_status;

		if ( $this->has_submitted_param( $request, 'title' ) ) {
			if ( '' === trim( (string) $title ) ) {
				return $this->error( 'missing_title', __( 'Title is required.', 'generateblocks-pro' ) );
			}

			$update_data['post_title'] = $title;
		}

		if ( ! empty( $status ) && in_array( $status, [ 'publish', 'draft' ], true ) ) {
			$update_data['post_status'] = $status;
			$effective_status           = $status;
			$should_invalidate          = true;
		}

		// Only re-validate when the request can change what's enforced (the
		// profile payload or the post status). Title/description edits must
		// not be blocked by stored state that no longer validates — e.g. a
		// rule whose control set was force-deleted outside our REST routes.
		$needs_validation = $this->has_submitted_param( $request, 'profile' )
			|| $effective_status !== $post->post_status;

		if ( $needs_validation ) {
			$validation = $this->validate_profile_for_status( $effective_profile, $effective_status );

			if ( is_wp_error( $validation ) ) {
				return $this->error( $validation->get_error_code(), $validation->get_error_message() );
			}
		}

		if ( $this->has_submitted_param( $request, 'description' ) ) {
			$update_data['post_content'] = null === $description ? '' : $description;
		}

		if ( count( $update_data ) > 1 ) {
			// Core unslashes post data on write; slash so backslashes survive.
			$result = wp_update_post( wp_slash( $update_data ) );

			if ( is_wp_error( $result ) || ! $result ) {
				return $this->error(
					'update_failed',
					is_wp_error( $result )
						? $result->get_error_message()
						: __( 'Failed to update access profile.', 'generateblocks-pro' )
				);
			}
		}

		if ( $this->has_submitted_param( $request, 'profile' ) ) {
			update_post_meta( $id, '_gb_access_profile', wp_slash( $effective_profile ) );
			$should_invalidate = true;
		}

		if ( $should_invalidate ) {
			GenerateBlocks_Pro_Editor_Access::invalidate_editor_access_cache();
		}

		return $this->success( $this->format_access_profile_response( get_post( $id ) ) );
	}

	/**
	 * Delete an access profile.
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function delete_access_profile( WP_REST_Request $request ) {
		$id   = $request->get_param( 'id' );
		$post = get_post( $id );

		if ( ! $post || 'gb_access_profile' !== $post->post_type ) {
			return $this->error( 'access_profile_not_found', __( 'Access profile not found.', 'generateblocks-pro' ), 404 );
		}

		$result = wp_delete_post( $id, true );

		if ( ! $result ) {
			return $this->error( 'deletion_failed', __( 'Failed to delete access profile.', 'generateblocks-pro' ) );
		}

		GenerateBlocks_Pro_Editor_Access::invalidate_editor_access_cache();

		return $this->success( [ 'deleted' => true ] );
	}

	/**
	 * Resolve a control set into the panels the editor renderer expects.
	 *
	 * @param int $control_set_id The control set post ID.
	 * @return array Panels for the editor.
	 */
	public static function resolve_control_set_panels( $control_set_id ) {
		$control_set_id = absint( $control_set_id );

		if ( ! $control_set_id || 'publish' !== get_post_status( $control_set_id ) ) {
			return [];
		}

		$post = get_post( $control_set_id );

		if ( ! $post || 'gb_access_set' !== $post->post_type ) {
			return [];
		}

		$panels = get_post_meta( $control_set_id, '_gb_access_set_panels', true );

		return array_values(
			array_filter(
				GenerateBlocks_Pro_Editor_Access::sanitize_control_set_panels( $panels ),
				function ( $panel ) {
					return GenerateBlocks_Pro_Editor_Access::has_renderable_items( $panel['items'] ?? [] );
				}
			)
		);
	}

	/**
	 * Resolve every control set referenced by an access profile.
	 *
	 * Public static so the block-editor runtime (includes/extend/editor-access.php)
	 * can share it instead of duplicating the walk.
	 *
	 * @param array $profile The sanitized profile.
	 * @return array
	 */
	public static function resolve_profile_control_sets( $profile ) {
		$control_sets = [];

		foreach ( $profile['rules'] ?? [] as $rule ) {
			$control_set_ids = isset( $rule['controlSetIds'] ) && is_array( $rule['controlSetIds'] )
				? $rule['controlSetIds']
				: [];

			foreach ( $control_set_ids as $control_set_id ) {
				$control_set_id = absint( $control_set_id );

				if ( ! $control_set_id || isset( $control_sets[ (string) $control_set_id ] ) ) {
					continue;
				}

				$panels = self::resolve_control_set_panels( $control_set_id );

				if ( ! empty( $panels ) ) {
					$control_sets[ (string) $control_set_id ] = $panels;
				}
			}
		}

		return $control_sets;
	}

	/**
	 * Format access profile response.
	 *
	 * @param WP_Post $post The post object.
	 * @return array
	 */
	private function format_access_profile_response( $post ) {
		$profile = GenerateBlocks_Pro_Editor_Access::sanitize_profile( get_post_meta( $post->ID, '_gb_access_profile', true ) );

		return [
			'id'              => $post->ID,
			'title'           => [
				'rendered' => $post->post_title,
			],
			'status'          => $post->post_status,
			'date'            => $this->format_gmt_datetime( $post->post_date_gmt ?? '' ),
			'modified'        => $this->format_gmt_datetime( $post->post_modified_gmt ?? '' ),
			'description'     => $post->post_content,
			'profile'         => $profile,
			'controlSets'     => self::resolve_profile_control_sets( $profile ),
		];
	}
}

GenerateBlocks_Pro_Editor_Access_REST::get_instance()->init();
