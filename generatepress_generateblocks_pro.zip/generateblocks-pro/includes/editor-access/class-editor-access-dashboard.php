<?php
/**
 * Editor Access Dashboard Admin Page.
 *
 * @package GenerateBlocks Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class GenerateBlocks_Pro_Editor_Access_Dashboard
 */
class GenerateBlocks_Pro_Editor_Access_Dashboard extends GenerateBlocks_Pro_Singleton {
	/**
	 * Initialize class.
	 */
	public function init() {
		if ( ! generateblocks_pro_editor_access_enabled() ) {
			return;
		}

		add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
		add_filter( 'generateblocks_dashboard_tabs', [ $this, 'add_tab' ] );
		add_filter( 'generateblocks_dashboard_screens', [ $this, 'add_to_dashboard_pages' ] );
	}

	/**
	 * Add admin menu page.
	 */
	public function add_admin_menu() {
		$capability = GenerateBlocks_Pro_Editor_Access::get_editor_access_capability( 'manage' );

		if ( ! current_user_can( $capability ) ) {
			return;
		}

		add_submenu_page(
			'generateblocks',
			__( 'Editor Access', 'generateblocks-pro' ),
			__( 'Editor Access', 'generateblocks-pro' ),
			$capability,
			'generateblocks-editor-access',
			[ $this, 'render_dashboard' ],
			5
		);
	}

	/**
	 * Render the dashboard page.
	 */
	public function render_dashboard() {
		if ( ! GenerateBlocks_Pro_Editor_Access::current_user_can_use_editor_access( 'manage' ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to access this page.', 'generateblocks-pro' ) );
		}
		?>
		<div class="wrap gblocks-dashboard-wrap">
			<div class="generateblocks-settings-area generateblocks-editor-access-area">
				<div id="gb-editor-access-dashboard"></div>
			</div>
		</div>
		<?php
	}

	/**
	 * Enqueue scripts for the dashboard.
	 *
	 * @param string $hook_suffix The current admin page.
	 */
	public function enqueue_scripts( $hook_suffix ) {
		if ( 'generateblocks_page_generateblocks-editor-access' !== $hook_suffix ) {
			return;
		}

		$assets = generateblocks_pro_get_enqueue_assets( 'editor-access-dashboard' );

		wp_enqueue_script(
			'gb-editor-access-dashboard',
			GENERATEBLOCKS_PRO_DIR_URL . 'dist/editor-access-dashboard.js',
			$assets['dependencies'],
			$assets['version'],
			true
		);

		wp_enqueue_style(
			'gb-editor-access-dashboard',
			GENERATEBLOCKS_PRO_DIR_URL . 'dist/editor-access-dashboard.css',
			[ 'generateblocks-pro-packages', 'generateblocks-pro-admin-ui' ],
			GENERATEBLOCKS_PRO_VERSION
		);

		$block_registry                 = WP_Block_Type_Registry::get_instance();
		$block_category_data            = self::get_block_category_data();
		$available_block_types_by_mode = [
			'contentOnly' => [],
			'readOnly'    => [],
			'custom'      => [],
		];
		$supported_block_types_by_mode = [
			'contentOnly' => generateblocks_pro_get_editor_access_supported_block_types( 'contentOnly' ),
			'readOnly'    => generateblocks_pro_get_editor_access_supported_block_types( 'readOnly' ),
			'custom'      => generateblocks_pro_get_editor_access_supported_block_types( 'custom' ),
		];

		$registered_blocks = $block_registry->get_all_registered();
		$inserter_order    = 0;

		foreach ( $registered_blocks as $name => $block ) {
			foreach ( $supported_block_types_by_mode as $mode => $supported_block_types ) {
				if ( ! in_array( $name, $supported_block_types, true ) ) {
					continue;
				}

				$category      = ! empty( $block->category ) ? $block->category : 'uncategorized';
				$category_data = isset( $block_category_data[ $category ] ) ? $block_category_data[ $category ] : [];

				$available_block_types_by_mode[ $mode ][] = [
					'value'         => $name,
					'label'         => $block->title ? $block->title : self::format_block_name_label( $name ),
					'category'      => $category,
					'categoryLabel' => isset( $category_data['label'] ) ? $category_data['label'] : self::format_block_category_label( $category ),
					'categoryOrder' => isset( $category_data['order'] ) ? $category_data['order'] : 999,
					'inserterOrder' => $inserter_order,
					'attributes'    => self::get_block_attribute_data( $block ),
				];
			}

			++$inserter_order;
		}

		foreach ( $available_block_types_by_mode as $mode => $available_block_types ) {
			usort(
				$available_block_types,
				function ( $a, $b ) {
					$a_order = isset( $a['categoryOrder'] ) ? (int) $a['categoryOrder'] : 999;
					$b_order = isset( $b['categoryOrder'] ) ? (int) $b['categoryOrder'] : 999;

					if ( $a_order !== $b_order ) {
						return $a_order <=> $b_order;
					}

					$a_inserter_order = isset( $a['inserterOrder'] ) ? (int) $a['inserterOrder'] : 999;
					$b_inserter_order = isset( $b['inserterOrder'] ) ? (int) $b['inserterOrder'] : 999;

					if ( $a_inserter_order !== $b_inserter_order ) {
						return $a_inserter_order <=> $b_inserter_order;
					}

					return strcasecmp( $a['label'], $b['label'] );
				}
			);

			$available_block_types_by_mode[ $mode ] = $available_block_types;
		}

		$available_inserter_entries = self::get_available_inserter_entries( $registered_blocks, $block_category_data );

		// User roles.
		if ( ! function_exists( 'get_editable_roles' ) ) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
		}

		$available_roles = [];

		foreach ( get_editable_roles() as $slug => $data ) {
			$available_roles[] = [
				'value' => $slug,
				'label' => translate_user_role( $data['name'] ),
			];
		}

		// Post types.
		$available_post_types = self::get_available_post_types();

		$color_palette = self::get_resolved_color_palette();

		wp_localize_script(
			'gb-editor-access-dashboard',
			'gbEditorAccessDashboard',
			[
				'nonce'                     => wp_create_nonce( 'wp_rest' ),
				'availableBlockTypesByMode' => $available_block_types_by_mode,
				'availableInserterEntries'  => $available_inserter_entries,
				'availableUserRoles'        => $available_roles,
				'availablePostTypes'        => $available_post_types,
				'colorPalette'              => $color_palette,
			]
		);
	}

	/**
	 * Get the post types available to the access profile scope picker.
	 *
	 * An empty postTypes scope matches *every* post type at runtime — that
	 * fail-closed behavior is deliberate (see get_profile_match_score() in
	 * includes/extend/editor-access.php), so private block-editor post types
	 * have to be pickable here or they could never be scoped or excluded
	 * explicitly.
	 *
	 * Public post types are always listed. Private post types are listed when
	 * they have a real admin editing UI, which covers post types like wp_block
	 * and wp_navigation while leaving out site-editor internals with no admin
	 * UI (wp_template, wp_template_part, wp_global_styles) and meta-driven post
	 * types that don't support the editor.
	 *
	 * @return array List of [ value, label ] rows.
	 */
	public static function get_available_post_types() {
		$available_post_types = [];
		$post_types           = get_post_types( [], 'objects' );

		foreach ( $post_types as $slug => $post_type ) {
			if ( ! is_object( $post_type ) ) {
				continue;
			}

			// show_in_rest can be an array for some post types, so any truthy value counts.
			$has_editing_ui = ! empty( $post_type->show_ui )
				&& ! empty( $post_type->show_in_rest )
				&& post_type_supports( $slug, 'editor' );

			if ( empty( $post_type->public ) && ! $has_editing_ui ) {
				continue;
			}

			$available_post_types[] = [
				'value' => $slug,
				'label' => isset( $post_type->labels->singular_name ) ? $post_type->labels->singular_name : $slug,
			];
		}

		return $available_post_types;
	}

	/**
	 * Check whether a registered block type should appear in the inserter.
	 *
	 * @param WP_Block_Type $block The registered block type.
	 * @return bool
	 */
	private static function block_supports_inserter( $block ) {
		$supports = is_object( $block ) && isset( $block->supports ) && is_array( $block->supports )
			? $block->supports
			: [];

		return false !== ( $supports['inserter'] ?? true );
	}

	/**
	 * Normalize a user-facing inserter entry for the dashboard picker.
	 *
	 * @param array         $entry               Entry data.
	 * @param WP_Block_Type $block               Registered block type.
	 * @param array         $block_category_data Category metadata.
	 * @param int|float     $inserter_order      Stable display order.
	 * @return array
	 */
	private static function format_inserter_entry( $entry, $block, $block_category_data, $inserter_order ) {
		$category      = ! empty( $entry['category'] ) ? $entry['category'] : ( ! empty( $block->category ) ? $block->category : 'uncategorized' );
		$category_data = isset( $block_category_data[ $category ] ) ? $block_category_data[ $category ] : [];

		return [
			'id'            => $entry['id'],
			'value'         => $entry['id'],
			'type'          => ! empty( $entry['variationName'] ) ? 'variation' : 'block',
			'blockName'     => $entry['blockName'],
			'variationName' => $entry['variationName'] ?? '',
			'label'         => ! empty( $entry['title'] ) ? $entry['title'] : ( $block->title ? $block->title : self::format_block_name_label( $entry['blockName'] ) ),
			'parentLabel'   => $block->title ? $block->title : self::format_block_name_label( $entry['blockName'] ),
			'category'      => $category,
			'categoryLabel' => isset( $category_data['label'] ) ? $category_data['label'] : self::format_block_category_label( $category ),
			'categoryOrder' => isset( $category_data['order'] ) ? $category_data['order'] : 999,
			'inserterOrder' => $inserter_order,
			'isDefault'     => ! empty( $entry['isDefault'] ),
			'isVariation'   => ! empty( $entry['variationName'] ),
		];
	}

	/**
	 * Get user-facing inserter entries available to access profiles.
	 *
	 * @param array $registered_blocks   Registered block types.
	 * @param array $block_category_data Category metadata.
	 * @return array
	 */
	private static function get_available_inserter_entries( $registered_blocks, $block_category_data ) {
		$entries                  = [];
		$known_entries            = GenerateBlocks_Pro_Editor_Access::get_known_inserter_entries();
		$known_entries_by_parent  = [];
		$default_variation_parent = [];

		foreach ( $known_entries as $entry ) {
			if ( empty( $entry['id'] ) || empty( $entry['blockName'] ) ) {
				continue;
			}

			$known_entries_by_parent[ $entry['blockName'] ][] = $entry;

			if ( ! empty( $entry['isDefault'] ) ) {
				$default_variation_parent[ $entry['blockName'] ] = true;
			}
		}

		$inserter_order = 0;

		foreach ( $registered_blocks as $name => $block ) {
			if ( in_array( $name, generateblocks_pro_get_editor_access_legacy_generateblocks_block_types(), true ) ) {
				++$inserter_order;
				continue;
			}

			if ( ! self::block_supports_inserter( $block ) ) {
				++$inserter_order;
				continue;
			}

			if ( empty( $default_variation_parent[ $name ] ) ) {
				$entries[] = self::format_inserter_entry(
					[
						'id'        => 'block:' . $name,
						'blockName' => $name,
						'title'     => $block->title ? $block->title : self::format_block_name_label( $name ),
					],
					$block,
					$block_category_data,
					$inserter_order
				);
			}

			if ( ! empty( $known_entries_by_parent[ $name ] ) ) {
				foreach ( array_values( $known_entries_by_parent[ $name ] ) as $index => $entry ) {
					$entries[] = self::format_inserter_entry(
						$entry,
						$block,
						$block_category_data,
						$inserter_order + ( ( $index + 1 ) / 100 )
					);
				}
			}

			++$inserter_order;
		}

		usort(
			$entries,
			function ( $a, $b ) {
				$a_order = isset( $a['categoryOrder'] ) ? (int) $a['categoryOrder'] : 999;
				$b_order = isset( $b['categoryOrder'] ) ? (int) $b['categoryOrder'] : 999;

				if ( $a_order !== $b_order ) {
					return $a_order <=> $b_order;
				}

				$a_inserter_order = isset( $a['inserterOrder'] ) ? (float) $a['inserterOrder'] : 999;
				$b_inserter_order = isset( $b['inserterOrder'] ) ? (float) $b['inserterOrder'] : 999;

				if ( $a_inserter_order !== $b_inserter_order ) {
					return $a_inserter_order <=> $b_inserter_order;
				}

				return strcasecmp( $a['label'], $b['label'] );
			}
		);

		return $entries;
	}

	/**
	 * Get the attribute data needed by the control set builder.
	 *
	 * @param WP_Block_Type $block The registered block type.
	 * @return array
	 */
	private static function get_block_attribute_data( $block ) {
		$attributes = is_array( $block->attributes ) ? $block->attributes : [];
		$data       = [];

		foreach ( $attributes as $name => $schema ) {
			if ( ! is_array( $schema ) ) {
				continue;
			}

			$attribute = [];

			foreach ( [ 'type', 'source', 'selector', 'role' ] as $key ) {
				if ( isset( $schema[ $key ] ) && is_scalar( $schema[ $key ] ) ) {
					$attribute[ $key ] = sanitize_text_field( (string) $schema[ $key ] );
				}
			}

			if ( isset( $schema['enum'] ) && is_array( $schema['enum'] ) ) {
				$attribute['enum'] = array_values(
					array_filter(
						$schema['enum'],
						function ( $value ) {
							return is_scalar( $value );
						}
					)
				);
			}

			$data[ sanitize_text_field( (string) $name ) ] = $attribute;
		}

		return $data;
	}

	/**
	 * Get block category labels and order from WordPress.
	 *
	 * @return array
	 */
	private static function get_block_category_data() {
		if ( ! function_exists( 'get_block_categories' ) ) {
			return [];
		}

		$editor_context = class_exists( 'WP_Block_Editor_Context' ) ? new WP_Block_Editor_Context() : null;
		$categories     = get_block_categories( $editor_context );

		if ( ! is_array( $categories ) ) {
			return [];
		}

		$category_data = [];

		$order = 0;

		foreach ( $categories as $category ) {
			if ( ! is_array( $category ) || empty( $category['slug'] ) ) {
				continue;
			}

			$category_data[ $category['slug'] ] = [
				'label' => ! empty( $category['title'] ) ? $category['title'] : self::format_block_category_label( $category['slug'] ),
				'order' => $order,
			];

			++$order;
		}

		return $category_data;
	}

	/**
	 * Format a fallback block label from a block name.
	 *
	 * @param string $name The block name.
	 * @return string
	 */
	private static function format_block_name_label( $name ) {
		$parts = explode( '/', $name );
		$slug  = end( $parts );

		return ucwords( str_replace( [ '-', '_' ], ' ', $slug ) );
	}

	/**
	 * Format a fallback block category label.
	 *
	 * @param string $category The block category slug.
	 * @return string
	 */
	private static function format_block_category_label( $category ) {
		if ( ! is_string( $category ) || '' === $category ) {
			return __( 'Uncategorized', 'generateblocks-pro' );
		}

		return ucwords( str_replace( [ '-', '_' ], ' ', $category ) );
	}

	/**
	 * Add an Editor Access tab to the GB Dashboard tabs.
	 *
	 * @param array $tabs The existing tabs.
	 */
	public function add_tab( $tabs ) {
		if ( ! GenerateBlocks_Pro_Editor_Access::current_user_can_use_editor_access( 'manage' ) ) {
			return $tabs;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		$tabs['editor-access'] = [
			'name'  => __( 'Editor Access', 'generateblocks-pro' ),
			'url'   => admin_url( 'admin.php?page=generateblocks-editor-access' ),
			'class' => $screen && 'generateblocks_page_generateblocks-editor-access' === $screen->id ? 'active' : '',
		];

		return $tabs;
	}

	/**
	 * Add to our Dashboard pages.
	 *
	 * @param array $pages The existing pages.
	 */
	public function add_to_dashboard_pages( $pages ) {
		$pages[] = 'generateblocks_page_generateblocks-editor-access';

		return $pages;
	}

	/**
	 * Get the theme color palette with CSS variable references resolved to actual values.
	 *
	 * Some themes (e.g. GeneratePress) define palette colors as var(--slug) references.
	 * These variables aren't available on admin pages, so we resolve them here.
	 *
	 * @return array
	 */
	private static function get_resolved_color_palette() {
		if ( ! function_exists( 'wp_get_global_settings' ) ) {
			return [];
		}

		$global_settings = wp_get_global_settings( [ 'color', 'palette' ] );
		$theme_colors    = isset( $global_settings['theme'] ) ? $global_settings['theme'] : [];
		$custom_colors   = isset( $global_settings['custom'] ) ? $global_settings['custom'] : [];
		$color_palette   = array_merge( $theme_colors, $custom_colors );

		// Check if any colors use var() references that need resolving.
		$needs_resolving = false;

		foreach ( $color_palette as $color ) {
			if ( ! empty( $color['color'] ) && strpos( $color['color'], 'var(' ) !== false ) {
				$needs_resolving = true;
				break;
			}
		}

		if ( ! $needs_resolving ) {
			return $color_palette;
		}

		// Build a map of CSS custom property name to resolved value.
		$css_var_map = [];

		// GeneratePress defines global colors with actual hex values.
		if ( function_exists( 'generate_get_global_colors' ) ) {
			foreach ( (array) generate_get_global_colors() as $gp_color ) {
				if ( ! empty( $gp_color['slug'] ) && ! empty( $gp_color['color'] ) ) {
					$css_var_map[ '--' . $gp_color['slug'] ] = $gp_color['color'];
				}
			}
		}

		// Resolve var() references in the palette.
		foreach ( $color_palette as &$color ) {
			if ( empty( $color['color'] ) || strpos( $color['color'], 'var(' ) === false ) {
				continue;
			}

			if ( preg_match( '/var\(\s*(--[a-zA-Z0-9_-]+)\s*\)/', $color['color'], $matches ) ) {
				$var_name = $matches[1];

				if ( isset( $css_var_map[ $var_name ] ) ) {
					$color['color'] = $css_var_map[ $var_name ];
				}
			}
		}

		unset( $color );

		return $color_palette;
	}
}

GenerateBlocks_Pro_Editor_Access_Dashboard::get_instance()->init();
