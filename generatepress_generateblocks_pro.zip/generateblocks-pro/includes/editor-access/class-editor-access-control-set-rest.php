<?php
/**
 * Control Set REST API endpoints.
 *
 * Control-set writes deliberately do not call invalidate_editor_access_cache():
 * the gb_access_profile_data / gb_access_profile_preview_data transients hold
 * profile data only — control-set panels are resolved live on each editor load,
 * so control-set changes never affect the cached payload.
 *
 * @package GenerateBlocks Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once GENERATEBLOCKS_PRO_DIR . 'includes/utils/trait-rest-response.php';

/**
 * Class GenerateBlocks_Pro_Editor_Access_Control_Set_REST
 */
class GenerateBlocks_Pro_Editor_Access_Control_Set_REST extends GenerateBlocks_Pro_Singleton {

	use GenerateBlocks_Pro_REST_Response;

	/**
	 * Namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'generateblocks-pro/editor-access/v';

	/**
	 * Version.
	 *
	 * @var string
	 */
	protected $version = '1';

	/**
	 * Initialize class.
	 */
	public function init() {
		if ( ! generateblocks_pro_editor_access_enabled() ) {
			return;
		}

		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 */
	public function register_routes() {
		$namespace = $this->namespace . $this->version;

		register_rest_route(
			$namespace,
			'/control-sets/',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_control_sets' ],
					'permission_callback' => [ $this, 'manage_permission' ],
					'args'                => [
						'page' => [
							'required'          => false,
							'type'              => 'integer',
							'default'           => 1,
							'sanitize_callback' => 'absint',
						],
						'per_page' => [
							'required'          => false,
							'type'              => 'integer',
							'default'           => 100,
							'sanitize_callback' => [ $this, 'sanitize_per_page' ],
						],
					],
				],
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'create_control_set' ],
					'permission_callback' => [ $this, 'manage_permission' ],
					'args'                => [
						'title' => [
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						],
						'panels' => [
							'required'          => true,
							'type'              => 'array',
							'sanitize_callback' => [ 'GenerateBlocks_Pro_Editor_Access', 'sanitize_control_set_panels' ],
						],
					],
				],
			]
		);

		register_rest_route(
			$namespace,
			'/control-sets/(?P<id>[1-9]\d*)',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_control_set' ],
					'permission_callback' => [ $this, 'manage_permission' ],
					'args'                => [
						'id' => [
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						],
					],
				],
				[
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => [ $this, 'update_control_set' ],
					'permission_callback' => [ $this, 'manage_permission' ],
					'args'                => [
						'id' => [
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						],
						'title' => [
							'required'          => false,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						],
						'panels' => [
							'required'          => false,
							'type'              => 'array',
							'sanitize_callback' => [ 'GenerateBlocks_Pro_Editor_Access', 'sanitize_control_set_panels' ],
						],
					],
				],
				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'delete_control_set' ],
					'permission_callback' => [ $this, 'manage_permission' ],
					'args'                => [
						'id' => [
							'required'          => true,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						],
					],
				],
			]
		);
	}

	/**
	 * Permission callback for manage operations.
	 *
	 * @return bool
	 */
	public function manage_permission() {
		return GenerateBlocks_Pro_Editor_Access::current_user_can_use_editor_access( 'manage' );
	}

	/**
	 * Get all control sets.
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function get_control_sets( WP_REST_Request $request ) {
		$page     = max( 1, absint( $request->get_param( 'page' ) ) );
		$per_page = $this->normalize_per_page( $request->get_param( 'per_page' ), true );

		$args = [
			'post_type'      => 'gb_access_set',
			'post_status'    => 'publish',
			'posts_per_page' => $per_page,
			'orderby'        => [
				'title' => 'ASC',
				'ID'    => 'ASC',
			],
		];

		if ( -1 !== $per_page ) {
			$args['paged'] = $page;
		}

		$query = new WP_Query( $args );

		$control_sets = [];

		foreach ( $query->posts as $post ) {
			$control_sets[] = $this->format_control_set_response( $post );
		}

		return $this->success(
			[
				'controlSets' => $control_sets,
				'total'       => $query->found_posts,
				'pages'       => $query->max_num_pages,
			]
		);
	}

	/**
	 * Get a single control set.
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function get_control_set( WP_REST_Request $request ) {
		$id   = $request->get_param( 'id' );
		$post = get_post( $id );

		if ( ! $post || 'gb_access_set' !== $post->post_type ) {
			return $this->error( 'control_set_not_found', __( 'Control set not found.', 'generateblocks-pro' ), 404 );
		}

		return $this->success( $this->format_control_set_response( $post ) );
	}

	/**
	 * Create a new control set.
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function create_control_set( WP_REST_Request $request ) {
		$title  = $request->get_param( 'title' );
		$panels = $request->get_param( 'panels' );

		if ( '' === trim( (string) $title ) ) {
			return $this->error( 'missing_title', __( 'Title is required.', 'generateblocks-pro' ) );
		}

		$validation = $this->validate_control_set_panels_for_save( $panels );

		if ( is_wp_error( $validation ) ) {
			return $this->error( $validation->get_error_code(), $validation->get_error_message() );
		}

		// Core unslashes post data on write; slash so backslashes survive.
		$post_id = wp_insert_post(
			wp_slash(
				[
					'post_title'  => $title,
					'post_type'   => 'gb_access_set',
					'post_status' => 'publish',
				]
			)
		);

		if ( is_wp_error( $post_id ) || ! $post_id ) {
			return $this->error(
				'creation_failed',
				is_wp_error( $post_id )
					? $post_id->get_error_message()
					: __( 'Failed to create control set.', 'generateblocks-pro' )
			);
		}

		update_post_meta( $post_id, '_gb_access_set_panels', wp_slash( $panels ) );

		return $this->success( $this->format_control_set_response( get_post( $post_id ) ) );
	}

	/**
	 * Update an existing control set.
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function update_control_set( WP_REST_Request $request ) {
		$id   = $request->get_param( 'id' );
		$post = get_post( $id );

		if ( ! $post || 'gb_access_set' !== $post->post_type ) {
			return $this->error( 'control_set_not_found', __( 'Control set not found.', 'generateblocks-pro' ), 404 );
		}

		$title      = $request->get_param( 'title' );
		$has_panels = $this->has_submitted_param( $request, 'panels' );
		$panels     = $has_panels ? $request->get_param( 'panels' ) : null;

		if ( $has_panels ) {
			$validation = $this->validate_control_set_panels_for_save( $panels );

			if ( is_wp_error( $validation ) ) {
				return $this->error( $validation->get_error_code(), $validation->get_error_message() );
			}
		}

		if ( $this->has_submitted_param( $request, 'title' ) ) {
			if ( '' === trim( (string) $title ) ) {
				return $this->error( 'missing_title', __( 'Title is required.', 'generateblocks-pro' ) );
			}

			// Core unslashes post data on write; slash so backslashes survive.
			$result = wp_update_post(
				wp_slash(
					[
						'ID'         => $id,
						'post_title' => $title,
					]
				)
			);

			if ( is_wp_error( $result ) || ! $result ) {
				return $this->error(
					'update_failed',
					is_wp_error( $result )
						? $result->get_error_message()
						: __( 'Failed to update control set.', 'generateblocks-pro' )
				);
			}
		}

		if ( $has_panels ) {
			update_post_meta( $id, '_gb_access_set_panels', wp_slash( $panels ) );
		}

		return $this->success( $this->format_control_set_response( get_post( $id ) ) );
	}

	/**
	 * Delete a control set.
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function delete_control_set( WP_REST_Request $request ) {
		$id   = $request->get_param( 'id' );
		$post = get_post( $id );

		if ( ! $post || 'gb_access_set' !== $post->post_type ) {
			return $this->error( 'control_set_not_found', __( 'Control set not found.', 'generateblocks-pro' ), 404 );
		}

		$referencing_profiles = get_posts(
			[
				'post_type'      => 'gb_access_profile',
				'post_status'    => [ 'publish', 'draft' ],
				'posts_per_page' => -1,
				'fields'         => 'ids',
			]
		);

		foreach ( $referencing_profiles as $profile_id ) {
			$profile = GenerateBlocks_Pro_Editor_Access::sanitize_profile( get_post_meta( $profile_id, '_gb_access_profile', true ) );

			foreach ( $profile['rules'] ?? [] as $rule ) {
				$control_set_ids = isset( $rule['controlSetIds'] ) && is_array( $rule['controlSetIds'] )
					? array_map( 'absint', $rule['controlSetIds'] )
					: [];

				if ( ! in_array( absint( $id ), $control_set_ids, true ) ) {
					continue;
				}

				return $this->error(
					'control_set_in_use',
					__( 'This control set is used by one or more access profiles.', 'generateblocks-pro' ),
					400
				);
			}
		}

		$result = wp_delete_post( $id, true );

		if ( ! $result ) {
			return $this->error( 'deletion_failed', __( 'Failed to delete control set.', 'generateblocks-pro' ) );
		}

		return $this->success( [ 'deleted' => true ] );
	}

	/**
	 * Format control set response.
	 *
	 * @param WP_Post $post The post object.
	 * @return array
	 */
	private function format_control_set_response( $post ) {
		$panels = get_post_meta( $post->ID, '_gb_access_set_panels', true );

		return [
			'id'       => $post->ID,
			'slug'     => $post->post_name,
			'title'    => [
				'rendered' => $post->post_title,
			],
			'date'     => $this->format_gmt_datetime( $post->post_date_gmt ?? '' ),
			'modified' => $this->format_gmt_datetime( $post->post_modified_gmt ?? '' ),
			'panels'   => GenerateBlocks_Pro_Editor_Access::sanitize_control_set_panels( $panels ),
		];
	}

	/**
	 * Validate control set panels before storage.
	 *
	 * @param mixed $panels The submitted panels.
	 * @return true|WP_Error
	 */
	private function validate_control_set_panels_for_save( $panels ) {
		if ( GenerateBlocks_Pro_Editor_Access::has_renderable_control_set_panels( $panels ) ) {
			return true;
		}

		return new WP_Error(
			'empty_control_set',
			__( 'Control sets must contain at least one usable control.', 'generateblocks-pro' )
		);
	}
}

GenerateBlocks_Pro_Editor_Access_Control_Set_REST::get_instance()->init();
