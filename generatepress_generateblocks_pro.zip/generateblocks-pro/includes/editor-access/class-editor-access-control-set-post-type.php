<?php
/**
 * Control Set Post Type Registration.
 *
 * @package GenerateBlocks Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class GenerateBlocks_Pro_Editor_Access_Control_Set_Post_Type
 */
class GenerateBlocks_Pro_Editor_Access_Control_Set_Post_Type extends GenerateBlocks_Pro_Singleton {
	/**
	 * Initialize class.
	 */
	public function init() {
		add_action( 'init', [ $this, 'register_post_type' ] );
		add_action( 'init', [ $this, 'register_post_meta' ] );
	}

	/**
	 * Build the control set post type args.
	 *
	 * Capabilities are pinned to the Editor Access 'manage' context so normal
	 * edit_posts users cannot modify the reusable control definitions outside
	 * the custom REST UI.
	 *
	 * @return array
	 */
	public function get_control_set_cpt_args() {
		$manage_cap = GenerateBlocks_Pro_Editor_Access::get_editor_access_capability( 'manage' );
		$use_cap    = GenerateBlocks_Pro_Editor_Access::get_editor_access_capability( 'use' );

		return [
			'labels'              => [
				'name'          => __( 'Control Sets', 'generateblocks-pro' ),
				'singular_name' => __( 'Control Set', 'generateblocks-pro' ),
			],
			'public'              => false,
			'show_ui'             => false,
			'show_in_menu'        => false,
			'show_in_admin_bar'   => false,
			'show_in_nav_menus'   => false,
			'can_export'          => true,
			'has_archive'         => false,
			'exclude_from_search' => true,
			'publicly_queryable'  => false,
			'capability_type'     => 'post',
			'map_meta_cap'        => true,
			'capabilities'        => [
				'edit_posts'             => $manage_cap,
				'edit_others_posts'      => $manage_cap,
				'delete_posts'           => $manage_cap,
				'delete_others_posts'    => $manage_cap,
				'delete_private_posts'   => $manage_cap,
				'delete_published_posts' => $manage_cap,
				'edit_private_posts'     => $manage_cap,
				'edit_published_posts'   => $manage_cap,
				'publish_posts'          => $manage_cap,
				'read_private_posts'     => $manage_cap,
				'create_posts'           => $manage_cap,
				'read'                   => $use_cap,
			],
			'show_in_rest'        => false,
			'supports'            => [ 'title' ],
		];
	}

	/**
	 * Register the control set post type.
	 */
	public function register_post_type() {
		register_post_type( 'gb_access_set', $this->get_control_set_cpt_args() );
	}

	/**
	 * Register post meta for control sets.
	 */
	public function register_post_meta() {
		register_post_meta(
			'gb_access_set',
			'_gb_access_set_panels',
			[
				'single'            => true,
				'type'              => 'array',
				'auth_callback'     => function () {
					return GenerateBlocks_Pro_Editor_Access::current_user_can_use_editor_access( 'manage' );
				},
				'sanitize_callback' => [ 'GenerateBlocks_Pro_Editor_Access', 'sanitize_control_set_panels' ],
				'show_in_rest'      => [
					'schema' => [
						'type'  => 'array',
						'items' => [
							'type'                 => 'object',
							'additionalProperties' => true,
						],
					],
				],
			]
		);
	}
}

GenerateBlocks_Pro_Editor_Access_Control_Set_Post_Type::get_instance()->init();
