<?php
/**
 * Handle plugin functions.
 *
 * @package GenerateBlocks Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Build CSS from an array of rules.
 *
 * @param array $rules Array of CSS rules where key is selector and value is properties array.
 * @return string CSS string.
 */
function generateblocks_pro_build_css_from_array( $rules ) {
	$css = '';

	foreach ( $rules as $selector => $properties ) {
		$css .= $selector . '{';
		foreach ( $properties as $property => $value ) {
			$css .= $property . ':' . $value . ';';
		}
		$css .= '}';
	}

	return $css;
}

/**
 * Get our effect selectors.
 *
 * @since 1.0.0
 * @param array  $effect_data The data.
 * @param array  $settings The settings.
 * @param string $selector The current selector.
 * @param int    $key The current key.
 * @return array
 */
function generateblocks_pro_get_effect_selector( $effect_data, $settings, $selector, $key ) {
	$state = '';
	$device = '';
	$backgroundType = '';

	if ( ! empty( $effect_data[ $key ]['state'] ) && 'normal' !== $effect_data[ $key ]['state'] ) {
		$state = $effect_data[ $key ]['state'];
	}

	if ( ! empty( $effect_data[ $key ]['device'] ) && 'all' !== $effect_data[ $key ]['device'] ) {
		$device = $effect_data[ $key ]['device'];
	}

	if ( isset( $effect_data[ $key ]['type'] ) ) {
		if ( 'background' === $effect_data[ $key ]['type'] ) {
			$backgroundType = 'background';
		} elseif ( 'gradient' === $effect_data[ $key ]['type'] ) {
			$backgroundType = 'gradient';
		}
	}

	$element = 'element' . $backgroundType . $state . $device;

	if ( ! empty( $effect_data[ $key ]['target'] ) && 'self' !== $effect_data[ $key ]['target'] ) {
		$element = $effect_data[ $key ]['target'] . $backgroundType . $state . $device;

		if ( 'customSelector' === $effect_data[ $key ]['target'] && ! empty( $effect_data[ $key ]['customSelector'] ) ) {
			$element = $effect_data[ $key ]['customSelector'] . $backgroundType . $state . $device;
		}
	}

	if ( 'hover' === $state ) {
		$state = ':hover';
	}

	$effectSelector = $selector . $state;

	if ( isset( $effect_data[ $key ]['target'] ) && 'self' !== $effect_data[ $key ]['target'] ) {
		if ( 'innerContainer' === $effect_data[ $key ]['target'] ) {
			$blockVersion = ! empty( $settings['blockVersion'] ) ? $settings['blockVersion'] : 1;
			$useInnerContainer = $blockVersion < 3 || ! empty( $settings['useInnerContainer'] );

			if ( ! $useInnerContainer ) {
				$effectSelector = '.gb-container-' . $settings['uniqueId'] . $state . ' > .gb-container';
			} else {
				$effectSelector = '.gb-container-' . $settings['uniqueId'] . $state . ' > .gb-inside-container';
			}
		}

		if ( 'backgroundImage' === $effect_data[ $key ]['target'] ) {
			$effectSelector = $selector . $state . ':before';
		}

		if ( 'icon' === $effect_data[ $key ]['target'] ) {
			$effectSelector = $selector . $state . ' .gb-icon';
		}

		if ( 'accordionContent' === $effect_data[ $key ]['target'] ) {
			$effectSelector = $selector . $state . ' > .gb-accordion__content';
		}

		if ( 'customSelector' === $effect_data[ $key ]['target'] ) {
			$effectSelector = $selector . $state . ' ' . $effect_data[ $key ]['customSelector'];
		}

		if ( 'pseudo-element' === $effect_data[ $key ]['target'] ) {
			$effectSelector = $selector . $state . ':before';

			if ( isset( $effect_data[ $key ]['direction'] ) ) {
				$effectSelector = $selector . $state . ':after';
			}
		}
	}

	return array(
		'element' => $element,
		'selector' => $effectSelector,
	);
}

/**
 * Get our transform data.
 *
 * @since 1.0.0
 * @param array  $settings  The block settings.
 * @param string $selector The selector we're using.
 */
function generateblocks_pro_get_transforms( $settings, $selector ) {
	$transformData = array();

	if ( $settings['useTransform'] && $settings['transforms'] ) {
		foreach ( $settings['transforms'] as $key => $value ) {
			$selectorData = generateblocks_pro_get_effect_selector( $settings['transforms'], $settings, $selector, $key );
			$element = $selectorData['element'];
			$effectSelector = $selectorData['selector'];

			$transformData[ $element ]['selector'] = $effectSelector;
			$transformData[ $element ]['state'] = ! empty( $value['state'] ) ? $value['state'] : 'normal';
			$transformData[ $element ]['device'] = ! empty( $value['device'] ) ? $value['device'] : 'all';

			if ( 'translate' === $value['type'] ) {
				$translateX = 0;
				$translateY = 0;

				if ( isset( $value['translateX'] ) && '' !== $value['translateX'] ) {
					$translateX = (float) $value['translateX'] . 'px';
				}

				if ( isset( $value['translateY'] ) && '' !== $value['translateY'] ) {
					$translateY = (float) $value['translateY'] . 'px';
				}

				if ( $translateX || $translateY ) {
					$transformData[ $element ]['transforms'][] = 'translate3d(' . $translateX . ',' . $translateY . ',0)';
				}
			}

			if ( 'rotate' === $value['type'] ) {
				if ( isset( $value['rotate'] ) && '' !== $value['rotate'] ) {
					$transformData[ $element ]['transforms'][] = 'rotate(' . (float) $value['rotate'] . 'deg)';
				}
			}

			if ( 'skew' === $value['type'] ) {
				if ( isset( $value['skewX'] ) && '' !== $value['skewX'] ) {
					$transformData[ $element ]['transforms'][] = 'skewX(' . (float) $value['skewX'] . 'deg)';
				}

				if ( isset( $value['skewY'] ) && '' !== $value['skewY'] ) {
					$transformData[ $element ]['transforms'][] = 'skewY(' . (float) $value['skewY'] . 'deg)';
				}
			}

			if ( 'scale' === $value['type'] ) {
				if ( isset( $value['scale'] ) && '' !== $value['scale'] ) {
					$transformData[ $element ]['transforms'][] = 'scale(' . (float) $value['scale'] . ')';
					$transformData[ $element ]['transforms'][] = 'perspective(1000px)'; // Activate GPU.
				}
			}
		}
	}

	return $transformData;
}

/**
 * Get our CSS filter data.
 *
 * @since 1.0.0
 * @param array  $settings  The block settings.
 * @param string $selector The selector we're using.
 */
function generateblocks_pro_get_css_filters( $settings, $selector ) {
	$filterData = array();

	if ( $settings['useFilter'] && $settings['filters'] ) {
		foreach ( $settings['filters'] as $key => $value ) {
			$selectorData = generateblocks_pro_get_effect_selector( $settings['filters'], $settings, $selector, $key );
			$element = $selectorData['element'];
			$effectSelector = $selectorData['selector'];

			$filterData[ $element ]['selector'] = $effectSelector;
			$filterData[ $element ]['state'] = ! empty( $value['state'] ) ? $value['state'] : 'normal';
			$filterData[ $element ]['device'] = ! empty( $value['device'] ) ? $value['device'] : 'all';

			if ( 'blur' === $value['type'] ) {
				if ( isset( $value['blur'] ) && '' !== $value['blur'] ) {
					$filterData[ $element ]['filters'][] = 'blur(' . (float) $value['blur'] . 'px)';
				}
			}

			if ( 'brightness' === $value['type'] ) {
				if ( isset( $value['brightness'] ) && '' !== $value['brightness'] ) {
					$filterData[ $element ]['filters'][] = 'brightness(' . (float) $value['brightness'] . '%)';
				}
			}

			if ( 'contrast' === $value['type'] ) {
				if ( isset( $value['contrast'] ) && '' !== $value['contrast'] ) {
					$filterData[ $element ]['filters'][] = 'contrast(' . (float) $value['contrast'] . '%)';
				}
			}

			if ( 'grayscale' === $value['type'] ) {
				if ( isset( $value['grayscale'] ) && '' !== $value['grayscale'] ) {
					$filterData[ $element ]['filters'][] = 'grayscale(' . (float) $value['grayscale'] . '%)';
				}
			}

			if ( 'hue-rotate' === $value['type'] ) {
				if ( isset( $value['hueRotate'] ) && '' !== $value['hueRotate'] ) {
					$filterData[ $element ]['filters'][] = 'hue-rotate(' . (float) $value['hueRotate'] . 'deg)';
				}
			}

			if ( 'invert' === $value['type'] ) {
				if ( isset( $value['invert'] ) && '' !== $value['invert'] ) {
					$filterData[ $element ]['filters'][] = 'invert(' . (float) $value['invert'] . '%)';
				}
			}

			if ( 'saturate' === $value['type'] ) {
				if ( isset( $value['saturate'] ) && '' !== $value['saturate'] ) {
					$filterData[ $element ]['filters'][] = 'saturate(' . (float) $value['saturate'] . '%)';
				}
			}

			if ( 'sepia' === $value['type'] ) {
				if ( isset( $value['sepia'] ) && '' !== $value['sepia'] ) {
					$filterData[ $element ]['filters'][] = 'sepia(' . (float) $value['sepia'] . '%)';
				}
			}
		}
	}

	return $filterData;
}

/**
 * Check if we can upload SVG files.
 *
 * @since 1.1.0
 */
function generateblocks_pro_has_svg_support() {
	$has_mime_type = in_array( 'image/svg+xml', (array) get_allowed_mime_types() );
	$has_safe_svg  = is_plugin_active( 'safe-svg/safe-svg.php' );

	return $has_mime_type || $has_safe_svg;
}

/**
 * Try to sanitize SVGs if the Safe SVG plugin isn't active.
 *
 * @since 1.0.0
 */
function generateblocks_pro_kses_svg() {
	$kses_defaults = wp_kses_allowed_html( 'post' );

	$svg_args = array(
		'svg' => array(
			'class'           => true,
			'aria-hidden'     => true,
			'aria-labelledby' => true,
			'role'            => true,
			'xmlns'           => true,
			'width'           => true,
			'height'          => true,
			'viewbox'         => true, // <= Must be lower case!
		),
		'g' => array( 'fill' => true ),
		'title' => array( 'title' => true ),
		'path' => array(
			'd' => true,
			'fill' => true,
		),
	);

	return array_merge( $kses_defaults, $svg_args );
}

/**
 * Prepare our custom icons for the editor.
 *
 * @since 1.0.0
 */
function generateblocks_pro_editor_icon_list() {
	$custom_icons = get_option( 'generateblocks_svg_icons', array() );
	$new_icons = array();

	// Format our custom shapes to fit our shapes structure.
	foreach ( $custom_icons as $index => $data ) {
		$new_icons[ sanitize_key( $data['group'] ) ] = array(
			'group' => sanitize_text_field( $data['group'] ),
			'svgs' => array(),
		);

		if ( isset( $data['icons'] ) ) {
			foreach ( (array) $data['icons'] as $shape_index => $icon ) {
				$new_icons[ sanitize_key( $data['group'] ) ]['svgs'][ $icon['id'] ] = array(
					'label' => $icon['name'],
					'icon' => $icon['icon'],
				);
			}
		}
	}

	return $new_icons;
}

/**
 * Get all of our global style IDs.
 *
 * @since 1.0.0
 */
function generateblocks_pro_get_global_style_ids() {
	$global_styles = get_option( 'generateblocks_global_style_attrs', array() );
	$ids = array();

	foreach ( $global_styles as $id => $data ) {
		foreach ( $data['ids'] as $name => $block_ids ) {
			foreach ( $block_ids as $id ) {
				$ids[ $name ][] = $id['uniqueId'];
			}
		}
	}

	return $ids;
}

/**
 * Get all of our global style IDs.
 *
 * @since 1.0.0
 */
function generateblocks_pro_get_global_style_attrs() {
	$global_styles = get_option( 'generateblocks_global_style_attrs', array() );
	$ids = array();

	foreach ( $global_styles as $id => $data ) {
		foreach ( $data['ids'] as $name => $block_ids ) {
			foreach ( $block_ids as $id => $attrs ) {
				$ids[ $name ][ $id ] = $attrs;
			}
		}
	}

	return $ids;
}

/**
 * Sanitize a custom HTML attribute name.
 *
 * This mirrors the legacy editor allow-list for custom attributes.
 *
 * @since 2.6.0
 * @param mixed $attribute The raw attribute name.
 * @return string
 */
function generateblocks_pro_sanitize_custom_attribute_name( $attribute ) {
	if ( ! is_scalar( $attribute ) ) {
		return '';
	}

	$attribute = strtolower( trim( (string) $attribute ) );

	if ( '' === $attribute || ! preg_match( '/^[a-z][a-z0-9._:-]*$/', $attribute ) ) {
		return '';
	}

	$safe_values = [
		'title',
		'role',
		'download',
		'itemtype',
		'itemscope',
		'itemprop',
	];

	if ( in_array( $attribute, $safe_values, true ) ) {
		return $attribute;
	}

	if ( 0 === strpos( $attribute, 'data-' ) || 0 === strpos( $attribute, 'aria-' ) ) {
		return $attribute;
	}

	return '';
}

/**
 * Add custom attributes to a block.
 *
 * @since 1.3.0
 * @param array $attributes The existing attributes.
 * @param array $settings The settings for the block.
 */
function generateblocks_pro_with_custom_attributes( $attributes, $settings ) {
	if ( ! empty( $settings['htmlAttributes'] ) && is_array( $settings['htmlAttributes'] ) ) {
		foreach ( $settings['htmlAttributes'] as $data ) {
			if ( ! is_array( $data ) ) {
				continue;
			}

			$attribute = generateblocks_pro_sanitize_custom_attribute_name( $data['attribute'] ?? '' );

			if ( ! $attribute ) {
				continue;
			}

			$attributes[ $attribute ] = isset( $data['value'] ) && '' !== $data['value'] ? esc_attr( $data['value'] ) : true;
		}
	}

	return $attributes;
}

/**
 * Get our script dependencies and version.
 *
 * @param string $filename The filename to use.
 * @param array  $fallback_assets The assets to fallback to.
 * @param string $base_path The base path for the file search.
 */
function generateblocks_pro_get_enqueue_assets(
	$filename = '',
	$fallback_assets = [
		'dependencies' => [],
		'version' => '',
	],
	$base_path = GENERATEBLOCKS_PRO_DIR . 'dist/'
) {
	if ( ! $filename ) {
		return $fallback_assets;
	}

	$assets_file = $base_path . $filename . '.asset.php';
	$compiled_assets = file_exists( $assets_file )
		? require $assets_file
		: false;

	$assets =
		isset( $compiled_assets['dependencies'] ) &&
		isset( $compiled_assets['version'] )
		? $compiled_assets
		: $fallback_assets;

	return $assets;
}

/**
 * Get the total number of legacy patterns.
 */
function generateblocks_pro_get_legacy_patterns_count() {
	$count = wp_count_posts( 'gblocks_templates' );

	if ( ! is_object( $count ) ) {
		return 0;
	}

	$total = 0;

	foreach ( array( 'publish', 'future', 'draft', 'pending', 'private', 'trash' ) as $status ) {
		$total += isset( $count->{$status} ) ? (int) $count->{$status} : 0;
	}

	return $total;
}

/**
 * Check if we have any legacy patterns.
 */
function generateblocks_pro_has_legacy_patterns() {
	return generateblocks_pro_get_legacy_patterns_count() > 0;
}

/**
 * Get inline CSS for blocks as a pure string without using filters.
 * This allows CSS generation for specific content without side effects.
 *
 * @since 2.3.0
 * @param string|array $content The content to parse (can be raw content or parsed blocks).
 * @return string The generated CSS.
 */
function generateblocks_pro_get_css_from_content( $content ) {
	// Short circuit if GenerateBlocks adds this function in the future.
	if ( function_exists( 'generateblocks_get_css_from_content' ) ) {
		return generateblocks_get_css_from_content( $content );
	}

	if ( ! function_exists( 'generateblocks_get_block_data' ) ) {
		return '';
	}

	// Parse blocks if we received raw content.
	$parsed_blocks = is_array( $content ) ? $content : parse_blocks( $content );
	$data = generateblocks_get_block_data( $parsed_blocks );

	if ( empty( $data ) ) {
		return '';
	}

	$css = '';
	$css_data = array();

	$blocks = apply_filters(
		'generateblocks_dynamic_css_blocks',
		array(
			'text'               => 'GenerateBlocks_Block_Text',
			'element'            => 'GenerateBlocks_Block_Element',
			'media'              => 'GenerateBlocks_Block_Media',
			'shape'              => 'GenerateBlocks_Block_Shape',
			'query'              => 'GenerateBlocks_Block_Query',
			'looper'             => 'GenerateBlocks_Block_Looper',
			'query-page-numbers' => 'GenerateBlocks_Block_Query_Page_Numbers',
			'loop-item'          => 'GenerateBlocks_Block_Loop_Item',
		)
	);

	// Legacy blocks that use get_css_data().
	$legacy_blocks = array(
		'grid'             => 'GenerateBlocks_Block_Grid',
		'container'        => 'GenerateBlocks_Block_Container',
		'button-container' => 'GenerateBlocks_Block_Button_Container',
		'button'           => 'GenerateBlocks_Block_Button',
		'headline'         => 'GenerateBlocks_Block_Headline',
		'image'            => 'GenerateBlocks_Block_Image',
	);

	// Process each block type.
	foreach ( $data as $block_type => $block_instances ) {
		// Handle modern blocks.
		if ( isset( $blocks[ $block_type ] ) ) {
			$class_name = $blocks[ $block_type ];

			if ( class_exists( $class_name ) && is_callable( array( $class_name, 'get_css' ) ) ) {
				foreach ( $block_instances as $attributes ) {
					$block_css = $class_name::get_css( $attributes );

					if ( $block_css ) {
						$css .= wp_strip_all_tags( $block_css );
					}
				}
			}
		} elseif ( isset( $legacy_blocks[ $block_type ] ) ) {
			// Handle legacy blocks.
			$class_name = $legacy_blocks[ $block_type ];

			if ( class_exists( $class_name ) && is_callable( array( $class_name, 'get_css_data' ) ) ) {
				foreach ( $block_instances as $attributes ) {
					$block_css_data = $class_name::get_css_data( $attributes );

					if ( $block_css_data && function_exists( 'generateblocks_group_css_data' ) ) {
						$css_data = generateblocks_group_css_data( $css_data, $block_css_data );
					}
				}
			}
		}
	}

	// Compile legacy block CSS data if we have any.
	if ( ! empty( $css_data ) && function_exists( 'generateblocks_get_compiled_css' ) ) {
		$css .= generateblocks_get_compiled_css( $css_data );
	}

	return $css;
}

/**
 * Check if the overlay panels feature is enabled.
 *
 * @since 2.4.0
 * @return bool Whether overlay panels are enabled.
 */
function generateblocks_pro_overlays_enabled() {
	// Bail early if the function doesn't exist.
	if ( ! function_exists( 'generateblocks_get_option' ) ) {
		return true;
	}

	$enabled = generateblocks_get_option( 'enable_overlay_panels' );

	// If explicitly set to false, respect that.
	if ( false === $enabled ) {
		return false;
	}

	// Default to true for null or any other value.
	return true;
}

/**
 * Check if the Editor Access feature can be registered.
 *
 * @return bool Whether Editor Access is enabled.
 */
function generateblocks_pro_editor_access_enabled() {
	return generateblocks_pro_editor_access_supports_generateblocks_content_only();
}

/**
 * Check whether GenerateBlocks can hide its inspector panels for content-only Editor Access.
 *
 * @return bool Whether GenerateBlocks exposes the inspector slot needed by Editor Access.
 */
function generateblocks_pro_editor_access_supports_generateblocks_content_only() {
	return function_exists( 'generateblocks_supports' ) && generateblocks_supports( 'block-inspector-slot' );
}

/**
 * Check if the block conditions feature is enabled.
 *
 * @since 2.4.0
 * @return bool Whether block conditions are enabled.
 */
function generateblocks_pro_block_conditions_enabled() {
	// Bail early if the function doesn't exist.
	if ( ! function_exists( 'generateblocks_get_option' ) ) {
		return true;
	}

	$enabled = generateblocks_get_option( 'enable_block_conditions' );

	// If explicitly set to false, respect that.
	if ( false === $enabled ) {
		return false;
	}

	// Default to true for null or any other value.
	return true;
}

/**
 * Check if the forms feature is enabled.
 *
 * @since 2.6.0
 * @return bool Whether forms are enabled.
 */
function generateblocks_pro_forms_enabled() {
	// Bail early if the function doesn't exist.
	if ( ! function_exists( 'generateblocks_get_option' ) ) {
		return false;
	}

	$enabled = generateblocks_get_option( 'enable_forms' );

	return true === $enabled || 1 === $enabled || '1' === $enabled || 'true' === $enabled;
}

/**
 * Get GenerateBlocks v1 block types that should not appear in Editor Access.
 *
 * This mirrors src/utils/v1BlockNames.js for the dashboard and REST payloads.
 *
 * @since 2.7.0
 * @return array
 */
function generateblocks_pro_get_editor_access_legacy_generateblocks_block_types() {
	return [
		'generateblocks/button-container',
		'generateblocks/button',
		'generateblocks/container',
		'generateblocks/headline',
		'generateblocks/image',
		'generateblocks/grid',
		'generateblocks/query-loop',
	];
}

/**
 * Get block types that do not support Editor Access.
 *
 * @since 2.7.0
 * @return array
 */
function generateblocks_pro_get_editor_access_unsupported_block_types() {
	return array_merge(
		generateblocks_pro_get_editor_access_legacy_generateblocks_block_types(),
		[
			'generateblocks/query-no-results',
			'generateblocks/no-results',
			'generateblocks-pro/form-render',
		]
	);
}

/**
 * Check whether a registered block type exposes content-role attributes.
 *
 * @since 2.7.0
 * @param string $block_type The block type name.
 * @return bool
 */
function generateblocks_pro_editor_access_block_type_has_content_role( $block_type ) {
	if ( ! is_string( $block_type ) || ! class_exists( 'WP_Block_Type_Registry' ) ) {
		return false;
	}

	$block_registry = WP_Block_Type_Registry::get_instance();
	$registered     = method_exists( $block_registry, 'get_registered' )
		? $block_registry->get_registered( $block_type )
		: null;

	if ( ! $registered && method_exists( $block_registry, 'get_all_registered' ) ) {
		$all_registered = $block_registry->get_all_registered();
		$registered     = is_array( $all_registered ) && isset( $all_registered[ $block_type ] )
			? $all_registered[ $block_type ]
			: null;
	}

	if ( ! $registered ) {
		return false;
	}

	$supports = is_object( $registered ) && isset( $registered->supports ) && is_array( $registered->supports )
		? $registered->supports
		: [];

	if ( ! empty( $supports['contentRole'] ) ) {
		return true;
	}

	$attributes = is_object( $registered ) && isset( $registered->attributes ) && is_array( $registered->attributes )
		? $registered->attributes
		: [];

	foreach ( $attributes as $attribute ) {
		$role                  = '';
		$experimental_role_key = '__experimentalRole';

		if ( is_array( $attribute ) ) {
			$role = $attribute['role'] ?? $attribute['__experimentalRole'] ?? '';
		} elseif ( is_object( $attribute ) ) {
			$role = $attribute->role ?? $attribute->{$experimental_role_key} ?? '';
		}

		if ( 'content' === $role ) {
			return true;
		}
	}

	return false;
}

/**
 * Check whether a block type supports Editor Access.
 *
 * @since 2.7.0
 * @param string $block_type The block type name.
 * @param string $mode       The Editor Access mode.
 * @return bool
 */
function generateblocks_pro_is_editor_access_supported_block_type( $block_type, $mode = 'contentOnly' ) {
	if ( ! is_string( $block_type ) ) {
		return false;
	}

	if ( in_array( $block_type, generateblocks_pro_get_editor_access_legacy_generateblocks_block_types(), true ) ) {
		return false;
	}

	if ( 'readOnly' === $mode ) {
		return true;
	}

	if ( 'contentOnly' === $mode ) {
		if (
			0 === strpos( $block_type, 'generateblocks/' ) &&
			! generateblocks_pro_editor_access_supports_generateblocks_content_only()
		) {
			return false;
		}

		return generateblocks_pro_editor_access_block_type_has_content_role( $block_type );
	}

	if ( 'custom' !== $mode ) {
		return false;
	}

	$is_generateblocks_block     = 0 === strpos( $block_type, 'generateblocks/' );
	$is_generateblocks_pro_block = 0 === strpos( $block_type, 'generateblocks-pro/' );

	if ( ! $is_generateblocks_block && ! $is_generateblocks_pro_block ) {
		return false;
	}

	if (
		$is_generateblocks_block &&
		! generateblocks_pro_editor_access_supports_generateblocks_content_only()
	) {
		return false;
	}

	return ! in_array( $block_type, generateblocks_pro_get_editor_access_unsupported_block_types(), true );
}

/**
 * Get all registered block types that support Editor Access.
 *
 * @since 2.7.0
 * @param string $mode The Editor Access mode.
 * @return array
 */
function generateblocks_pro_get_editor_access_supported_block_types( $mode = 'contentOnly' ) {
	if ( ! class_exists( 'WP_Block_Type_Registry' ) ) {
		return [];
	}

	$block_registry = WP_Block_Type_Registry::get_instance();

	return array_values(
		array_filter(
			array_keys( $block_registry->get_all_registered() ),
			function ( $block_type ) use ( $mode ) {
				return generateblocks_pro_is_editor_access_supported_block_type( $block_type, $mode );
			}
		)
	);
}

/**
 * Whether the current user can import forms via the pattern library route.
 *
 * Resolves the same cap + filter the route uses, so the editor's disable
 * state mirrors what the REST permission_callback will accept. Filters
 * that branch on the WP_REST_Request must tolerate `null` here — this is
 * an enqueue-time evaluation with no request in flight.
 *
 * @since 2.6.0
 * @return bool
 */
function generateblocks_pro_can_import_pattern_forms() {
	if ( ! class_exists( 'GenerateBlocks_Pro_Form_Post_Type' ) ) {
		return false;
	}

	$can_import = GenerateBlocks_Pro_Form_Post_Type::current_user_can( 'manage' );

	/**
	 * Filter whether the current user can import forms via the pattern
	 * library route. Receives `null` for `$request` when evaluated at
	 * editor enqueue time (no request in flight).
	 *
	 * @since 2.6.0
	 * @param bool                  $can_import Default cap result.
	 * @param WP_REST_Request|null  $request    Request when called from the
	 *                                          REST permission_callback,
	 *                                          `null` at enqueue time.
	 */
	return (bool) apply_filters(
		'generateblocks_pattern_library_can_import_forms',
		$can_import,
		null
	);
}

/**
 * Run a render callback inside a declared post_content source frame.
 *
 * Wraps GenerateBlocks free's post-source taint helper so raw do_blocks()
 * renders of a stored post's content are suppressed when that post was last
 * saved by a user who cannot author dynamic data. Falls back to running the
 * callback directly when free is older than 2.4.0 (dormant-hook pattern).
 *
 * @since 2.7.0
 *
 * @param int      $post_id  The post whose content the callback renders.
 * @param callable $callback The render callback.
 * @return mixed The callback's return value.
 */
function generateblocks_pro_render_with_content_source( $post_id, $callback ) {
	if ( ! is_callable( $callback ) ) {
		return '';
	}

	if (
		class_exists( 'GenerateBlocks_Dynamic_Tag_Security' ) &&
		method_exists( 'GenerateBlocks_Dynamic_Tag_Security', 'render_with_content_source' )
	) {
		return GenerateBlocks_Dynamic_Tag_Security::render_with_content_source( absint( $post_id ), $callback );
	}

	return call_user_func( $callback );
}

/**
 * Get the at-rule presets offered by the Styles Builder.
 *
 * Presets only affect authoring: at-rules are saved with each style, so
 * changing them never alters existing content. Built-in labels and icons live
 * in the styles-builder package, which also validates and normalizes values.
 *
 * GenerateBlocks applies the same filter for its own copy of the package. This
 * is deliberately not shared with it: each plugin feeds the package copy it
 * ships, so any combination of plugin versions keeps working.
 *
 * @since 2.8.0
 *
 * @return array[] Ordered list of `id`, `value` and optional `label`/`show` entries.
 */
function generateblocks_pro_get_default_at_rules() {
	$defaults = array(
		'largeWidth'       => array( 'value' => '@media (min-width:1025px)' ),
		'mediumLargeWidth' => array( 'value' => '@media (min-width:768px)' ),
		'mediumWidth'      => array( 'value' => '@media (max-width:1024px) and (min-width:768px)' ),
		'mediumSmallWidth' => array( 'value' => '@media (max-width:1024px)' ),
		'smallWidth'       => array( 'value' => '@media (max-width:767px)' ),
	);

	/**
	 * Filters the at-rule presets offered by the Styles Builder.
	 *
	 * The returned list is the preset list: its order is kept, and a built-in
	 * that is unset is no longer offered. "All screens" is always present.
	 *
	 * @since 2.8.0
	 *
	 * @param array[] $at_rules Presets keyed by id. Each entry takes a `value`
	 *                          ("@media (max-width:767px)"), plus an optional
	 *                          `label` and `show` (give it a device button).
	 */
	$at_rules = apply_filters( 'generateblocks_default_at_rules', $defaults );

	if ( ! is_array( $at_rules ) ) {
		$at_rules = $defaults;
	}

	$presets = array();

	foreach ( $at_rules as $id => $at_rule ) {
		$id = is_int( $id ) ? 'preset-' . $id : (string) $id;

		if ( 'all' === $id ) {
			continue;
		}

		$at_rule = is_array( $at_rule ) ? $at_rule : array();
		$value   = isset( $at_rule['value'] ) && is_string( $at_rule['value'] ) ? trim( $at_rule['value'] ) : '';

		// A mistake in a built-in breakpoint shouldn't remove the device.
		if ( '' === $value && isset( $defaults[ $id ] ) ) {
			$value = $defaults[ $id ]['value'];
		}

		if ( '' === $value ) {
			continue;
		}

		$preset = array(
			'id'    => $id,
			'value' => $value,
		);

		if ( isset( $at_rule['label'] ) && is_string( $at_rule['label'] ) ) {
			$preset['label'] = sanitize_text_field( $at_rule['label'] );
		}

		if ( isset( $at_rule['show'] ) ) {
			$preset['show'] = (bool) $at_rule['show'];
		}

		$presets[] = $preset;
	}

	return $presets;
}
