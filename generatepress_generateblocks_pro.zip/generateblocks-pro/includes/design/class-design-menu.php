<?php
/**
 * GenerateBlocks admin menu organization for design tools.
 *
 * @package GenerateBlocksPro\Design
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Organizes the unified GenerateBlocks menu and Studio navigation.
 */
class GenerateBlocks_Pro_Design_Menu extends GenerateBlocks_Pro_Singleton {

	const PARENT_SLUG = 'generateblocks';

	const MENU_POSITION = '58.5';

	/**
	 * Link-only submenu route for the Design Tokens workspace.
	 *
	 * Design Tokens shares the Global Styles admin screen, so this must remain
	 * a URL instead of being registered as a second WordPress admin page.
	 */
	const DESIGN_TOKENS_SUBMENU_URL = 'admin.php?page=generateblocks-styles&view=design-tokens';

	/**
	 * Submenu group order.
	 *
	 * @var array<string, array{group:string, order:int}>
	 */
	private static $submenu_items = [
		'generateblocks-settings' => [
			'group' => 'settings',
			'order' => 10,
		],
		'generateblocks-editor-access' => [
			'group' => 'settings',
			'order' => 20,
		],
		'generateblocks-styles' => [
			'group' => 'design',
			'order' => 10,
		],
		'admin.php?page=generateblocks-styles&view=design-tokens' => [
			'group' => 'design',
			'order' => 20,
		],
		'edit.php?post_type=wp_block' => [
			'group' => 'build',
			'order' => 10,
		],
		'generateblocks-asset-library' => [
			'group' => 'build',
			'order' => 20,
		],
		'generateblocks-site-templates' => [
			'group' => 'build',
			'order' => 30,
		],
		'generateblocks-forms' => [
			'group' => 'build',
			'order' => 40,
		],
		'generateblocks-overlay-panels' => [
			'group' => 'build',
			'order' => 50,
		],
		'generateblocks-conditions' => [
			'group' => 'build',
			'order' => 60,
		],
		// GenerateCloud registers this submenu when active; keep the partner
		// plugin's entry grouped instead of letting it sort to the tail.
		'generateblocks-public-keys' => [
			'group' => 'build',
			'order' => 70,
		],
	];

	/**
	 * Register hooks.
	 */
	public function init() {
		add_action( 'admin_menu', [ $this, 'rebuild_parent_menu' ], 1000 );
		add_action( 'admin_menu', [ $this, 'organize_submenu' ], 1001 );
		add_action( 'admin_head', [ $this, 'print_menu_group_styles' ] );
	}

	/**
	 * Get the Studio design pages the current user can access.
	 *
	 * This feeds the in-app workspace switcher. The shared dashboard follows
	 * the same filtered Global Styles management check as the editor.
	 *
	 * @return array<int, array{id:string,label:string,url:string}>
	 */
	public static function get_studio_navigation() {
		$pages = [];

		if ( ! GenerateBlocks_Pro_Styles::can_manage_styles() ) {
			return $pages;
		}

		$pages[] = [
			'id'    => 'global-styles',
			'label' => __( 'Global Styles', 'generateblocks-pro' ),
			'url'   => GenerateBlocks_Pro_Style_Book::get_dashboard_url(),
		];

		if ( GenerateBlocks_Pro_Design_Tokens::can_manage_tokens() ) {
			$pages[] = [
				'id'    => 'design-tokens',
				'label' => __( 'Design Tokens', 'generateblocks-pro' ),
				'url'   => GenerateBlocks_Pro_Style_Book::get_dashboard_url( 'design-tokens' ),
			];
		}

		return $pages;
	}

	/**
	 * Move the existing GenerateBlocks parent to the top plugin group.
	 *
	 * Re-registers only when the parent was actually present. If third-party
	 * code removed the menu earlier in `admin_menu` (white-labeling is common
	 * — `remove_menu_page( 'generateblocks' )` from an agency mu-plugin),
	 * that removal is respected: re-adding here would silently undo it on
	 * every admin load.
	 */
	public function rebuild_parent_menu() {
		$removed = remove_menu_page( self::PARENT_SLUG );

		if ( false === $removed ) {
			return;
		}

		// The parent must be visible to filtered-capability Styles users, but it
		// also owns settings screens that continue to use manage_options. Resolve
		// that OR relationship for the current request instead of globally
		// lowering the parent capability or hiding it from settings-only users.
		$parent_capability = GenerateBlocks_Pro_Styles::can_manage_styles()
			? GenerateBlocks_Pro_Styles::get_manage_styles_capability()
			: 'manage_options';

		add_menu_page(
			__( 'GenerateBlocks', 'generateblocks-pro' ),
			__( 'GenerateBlocks', 'generateblocks-pro' ),
			$parent_capability,
			self::PARENT_SLUG,
			'',
			'',
			self::MENU_POSITION
		);
	}

	/**
	 * Sort the GenerateBlocks submenu into coarse product groups.
	 */
	public function organize_submenu() {
		global $submenu;

		if ( empty( $submenu[ self::PARENT_SLUG ] ) ) {
			return;
		}

		$items = array_values( $submenu[ self::PARENT_SLUG ] );

		$items = array_map(
			static function ( $item, $index ) {
				$item['_gb_original_index'] = $index;
				return $item;
			},
			$items,
			array_keys( $items )
		);

		usort( $items, [ $this, 'sort_submenu_items' ] );

		// WordPress uses the first raw submenu item as the top-level link before
		// skipping items the current user cannot access. Move the first accessible
		// item to the front so a filtered Styles user lands on Global Styles instead
		// of an inaccessible manage_options screen. Default administrators retain
		// the normal Settings-first ordering.
		foreach ( $items as $index => $item ) {
			$capability = $item[1] ?? '';

			if ( '' === $capability || ! current_user_can( $capability ) ) {
				continue;
			}

			if ( $index > 0 ) {
				$first_accessible = array_splice( $items, $index, 1 );
				$items = array_merge( $first_accessible, $items );
			}

			break;
		}

		$seen_groups = [];

		foreach ( $items as &$item ) {
			$slug = $item[2] ?? '';

			unset( $item['_gb_original_index'] );

			if ( empty( self::$submenu_items[ $slug ] ) ) {
				continue;
			}

			$group = self::$submenu_items[ $slug ]['group'];

			if ( isset( $seen_groups[ $group ] ) ) {
				continue;
			}

			$seen_groups[ $group ] = true;
			$this->add_submenu_item_class( $item, 'gb-admin-menu-group-start gb-admin-menu-group-' . $group );
		}
		unset( $item );

		$submenu[ self::PARENT_SLUG ] = $items; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
	}

	/**
	 * Sort known menu items by group/order, leaving unknown third-party items
	 * after GenerateBlocks-owned items in their existing relative order.
	 *
	 * @param array $a First menu item.
	 * @param array $b Second menu item.
	 * @return int
	 */
	public function sort_submenu_items( $a, $b ) {
		$a_weight = $this->get_submenu_sort_weight( $a );
		$b_weight = $this->get_submenu_sort_weight( $b );

		return $a_weight <=> $b_weight;
	}

	/**
	 * Get a sortable weight for a submenu item.
	 *
	 * @param array $item Submenu item.
	 * @return int
	 */
	private function get_submenu_sort_weight( $item ): int {
		$slug = $item[2] ?? '';

		if ( ! empty( self::$submenu_items[ $slug ] ) ) {
			$groups = [
				'settings' => 100,
				'design'   => 200,
				'build'    => 300,
			];

			$group = self::$submenu_items[ $slug ]['group'];
			$order = self::$submenu_items[ $slug ]['order'];

			return ( $groups[ $group ] ?? 900 ) + $order;
		}

		return 1000 + (int) ( $item['_gb_original_index'] ?? 0 );
	}

	/**
	 * Add classes to a submenu item.
	 *
	 * @param array  $item Submenu item.
	 * @param string $class_names Class names.
	 */
	private function add_submenu_item_class( &$item, string $class_names ) {
		$existing = isset( $item[4] ) ? (string) $item[4] : '';
		$classes  = array_filter( array_merge( explode( ' ', $existing ), explode( ' ', $class_names ) ) );

		$item[4] = implode( ' ', array_unique( $classes ) );
	}

	/**
	 * Encode a translated group label for a CSS `content:` string.
	 *
	 * `wp_json_encode()` with default flags escapes non-ASCII to `\uXXXX`,
	 * which CSS does not understand (`\u` is an identity escape for the
	 * letter "u"), so French "Réglages" would render as "Ru00e9glages" and
	 * CJK labels as garbage. `JSON_UNESCAPED_UNICODE` keeps the characters
	 * literal; `JSON_HEX_TAG` escapes `<`/`>` so a hostile translation can't
	 * carry `</style>` out of the inline style element (the escaped form
	 * renders mangled in CSS, but stays safe).
	 *
	 * @param string $label Translated label.
	 * @return string JSON/CSS string literal including quotes.
	 */
	public static function css_content_label( string $label ): string {
		return (string) wp_json_encode( $label, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG );
	}

	/**
	 * Print visual group labels for the GenerateBlocks submenu.
	 */
	public function print_menu_group_styles() {
		global $submenu;

		if ( empty( $submenu[ self::PARENT_SLUG ] ) ) {
			return;
		}

		$menu_font_url = GENERATEBLOCKS_PRO_DIR_URL . 'dist/assets/fonts/generatepress-admin.woff2';
		?>
		<style id="gb-admin-menu-groups">
		@font-face {
			font-family: generatepress-admin;
			src: url("<?php echo esc_url( $menu_font_url ); ?>") format("woff2");
			font-weight: 400;
			font-style: normal;
			font-display: block;
		}
		body #adminmenu #toplevel_page_generateblocks.menu-top div.wp-menu-image::before {
			/* Share Dashicons' generic icon code point for a failed-font fallback. */
			content: "\f111";
			background-color: transparent;
			-webkit-mask-image: none;
			mask-image: none;
			font-family: generatepress-admin, dashicons, sans-serif;
			font-size: 18px;
			line-height: 20px;
			margin-top: 0;
		}
		#adminmenu #toplevel_page_generateblocks .wp-submenu li.gb-admin-menu-group-start {
			margin-top: 8px;
		}
		#adminmenu #toplevel_page_generateblocks .wp-submenu li.wp-first-item.gb-admin-menu-group-start {
			margin-top: 0;
		}
		#adminmenu #toplevel_page_generateblocks .wp-submenu li.gb-admin-menu-group-start::before {
			display: block;
			padding: 8px 12px 4px;
			color: rgba(240, 246, 252, 0.58);
			font-size: 11px;
			font-weight: 600;
			line-height: 1.4;
			letter-spacing: 0.04em;
			text-transform: uppercase;
		}
		/* The "Light" admin color scheme is the one core scheme with a light submenu background — the near-white label above would be invisible. */
		body.admin-color-light #adminmenu #toplevel_page_generateblocks .wp-submenu li.gb-admin-menu-group-start::before {
			color: rgba(30, 30, 30, 0.58);
		}
		#adminmenu #toplevel_page_generateblocks .wp-submenu li.gb-admin-menu-group-settings::before {
			content: <?php echo self::css_content_label( __( 'Settings', 'generateblocks-pro' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON-encoded string literal. ?>;
		}
		#adminmenu #toplevel_page_generateblocks .wp-submenu li.gb-admin-menu-group-design::before {
			content: <?php echo self::css_content_label( __( 'Design', 'generateblocks-pro' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON-encoded string literal. ?>;
		}
		#adminmenu #toplevel_page_generateblocks .wp-submenu li.gb-admin-menu-group-build::before {
			content: <?php echo self::css_content_label( __( 'Build', 'generateblocks-pro' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON-encoded string literal. ?>;
		}
		</style>
		<?php
	}
}

GenerateBlocks_Pro_Design_Menu::get_instance()->init();
