<?php
/**
 * Webhook email signup integration.
 *
 * Sends signup submissions to a configured webhook URL through the
 * email-signup action.
 *
 * @package GenerateBlocksPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Webhook email signup provider.
 */
class GenerateBlocks_Pro_Form_Integration_Webhook {

	/**
	 * Register the provider with the registry.
	 */
	public static function init() {
		generateblocks_pro_register_form_integration(
			[
				'id'                         => 'webhook',
				'label'                      => __( 'Webhook', 'generateblocks-pro' ),
				'type'                       => 'email',
				'settings_fields'            => [
					[
						'key'         => 'url',
						'label'       => __( 'Webhook URL', 'generateblocks-pro' ),
						'type'        => 'url',
						'placeholder' => 'https://example.com/webhook',
						'required'    => true,
					],
				],
				'settings_validate_callback' => [ 'GenerateBlocks_Pro_Form_Action_Webhook', 'validate_signup_settings' ],
				'subscribe_callback'         => [ 'GenerateBlocks_Pro_Form_Action_Webhook', 'subscribe' ],
			]
		);
	}
}
