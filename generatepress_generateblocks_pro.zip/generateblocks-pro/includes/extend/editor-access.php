<?php
/**
 * Editor Access editor functionality.
 *
 * @package GenerateBlocks Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class GenerateBlocks_Pro_Editor_Access_Runtime
 */
class GenerateBlocks_Pro_Editor_Access_Runtime extends GenerateBlocks_Pro_Singleton {

	/**
	 * Constructor.
	 */
	public function init() {
		if ( ! generateblocks_pro_editor_access_enabled() ) {
			return;
		}

		add_filter( 'block_editor_settings_all', [ $this, 'filter_block_editor_settings' ], 20, 2 );
		add_filter( 'allowed_block_types_all', [ $this, 'filter_allowed_block_types' ], 20, 2 );
		add_action( 'enqueue_block_editor_assets', [ $this, 'enqueue_editor_assets' ], 1 );
		add_action( 'save_post_gb_access_profile', [ $this, 'invalidate_editor_access_cache' ] );
		add_action( 'delete_post', [ $this, 'invalidate_editor_access_cache_on_delete' ] );
		add_action( 'updated_post_meta', [ $this, 'invalidate_editor_access_cache_on_meta_change' ], 10, 3 );
		add_action( 'added_post_meta', [ $this, 'invalidate_editor_access_cache_on_meta_change' ], 10, 3 );
		add_action( 'deleted_post_meta', [ $this, 'invalidate_editor_access_cache_on_meta_change' ], 10, 3 );
	}

	/**
	 * Invalidate the editor access cache when an access profile is saved.
	 */
	public function invalidate_editor_access_cache() {
		GenerateBlocks_Pro_Editor_Access::invalidate_editor_access_cache();
	}

	/**
	 * Invalidate the editor access cache when a post is deleted, if it's an access profile.
	 *
	 * @param int $post_id The post ID.
	 */
	public function invalidate_editor_access_cache_on_delete( $post_id ) {
		if ( 'gb_access_profile' === get_post_type( $post_id ) ) {
			GenerateBlocks_Pro_Editor_Access::invalidate_editor_access_cache();
		}
	}

	/**
	 * Invalidate the editor access cache when profile meta changes directly.
	 *
	 * Covers raw update_post_meta()/delete_post_meta() writes (WP-CLI,
	 * third-party code) that bypass the REST and save_post paths.
	 *
	 * @param int|array $meta_id   The meta ID, or meta IDs on delete.
	 * @param int       $object_id The post ID.
	 * @param string    $meta_key  The meta key.
	 */
	public function invalidate_editor_access_cache_on_meta_change( $meta_id, $object_id, $meta_key ) {
		if ( '_gb_access_profile' === $meta_key ) {
			GenerateBlocks_Pro_Editor_Access::invalidate_editor_access_cache();
		}
	}

	/**
	 * Get all currently registered block types that support Editor Access.
	 *
	 * @param string $mode The access mode.
	 * @return array
	 */
	private function get_supported_block_types( $mode = 'contentOnly' ) {
		return generateblocks_pro_get_editor_access_supported_block_types( $mode );
	}

	/**
	 * Get the deterministic role order used for multi-role users.
	 *
	 * @return array Role slugs in resolution order.
	 */
	private function get_role_order() {
		$roles = function_exists( 'wp_roles' ) && wp_roles()
			? array_keys( wp_roles()->get_names() )
			: [];

		/**
		 * Filter the deterministic role order used to select one access profile.
		 *
		 * @param array $roles Role slugs in resolution order.
		 */
		$roles = apply_filters( 'generateblocks_editor_access_role_order', $roles );

		return is_array( $roles ) ? array_values( array_filter( array_map( 'sanitize_key', $roles ) ) ) : [];
	}

	/**
	 * Sort current user roles by the deterministic role order.
	 *
	 * @param array $current_roles Current user role slugs.
	 * @return array
	 */
	private function get_ordered_current_roles( $current_roles ) {
		$current_roles = array_values( array_filter( array_map( 'sanitize_key', (array) $current_roles ) ) );
		$role_order    = $this->get_role_order();
		$ordered       = [];

		foreach ( $role_order as $role ) {
			if ( in_array( $role, $current_roles, true ) ) {
				$ordered[] = $role;
			}
		}

		foreach ( $current_roles as $role ) {
			if ( ! in_array( $role, $ordered, true ) ) {
				$ordered[] = $role;
			}
		}

		return $ordered;
	}

	/**
	 * Get the current editor post type.
	 *
	 * @param WP_Block_Editor_Context|null $block_editor_context Current editor context.
	 * @return string
	 */
	private function get_current_post_type( $block_editor_context = null ) {
		if (
			is_object( $block_editor_context ) &&
			isset( $block_editor_context->post ) &&
			is_object( $block_editor_context->post ) &&
			! empty( $block_editor_context->post->post_type )
		) {
			return sanitize_key( $block_editor_context->post->post_type );
		}

		if (
			is_object( $block_editor_context ) &&
			! empty( $block_editor_context->post_type )
		) {
			return sanitize_key( $block_editor_context->post_type );
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		if ( $screen && ! empty( $screen->post_type ) ) {
			return sanitize_key( $screen->post_type );
		}

		return '';
	}

	/**
	 * Get the match score for a profile in the current context.
	 *
	 * Lower scores win. Empty role scope matches users who cannot manage Editor
	 * Access. Manager-capable users are bypassed unless explicitly targeted.
	 * Post-type-specific profiles win over broad profiles when the role score is
	 * tied.
	 *
	 * @param array  $profile                   Access profile data.
	 * @param array  $ordered_current_roles     Current user roles in deterministic order.
	 * @param string $current_post_type         Current post type.
	 * @param bool   $can_manage_editor_access  Whether the user can manage Editor Access.
	 * @return array|null
	 */
	private function get_profile_match_score( $profile, $ordered_current_roles, $current_post_type, $can_manage_editor_access ) {
		$scope      = isset( $profile['scope'] ) && is_array( $profile['scope'] ) ? $profile['scope'] : [];
		$roles      = ! empty( $scope['roles'] ) && is_array( $scope['roles'] ) ? $scope['roles'] : [];
		$post_types = ! empty( $scope['postTypes'] ) && is_array( $scope['postTypes'] ) ? $scope['postTypes'] : [];

		// Stored scope roles preserve case (sanitize_text_field) while current
		// user roles are sanitize_key'd; normalize so custom role slugs with
		// uppercase characters still match instead of silently never applying.
		$roles = array_values( array_filter( array_map( 'sanitize_key', $roles ) ) );

		// An empty postTypes scope deliberately matches every post type, including
		// private block-editor post types such as wp_block. Exempting private post
		// types would let a restricted user open the synced pattern editor with the
		// full unrestricted toolset and insert that pattern back into gated posts.
		// Profiles that need a narrower scope pick post types explicitly — the
		// dashboard picker lists private block-editor post types for that reason.
		if ( ! empty( $post_types ) && ( empty( $current_post_type ) || ! in_array( $current_post_type, $post_types, true ) ) ) {
			return null;
		}

		$role_score = null;

		if ( empty( $roles ) ) {
			if ( $can_manage_editor_access ) {
				return null;
			}

			$role_score = count( $ordered_current_roles );
		} else {
			foreach ( $ordered_current_roles as $index => $role ) {
				if ( in_array( $role, $roles, true ) ) {
					$role_score = $index;
					break;
				}
			}
		}

		if ( null === $role_score ) {
			return null;
		}

		return [
			'role'      => $role_score,
			'post_type' => empty( $post_types ) ? PHP_INT_MAX : count( $post_types ),
		];
	}

	/**
	 * Get all published access profiles.
	 *
	 * @return array
	 */
	private function get_published_access_profiles() {
		$cached = get_transient( 'gb_access_profile_data' );

		if ( false !== $cached && is_array( $cached ) ) {
			return $cached;
		}

		$posts = get_posts(
			[
				'post_type'      => 'gb_access_profile',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => [
					'title' => 'ASC',
					'ID'    => 'ASC',
				],
			]
		);

		$profiles = [];

		foreach ( $posts as $post ) {
			$profiles[] = [
				'id'      => $post->ID,
				'title'   => $post->post_title,
				'status'  => $post->post_status,
				'profile' => GenerateBlocks_Pro_Editor_Access::sanitize_profile( get_post_meta( $post->ID, '_gb_access_profile', true ) ),
			];
		}

		set_transient( 'gb_access_profile_data', $profiles, HOUR_IN_SECONDS );

		return $profiles;
	}

	/**
	 * Resolve the active access profile for this editor context.
	 *
	 * @param array  $profiles                  Published access profiles.
	 * @param array  $ordered_current_roles     Current user roles in deterministic order.
	 * @param string $current_post_type         Current post type.
	 * @param bool   $can_manage_editor_access  Whether the user can manage Editor Access.
	 * @return array|null
	 */
	private function resolve_active_access_profile( $profiles, $ordered_current_roles, $current_post_type, $can_manage_editor_access ) {
		$active = null;

		foreach ( $profiles as $index => $profile_data ) {
			$score = $this->get_profile_match_score(
				$profile_data['profile'] ?? [],
				$ordered_current_roles,
				$current_post_type,
				$can_manage_editor_access
			);

			if ( null === $score ) {
				continue;
			}

			if (
				null === $active ||
				$score['role'] < $active['score']['role'] ||
				(
					$score['role'] === $active['score']['role'] &&
					$score['post_type'] < $active['score']['post_type']
				) ||
				(
					$score['role'] === $active['score']['role'] &&
					$score['post_type'] === $active['score']['post_type'] &&
					$index < $active['index']
				)
			) {
				$active = [
					'score'   => $score,
					'index'   => $index,
					'profile' => $profile_data,
				];
			}
		}

		return $active ? $active['profile'] : null;
	}

	/**
	 * Resolve the active access profile for a post type.
	 *
	 * @param string $current_post_type Current editor post type.
	 * @return array|null
	 */
	private function get_active_access_profile_for_post_type( $current_post_type ) {
		if ( empty( $current_post_type ) ) {
			return null;
		}

		$current_user             = wp_get_current_user();
		$current_user_roles       = is_array( $current_user->roles ) ? $current_user->roles : [];
		$ordered_current_roles    = $this->get_ordered_current_roles( $current_user_roles );
		$can_manage_editor_access = GenerateBlocks_Pro_Editor_Access::current_user_can_use_editor_access( 'manage' );

		return $this->resolve_active_access_profile(
			$this->get_published_access_profiles(),
			$ordered_current_roles,
			$current_post_type,
			$can_manage_editor_access
		);
	}

	/**
	 * Whether an active profile has any restriction to apply.
	 *
	 * @param array|null $active_access_profile Active access profile data.
	 * @return bool
	 */
	private function has_restricting_access_profile( $active_access_profile ) {
		if ( ! $active_access_profile ) {
			return false;
		}

		$profile = $active_access_profile['profile'] ?? [];

		if ( ! empty( $profile['fallbackMode'] ) ) {
			return true;
		}

		$inserter_policy = GenerateBlocks_Pro_Editor_Access::sanitize_inserter_policy( $profile['inserter'] ?? [] );

		if ( 'all' !== $inserter_policy['mode'] ) {
			return true;
		}

		foreach ( $profile['rules'] ?? [] as $rule ) {
			if ( ! empty( $rule['mode'] ) && 'unchanged' !== $rule['mode'] ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Disable Gutenberg's code editing affordances when Editor Access is active.
	 *
	 * `codeEditingEnabled` controls both the full Code editor mode and each
	 * block's "Edit as HTML" menu item in core.
	 *
	 * @param array                   $settings             Editor settings.
	 * @param WP_Block_Editor_Context $block_editor_context Current editor context.
	 * @return array
	 */
	public function filter_block_editor_settings( $settings, $block_editor_context ) {
		if ( ! is_array( $settings ) ) {
			return $settings;
		}

		// Managers are exempt from server-side enforcement, matching
		// filter_allowed_block_types(). The JS bypass toggle cannot restore
		// a server-disabled code editor, so disabling it here would lock
		// explicitly-targeted managers out of the code editor entirely.
		if ( GenerateBlocks_Pro_Editor_Access::current_user_can_use_editor_access( 'manage' ) ) {
			return $settings;
		}

		$current_post_type     = $this->get_current_post_type( $block_editor_context );
		$active_access_profile = $this->get_active_access_profile_for_post_type( $current_post_type );

		if ( $this->has_restricting_access_profile( $active_access_profile ) ) {
			$settings['codeEditingEnabled'] = false;
		}

		return $settings;
	}

	/**
	 * Get registered block names.
	 *
	 * @return array
	 */
	private function get_registered_block_names() {
		if ( ! class_exists( 'WP_Block_Type_Registry' ) ) {
			return [];
		}

		$block_registry = WP_Block_Type_Registry::get_instance();

		if ( ! method_exists( $block_registry, 'get_all_registered' ) ) {
			return [];
		}

		return array_keys( $block_registry->get_all_registered() );
	}

	/**
	 * Get the parent block type for an inserter entry ID.
	 *
	 * @param string $item_id Inserter entry ID.
	 * @return string
	 */
	private function get_inserter_item_parent_block_name( $item_id ) {
		if ( ! is_string( $item_id ) || '' === $item_id ) {
			return '';
		}

		if ( 0 === strpos( $item_id, 'block:' ) ) {
			return substr( $item_id, 6 );
		}

		$known_entries = GenerateBlocks_Pro_Editor_Access::get_known_inserter_entries();

		foreach ( $known_entries as $entry ) {
			if ( ( $entry['id'] ?? '' ) === $item_id ) {
				return $entry['blockName'] ?? '';
			}
		}

		return '';
	}

	/**
	 * Get parent block types allowed by an inserter policy.
	 *
	 * @param array $policy Inserter policy.
	 * @return array
	 */
	private function get_inserter_policy_allowed_block_types( $policy ) {
		$policy = GenerateBlocks_Pro_Editor_Access::sanitize_inserter_policy( $policy );

		if ( 'selected' !== $policy['mode'] ) {
			return [];
		}

		$allowed = [];

		foreach ( $policy['items'] as $item_id ) {
			$block_name = $this->get_inserter_item_parent_block_name( $item_id );

			if ( '' === $block_name || in_array( $block_name, $allowed, true ) ) {
				continue;
			}

			$allowed[] = $block_name;
		}

		$registered = $this->get_registered_block_names();

		if ( empty( $registered ) ) {
			return $allowed;
		}

		$allowed = array_values( array_intersect( $allowed, $registered ) );

		return $this->expand_allowed_block_types( $allowed );
	}

	/**
	 * Expand allowed block types to the child block types they need.
	 *
	 * Core's canInsertBlockType consults the editor-wide allow list before
	 * parent/ancestor constraints, so composite blocks (accordion, tabs, form)
	 * need their child types in the list or their own add-item flows silently
	 * fail. Children stay out of the top-level inserter through their own
	 * parent/ancestor metadata; the companion map covers children without it.
	 *
	 * Mirrored client-side in src/editor-access/inserter-policy.js.
	 *
	 * @param array $allowed Allowed block type names.
	 * @return array
	 */
	private function expand_allowed_block_types( $allowed ) {
		if ( empty( $allowed ) || ! class_exists( 'WP_Block_Type_Registry' ) ) {
			return $allowed;
		}

		$registered = WP_Block_Type_Registry::get_instance()->get_all_registered();
		$companions = GenerateBlocks_Pro_Editor_Access::get_companion_block_types();
		$allowed    = array_fill_keys( $allowed, true );

		do {
			$added = false;

			foreach ( array_keys( $allowed ) as $allowed_name ) {
				foreach ( $companions[ $allowed_name ] ?? [] as $companion ) {
					if ( ! isset( $allowed[ $companion ] ) && isset( $registered[ $companion ] ) ) {
						$allowed[ $companion ] = true;
						$added                 = true;
					}
				}
			}

			foreach ( $registered as $name => $block ) {
				if ( isset( $allowed[ $name ] ) ) {
					continue;
				}

				$relations = array_merge(
					is_array( $block->parent ?? null ) ? $block->parent : [],
					is_array( $block->ancestor ?? null ) ? $block->ancestor : []
				);

				foreach ( $relations as $relation ) {
					if ( isset( $allowed[ $relation ] ) ) {
						$allowed[ $name ] = true;
						$added            = true;
						break;
					}
				}
			}
		} while ( $added );

		return array_keys( $allowed );
	}

	/**
	 * Constrain inserted parent block types for the active access profile.
	 *
	 * @param bool|array              $allowed_block_types Allowed block types.
	 * @param WP_Block_Editor_Context $editor_context      Current editor context.
	 * @return bool|array
	 */
	public function filter_allowed_block_types( $allowed_block_types, $editor_context ) {
		if ( GenerateBlocks_Pro_Editor_Access::current_user_can_use_editor_access( 'manage' ) ) {
			return $allowed_block_types;
		}

		$current_post_type = $this->get_current_post_type( $editor_context );

		if ( empty( $current_post_type ) ) {
			return $allowed_block_types;
		}

		$active_access_profile = $this->get_active_access_profile_for_post_type( $current_post_type );

		if ( ! $active_access_profile ) {
			return $allowed_block_types;
		}

		$profile = $active_access_profile['profile'] ?? [];
		$policy  = GenerateBlocks_Pro_Editor_Access::sanitize_inserter_policy( $profile['inserter'] ?? [] );

		if ( 'all' === $policy['mode'] ) {
			return $allowed_block_types;
		}

		if ( false === $allowed_block_types ) {
			return false;
		}

		$allowed_by_profile = 'none' === $policy['mode']
			? []
			: $this->get_inserter_policy_allowed_block_types( $policy );

		if ( true === $allowed_block_types ) {
			return $allowed_by_profile;
		}

		if ( is_array( $allowed_block_types ) ) {
			return array_values( array_intersect( $allowed_block_types, $allowed_by_profile ) );
		}

		return $allowed_block_types;
	}

	/**
	 * Get the access profiles a managing user can preview in the editor.
	 *
	 * Returns a lightweight list (no rules or control sets); the full profile
	 * is fetched over REST when a preview starts. Drafts are included so
	 * profiles can be validated before they go live.
	 *
	 * @return array
	 */
	public function get_previewable_access_profiles() {
		if ( ! GenerateBlocks_Pro_Editor_Access::current_user_can_use_editor_access( 'manage' ) ) {
			return [];
		}

		$cached = get_transient( 'gb_access_profile_preview_data' );

		if ( false !== $cached && is_array( $cached ) ) {
			return $cached;
		}

		$posts = get_posts(
			[
				'post_type'      => 'gb_access_profile',
				'post_status'    => [ 'publish', 'draft' ],
				'posts_per_page' => -1,
				'orderby'        => [
					'title' => 'ASC',
					'ID'    => 'ASC',
				],
			]
		);

		$profiles = [];

		foreach ( $posts as $post ) {
			$profiles[] = [
				'id'     => $post->ID,
				'title'  => $post->post_title,
				'status' => $post->post_status,
			];
		}

		set_transient( 'gb_access_profile_preview_data', $profiles, HOUR_IN_SECONDS );

		return $profiles;
	}

	/**
	 * Enqueue block editor assets for Editor Access.
	 */
	public function enqueue_editor_assets() {
		$current_user              = wp_get_current_user();
		$current_user_roles        = is_array( $current_user->roles ) ? $current_user->roles : [];
		$ordered_current_roles     = $this->get_ordered_current_roles( $current_user_roles );
		$current_post_type         = $this->get_current_post_type();
		$can_manage_editor_access  = GenerateBlocks_Pro_Editor_Access::current_user_can_use_editor_access( 'manage' );

		if ( empty( $current_post_type ) ) {
			return;
		}

		$active_access_profile = $this->resolve_active_access_profile(
			$this->get_published_access_profiles(),
			$ordered_current_roles,
			$current_post_type,
			$can_manage_editor_access
		);

		$has_restricting_profile = $this->has_restricting_access_profile( $active_access_profile );
		$previewable_profiles    = $can_manage_editor_access
			? $this->get_previewable_access_profiles()
			: [];

		if ( ! $has_restricting_profile && empty( $previewable_profiles ) ) {
			return;
		}

		$profile = $has_restricting_profile
			? ( $active_access_profile['profile'] ?? [] )
			: [];

		$assets = generateblocks_pro_get_enqueue_assets( 'editor-access' );

		wp_enqueue_script(
			'generateblocks-pro-editor-access',
			GENERATEBLOCKS_PRO_DIR_URL . 'dist/editor-access.js',
			$assets['dependencies'],
			$assets['version'],
			true
		);

		wp_enqueue_style(
			'generateblocks-pro-editor-access',
			GENERATEBLOCKS_PRO_DIR_URL . 'dist/editor-access.css',
			[],
			$assets['version']
		);

		wp_localize_script(
			'generateblocks-pro-editor-access',
			'gbEditorAccessConfig',
			[
				'canManageEditorAccess'     => $can_manage_editor_access,
				'inserterEntries'           => GenerateBlocks_Pro_Editor_Access::get_known_inserter_entries(),
				'companionBlockTypes'       => GenerateBlocks_Pro_Editor_Access::get_companion_block_types(),
				'previewableProfiles'       => $previewable_profiles,
				'supportedBlockTypesByMode' => [
					'contentOnly' => $this->get_supported_block_types( 'contentOnly' ),
					'readOnly'    => $this->get_supported_block_types( 'readOnly' ),
					'custom'      => $this->get_supported_block_types( 'custom' ),
				],
			]
		);

		if ( ! $has_restricting_profile ) {
			return;
		}

		$control_sets = class_exists( 'GenerateBlocks_Pro_Editor_Access_REST' )
			? GenerateBlocks_Pro_Editor_Access_REST::resolve_profile_control_sets( $profile )
			: [];

		wp_add_inline_script(
			'generateblocks-pro-editor-access',
			'window.gbActiveEditorAccessProfile = ' . wp_json_encode(
				[
					'id'          => $active_access_profile['id'],
					'title'       => [
						'rendered' => $active_access_profile['title'],
					],
					'status'      => $active_access_profile['status'],
					'profile'     => $profile,
					'controlSets' => $control_sets,
				]
			) . ';',
			'before'
		);
	}
}

GenerateBlocks_Pro_Editor_Access_Runtime::get_instance()->init();
