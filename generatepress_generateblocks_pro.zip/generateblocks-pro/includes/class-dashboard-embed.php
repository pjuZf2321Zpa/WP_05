<?php
/**
 * Presentation adapter for the real dashboard pages inside editor modals.
 *
 * Embed parameters never grant access: the normal page and REST capabilities
 * still apply. No assets or document changes run outside these admin screens.
 *
 * @package GenerateBlocks
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Read presentation context, including core's programmatic iframe navigation.
 *
 * Core's trash/duplicate actions omit our query arguments. Older browsers may
 * also omit Sec-Fetch-Dest, so the client confirms it is framed before applying
 * inherited context. A new tab stays a normal admin page. Neither source grants
 * permission to a page or record.
 *
 * @return array Embed type and dashboard return URL.
 */
function generateblocks_pro_dashboard_embed_context() {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Presentation only.
	$params = wp_unslash( $_GET );
	if ( ! isset( $params['gb_dashboard_embed'] ) && in_array( $_SERVER['HTTP_SEC_FETCH_DEST'] ?? '', [ '', 'iframe' ], true ) ) {
		$referer = wp_get_raw_referer();
		if ( is_string( $referer ) && 0 === strpos( $referer, admin_url() ) ) {
			wp_parse_str( wp_parse_url( $referer, PHP_URL_QUERY ) ?? '', $params );
		}
	}

	return [
		'type'       => isset( $params['gb_dashboard_embed'] ) && is_string( $params['gb_dashboard_embed'] ) ? sanitize_key( $params['gb_dashboard_embed'] ) : '',
		'return_url' => isset( $params['gb_dashboard_return'] ) && is_string( $params['gb_dashboard_return'] ) ? esc_url_raw( $params['gb_dashboard_return'] ) : '',
	];
}

/**
 * Keep core post-list redirects inside their embedded dashboard.
 *
 * @param string $url  The normal dashboard destination.
 * @param string $type Dashboard type.
 * @return string Dashboard URL.
 */
function generateblocks_pro_dashboard_embed_redirect( $url, $type ) {
	$context = generateblocks_pro_dashboard_embed_context();
	if ( $context['type'] !== $type ) {
		return $url;
	}

	$return = $context['return_url'];
	if ( 0 === strpos( $return, admin_url() ) && wp_parse_url( $return, PHP_URL_PATH ) === wp_parse_url( $url, PHP_URL_PATH ) ) {
		wp_parse_str( wp_parse_url( $return, PHP_URL_QUERY ) ?? '', $return_params );
		wp_parse_str( wp_parse_url( $url, PHP_URL_QUERY ) ?? '', $expected_params );
		if ( ( $return_params['page'] ?? '' ) === ( $expected_params['page'] ?? '' ) ) {
			$url = $return;
		}
	}
	return add_query_arg( 'gb_dashboard_embed', $type, $url );
}

add_action(
	'current_screen',
	function ( $screen ) {
		$context = generateblocks_pro_dashboard_embed_context();
		$type = $context['type'];
		$screens = [
			'conditions' => [ 'generateblocks_page_generateblocks-conditions', '' ],
			'overlays'   => [ 'generateblocks_page_generateblocks-overlay-panels', 'gblocks_overlay' ],
			'forms'      => [ 'generateblocks_page_generateblocks-forms', 'gblocks_form' ],
		];

		if ( ! isset( $screens[ $type ] ) ) {
			return;
		}

		[ $dashboard, $post_type ] = $screens[ $type ];
		$is_editor = $post_type && 'post' === $screen->base && $post_type === $screen->post_type;
		if ( $screen->id !== $dashboard && ! $is_editor ) {
			return;
		}

		add_action(
			'admin_enqueue_scripts',
			static function () use ( $type, $is_editor, $post_type, $context ) {
				$assets = generateblocks_pro_get_enqueue_assets( 'dashboard-embed' );
				wp_enqueue_script(
					'generateblocks-pro-dashboard-embed',
					GENERATEBLOCKS_PRO_DIR_URL . 'dist/dashboard-embed.js',
					$assets['dependencies'],
					$assets['version'],
					true
				);
				wp_enqueue_style(
					'generateblocks-pro-dashboard-embed',
					GENERATEBLOCKS_PRO_DIR_URL . 'dist/dashboard-embed.css',
					[],
					$assets['version']
				);
				wp_localize_script(
					'generateblocks-pro-dashboard-embed',
					'gbDashboardEmbedSettings',
					[
						'type'     => $type,
						'postType' => $is_editor ? $post_type : '',
						'returnUrl' => $context['return_url'],
					]
				);
				wp_set_script_translations( 'generateblocks-pro-dashboard-embed', 'generateblocks-pro' );
			},
			1
		);
	}
);
